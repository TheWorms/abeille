"""Addon « agenda » — client CalDAV (lot M).

Migré du noyau vers un backend autonome. Découverte des calendriers (principal
→ calendar-home → collections), lecture des événements (REPORT calendar-query
avec repli sans expand), et création (PUT iCal). Auth par mot de passe
d'application (jamais exposé).

Cache : calendriers 10 min, événements 5 min, via ``sdk.cache``. Un stamp dans
``sdk.data_dir`` invalide les événements de TOUS les workers après une
création (l'événement ajouté apparaît immédiatement).
"""
import hashlib
import os
import re
import secrets
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from urllib.parse import urljoin

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

_NS = {"d": "DAV:", "c": "urn:ietf:params:xml:ns:caldav"}


def _stamp_file(sdk):
    return os.path.join(sdk.data_dir, ".stamp")


def _stamp(sdk):
    try:
        return os.path.getmtime(_stamp_file(sdk))
    except OSError:
        return 0.0


def _touch(sdk):
    try:
        with open(_stamp_file(sdk), "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


def _dav(sdk, url, method, user, pw, body, depth="0"):
    r = sdk.requests.request(method, url, data=body.encode(), auth=(user, pw),
                             headers={"Depth": depth,
                                      "Content-Type": "application/xml; charset=utf-8"},
                             timeout=8)
    if r.status_code == 401:
        raise RuntimeError("identifiants refusés (401) — utilise un mot de passe d'application")
    if r.status_code not in (200, 207):
        raise RuntimeError(f"HTTP {r.status_code}")
    return ET.fromstring(r.content)


def _calendars(sdk, base, user, pw):
    """Découverte des calendriers — cache 10 min (3 requêtes DAV sinon)."""
    base = base.rstrip("/")
    key = "cals:" + hashlib.sha256(f"{base}|{user}".encode()).hexdigest()[:16]
    hit = sdk.cache_get(key, 600)
    if hit is not None:
        return hit
    root = _dav(sdk, base + "/", "PROPFIND", user, pw,
                '<?xml version="1.0"?><d:propfind xmlns:d="DAV:">'
                '<d:prop><d:current-user-principal/></d:prop></d:propfind>')
    el = root.find(".//d:current-user-principal/d:href", _NS)
    if el is None or not el.text:
        raise RuntimeError("principal introuvable")
    principal = urljoin(base + "/", el.text)
    root = _dav(sdk, principal, "PROPFIND", user, pw,
                '<?xml version="1.0"?><d:propfind xmlns:d="DAV:" '
                'xmlns:c="urn:ietf:params:xml:ns:caldav">'
                '<d:prop><c:calendar-home-set/></d:prop></d:propfind>')
    el = root.find(".//c:calendar-home-set/d:href", _NS)
    if el is None or not el.text:
        raise RuntimeError("calendar-home introuvable")
    home = urljoin(base + "/", el.text)
    root = _dav(sdk, home, "PROPFIND", user, pw,
                '<?xml version="1.0"?><d:propfind xmlns:d="DAV:" '
                'xmlns:c="urn:ietf:params:xml:ns:caldav">'
                '<d:prop><d:displayname/><d:resourcetype/></d:prop></d:propfind>',
                depth="1")
    cals = []
    for resp in root.findall("d:response", _NS):
        if resp.find(".//d:resourcetype/c:calendar", _NS) is None:
            continue
        href = resp.find("d:href", _NS)
        name = resp.find(".//d:displayname", _NS)
        if href is not None and href.text:
            cals.append({"href": urljoin(base + "/", href.text),
                         "name": (name.text if name is not None else "") or "Calendrier"})
    return sdk.cache_set(key, cals)


def _ics_dt(val, params):
    val = val.strip()
    if re.fullmatch(r"\d{8}", val):
        d = datetime.strptime(val, "%Y%m%d")
        return d.astimezone(), True
    if val.endswith("Z"):
        return datetime.strptime(val, "%Y%m%dT%H%M%SZ").replace(
            tzinfo=timezone.utc).astimezone(), False
    dt = datetime.strptime(val[:15], "%Y%m%dT%H%M%S")
    tzid = params.get("TZID")
    if tzid and ZoneInfo:
        try:
            return dt.replace(tzinfo=ZoneInfo(tzid)).astimezone(), False
        except Exception:
            pass
    return dt.astimezone(), False


def _ics_events(text):
    lines, out = [], []
    for raw in text.splitlines():
        if raw[:1] in (" ", "\t") and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw)
    ev = None
    in_alarm = False
    for ln in lines:
        u = ln.strip()
        if u == "BEGIN:VEVENT":
            ev = {}
        elif u == "END:VEVENT":
            if ev and "start" in ev:
                out.append(ev)
            ev = None
        elif u == "BEGIN:VALARM":
            in_alarm = True
        elif u == "END:VALARM":
            in_alarm = False
        elif ev is not None and in_alarm:
            if u.upper().startswith("TRIGGER"):
                ev["alarm"] = u.split(":", 1)[1] if ":" in u else ""
        elif ev is not None and ":" in u:
            head, val = u.split(":", 1)
            parts = head.split(";")
            key = parts[0].upper()
            params = dict(p.split("=", 1) for p in parts[1:] if "=" in p)
            try:
                if key == "DTSTART":
                    ev["start"], ev["all_day"] = _ics_dt(val, params)
                elif key == "DTEND":
                    ev["end"], _ = _ics_dt(val, params)
            except ValueError:
                continue
            if key == "SUMMARY":
                ev["title"] = val.replace("\\,", ",").replace("\\n", " ")
            elif key == "LOCATION":
                ev["location"] = val.replace("\\,", ",")
            elif key == "DESCRIPTION":
                ev["description"] = (val.replace("\\,", ",")
                                        .replace("\\n", "\n").replace("\\N", "\n"))
            elif key == "UID":
                ev["uid"] = val
            elif key == "ATTENDEE":
                who = params.get("CN") or val.replace("mailto:", "")
                ev.setdefault("attendees", []).append(who)
    return out


def _events(sdk, cfg, days=7):
    base = (cfg.get("url") or "https://sync.infomaniak.com").strip()
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not (user and pw):
        return {"ok": False, "reason": "e-mail / mot de passe d'application manquants"}
    key = "ev:" + hashlib.sha256(f"{base}|{user}|{days}".encode()).hexdigest()[:16]
    hit = sdk.cache_get(key, 300)
    if hit is not None and hit[0] > _stamp(sdk):
        return hit[1]
    now = datetime.now(timezone.utc)
    start = now.strftime("%Y%m%dT000000Z")
    end = (now + timedelta(days=days)).strftime("%Y%m%dT235959Z")
    exp = '<c:expand start="%s" end="%s"/>' % (start, end)
    body = ('<?xml version="1.0"?><c:calendar-query xmlns:d="DAV:" '
            'xmlns:c="urn:ietf:params:xml:ns:caldav">'
            '<d:prop><c:calendar-data>' + exp + '</c:calendar-data></d:prop>'
            '<c:filter><c:comp-filter name="VCALENDAR"><c:comp-filter name="VEVENT">'
            '<c:time-range start="%s" end="%s"/></c:comp-filter></c:comp-filter></c:filter>'
            '</c:calendar-query>' % (start, end))
    try:
        cals = _calendars(sdk, base, user, pw)
        events = []
        for cal in cals[:6]:
            try:
                root = _dav(sdk, cal["href"], "REPORT", user, pw, body, depth="1")
            except RuntimeError:
                root = _dav(sdk, cal["href"], "REPORT", user, pw, body.replace(exp, ""), depth="1")
            for cd in root.findall(".//c:calendar-data", _NS):
                if not cd.text:
                    continue
                for ev in _ics_events(cd.text):
                    ev["calendar"] = cal["name"]
                    events.append(ev)
        seen, uniq = set(), []
        for ev in sorted(events, key=lambda e: e["start"]):
            k = (ev.get("title"), ev["start"].isoformat())
            if k in seen:
                continue
            seen.add(k)
            uniq.append({"title": ev.get("title") or "(sans titre)",
                         "start": ev["start"].isoformat(),
                         "end": ev["end"].isoformat() if ev.get("end") else None,
                         "all_day": bool(ev.get("all_day")),
                         "location": ev.get("location") or "",
                         "description": ev.get("description") or "",
                         "attendees": ev.get("attendees") or [],
                         "alarm": ev.get("alarm") or "",
                         "uid": ev.get("uid") or "",
                         "calendar": ev.get("calendar") or ""})
        res = {"ok": True, "events": uniq, "calendars": [c2["name"] for c2 in cals]}
        sdk.cache_set(key, (time.time(), res))
        return res
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except Exception as e:
        return {"ok": False, "reason": type(e).__name__}


def _ics_escape(t):
    return (t or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def _create(sdk, cfg, title, start_iso, minutes, location="", description="",
            attendees=None, alarm_min=None, rrule=None, calendar=None):
    base = (cfg.get("url") or "https://sync.infomaniak.com").strip()
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    want = (calendar or cfg.get("calendar") or "").strip()
    if not (user and pw):
        raise RuntimeError("identifiants manquants")
    cals = _calendars(sdk, base, user, pw)
    if not cals:
        raise RuntimeError("aucun calendrier")
    if want:
        cal = next((c for c in cals if c["name"].strip().lower() == want.lower()), None)
        if not cal:
            raise RuntimeError("calendrier « %s » introuvable. Disponibles : %s"
                               % (want, ", ".join(c["name"] for c in cals)))
    elif len(cals) > 1:
        raise RuntimeError("plusieurs calendriers : précise lequel dans ⚙ (%s)"
                           % ", ".join(c["name"] for c in cals))
    else:
        cal = cals[0]
    try:
        start = datetime.fromisoformat(start_iso)
    except ValueError:
        raise RuntimeError("date invalide")
    if start.tzinfo is None:
        start = start.astimezone()
    end = start + timedelta(minutes=max(5, int(minutes or 60)))
    uid = f"{secrets.token_hex(12)}@panda"
    fmt = "%Y%m%dT%H%M%SZ"
    parts = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//panda//FR",
             "BEGIN:VEVENT", f"UID:{uid}",
             "DTSTAMP:" + datetime.now(timezone.utc).strftime(fmt),
             "DTSTART:" + start.astimezone(timezone.utc).strftime(fmt),
             "DTEND:" + end.astimezone(timezone.utc).strftime(fmt),
             f"SUMMARY:{_ics_escape(title)}"]
    if rrule:
        parts.append("RRULE:" + rrule)
    if location:
        parts.append(f"LOCATION:{_ics_escape(location)}")
    if description:
        parts.append(f"DESCRIPTION:{_ics_escape(description)}")
    for mail in (attendees or []):
        mail = mail.strip()
        if mail:
            parts.append("ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:mailto:" + mail)
    if alarm_min:
        parts += ["BEGIN:VALARM", "ACTION:DISPLAY",
                  f"DESCRIPTION:{_ics_escape(title)}",
                  f"TRIGGER:-PT{int(alarm_min)}M", "END:VALARM"]
    parts += ["END:VEVENT", "END:VCALENDAR", ""]
    ics = "\r\n".join(parts)
    href = cal["href"].rstrip("/") + f"/{uid}.ics"
    r = sdk.requests.put(href, data=ics.encode("utf-8"), auth=(user, pw),
                         headers={"Content-Type": "text/calendar; charset=utf-8",
                                  "If-None-Match": "*"}, timeout=12)
    if r.status_code == 401:
        raise RuntimeError("identifiants refusés (401)")
    if r.status_code not in (200, 201, 204):
        raise RuntimeError(f"HTTP {r.status_code}")
    _touch(sdk)   # invalide les événements en cache (tous workers)
    return {"calendar": cal["name"], "uid": uid}


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("agenda", __name__)

    @bp.route("/events")
    def events():
        try:
            days = max(1, min(45, int(request.args.get("days", 7))))
        except ValueError:
            days = 7
        return jsonify(_events(sdk, sdk.config(), days))

    @bp.route("/calendars")
    def calendars():
        cfg = sdk.config()
        base = (cfg.get("url") or "https://sync.infomaniak.com").strip()
        user, pw = (cfg.get("user") or "").strip(), (cfg.get("pass") or "").strip()
        if not (user and pw):
            return jsonify({"ok": False, "reason": "identifiants manquants"})
        try:
            cals = _calendars(sdk, base, user, pw)
            return jsonify({"ok": True, "calendars": [c["name"] for c in cals]})
        except (RuntimeError, sdk.requests.exceptions.RequestException) as e:
            return jsonify({"ok": False, "reason": str(e) or type(e).__name__})

    @bp.route("/add", methods=["POST"])
    def add():
        j = request.get_json(force=True, silent=True) or {}
        title = (j.get("title") or "").strip()[:120]
        start = (j.get("start") or "").strip()
        if not title or not start:
            return jsonify({"ok": False, "reason": "titre ou date manquants"}), 400
        cfg = sdk.config()
        try:
            atts = j.get("attendees") or []
            if isinstance(atts, str):
                atts = [x for x in re.split(r"[,;\s]+", atts) if x]
            freqs = {"weekly": "WEEKLY", "monthly": "MONTHLY", "yearly": "YEARLY", "daily": "DAILY"}
            rr = None
            freq = (j.get("repeat") or "").strip().lower()
            if freq in freqs:
                rr = "FREQ=" + freqs[freq]
                until = (j.get("repeat_until") or "").strip()
                if until:
                    try:
                        u = datetime.fromisoformat(until)
                        if u.tzinfo is None:
                            u = u.replace(hour=23, minute=59).astimezone()
                        rr += ";UNTIL=" + u.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                    except ValueError:
                        pass
            res = _create(sdk, cfg, title, start, j.get("minutes", 60),
                          (j.get("location") or "").strip()[:80],
                          (j.get("description") or "").strip()[:500],
                          atts[:10], j.get("alarm_min"),
                          rrule=rr, calendar=(j.get("calendar") or "").strip())
            return jsonify({"ok": True, **res})
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": type(e).__name__})

    return bp


def test(sdk, cfg):
    base = (cfg.get("url") or "https://sync.infomaniak.com").strip()
    user, pw = (cfg.get("user") or "").strip(), (cfg.get("pass") or "").strip()
    if not (user and pw):
        return False, "e-mail / mot de passe d'application manquants"
    try:
        cals = [x["name"] for x in _calendars(sdk, base, user, pw)]
        return True, f"CalDAV \u2713 \u2014 {len(cals)} calendrier(s) : " + ", ".join(cals)
    except Exception as e:
        return False, f"CalDAV \u2717 ({e})"
