/* Agenda — interface embarquée (contrat Phase 3, crash-test n°2).
   Portage intégral : vue liste/semaine/mois, fiches événement, formulaire
   de création CalDAV, volet ⚙ calendriers (couleurs + visibilité) et
   notifications d'événements imminents (hook background + sdk.notify).
   Préférences calendriers : sdk.store (reprise one-shot de l'ancien
   state.agCals à la première exécution). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.agenda = (function () {
  let S = null, root = null, tile = null;
  let mode = 'list', extra = false, data = null;
  let cals = null, calsLoaded = false;
  let bgTimer = null, bgSdk = null;

  const PALETTE = ['#2dd4bf', '#f0b429', '#7aa2f7', '#c98af0', '#e05252', '#5fd68a', '#f08a5d', '#8ab4f8'];
  const CSS = "  .agweek{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}\n  .agcol{background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:7px 6px;min-height:230px}\n  .agcol.today{border-color:var(--accent);background:var(--accent-tint)}\n  .agch{text-align:center;font-size:10.5px;color:var(--dim);text-transform:capitalize;margin-bottom:2px}\n  .agcd{text-align:center;font-size:15px;font-weight:700;margin-bottom:7px}\n  .agcol.today .agcd{color:var(--accent)}\n  .agev{background:var(--bg);\n        background:color-mix(in srgb, var(--evc,#2dd4bf) 20%, var(--tile));\n        border:1px solid color-mix(in srgb, var(--evc,#2dd4bf) 45%, transparent);\n        border-left:3px solid var(--evc,var(--accent));border-radius:6px;padding:4px 6px;margin-bottom:5px}\n\n  .agevh{font-size:9.5px;color:var(--dim);font-variant-numeric:tabular-nums}\n  .agevt{font-size:11px;font-weight:600;line-height:1.25;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n  .agform{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:7px;margin-bottom:12px}\n  .agform input,.agform select{padding:11px 12px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:14px}\n  .agform button{padding:11px 20px;border-radius:10px;border:none;background:var(--accent);color:#fff;font-weight:600;font-size:14px;cursor:pointer}\n  .agform button:disabled{opacity:.5}\n  .agmonth{display:grid;grid-template-columns:repeat(7,1fr);gap:3px}\n  .agmh{text-align:center;font-size:10px;color:var(--faint);text-transform:uppercase;letter-spacing:.4px;padding-bottom:2px}\n  .agmc{background:var(--tile);border:1px solid var(--border-soft);border-radius:7px;padding:3px 4px;min-height:58px;cursor:pointer;overflow:hidden}\n  .agmc.out{opacity:.35}\n  .agmc.we{background:color-mix(in srgb, var(--faint) 12%, var(--tile))}\n  .agmc.ferie{background:color-mix(in srgb, var(--bad) 10%, var(--tile))}\n  .agmc.ferie .agmn{color:var(--bad)}\n  .agmc.today{border-color:var(--accent);background:var(--accent-tint)}\n  .agcol.we{background:color-mix(in srgb, var(--faint) 12%, var(--tile))}\n  .agcol.ferie{background:color-mix(in srgb, var(--bad) 10%, var(--tile))}\n  .agcol.ferie .agcd{color:var(--bad)}\n  .agmc:active{border-color:var(--accent)}\n  .agmn{font-size:10px;font-weight:700;margin-bottom:1px;line-height:1.1}\n  .agmp{font-size:8.5px;line-height:1.35;background:var(--bg);\n        background:color-mix(in srgb, var(--evc,#2dd4bf) 24%, var(--tile));\n        border-left:2px solid var(--evc,var(--accent));\n        border-radius:3px;padding:0 3px;margin-bottom:1.5px;\n        white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n\n  .agmore{font-size:8.5px;color:var(--accent);font-weight:600;padding-left:2px}\n  .agform{grid-template-columns:2fr 1fr 1fr 1fr auto}\n  .agform2{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-bottom:12px}\n  .agform2 input,.agform2 select{padding:10px 12px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:13.5px}\n  .agmore-btn{font-size:11.5px;color:var(--accent);cursor:pointer;margin:-6px 0 10px;display:inline-block}\n  .evsheet{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9998;display:flex;align-items:center;justify-content:center}\n  .evbox{background:var(--panel,#1b1f24);border:1px solid var(--border-soft);border-radius:14px;padding:18px;width:460px;max-height:80vh;overflow:auto}\n  .evtitle{font-size:17px;font-weight:700;margin-bottom:4px}\n  .evwhen{font-size:12.5px;color:var(--accent);margin-bottom:12px}\n  .evrow{display:flex;gap:9px;font-size:13px;padding:7px 0;border-top:1px solid var(--border-soft)}\n  .evrow .k{color:var(--dim);min-width:92px;flex:none}\n  .evdesc{white-space:pre-wrap;line-height:1.45}\n  .agform{grid-template-columns:2fr 1fr 1fr 1fr auto}\n  .agform3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-bottom:12px}\n  .agform3 input,.agform3 select{padding:10px 12px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:13.5px}\n  .agcals{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px;align-items:center}\n  .agchip{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:20px;\n    background:var(--tile);border:1px solid var(--border-soft);font-size:12px;font-weight:600;\n    color:var(--text);cursor:pointer;user-select:none;transition:opacity .12s,border-color .12s}\n  .agchip.off{opacity:.4;text-decoration:line-through}\n  .agdot{width:9px;height:9px;border-radius:50%;flex:none}\n  .calrow{display:grid;grid-template-columns:1fr 44px 52px;align-items:center;gap:10px;\n          padding:9px 0;border-bottom:1px solid var(--border-soft)}\n  .calrow:last-child{border-bottom:none}\n  .calname{font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .calcolor{width:40px;height:30px;padding:0;border:1px solid var(--border-soft);border-radius:7px;background:none;cursor:pointer;justify-self:center}\n  .calrow .sw{justify-self:end}\n  .dayopt{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:10px;margin-bottom:6px;cursor:pointer;\n          background:var(--tile);border:1px solid var(--border-soft);border-left:4px solid var(--evc,var(--accent))}\n  .dayopt:active{border-color:var(--evc,var(--accent))}\n  .daytime{background:var(--bg);background:color-mix(in srgb, var(--evc,#2dd4bf) 30%, var(--tile));\n           border:1px solid color-mix(in srgb, var(--evc,#2dd4bf) 55%, transparent);\n           border-radius:7px;padding:4px 8px;font-size:11.5px;font-weight:700;min-width:66px;text-align:center;flex:none}\n  .daytitle{font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .daycal{margin-left:auto;font-size:10px;color:var(--faint);flex:none}\n  .agcal-chip{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;padding:5px 10px;border-radius:8px;\n              border:1px solid var(--border-soft);background:var(--tile);cursor:pointer;user-select:none}\n  .agcal-chip.off{opacity:.4}\n  .agcal-chip i{width:10px;height:10px;border-radius:3px;display:inline-block;flex:none}\n  .agcal-chip input[type=color]{width:20px;height:20px;padding:0;border:none;background:none;cursor:pointer}\n  .agday{margin-bottom:10px}\n  .agdh{font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px}\n  .agdh b{color:var(--accent)}\n  .agrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);\n         border-radius:10px;padding:7px 12px;margin-bottom:6px}\n  .agrow .agt{background:var(--bg);\n        background:color-mix(in srgb, var(--evc,#2dd4bf) 30%, var(--tile));\n        border:1px solid color-mix(in srgb, var(--evc,#2dd4bf) 55%, transparent);\n        border-radius:7px;padding:5px 9px;font-weight:700;font-size:12px;min-width:104px;text-align:center;flex:none}\n  .agt{font-size:13px;font-weight:700;font-variant-numeric:tabular-nums}\n  .agtitle{font-weight:600;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .agloc{margin-left:auto;font-size:11px;color:var(--dim);flex:none}\n  .agcal{font-size:10px;color:var(--faint);flex:none}";
  function ensureCss() {
    if (document.getElementById('agUiCss')) return;
    const st = document.createElement('style');
    st.id = 'agUiCss'; st.textContent = CSS;
    document.head.appendChild(st);
  }

  /* ---- préférences calendriers (sdk.store, migration depuis state.agCals) ---- */
  async function loadCals(sdk) {
    if (calsLoaded) return;
    const st = await sdk.store.load();
    cals = st.agCals || null;
    if (!cals && typeof window.state === 'object' && window.state && window.state.agCals) {
      cals = JSON.parse(JSON.stringify(window.state.agCals));   // reprise legacy one-shot
      await sdk.store.save({ agCals: cals });
    }
    cals = cals || {};
    calsLoaded = true;
  }
  let saveT = null;
  function saveCals(sdk) {
    clearTimeout(saveT);
    saveT = setTimeout(() => { sdk.store.save({ agCals: cals }); }, 300);
  }
  function calState(name, i) {
    if (!cals[name]) cals[name] = { color: PALETTE[i % PALETTE.length], on: true };
    return cals[name];
  }
  const calColor = n => { const c = cals[n]; return c ? c.color : 'var(--accent)'; };
  const calVisible = n => { const c = cals[n]; return !c || c.on !== false; };

  /* ---- helpers ---- */
  const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const isWE = dd => { const j = dd.getDay(); return j === 0 || j === 6; };
  const isFerie = (events, key) => (events || []).some(e => e.calendar === 'Jours fériés' && e.start.slice(0, 10) === key);
  const fmtT = e => e.all_day ? 'Journée' : new Date(e.start).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  /* ---- fiches ---- */
  function openEventSheet(e) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    const st2 = new Date(e.start), en2 = e.end ? new Date(e.end) : null;
    const when = e.all_day ? st2.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + ' · journée entière'
      : st2.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + ' · ' +
      st2.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) + (en2 ? ' – ' + en2.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '');
    const alarm = (e.alarm || '').match(/PT(\d+)([MH])/);
    const alarmTxt = alarm ? (alarm[2] === 'H' ? alarm[1] + ' h avant' : alarm[1] + ' min avant') : '';
    let b = '<div class="evbox"><div class="evtitle">' + e.title + '</div><div class="evwhen">' + when + '</div>';
    if (e.location) b += '<div class="evrow"><span class="k">📍 Lieu</span><span>' + e.location + '</span></div>';
    if (e.description) b += '<div class="evrow"><span class="k">📝 Description</span><span class="evdesc">' + e.description + '</span></div>';
    if (e.attendees && e.attendees.length) b += '<div class="evrow"><span class="k">👥 Invités</span><span>' + e.attendees.join(', ') + '</span></div>';
    if (alarmTxt) b += '<div class="evrow"><span class="k">🔔 Rappel</span><span>' + alarmTxt + '</span></div>';
    if (e.calendar) b += '<div class="evrow"><span class="k">📆 Calendrier</span><span>' + e.calendar + '</span></div>';
    b += '<button class="catclose">Fermer</button></div>';
    sh.innerHTML = b; document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('.catclose').addEventListener('click', close);
    sh.addEventListener('click', ev => { if (ev.target === sh) close(); });
  }
  function openDaySheet(day, evs) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    const dd = new Date(day + 'T12:00:00');
    sh.innerHTML = '<div class="evbox"><div class="evtitle">' + dd.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + '</div>' +
      '<div class="evwhen">' + evs.length + ' événement(s)</div>' +
      evs.map((e, i) => '<div class="dayopt" style="--evc:' + calColor(e.calendar) + '" data-i="' + i + '">' +
        '<span class="daytime">' + fmtT(e) + '</span><span class="daytitle">' + e.title + '</span>' +
        '<span class="daycal">' + (e.calendar || '') + '</span></div>').join('') +
      '<button class="catclose">Fermer</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('.catclose').addEventListener('click', close);
    sh.addEventListener('click', ev => { if (ev.target === sh) close(); });
    sh.querySelectorAll('[data-i]').forEach(o => o.addEventListener('click', () => { close(); openEventSheet(evs[parseInt(o.dataset.i)]); }));
  }

  /* ---- vue ---- */
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile;
    ensureCss();
    await loadCals(sdk);
    const days = mode === 'month' ? 40 : 7;
    try { const r = await S.api('/events?days=' + days); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }
  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    const modes = [['list', 'Liste'], ['week', 'Semaine'], ['month', 'Mois']];
    let h = '<div class="grafhead">' + modes.map(m => '<button class="wch' + (mode === m[0] ? ' on' : '') + '" data-agm="' + m[0] + '">' + m[1] + '</button>').join('') +
      '<button class="wch" id="agRefresh" style="margin-left:auto">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">📆</div><div class="t1">Agenda — CalDAV</div><div class="t2">' + ((d && d.reason) || '') + '<br>Configure dans \u2699 : serveur, e-mail et <b>mot de passe d\'application</b>.</div></div>';
      el.innerHTML = h;
      const r0 = document.getElementById('agRefresh'); if (r0) r0.addEventListener('click', () => render(el, S, tile));
      el.querySelectorAll('[data-agm]').forEach(x => x.addEventListener('click', () => { mode = x.dataset.agm; render(el, S, tile); }));
      return;
    }
    (d.calendars || []).forEach((c, i) => calState(c, i));
    d.events = (data.events || []).filter(e => calVisible(e.calendar));
    if ((d.calendars || []).length) {
      h += '<div class="agcals">' + d.calendars.map(c => {
        const on = calVisible(c), col = calColor(c);
        return '<span class="agchip' + (on ? '' : ' off') + '" data-agcal="' + encodeURIComponent(c) + '" ' +
          'style="--cc:' + col + '"><span class="agdot" style="background:' + col + '"></span>' + c + '</span>';
      }).join('') + '</div>';
    }
    const today = ymd(new Date());
    h += '<div class="agform"><input id="agT" placeholder="Titre de l\'événement" autocomplete="off">' +
      '<input id="agD" type="date" value="' + today + '">' +
      '<input id="agH" type="time" value="09:00">' +
      '<select id="agM"><option value="30">30 min</option><option value="60" selected>1 h</option>' +
      '<option value="90">1 h 30</option><option value="120">2 h</option><option value="240">4 h</option></select>' +
      '<button id="agAdd">Ajouter</button></div>';
    h += '<span class="agmore-btn" id="agToggle">' + (extra ? '− moins d\'options' : '+ lieu, description, invités, rappel') + '</span>';
    if (extra) {
      const cs = d.calendars || [];
      h += '<div class="agform2"><input id="agL" placeholder="Lieu" autocomplete="off">' +
        '<input id="agI" placeholder="Invités (e-mails séparés par des virgules)" autocomplete="off">' +
        '<select id="agA"><option value="">Aucun rappel</option><option value="10">10 min avant</option>' +
        '<option value="15">15 min avant</option><option value="30">30 min avant</option>' +
        '<option value="60">1 h avant</option><option value="1440">1 jour avant</option></select></div>' +
        '<div class="agform3">' +
        '<select id="agR"><option value="">Ne pas répéter</option><option value="daily">Chaque jour</option>' +
        '<option value="weekly">Chaque semaine</option><option value="monthly">Chaque mois</option>' +
        '<option value="yearly">Chaque année</option></select>' +
        '<input id="agRU" type="date" title="Répéter jusqu\'au (vide = indéfiniment)" placeholder="Jusqu\'au (vide = indéfiniment)">' +
        '<select id="agC">' + (cs.length ? cs.map(c => '<option value="' + c + '">📆 ' + c + '</option>').join('') : '<option value="">Calendrier par défaut</option>') + '</select>' +
        '</div>' +
        '<div class="agform2" style="grid-template-columns:1fr"><input id="agDesc" placeholder="Description" autocomplete="off"></div>';
    }
    h += '<div class="kotoast" id="agErr"></div>';

    if (mode === 'month') {
      const now = new Date(); now.setHours(0, 0, 0, 0);
      const first = new Date(now.getFullYear(), now.getMonth(), 1);
      const shift = (first.getDay() + 6) % 7;
      const start = new Date(first); start.setDate(1 - shift);
      const J = ['lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim'];
      h += '<div class="agmonth">' + J.map(x => '<div class="agmh">' + x + '</div>').join('');
      for (let i = 0; i < 42; i++) {
        const dd = new Date(start); dd.setDate(start.getDate() + i);
        const key = ymd(dd);
        const evs = d.events.filter(e => e.start.slice(0, 10) === key);
        const out = dd.getMonth() !== now.getMonth();
        const cls = (out ? ' out' : '') + (isWE(dd) ? ' we' : '') + (isFerie(data.events || [], key) ? ' ferie' : '') +
          (key === ymd(new Date()) ? ' today' : '');
        h += '<div class="agmc' + cls + '" data-day="' + key + '">' +
          '<div class="agmn">' + dd.getDate() + '</div>' +
          evs.slice(0, 2).map(e => '<div class="agmp" style="--evc:' + calColor(e.calendar) + '">' + (e.all_day ? '' : fmtT(e) + ' ') + e.title + '</div>').join('') +
          (evs.length > 2 ? '<div class="agmore">+' + (evs.length - 2) + ' autre' + (evs.length > 3 ? 's' : '') + '</div>' : '') + '</div>';
      }
      h += '</div>';
    } else if (mode === 'week') {
      const base = new Date(); base.setHours(0, 0, 0, 0);
      h += '<div class="agweek">';
      for (let i = 0; i < 7; i++) {
        const dd = new Date(base); dd.setDate(base.getDate() + i);
        const key = ymd(dd);
        const evs = d.events.filter(e => e.start.slice(0, 10) === key);
        const ccls = (isWE(dd) ? ' we' : '') + (isFerie(data.events || [], key) ? ' ferie' : '') + (i === 0 ? ' today' : '');
        h += '<div class="agcol' + ccls + '"><div class="agch">' + dd.toLocaleDateString('fr-FR', { weekday: 'short' }) + '</div>' +
          '<div class="agcd">' + dd.getDate() + '</div>' +
          evs.map(e => '<div class="agev" style="--evc:' + calColor(e.calendar) + '" data-uid="' + (e.uid || '') + '" data-start="' + e.start + '">' +
            '<div class="agevh">' + fmtT(e) + '</div><div class="agevt">' + e.title + '</div></div>').join('') + '</div>';
      }
      h += '</div>';
    } else if (!d.events.length) {
      h += '<div class="stub"><div class="big">📆</div><div class="t2">Rien de prévu sur les 7 prochains jours 🎉</div></div>';
    } else {
      const byDay = {}; d.events.forEach(e => { const k = e.start.slice(0, 10); (byDay[k] = byDay[k] || []).push(e); });
      h += Object.keys(byDay).sort().map(k => {
        const dd = new Date(k + 'T12:00:00');
        const lab = (k === today ? '<b>Aujourd\'hui</b>' : dd.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }));
        return '<div class="agday"><div class="agdh">' + lab + '</div>' + byDay[k].map(e => {
          const t = e.all_day ? 'Journée' : new Date(e.start).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) + (e.end ? '–' + new Date(e.end).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '');
          return '<div class="agrow" style="--evc:' + calColor(e.calendar) + '" data-start="' + e.start + '" data-uid="' + (e.uid || '') + '"><span class="agt">' + t + '</span>' +
            '<span class="agtitle">' + e.title + '</span>' +
            (e.location ? '<span class="agloc">📍 ' + e.location + '</span>' : '') +
            (e.calendar ? '<span class="agcal">' + e.calendar + '</span>' : '') + '</div>'; }).join('') + '</div>';
      }).join('');
    }
    h += '<div class="wsrc">CalDAV · ' + (d.calendars || []).join(', ') + ' · vue embarquée v0.2.0</div>';
    el.innerHTML = h;
    const rb = document.getElementById('agRefresh'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
    el.querySelectorAll('[data-agm]').forEach(x => x.addEventListener('click', () => { mode = x.dataset.agm; render(el, S, tile); }));
    el.querySelectorAll('[data-agcal]').forEach(x => x.addEventListener('click', () => {
      const name = decodeURIComponent(x.dataset.agcal);
      const st = calState(name, 0); st.on = (st.on === false); saveCals(S); paint();
    }));
    const tg = document.getElementById('agToggle'); if (tg) tg.addEventListener('click', () => { extra = !extra; paint(); });
    const find = (st2, uid) => d.events.find(e => (uid && e.uid === uid) || e.start === st2);
    el.querySelectorAll('[data-start]').forEach(x => x.addEventListener('click', () => {
      const e = find(x.dataset.start, x.dataset.uid); if (e) openEventSheet(e); }));
    el.querySelectorAll('[data-day]').forEach(x => x.addEventListener('click', () => {
      const evs = d.events.filter(e => e.start.slice(0, 10) === x.dataset.day);
      if (evs.length === 1) openEventSheet(evs[0]);
      else if (evs.length > 1) openDaySheet(x.dataset.day, evs); }));
    wireForm();
  }
  function wireForm() {
    const btn = document.getElementById('agAdd'); if (!btn) return;
    const err = document.getElementById('agErr');
    btn.addEventListener('click', async () => {
      const t = (document.getElementById('agT').value || '').trim();
      const dte = document.getElementById('agD').value, hr = document.getElementById('agH').value;
      const mn = parseInt(document.getElementById('agM').value);
      const loc = (document.getElementById('agL') || {}).value || '';
      const inv = (document.getElementById('agI') || {}).value || '';
      const alm = (document.getElementById('agA') || {}).value || '';
      const dsc = (document.getElementById('agDesc') || {}).value || '';
      const rep = (document.getElementById('agR') || {}).value || '';
      const repU = (document.getElementById('agRU') || {}).value || '';
      const cal = (document.getElementById('agC') || {}).value || '';
      err.textContent = '';
      if (!t) { err.textContent = 'Donne un titre à l\'événement'; return; }
      if (!dte || !hr) { err.textContent = 'Date et heure requises'; return; }
      const when = new Date(dte + 'T' + hr).toLocaleString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
      const RL = { daily: 'chaque jour', weekly: 'chaque semaine', monthly: 'chaque mois', yearly: 'chaque année' };
      const rtxt = rep ? (' · répété ' + RL[rep] + (repU ? (' jusqu\'au ' + new Date(repU).toLocaleDateString('fr-FR')) : ' (indéfiniment)')) : '';
      if (!confirm('Créer « ' + t + ' » le ' + when + rtxt + (cal ? (' dans « ' + cal + ' »') : '') + ' ?')) return;
      btn.disabled = true;
      try {
        const r = await S.api('/add', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: t, start: dte + 'T' + hr + ':00', minutes: mn, location: loc,
            description: dsc, attendees: inv, alarm_min: alm ? parseInt(alm) : null,
            repeat: rep, repeat_until: repU, calendar: cal }) });
        const j = await r.json();
        if (j.ok) { S.vk.close(); S.toast('Ajouté au calendrier « ' + j.calendar + ' »'); await render(root, S, tile); background(S); }
        else err.textContent = 'Création impossible — ' + (j.reason || '');
      } catch (e) { err.textContent = 'Serveur injoignable'; }
      btn.disabled = false;
    });
  }

  /* ---- volet ⚙ : calendrier par défaut, visibilité, couleurs ---- */
  async function configPanel(box, sdk) {
    S = S || sdk;
    await loadCals(sdk);
    const inp = document.querySelector('[data-k="calendar"]');
    box.innerHTML = '<span style="font-size:11.5px;color:var(--faint)">Lecture des calendriers…</span>';
    try {
      const r = await sdk.api('/calendars'); const j = await r.json();
      if (!document.body.contains(box)) return;
      if (!j.ok || !j.calendars.length) { box.innerHTML = '<span style="font-size:11.5px;color:var(--dim)">' + (j.reason || 'aucun calendrier — enregistre puis teste') + '</span>'; return; }
      j.calendars.forEach((c, i) => calState(c, i));
      const cur = inp ? inp.value : '';
      if (inp && inp.closest('label')) inp.closest('label').style.display = 'none';
      box.innerHTML = '<label class="cfgf"><span>Calendrier par défaut (nouveaux événements)</span>' +
        '<select class="inp" id="calSel">' +
        j.calendars.map(c => '<option value="' + c + '"' + (c === cur ? ' selected' : '') + '>📆 ' + c + '</option>').join('') + '</select></label>' +
        '<div class="cfgf" style="margin-top:10px"><span>Calendriers affichés &amp; couleurs</span>' +
        '<div id="calList" style="margin-top:6px">' + j.calendars.map(c => {
          const st2 = calState(c, 0);
          return '<div class="calrow"><span class="calname">' + c + '</span>' +
            '<input type="color" value="' + st2.color + '" data-calcolor="' + c + '" class="calcolor">' +
            '<div class="sw' + (st2.on !== false ? ' on' : '') + '" data-caltoggle="' + c + '"></div></div>';
        }).join('') + '</div></div>';
      const sel = document.getElementById('calSel');
      const apply = () => { if (inp) { inp.value = sel.value; inp.dispatchEvent(new Event('input', { bubbles: true })); } };
      if (!cur && sel.value) apply();
      sel.addEventListener('change', apply);
      box.querySelectorAll('[data-calcolor]').forEach(ci => ci.addEventListener('input', () => {
        cals[ci.dataset.calcolor].color = ci.value; saveCals(sdk); }));
      box.querySelectorAll('[data-caltoggle]').forEach(sw => sw.addEventListener('click', () => {
        const n = sw.dataset.caltoggle;
        cals[n].on = cals[n].on === false;
        sw.classList.toggle('on', cals[n].on); saveCals(sdk); }));
    } catch (e) { if (document.body.contains(box)) box.innerHTML = '<span style="font-size:11.5px;color:var(--bad)">serveur injoignable</span>'; }
  }

  /* ---- notifications d'événements imminents (hook background) ---- */
  async function tick(sdk) {
    const cfg = await sdk.config();
    if ((cfg.notif || 'on') === 'off') return sdk.notify(null);
    let d = null; try { const r = await sdk.api('/events?days=2'); d = await r.json(); } catch (e) {}
    if (!d || !d.ok || !d.events.length) return sdk.notify(null);
    const now = Date.now();
    const leadOf = e => { const m = (e.alarm || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?/);
      if (!m) return 60; const hh = parseInt(m[1] || 0), mm = parseInt(m[2] || 0); return (hh * 60 + mm) || 60; };
    let best = null;
    for (const e of d.events) {
      const t = new Date(e.start).getTime();
      const mins = Math.round((t - now) / 60000);
      if (mins < -60) continue;
      if (mins > leadOf(e)) continue;
      if (!best || t < new Date(best.start).getTime()) best = e;
    }
    if (!best) return sdk.notify(null);
    const mins = Math.round((new Date(best.start) - now) / 60000);
    let quand;
    if (mins < 0) quand = 'en cours';
    else if (mins < 60) quand = 'dans ' + mins + ' min';
    else if (mins < 1440) quand = 'dans ' + Math.round(mins / 60) + ' h';
    else quand = 'demain';
    sdk.notify({ text: quand, title: best.title + ' — ' + quand, urgent: mins <= 60, onclick: () => sdk.open() });
  }
  function background(sdk) {
    bgSdk = sdk;
    if (bgTimer) clearInterval(bgTimer);      // idempotent : un seul timer
    tick(sdk);
    bgTimer = setInterval(() => tick(bgSdk), 120000);
  }

  function unmount() {
    document.querySelectorAll('.evsheet').forEach(x => x.remove());
    // bgTimer volontairement conservé : les notifications vivent hors de la vue
  }

  return { render, configPanel, background, unmount };
})();
