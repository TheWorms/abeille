"""Addon « arcane » — Docker via Arcane : multi-environnements, stats, actions.

    register(sdk) -> flask.Blueprint   (routes sous /addons/arcane/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:3552) + apikey (arc_...).
Arcane gère plusieurs ENVIRONNEMENTS (une machine chacun). L'addon liste
d'abord /api/environments, puis agrège les conteneurs de chaque environnement
en ligne, en tagguant chaque conteneur du nom de sa machine.
Actions POST /containers/{id}/{start|stop|restart} sur le bon environnement.
"""


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _hdr(key):
    return {"X-API-Key": key}


def _short_name(names):
    if isinstance(names, list) and names:
        return str(names[0]).lstrip("/")
    return str(names or "").lstrip("/")


def _fmt_ports(ports):
    if not isinstance(ports, list):
        return []
    out, seen = [], set()
    for p in ports:
        if not isinstance(p, dict):
            continue
        pub, priv, typ = p.get("publicPort"), p.get("privatePort"), p.get("type", "tcp")
        if pub:
            label = f"{pub}→{priv}/{typ}"
        elif priv:
            label = f"{priv}/{typ}"
        else:
            continue
        if label not in seen:
            seen.add(label)
            out.append(label)
    return out


def _environments(sdk, url, key):
    """Liste [(id, name, online)] des environnements Arcane."""
    try:
        r = sdk.requests.get(f"{url}/api/environments", headers=_hdr(key),
                             timeout=10, verify=False)
        if not r.ok:
            return None, (r.status_code if r.status_code == 401 else None)
        raw = r.json()
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None, None
    items = raw.get("data", raw) if isinstance(raw, dict) else raw
    if not isinstance(items, list):
        return None, None
    envs = []
    for e in items:
        if not isinstance(e, dict):
            continue
        eid = e.get("id")
        if eid is None:
            continue
        name = e.get("name") or str(eid)
        st = e.get("status") or e.get("state") or ""
        enabled = e.get("enabled")
        online = (str(st).lower() in ("online", "up", "ok", "reachable")
                  or enabled is True or st == "" and enabled is None)
        envs.append((str(eid), name, online))
    return envs, None


def _containers_of(sdk, url, key, eid):
    try:
        r = sdk.requests.get(f"{url}/api/environments/{eid}/containers",
                             headers=_hdr(key), timeout=10, verify=False)
        if not r.ok:
            return []
        raw = r.json()
    except (sdk.requests.exceptions.RequestException, ValueError):
        return []
    return raw.get("data", raw) if isinstance(raw, dict) else (raw if isinstance(raw, list) else [])


def _list(sdk, cfg, bust=False):
    url, key = _base(cfg)
    if not (url and key):
        return {"ok": False, "reason": "URL/clé non configurées"}
    ck = f"arc:{url}"
    if not bust:
        c = sdk.cache_get(ck, 30)
        if c is not None:
            return c

    envs, err = _environments(sdk, url, key)
    if err == 401:
        return {"ok": False, "reason": "clé refusée (401) — format arc_..."}
    if envs is None:
        return {"ok": False, "reason": "Arcane injoignable ou API inattendue"}

    containers = []
    images = set()
    env_names = []
    for eid, ename, online in envs:
        env_names.append(ename)
        if not online:
            continue
        for c in _containers_of(sdk, url, key, eid):
            if not isinstance(c, dict):
                continue
            state = (c.get("state") or "").lower()
            img = c.get("image") or ""
            images.add(img)
            upd = c.get("updateInfo")
            has_update = bool(upd.get("hasUpdate")) if isinstance(upd, dict) else False
            containers.append({
                "id": c.get("id", ""),
                "env": eid,
                "machine": ename,
                "name": _short_name(c.get("names")),
                "image": img,
                "state": state,
                "running": state == "running",
                "status": c.get("status") or "",
                "ports": _fmt_ports(c.get("ports")),
                "has_update": has_update,
            })
    containers.sort(key=lambda x: (not x["running"], x["machine"].lower(), x["name"].lower()))

    running = sum(1 for c in containers if c["running"])
    out = {
        "ok": True,
        "containers": containers,
        "total": len(containers),
        "running": running,
        "stopped": len(containers) - running,
        "images": len(images),
        "env_count": len(envs),
        "machines": env_names,
    }
    return sdk.cache_set(ck, out)


def _action(sdk, cfg, eid, cid, action):
    url, key = _base(cfg)
    if not (url and key):
        return {"ok": False, "reason": "non configuré"}
    if action not in ("start", "stop", "restart"):
        return {"ok": False, "reason": "action non autorisée"}
    if not (cid and eid):
        return {"ok": False, "reason": "conteneur/environnement manquant"}
    try:
        r = sdk.requests.post(
            f"{url}/api/environments/{eid}/containers/{cid}/{action}",
            headers=_hdr(key), timeout=25, verify=False)
        if r.status_code == 401:
            return {"ok": False, "reason": "clé refusée (401)"}
        if r.status_code not in (200, 201, 202, 204):
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": f"injoignable ({type(e).__name__})"}
    _list(sdk, cfg, bust=True)
    return {"ok": True, "action": action}


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("arcane", __name__)

    @bp.route("/containers")
    def containers():
        try:
            return jsonify(_list(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("arcane list")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/action", methods=["POST"])
    def action():
        try:
            body = request.get_json(silent=True) or {}
            return jsonify(_action(sdk, sdk.config(),
                                   (body.get("env") or "").strip(),
                                   (body.get("id") or "").strip(),
                                   (body.get("action") or "").strip()))
        except Exception as e:
            sdk.log.exception("arcane action")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _list(sdk, cfg)
    if d.get("ok"):
        return True, (f"Arcane ✓ — {d['running']}/{d['total']} conteneur(s) en cours "
                      f"sur {d['env_count']} machine(s), {d['images']} image(s)")
    return False, f"Arcane ✗ ({d.get('reason')})"
