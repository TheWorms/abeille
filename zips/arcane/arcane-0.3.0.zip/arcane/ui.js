/* Arcane — conteneurs Docker : stats, liste/cards, actions start/stop/restart. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.arcane = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'list', busy = {};
  const ACCENT = '#2496ed';  // bleu Docker
  const CSS =
    "  .arwrap{flex:1;display:flex;flex-direction:column;min-height:0;--ar:" + ACCENT + "}\n" +
    "  .artopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .artotals{display:flex;gap:16px;flex:1}\n" +
    "  .artk{text-align:center}\n" +
    "  .artk b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--ar)}\n" +
    "  .artk.run b{color:var(--green)}.artk.stop b{color:var(--dim)}\n" +
    "  .artk span{font-size:11px;color:var(--dim)}\n" +
    "  .arvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .arvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .arvtoggle button.on{background:var(--tile);color:var(--ar)}\n" +
    "  .arscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    /* liste */
    "  .arrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:10px 14px;margin-bottom:7px}\n" +
    "  .arrow.off{opacity:.55}\n" +
    "  .ardot{width:10px;height:10px;border-radius:50%;flex:none;background:var(--green)}\n" +
    "  .arrow.off .ardot{background:var(--dim)}\n" +
    "  .artx{min-width:0;flex:1}\n" +
    "  .arnm{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .arnm .upd{color:var(--warn);font-size:11px;margin-left:6px}\n" +
    "  .arsub{font-family:var(--mono);font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .arstatus{font-size:11px;color:var(--dim);flex:none;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .aracts{display:flex;gap:5px;flex:none}\n" +
    "  .aract{width:36px;height:36px;border-radius:9px;border:1px solid var(--border-soft);background:var(--bg);color:var(--fg);font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center}\n" +
    "  .aract:disabled{opacity:.4}\n" +
    "  .aract.start{color:var(--green)}.aract.stop{color:var(--bad)}.aract.restart{color:var(--ar)}\n" +
    /* cards */
    "  .arcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:11px}\n" +
    "  .arcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px;border-left:3px solid var(--green);display:flex;flex-direction:column}\n" +
    "  .arcard.off{opacity:.55;border-left-color:var(--dim)}\n" +
    "  .arctop{display:flex;align-items:center;gap:8px;margin-bottom:7px}\n" +
    "  .arcdot{width:10px;height:10px;border-radius:50%;flex:none;background:var(--green)}\n" +
    "  .arcard.off .arcdot{background:var(--dim)}\n" +
    "  .arcnm{font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .arcimg{font-family:var(--mono);font-size:11px;color:var(--dim);margin-bottom:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .arcports{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:9px;min-height:4px}\n" +
    "  .arport{font-family:var(--mono);font-size:10px;background:var(--bg);border:1px solid var(--border-soft);border-radius:6px;padding:1px 6px;color:var(--dim)}\n" +
    "  .arcstatus{font-size:11px;color:var(--dim);margin-bottom:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .arcfoot{display:flex;gap:5px;margin-top:auto}\n" +
    "  .arcfoot .aract{flex:1}\n" +
    "  .arempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    "  .arupd-chip{font-size:10px;color:var(--warn);background:rgba(240,180,41,.12);border-radius:6px;padding:1px 6px;margin-left:auto}";
  function ensureCss() { if (document.getElementById('arUiCss')) return; const s = document.createElement('style'); s.id = 'arUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des conteneurs…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    await reload();
  }

  async function reload() {
    try { const r = await S.api('/containers'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function actBtns(c, inCard) {
    const b = busy[c.id];
    const cls = inCard ? '' : '';
    let h = '<div class="' + (inCard ? 'arcfoot' : 'aracts') + '">';
    if (c.running) {
      h += '<button class="aract restart" data-act="restart" data-id="' + esc(c.id) + '" title="Redémarrer"' + (b ? ' disabled' : '') + '>' + (b === 'restart' ? '…' : '\u21BB') + '</button>';
      h += '<button class="aract stop" data-act="stop" data-id="' + esc(c.id) + '" title="Arrêter"' + (b ? ' disabled' : '') + '>' + (b === 'stop' ? '…' : '\u23F9') + '</button>';
    } else {
      h += '<button class="aract start" data-act="start" data-id="' + esc(c.id) + '" title="Démarrer"' + (b ? ' disabled' : '') + '>' + (b === 'start' ? '…' : '\u25B6') + '</button>';
    }
    h += '</div>';
    return h;
  }

  function row(c) {
    return '<div class="arrow' + (c.running ? '' : ' off') + '">' +
      '<span class="ardot"></span>' +
      '<div class="artx"><div class="arnm">' + esc(c.name) + (c.has_update ? '<span class="upd">⬆ maj</span>' : '') + '</div>' +
      '<div class="arsub">' + esc(c.image) + '</div></div>' +
      '<span class="arstatus">' + esc(c.status) + '</span>' +
      actBtns(c, false) + '</div>';
  }
  function card(c) {
    return '<div class="arcard' + (c.running ? '' : ' off') + '">' +
      '<div class="arctop"><span class="arcdot"></span><span class="arcnm">' + esc(c.name) + '</span>' +
      (c.has_update ? '<span class="arupd-chip">⬆ maj</span>' : '') + '</div>' +
      '<div class="arcimg">' + esc(c.image) + '</div>' +
      '<div class="arcports">' + (c.ports.length ? c.ports.map(p => '<span class="arport">' + esc(p) + '</span>').join('') : '<span class="arport" style="opacity:.5">aucun port</span>') + '</div>' +
      '<div class="arcstatus">' + esc(c.status) + '</div>' +
      actBtns(c, true) + '</div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🐳</div><div class="t1">Arcane indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API (arc_...) dans ⚙.</div>' +
        '<button class="btnpill install" id="arRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('arRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="arwrap"><div class="artopbar">' +
      '<div class="artotals">' +
      '<div class="artk"><b>' + nf(d.total) + '</b><span>conteneurs</span></div>' +
      '<div class="artk run"><b>' + nf(d.running) + '</b><span>en cours</span></div>' +
      '<div class="artk stop"><b>' + nf(d.stopped) + '</b><span>arrêtés</span></div>' +
      '<div class="artk"><b>' + nf(d.images) + '</b><span>images</span></div>' +
      '</div>' +
      '<div class="arvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="arscroll">';
    if (!d.containers || !d.containers.length) {
      h += '<div class="arempty">Aucun conteneur.</div>';
    } else if (viewMode === 'cards') {
      h += '<div class="arcards">' + d.containers.map(card).join('') + '</div>';
    } else {
      h += d.containers.map(row).join('');
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.arvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v');
      if (v === viewMode) return;
      viewMode = v;
      try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    el.querySelectorAll('.aract').forEach(b => b.addEventListener('click', () => doAction(b.getAttribute('data-id'), b.getAttribute('data-act'))));
  }

  async function doAction(id, act) {
    if (!id || !act) return;
    const cont = (data.containers || []).find(c => c.id === id);
    const name = cont ? cont.name : id.slice(0, 12);
    const labels = { start: 'Démarrer', stop: 'Arrêter', restart: 'Redémarrer' };
    if (!confirm(labels[act] + ' le conteneur « ' + name + ' » ?')) return;
    busy[id] = act; paint();
    try {
      const r = await S.api('/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id, action: act }) });
      const j = await r.json();
      if (j.ok) { S.toast(labels[act] + ' : ' + name + ' ✓'); }
      else { S.toast('Échec : ' + (j.reason || 'erreur')); }
    } catch (e) { S.toast('Échec de l\'action'); }
    delete busy[id];
    // petit délai pour laisser Docker changer d'état, puis recharge
    setTimeout(reload, 1200);
  }

  return { render };
})();
