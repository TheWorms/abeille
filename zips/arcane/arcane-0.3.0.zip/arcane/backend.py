"""Addon « arcane » — Docker via Arcane (Poulpe) : stats, liste/cards, actions.

    register(sdk) -> flask.Blueprint   (routes sous /addons/arcane/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:3552) + apikey (arc_...).
API Arcane v2 : GET /api/environments/{env}/containers, actions POST
  /containers/{id}/{start|stop|restart}. Auth par header X-API-Key.
Cache 30 s pour la liste ; invalidé après une action.
"""

ENV = "0"  # environnement Arcane par défaut (local)


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _hdr(key):
    return {"X-API-Key": key}


def _short_name(names):
    if isinstance(names, list) and names:
        return str(names[0]).lstrip("/")
    return str(names or "").lstrip("/")


def _fmt_ports(ports):
    if not isinstance(ports, list):
        return []
    out = []
    seen = set()
    for p in ports:
        if not isinstance(p, dict):
            continue
        pub = p.get("publicPort")
        priv = p.get("privatePort")
        typ = p.get("type", "tcp")
        if pub:
            label = f"{pub}→{priv}/{typ}"
        elif priv:
            label = f"{priv}/{typ}"
        else:
            continue
        if label not in seen:
            seen.add(label)
            out.append(label)
    return out


def _list(sdk, cfg, bust=False):
    url, key = _base(cfg)
    if not (url and key):
        return {"ok": False, "reason": "URL/clé non configurées"}
    ck = f"arc:{url}"
    if not bust:
        c = sdk.cache_get(ck, 30)
        if c is not None:
            return c
    try:
        r = sdk.requests.get(f"{url}/api/environments/{ENV}/containers",
                             headers=_hdr(key), timeout=10, verify=False)
        if r.status_code == 401:
            return {"ok": False, "reason": "clé refusée (401) — format arc_..."}
        if r.status_code != 200:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        raw = r.json()
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": f"injoignable ({type(e).__name__})"}
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}

    items = raw.get("data", raw) if isinstance(raw, dict) else raw
    if not isinstance(items, list):
        items = []

    containers = []
    images = set()
    for c in items:
        if not isinstance(c, dict):
            continue
        state = (c.get("state") or "").lower()
        img = c.get("image") or ""
        images.add(img)
        proj = ""
        labels = c.get("labels")
        if isinstance(labels, dict):
            proj = labels.get("com.docker.compose.project", "") or ""
        upd = c.get("updateInfo")
        has_update = bool(upd.get("hasUpdate")) if isinstance(upd, dict) else False
        containers.append({
            "id": c.get("id", ""),
            "name": _short_name(c.get("names")),
            "image": img,
            "state": state,
            "running": state == "running",
            "status": c.get("status") or "",
            "ports": _fmt_ports(c.get("ports")),
            "project": proj,
            "has_update": has_update,
        })
    containers.sort(key=lambda x: (not x["running"], x["name"].lower()))

    running = sum(1 for c in containers if c["running"])
    out = {
        "ok": True,
        "containers": containers,
        "total": len(containers),
        "running": running,
        "stopped": len(containers) - running,
        "images": len(images),
    }
    return sdk.cache_set(ck, out)


def _action(sdk, cfg, cid, action):
    url, key = _base(cfg)
    if not (url and key):
        return {"ok": False, "reason": "non configuré"}
    if action not in ("start", "stop", "restart"):
        return {"ok": False, "reason": "action non autorisée"}
    if not cid:
        return {"ok": False, "reason": "conteneur manquant"}
    try:
        r = sdk.requests.post(
            f"{url}/api/environments/{ENV}/containers/{cid}/{action}",
            headers=_hdr(key), timeout=25, verify=False)
        if r.status_code == 401:
            return {"ok": False, "reason": "clé refusée (401)"}
        if r.status_code not in (200, 201, 202, 204):
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": f"injoignable ({type(e).__name__})"}
    # invalider le cache pour refléter le nouvel état
    _list(sdk, cfg, bust=True)
    return {"ok": True, "action": action}


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("arcane", __name__)

    @bp.route("/containers")
    def containers():
        try:
            return jsonify(_list(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("arcane list")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/action", methods=["POST"])
    def action():
        try:
            body = request.get_json(silent=True) or {}
            cid = (body.get("id") or "").strip()
            act = (body.get("action") or "").strip()
            return jsonify(_action(sdk, sdk.config(), cid, act))
        except Exception as e:
            sdk.log.exception("arcane action")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _list(sdk, cfg)
    if d.get("ok"):
        return True, (f"Arcane ✓ — {d['running']}/{d['total']} conteneur(s) en cours, "
                      f"{d['images']} image(s)")
    return False, f"Arcane ✗ ({d.get('reason')})"
