"""Addon « maree » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/maree/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : api-maree.fr (hauteurs d'eau IFREMER/PREVIMER, CC-BY), clé gratuite.
"""
from datetime import datetime, timedelta


def _tide_extremes(pts):
    """Détecte les pleines/basses mers (points de retournement) dans la série."""
    ex = []
    for i in range(1, len(pts) - 1):
        a, b, c = pts[i - 1]["height"], pts[i]["height"], pts[i + 1]["height"]
        if a is None or b is None or c is None:
            continue
        if b >= a and b > c:
            ex.append({"type": "PM", "dt": pts[i]["dt"], "height": b})
        elif b <= a and b < c:
            ex.append({"type": "BM", "dt": pts[i]["dt"], "height": b})
    return ex


def _maree_fetch(sdk, site, key, frm, to, step=30):
    """Un appel api-maree.fr. Retourne (points, erreur)."""
    try:
        r = sdk.requests.get("https://api-maree.fr/water-levels",
                             params={"site": site, "from": frm, "to": to,
                                     "step": step, "tz": "Europe/Paris", "key": key},
                             timeout=10)
    except sdk.requests.exceptions.RequestException as e:
        return None, type(e).__name__
    if r.status_code != 200:
        detail = ""
        try:
            j = r.json()
            detail = j.get("message") or j.get("error") or ""
        except ValueError:
            detail = (r.text or "")[:80]
        return None, f"HTTP {r.status_code}" + (f" — {detail}" if detail else "")
    try:
        data = r.json().get("data", [])
    except ValueError:
        return None, "réponse invalide"
    pts = []
    for p in data:
        t = p.get("time")
        if not t:
            continue
        try:
            epoch = int(datetime.fromisoformat(t).timestamp())
        except ValueError:
            continue
        hh = p.get("height")
        pts.append({"dt": epoch, "height": round(hh, 2) if hh is not None else None})
    return pts, None


def _tides(sdk, cfg, days=7):
    """Hauteurs d'eau via api-maree.fr (IFREMER/PREVIMER, CC-BY).
    Essaie une fenêtre large ; si l'API la refuse, découpe en tranches d'un jour."""
    site = (cfg.get("site") or "").strip().lower().replace(" ", "-")
    key = (cfg.get("apikey") or "").strip()
    out = {}
    if not (site and key):
        out.update(ok=False, reason="site/clé api-maree manquants")
        return out
    ck = f"tides:{site}:{days}:{datetime.now().strftime('%Y-%m-%d')}"
    cached = sdk.cache_get(ck, 21600)  # 6 h
    if cached is not None:
        out.update(ok=True, **cached)
        return out

    base = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)
    fmt = "%Y-%m-%dT%H:%M"
    pts, err = _maree_fetch(sdk, site, key, base.strftime(fmt),
                            (base + timedelta(days=days + 1)).strftime(fmt))
    if pts is None:
        # repli : jour par jour (certaines offres limitent la fenêtre)
        pts, first_err = [], err
        for d in range(days + 1):
            d0 = base + timedelta(days=d)
            chunk, e2 = _maree_fetch(sdk, site, key, d0.strftime(fmt),
                                     (d0 + timedelta(days=1)).strftime(fmt))
            if chunk is None:
                if d == 0:
                    out.update(ok=False, reason=first_err or e2)
                    return out
                break
            pts.extend(chunk)
    if not pts:
        out.update(ok=False, reason=err or "aucune donnée")
        return out
    pts.sort(key=lambda p: p["dt"])
    payload = {"points": pts, "extremes": _tide_extremes(pts), "site": site}
    sdk.cache_set(ck, payload)
    out.update(ok=True, **payload)
    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("maree", __name__)

    @bp.route("/tides")
    def tides():
        try:
            return jsonify(_tides(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("tides")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    td = _tides(sdk, cfg, days=1)
    if td.get("ok"):
        return True, (f"api-maree ✓ ({len(td.get('points', []))} points, "
                      f"{len(td.get('extremes', []))} PM/BM)")
    return False, f"api-maree ✗ ({td.get('reason')})"
