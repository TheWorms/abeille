/* Marée — courbes et horloge de marée (Phase 3, lot A, livraison 2).
   Deux graphes SVG : courbe du jour (12 h de points + extrêmes PM/BM) et
   courbe de la semaine, plus une horloge de marée montante/descendante.
   Réutilise les classes partagées du noyau (wsec, wpollen, wpill, wsrc,
   accent-tint) ; n'embarque que son CSS propre (td*). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.maree = (function () {
  let S = null, root = null, tile = null, data = null;
  const CSS = ".mrwrap{flex:1;display:flex;flex-direction:column;min-height:0}\n.tdlist{display:grid;grid-template-columns:1fr;gap:6px;padding:0}\n.tdrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-left:4px solid var(--accent);border-radius:9px;padding:6px 12px}\n.tdrow.bm{border-left-color:var(--warn)}\n.tdtag{font-family:var(--mono);font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:var(--accent-tint);color:var(--accent)}\n.tdrow.bm .tdtag{background:rgba(240,180,41,.15);color:var(--warn)}\n.tdtime{font-size:15px;font-weight:600;font-variant-numeric:tabular-nums}\n.tdinfo{margin-left:auto;text-align:right;font-size:11px;color:var(--dim)}\n.tdinfo b{display:block;font-size:13px;color:var(--text)}\n.tdlabel{margin-left:12px;font-size:11.5px;color:var(--dim)}\n.tdtop{flex:0 0 auto;display:flex;gap:14px;padding:0 22px 8px;align-items:stretch}\n.tdclock{flex:0 0 168px;background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:6px;display:flex;flex-direction:column;align-items:center;justify-content:center}\n.tdclock svg{width:112px;height:112px}\n.tdclock .cap{font-size:10.5px;color:var(--dim);margin-top:2px;text-align:center}\n.tdclock .cap b{color:var(--text)}\n.tdcol{flex:1;display:flex;flex-direction:column;justify-content:center;gap:6px;min-width:0}\n.tdcol .tdlist{grid-template-columns:1fr;padding:0}\n.mrday{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;padding:0 22px}\n.mrday svg{flex:1;min-height:0;width:100%;height:100%;display:block}\n.mrweek{flex:0 0 96px;padding:0 22px 4px}\n.mrweek svg{width:100%;height:100%;display:block}\n.mrhead{padding:6px 0 4px}";
  function ensureCss() { if (document.getElementById('tdUiCss')) return; const s = document.createElement('style'); s.id = 'tdUiCss'; s.textContent = CSS; document.head.appendChild(s); }

  const tTime = dt => new Date(dt * 1000).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  function tPointsDay(points, off) { const b = new Date(); b.setHours(0, 0, 0, 0); b.setDate(b.getDate() + off); const s = b.getTime() / 1000, e = s + 86400; return (points || []).filter(p => p.dt >= s && p.dt < e && p.height != null); }
  function tExtremesDay(ex, off) { const b = new Date(); b.setHours(0, 0, 0, 0); b.setDate(b.getDate() + off); const s = b.getTime() / 1000, e = s + 86400; return (ex || []).filter(t => t.dt >= s && t.dt < e); }
  const _poly = (arr, X, Y) => arr.map(p => X(p.dt).toFixed(1) + ',' + Y(p.height).toFixed(1)).join(' ');
  const _area = (arr, X, Y, base) => 'M ' + X(arr[0].dt).toFixed(1) + ' ' + base + ' L ' + arr.map(p => X(p.dt).toFixed(1) + ' ' + Y(p.height).toFixed(1)).join(' L ') + ' L ' + X(arr[arr.length - 1].dt).toFixed(1) + ' ' + base + ' Z';

  function tideClock(extremes) {
    const now = Date.now() / 1000;
    const ex = (extremes || []).slice().sort((a, b) => a.dt - b.dt);
    let prev = null, next = null;
    for (const t of ex) { if (t.dt <= now) prev = t; else { next = t; break; } }
    if (!prev || !next) return '<div class="tdclock"><div class="cap">Horloge indisponible</div></div>';
    const rising = (next.type === 'PM');
    const f = Math.min(1, Math.max(0, (now - prev.dt) / ((next.dt - prev.dt) || 1)));
    const ang = rising ? (180 + f * 180) : (f * 180);
    const R = 62, C = 80, rad = (ang - 90) * Math.PI / 180;
    const nx = C + R * 0.72 * Math.cos(rad), ny = C + R * 0.72 * Math.sin(rad);
    const arc = (a0, a1, col) => { const p = a => { const r = (a - 90) * Math.PI / 180; return [(C + R * Math.cos(r)).toFixed(1), (C + R * Math.sin(r)).toFixed(1)]; };
      const [x0, y0] = p(a0), [x1, y1] = p(a1); return '<path d="M ' + x0 + ' ' + y0 + ' A ' + R + ' ' + R + ' 0 0 1 ' + x1 + ' ' + y1 + '" fill="none" stroke="' + col + '" stroke-width="6" stroke-linecap="round"/>'; };
    const rem = Math.max(0, Math.round((next.dt - now) / 60));
    const remTxt = (rem >= 60 ? (Math.floor(rem / 60) + ' h ' + String(rem % 60).padStart(2, '0')) : (rem + ' min'));
    return '<div class="tdclock"><svg viewBox="0 0 160 160" style="width:150px;height:150px">' +
      '<circle cx="80" cy="80" r="' + R + '" fill="none" stroke="var(--border-soft)" stroke-width="6"/>' +
      arc(180, 360, 'var(--accent)') + arc(0, 180, 'var(--warn)') +
      '<text x="80" y="14" text-anchor="middle" font-size="11" font-weight="700" fill="var(--accent)">PM</text>' +
      '<text x="80" y="154" text-anchor="middle" font-size="11" font-weight="700" fill="var(--warn)">BM</text>' +
      '<line x1="80" y1="80" x2="' + nx.toFixed(1) + '" y2="' + ny.toFixed(1) + '" stroke="var(--text)" stroke-width="2.5" stroke-linecap="round"/>' +
      '<circle cx="80" cy="80" r="4.5" fill="var(--text)"/></svg>' +
      '<div class="cap">Marée <b>' + (rising ? 'montante' : 'descendante') + '</b><br>' + next.type + ' dans <b>' + remTxt + '</b></div></div>';
  }

  function dayTideCurve(points, extremes) {
    if (!points || points.length < 2) return '';
    const W = 960, H = 200, padX = 46, padTop = 40, padBot = 34;
    const b = new Date(); b.setHours(0, 0, 0, 0); const s = b.getTime() / 1000, e = s + 86400;
    const X = dt => padX + ((dt - s) / 86400) * (W - 2 * padX);
    const hs = points.map(p => p.height); const lo = Math.min(...hs), hi = Math.max(...hs), hr = (hi - lo) || 1;
    const Y = h => padTop + (1 - (h - lo) / hr) * (H - padTop - padBot);
    let grid = '';
    for (let hh = 0; hh <= 24; hh += 2) { const gx = padX + (hh / 24) * (W - 2 * padX);
      grid += '<line x1="' + gx.toFixed(1) + '" y1="' + padTop + '" x2="' + gx.toFixed(1) + '" y2="' + (H - padBot) + '" stroke="var(--border-soft)" stroke-width="' + (hh % 6 === 0 ? '1' : '0.5') + '"/>' +
        '<text x="' + gx.toFixed(1) + '" y="' + (H - 9) + '" text-anchor="middle" font-size="9.5" fill="var(--faint)">' + String(hh).padStart(2, "0") + ':00</text>'; }
    grid += '<text x="' + (padX - 8) + '" y="' + (Y(hi) + 4).toFixed(1) + '" text-anchor="end" font-size="9.5" fill="var(--faint)">' + hi.toFixed(1) + ' m</text>' +
      '<text x="' + (padX - 8) + '" y="' + (Y(lo) + 4).toFixed(1) + '" text-anchor="end" font-size="9.5" fill="var(--faint)">' + lo.toFixed(1) + ' m</text>';
    const nd = Date.now() / 1000; let nl = '';
    if (nd >= s && nd < e) { const nx = X(nd); nl = '<line x1="' + nx.toFixed(1) + '" y1="' + padTop + '" x2="' + nx.toFixed(1) + '" y2="' + (H - padBot) + '" stroke="var(--accent)" stroke-width="1.2" stroke-dasharray="3 3"/>'; }
    let m = ''; (extremes || []).forEach(t => { if (t.dt < s || t.dt >= e) return; const x = X(t.dt), y = Y(t.height), pm = t.type === 'PM';
      m += '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="4" fill="' + (pm ? 'var(--accent)' : 'var(--warn)') + '"/>' +
        '<text x="' + x.toFixed(1) + '" y="' + (pm ? (y - 15) : (y + 22)).toFixed(1) + '" text-anchor="middle" font-size="11.5" font-weight="600" fill="var(--text)">' + t.height + ' m</text>'; });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '">' + grid + '<path d="' + _area(points, X, Y, H - padBot) + '" fill="var(--accent-tint)"/><polyline points="' + _poly(points, X, Y) + '" fill="none" stroke="var(--accent)" stroke-width="2"/>' + nl + m + '</svg>';
  }

  function weekTideCurve(points, extremes) {
    const b = new Date(); b.setHours(0, 0, 0, 0); const s0 = b.getTime() / 1000;
    const wp = (points || []).filter(p => p.dt >= s0 && p.height != null);
    if (wp.length < 2) return '';
    const t0 = wp[0].dt, t1 = wp[wp.length - 1].dt, span = (t1 - t0) || 1;
    const W = 960, H = 100, padX = 40, padTop = 12, padBot = 20;
    const X = dt => padX + ((dt - t0) / span) * (W - 2 * padX);
    const hs = wp.map(p => p.height); const lo = Math.min(...hs), hi = Math.max(...hs), hr = (hi - lo) || 1;
    const Y = h => padTop + (1 - (h - lo) / hr) * (H - padTop - padBot);
    const mid = (lo + hi) / 2;
    let grid = '';
    [[hi, hi.toFixed(1)], [mid, mid.toFixed(1)], [lo, lo.toFixed(1)]].forEach(([v, lab]) => {
      grid += '<line x1="' + padX + '" y1="' + Y(v).toFixed(1) + '" x2="' + (W - padX) + '" y2="' + Y(v).toFixed(1) + '" stroke="var(--border-soft)" stroke-width="0.6" stroke-dasharray="2 4"/>' +
        '<text x="' + (padX - 8) + '" y="' + (Y(v) + 4).toFixed(1) + '" text-anchor="end" font-size="9.5" fill="var(--faint)">' + lab + ' m</text>'; });
    const d0 = new Date(t0 * 1000); d0.setHours(0, 0, 0, 0);
    for (let day = d0.getTime() / 1000; day <= t1; day += 86400) {
      const dayEnd = Math.min(day + 86400, t1);
      if (day > t0) { const gx = X(day); grid += '<line x1="' + gx.toFixed(1) + '" y1="' + padTop + '" x2="' + gx.toFixed(1) + '" y2="' + (H - padBot) + '" stroke="var(--border-soft)" stroke-width="1"/>'; }
      const midx = X(Math.max(day, t0) + (dayEnd - Math.max(day, t0)) / 2);
      const dd = new Date(day * 1000);
      const isToday = (day === s0);
      const dn = isToday ? 'Auj.' : dd.toLocaleDateString('fr-FR', { weekday: 'short' });
      if (dayEnd - Math.max(day, t0) > 7200) {
        grid += '<text x="' + midx.toFixed(1) + '" y="' + (H - 17) + '" text-anchor="middle" font-size="10" fill="var(--dim)">' + dn + '</text>' +
          '<text x="' + midx.toFixed(1) + '" y="' + (H - 5) + '" text-anchor="middle" font-size="9" fill="var(--faint)">' + dd.getDate() + '/' + (dd.getMonth() + 1) + '</text>';
      }
    }
    return '<svg viewBox="0 0 ' + W + ' ' + H + '">' + grid + '<path d="' + _area(wp, X, Y, H - padBot) + '" fill="var(--accent-tint)"/><polyline points="' + _poly(wp, X, Y) + '" fill="none" stroke="var(--accent)" stroke-width="1.8"/></svg>';
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Chargement des marées…</div></div>';
    try { const r = await sdk.api('/tides'); data = await r.json(); } catch (e) { data = null; }
    paint();
  }
  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🌊</div><div class="t1">Marées indisponibles</div><div class="t2">' + ((d && d.reason) || '') + ' — renseigne le port et la clé dans ⚙ Marée (inscription gratuite sur api-maree.fr).</div><button class="btnpill install" id="tdRetry" style="margin-top:14px">↻ Actualiser</button></div>';
      const rb = document.getElementById('tdRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile)); return;
    }
    const ptsToday = tPointsDay(d.points, 0), exToday = tExtremesDay(d.extremes, 0);
    const dLab = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    let h = '<div class="mrwrap"><div class="wsec mrhead">Marées du jour <span style="text-transform:none;letter-spacing:0;color:var(--dim);font-weight:400">· ' + dLab + ' · ' + (d.site || '') + '</span></div>';
    if (exToday.length) {
      h += '<div class="tdtop">' + tideClock(d.extremes) + '<div class="tdcol"><div class="tdlist">' + exToday.map(t => { const pm = t.type === 'PM';
        return '<div class="tdrow' + (pm ? '' : ' bm') + '"><span class="tdtag">' + t.type + '</span><span class="tdtime">' + tTime(t.dt) + '</span>' +
          '<span class="tdlabel">' + (pm ? 'Pleine Mer' : 'Basse Mer') + '</span>' +
          '<span class="tdinfo"><b>' + t.height + ' m</b></span></div>'; }).join('') + '</div></div></div>';
    } else h += '<div class="wpollen"><div class="wpill">Pas de données pour aujourd\'hui</div></div>';
    if (ptsToday.length) h += '<div class="wsec mrhead">Courbe de marée</div><div class="mrday">' + dayTideCurve(ptsToday, exToday) + '</div>';
    if (d.points && d.points.length) { h += '<div class="wsec mrhead">Marées de la semaine</div><div class="mrweek">' + weekTideCurve(d.points, d.extremes) + '</div>'; }
    h += '<div class="wsrc">Données : api-maree.fr — IFREMER / PREVIMER (CC-BY) · vue embarquée v0.3.0</div></div>';
    el.innerHTML = h;
  }
  return { render };
})();
