"""Addon Hetzner — Cloud (VPS/volumes) + Robot (dédiés) + Storage Box, sections à toggles."""

CLOUD = "https://api.hetzner.cloud/v1"
SBOX_API = "https://api.hetzner.com/v1"
ROBOT = "https://robot-ws.your-server.de"


def _cfg(cfg):
    m = (cfg or {}).get("modules", {}).get("hetzner", {}) if "modules" in (cfg or {}) else (cfg or {})
    tog = lambda k: m.get(k) is True or str(m.get(k)).lower() == "true"
    # Tokens par slot : name1/token1 .. name8/token8 (+ compat ancien champ cloud_token)
    tokens = []
    legacy = _parse_tokens(m.get("cloud_token") or "")
    tokens.extend(legacy)
    for i in range(1, 9):
        tok = (m.get(f"token{i}") or "").strip()
        if tok:
            name = (m.get(f"name{i}") or "").strip() or f"Projet {i}"
            tokens.append((name, tok))
    return {
        "cloud_on": tog("cloud_on"),
        "cloud_tokens": tokens,
        "robot_on": tog("robot_on"),
        "robot_user": (m.get("robot_user") or "").strip(),
        "robot_pass": (m.get("robot_pass") or "").strip(),
    }


def _parse_tokens(raw):
    """Accepte plusieurs tokens : séparés par virgule ou saut de ligne,
    chacun optionnellement préfixé 'nom=token'. Retourne [(nom, token)]."""
    out = []
    for part in raw.replace("\n", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "=" in part:
            name, tok = part.split("=", 1)
            out.append((name.strip(), tok.strip()))
        else:
            out.append((None, part))
    # nom par défaut = P1, P2… si non fourni
    return [(name or f"P{i+1}", tok) for i, (name, tok) in enumerate(out) if tok]


def _cloud_get(sdk, token, path, timeout=10):
    r = sdk.requests.get(CLOUD + path, timeout=timeout,
                         headers={"Authorization": "Bearer " + token})
    if r.status_code == 401:
        raise PermissionError("token Cloud invalide")
    r.raise_for_status()
    return r.json()


def _sbox_get(sdk, token, path, timeout=10):
    r = sdk.requests.get(SBOX_API + path, timeout=timeout,
                         headers={"Authorization": "Bearer " + token})
    if r.status_code == 401:
        raise PermissionError("token invalide (storage box)")
    r.raise_for_status()
    return r.json()


def _fmt_bytes_gb(n):
    """Octets -> (valeur, unité) lisible en Go ou To."""
    if not n:
        return 0, "Go"
    gb = n / (1024 ** 3)
    if gb >= 1024:
        return round(gb / 1024, 2), "To"
    return round(gb), "Go"


def _robot_get(sdk, user, pw, path, timeout=12):
    r = sdk.requests.get(ROBOT + path, timeout=timeout, auth=(user, pw))
    if r.status_code == 401:
        raise PermissionError("identifiants Robot invalides")
    if r.status_code == 404:
        return []  # aucun produit de ce type
    r.raise_for_status()
    return r.json()


def _monthly_price(server):
    """Prix mensuel brut du server_type dans la location du serveur."""
    try:
        st = server.get("server_type") or {}
        loc = ((server.get("datacenter") or {}).get("location") or {}).get("name")
        for p in st.get("prices") or []:
            if p.get("location") == loc:
                gross = (p.get("price_monthly") or {}).get("gross")
                return round(float(gross), 2) if gross else None
    except (TypeError, ValueError):
        pass
    return None


def _data(sdk, cfg):
    c = _cfg(cfg)
    if not (c["cloud_on"] or c["robot_on"]):
        return {"ok": False, "reason": "active au moins une section dans ⚙"}
    out = {"ok": True, "sections": []}

    if c["cloud_on"]:
        if not c["cloud_tokens"]:
            out["cloud_error"] = "aucun token Cloud renseigné"
        else:
            out["sections"].append("cloud")
            all_servers, all_vols, all_sboxes, proj_errors = [], [], [], []
            projects = []
            for pname, tok in c["cloud_tokens"]:
                try:
                    servers = _cloud_get(sdk, tok, "/servers").get("servers", [])
                except PermissionError:
                    proj_errors.append(f"{pname} : token invalide")
                    continue
                except Exception:
                    proj_errors.append(f"{pname} : injoignable")
                    continue
                pcost = round(sum(_monthly_price(s) or 0 for s in servers), 2)
                projects.append({"name": pname, "count": len(servers),
                                 "running": sum(1 for s in servers if s.get("status") == "running"),
                                 "cost": pcost})
                for s in servers:
                    all_servers.append({
                        "project": pname,
                        "name": s.get("name"),
                        "status": s.get("status"),
                        "type": (s.get("server_type") or {}).get("name"),
                        "cores": (s.get("server_type") or {}).get("cores"),
                        "ram": (s.get("server_type") or {}).get("memory"),
                        "disk": (s.get("server_type") or {}).get("disk"),
                        "ip": ((s.get("public_net") or {}).get("ipv4") or {}).get("ip"),
                        "dc": ((s.get("datacenter") or {}).get("location") or {}).get("city"),
                        "price": _monthly_price(s),
                    })
                try:
                    vols = _cloud_get(sdk, tok, "/volumes").get("volumes", [])
                    for v in vols:
                        all_vols.append({"project": pname, "name": v.get("name"),
                                         "size": v.get("size"), "server": v.get("server")})
                except Exception:
                    pass
                # Storage Boxes du projet (API api.hetzner.com, même token)
                try:
                    boxes = _sbox_get(sdk, tok, "/storage_boxes").get("storage_boxes", [])
                    for b in boxes:
                        typ = b.get("storage_box_type") or {}
                        st = b.get("stats") or {}
                        used = st.get("size_data") or st.get("size") or 0
                        total = typ.get("size") or 0
                        uv, uu = _fmt_bytes_gb(used)
                        tv, tu = _fmt_bytes_gb(total)
                        all_sboxes.append({
                            "project": pname,
                            "name": b.get("name") or ("SB" + str(b.get("id"))),
                            "id": b.get("id"),
                            "type": (typ.get("name") or "").upper(),
                            "username": b.get("username"),
                            "status": b.get("status"),
                            "city": (b.get("location") or {}).get("city"),
                            "country": (b.get("location") or {}).get("country"),
                            "used": used, "total": total,
                            "used_h": f"{uv} {uu}", "total_h": f"{tv} {tu}",
                            "pct": round(used / total * 100) if total else 0,
                        })
                except PermissionError:
                    pass
                except Exception:
                    pass
            out["cloud_projects"] = projects
            out["cloud_count"] = len(all_servers)
            out["cloud_running"] = sum(1 for s in all_servers if s.get("status") == "running")
            out["cloud_cost"] = round(sum(s.get("price") or 0 for s in all_servers), 2)
            out["cloud"] = all_servers
            out["volumes"] = all_vols
            if all_sboxes:
                out["sbox"] = all_sboxes
                out["sbox_total"] = len(all_sboxes)
            if proj_errors:
                out["cloud_error"] = " · ".join(proj_errors)

    if c["robot_on"]:
        if not (c["robot_user"] and c["robot_pass"]):
            out["robot_error"] = "identifiants Robot (webservice) manquants"
        else:
            try:
                lst = _robot_get(sdk, c["robot_user"], c["robot_pass"], "/server")
                servers = [x.get("server", x) for x in (lst if isinstance(lst, list) else [])]
                out["sections"].append("robot")
                out["robot_count"] = len(servers)
                out["robot"] = [{
                    "name": s.get("server_name") or s.get("server_ip"),
                    "ip": s.get("server_ip"),
                    "product": s.get("product"),
                    "dc": s.get("dc"),
                    "status": s.get("status"),
                    "paid_until": s.get("paid_until"),
                } for s in servers]
            except PermissionError:
                out["robot_error"] = "identifiants Robot invalides"
            except Exception:
                out["robot_error"] = "lecture serveurs dédiés impossible"

    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("addon_hetzner", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except PermissionError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": f"connexion : {type(e).__name__}"[:100]})
        except Exception as e:
            sdk.log.exception("hetzner")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    c = _cfg(cfg)
    msgs = []
    try:
        if c["cloud_on"] and c["cloud_tokens"]:
            total = 0
            for pname, tok in c["cloud_tokens"]:
                d = _cloud_get(sdk, tok, "/servers", timeout=6)
                total += len(d.get("servers", []))
            msgs.append(f"Cloud : {total} serveur(s) sur {len(c['cloud_tokens'])} projet(s)")
        if (c["robot_on"] or c["sbox_on"]) and c["robot_user"]:
            lst = _robot_get(sdk, c["robot_user"], c["robot_pass"], "/server", timeout=8)
            msgs.append(f"Robot : {len(lst) if isinstance(lst, list) else 0} dédié(s)")
    except PermissionError as e:
        return False, str(e)
    except Exception as e:
        return False, f"{type(e).__name__}"[:60]
    if not msgs:
        return False, "aucune section activée/configurée"
    return True, " · ".join(msgs)
