/* Hetzner — Cloud, dédiés, Storage Box : sections selon config. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.hetzner = (function () {
  let S = null, root = null, tile = null, data = null;
  const ACCENT = '#d50c2d';
  const CSS =
    "  .hzwrap{flex:1;display:flex;flex-direction:column;min-height:0;--hz:" + ACCENT + "}\n" +
    "  .hzhead{display:flex;align-items:center;gap:20px;padding:18px 26px 14px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .hztotals{display:flex;gap:26px;flex-wrap:wrap}\n" +
    "  .hztk{text-align:left;display:flex;flex-direction:column}\n" +
    "  .hztk b{font-size:28px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums;color:var(--hz)}\n" +
    "  .hztk.ok b{color:var(--green)}\n" +
    "  .hztk span{font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:.05em;margin-top:5px}\n" +
    "  .hzcost{margin-left:auto;text-align:right}\n" +
    "  .hzcost b{font-size:24px;font-weight:800;color:var(--fg);font-variant-numeric:tabular-nums}\n" +
    "  .hzcost span{display:block;font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:.05em;margin-top:4px}\n" +
    "  .hzscroll{flex:1;min-height:0;overflow:auto;padding:18px 26px 24px}\n" +
    "  .hzsec{font-size:13px;font-weight:800;color:var(--fg);letter-spacing:.02em;margin:22px 0 12px;display:flex;align-items:center;gap:9px}\n" +
    "  .hzsec:first-child{margin-top:0}\n" +
    "  .hzsec .ic{font-size:17px}\n" +
    "  .hzsec .c{background:var(--hz);color:#fff;font-size:11px;font-weight:700;border-radius:20px;padding:1px 9px;min-width:20px;text-align:center}\n" +
    "  .hzsec .projs{margin-left:auto;font-size:11px;font-weight:400;color:var(--dim);letter-spacing:0}\n" +
    "  .hzprojbar{display:flex;flex-wrap:wrap;gap:7px;margin:-4px 0 14px}\n" +
    "  .hzprojpill{font-size:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:8px;padding:4px 11px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .hzprojpill b{color:var(--hz);font-weight:700}\n" +
    "  .hzgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}\n" +
    "  .hzcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:14px;padding:15px 17px;display:flex;flex-direction:column;gap:11px;transition:border-color .15s}\n" +
    "  .hzcard:hover{border-color:var(--hz)}\n" +
    "  .hzchead{display:flex;align-items:center;gap:10px}\n" +
    "  .hzdot{width:11px;height:11px;border-radius:50%;background:var(--green);flex:none;box-shadow:0 0 0 3px color-mix(in srgb,var(--green) 22%,transparent)}\n" +
    "  .hzdot.off{background:var(--bad);box-shadow:0 0 0 3px color-mix(in srgb,var(--bad) 22%,transparent)}\n" +
    "  .hzname{font-weight:800;font-size:16px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .hzprice{font-size:15px;font-weight:800;color:var(--hz);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .hztype{font-size:11px;font-weight:700;color:var(--dim);flex:none;text-transform:uppercase;letter-spacing:.03em}\n" +
    "  .hzchips{display:flex;flex-wrap:wrap;gap:6px}\n" +
    "  .hzchip{font-size:11.5px;background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:3px 9px;color:var(--fg);font-variant-numeric:tabular-nums}\n" +
    "  .hzchip.proj{color:#fff;background:var(--hz);border-color:var(--hz);font-weight:600}\n" +
    "  .hzchip.dim{color:var(--dim)}\n" +
    "  .hzspecs{display:flex;gap:16px;flex-wrap:wrap}\n" +
    "  .hzspec{display:flex;flex-direction:column;gap:2px}\n" +
    "  .hzspec b{font-size:14px;font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .hzspec span{font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}\n" +
    "  .hzfoot{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--dim);border-top:1px solid var(--border-soft);padding-top:9px;font-variant-numeric:tabular-nums}\n" +
    "  .hzbar{height:9px;border-radius:6px;background:var(--bg);overflow:hidden}\n" +
    "  .hzbar>i{display:block;height:100%;border-radius:6px;transition:width .3s}\n" +
    "  .hzbarrow{display:flex;justify-content:space-between;align-items:baseline;font-size:12.5px}\n" +
    "  .hzbarrow b{font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .hzbarpct{font-weight:800;font-variant-numeric:tabular-nums}\n" +
    "  .hzerr{font-size:12.5px;color:var(--warn);background:color-mix(in srgb,var(--warn) 9%,transparent);border:1px solid color-mix(in srgb,var(--warn) 30%,transparent);border-radius:10px;padding:10px 14px;margin-bottom:12px}\n" +
    "  .hzempty{color:var(--dim);font-size:13px;padding:10px 0}\n";
  function ensureCss() { if (document.getElementById('hzUiCss')) return; const s = document.createElement('style'); s.id = 'hzUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Hetzner…</div></div>';
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function cloudCard(s) {
    return '<div class="hzcard"><div class="hzchead">' +
      '<span class="hzdot' + (s.status === 'running' ? '' : ' off') + '"></span>' +
      '<span class="hzname">' + esc(s.name) + '</span>' +
      (s.type ? '<span class="hztype">' + esc(s.type) + '</span>' : '') +
      (s.price ? '<span class="hzprice">' + s.price.toFixed(2) + ' €</span>' : '') + '</div>' +
      '<div class="hzspecs">' +
      (s.cores ? '<div class="hzspec"><b>' + s.cores + '</b><span>vCPU</span></div>' : '') +
      (s.ram ? '<div class="hzspec"><b>' + s.ram + ' Go</b><span>RAM</span></div>' : '') +
      (s.disk ? '<div class="hzspec"><b>' + s.disk + ' Go</b><span>disque</span></div>' : '') +
      '</div>' +
      '<div class="hzchips">' +
      (s.project ? '<span class="hzchip proj">' + esc(s.project) + '</span>' : '') +
      (s.dc ? '<span class="hzchip">📍 ' + esc(s.dc) + '</span>' : '') +
      '</div>' +
      '<div class="hzfoot"><span class="hzdot' + (s.status === 'running' ? '' : ' off') + '" style="box-shadow:none;width:8px;height:8px"></span>' +
      esc(s.ip || '') + ' · ' + esc(s.status || '') + '</div></div>';
  }
  function robotCard(s) {
    return '<div class="hzcard"><div class="hzchead">' +
      '<span class="hzdot' + ((s.status || 'ready') === 'ready' ? '' : ' off') + '"></span>' +
      '<span class="hzname">' + esc(s.name) + '</span>' +
      (s.product ? '<span class="hztype">' + esc(s.product) + '</span>' : '') + '</div>' +
      '<div class="hzchips">' +
      (s.dc ? '<span class="hzchip">📍 ' + esc(s.dc) + '</span>' : '') +
      (s.paid_until ? '<span class="hzchip dim">payé → ' + esc(s.paid_until) + '</span>' : '') +
      '</div>' +
      '<div class="hzfoot">' + esc(s.ip || '') + '</div></div>';
  }
  function flag(cc) {
    if (!cc || cc.length !== 2) return '';
    return String.fromCodePoint(...[...cc.toUpperCase()].map(c => 0x1F1E6 + c.charCodeAt(0) - 65));
  }
  function sboxCard(b) {
    const pct = b.pct || 0;
    const col = pct >= 90 ? 'var(--bad)' : (pct >= 75 ? 'var(--warn)' : 'var(--hz)');
    return '<div class="hzcard"><div class="hzchead">' +
      '<span class="hzname">🗄 ' + esc(b.name) + '</span>' +
      (b.type ? '<span class="hztype">' + esc(b.type) + '</span>' : '') + '</div>' +
      '<div class="hzbarrow"><b>' + esc(b.used_h) + ' <span style="color:var(--dim);font-weight:400">/ ' + esc(b.total_h) + '</span></b>' +
      '<span class="hzbarpct" style="color:' + col + '">' + pct + '%</span></div>' +
      '<div class="hzbar"><i style="width:' + pct + '%;background:' + col + '"></i></div>' +
      '<div class="hzchips">' +
      (b.project ? '<span class="hzchip proj">' + esc(b.project) + '</span>' : '') +
      (b.username ? '<span class="hzchip dim">' + esc(b.username) + '</span>' : '') +
      (b.city ? '<span class="hzchip">' + flag(b.country) + ' ' + esc(b.city) + '</span>' : '') +
      '</div></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🔴</div><div class="t1">Hetzner indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Active les sections et renseigne les accès dans ⚙.</div>' +
        '<button class="btnpill install" id="hzRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('hzRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    // En-tête
    let h = '<div class="hzwrap"><div class="hzhead"><div class="hztotals">';
    if (d.cloud_count != null) {
      h += '<div class="hztk"><b>' + nf(d.cloud_count) + '</b><span>serveurs cloud</span></div>' +
        '<div class="hztk ok"><b>' + nf(d.cloud_running) + '</b><span>actifs</span></div>';
    }
    if (d.sbox && d.sbox.length) h += '<div class="hztk"><b>' + d.sbox.length + '</b><span>storage box</span></div>';
    if (d.robot_count != null) h += '<div class="hztk"><b>' + nf(d.robot_count) + '</b><span>dédiés</span></div>';
    h += '</div>';
    if (d.cloud_cost) h += '<div class="hzcost"><b>' + d.cloud_cost.toFixed(2) + ' €</b><span>par mois</span></div>';
    h += '</div><div class="hzscroll">';

    for (const k of ['cloud_error', 'robot_error']) {
      if (d[k]) h += '<div class="hzerr">⚠ ' + esc(d[k]) + '</div>';
    }

    // Serveurs Cloud
    if (d.cloud) {
      h += '<div class="hzsec"><span class="ic">☁️</span> Serveurs Cloud <span class="c">' + nf(d.cloud_count) + '</span>' +
        (d.cloud_projects && d.cloud_projects.length > 1 ? '<span class="projs">' + d.cloud_projects.length + ' projets</span>' : '') + '</div>';
      if (d.cloud_projects && d.cloud_projects.length > 1) {
        h += '<div class="hzprojbar">' + d.cloud_projects.map(p =>
          '<span class="hzprojpill"><b>' + esc(p.name) + '</b> · ' + p.running + '/' + p.count +
          (p.cost ? ' · ' + p.cost.toFixed(2) + ' €' : '') + '</span>').join('') + '</div>';
      }
      h += d.cloud.length ? '<div class="hzgrid">' + d.cloud.map(cloudCard).join('') + '</div>' : '<div class="hzempty">Aucun serveur.</div>';
      if (d.volumes && d.volumes.length) {
        h += '<div class="hzchips" style="margin-top:12px">' +
          d.volumes.map(v => '<span class="hzchip">💾 ' + esc(v.name) + ' · ' + v.size + ' Go</span>').join('') + '</div>';
      }
    }
    // Storage Boxes
    if (d.sbox && d.sbox.length) {
      h += '<div class="hzsec"><span class="ic">🗄</span> Storage Boxes <span class="c">' + d.sbox.length + '</span></div>';
      h += '<div class="hzgrid">' + d.sbox.map(sboxCard).join('') + '</div>';
    }
    // Dédiés
    if (d.robot) {
      h += '<div class="hzsec"><span class="ic">🖥</span> Serveurs dédiés <span class="c">' + nf(d.robot_count) + '</span></div>';
      h += d.robot.length ? '<div class="hzgrid">' + d.robot.map(robotCard).join('') + '</div>' : '<div class="hzempty">Aucun dédié.</div>';
    }
    h += '</div></div>';
    el.innerHTML = h;
  }

    return { render };
})();
