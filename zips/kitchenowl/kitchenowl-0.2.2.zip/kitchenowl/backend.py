"""Addon « kitchenowl » — fournisseur de service (lot F).

Service *headless* (aucune tuile) : il concentre la connexion KitchenOwl
(Marmotte) autrefois dupliquée entre les 5 addons cuisine, et l'expose via
``provide(sdk)``. Les addons cuisine (stock/congelateur/courses/recettes/
repas) le consommeront au lot G en déclarant ``requires: ["kitchenowl"]``
puis ``sdk.use("kitchenowl")``.

Config propre au service (bac à sable respecté) : ``url``, ``token``,
``household``. Renseignable via panda-cfg.py ; migrée automatiquement au boot
depuis l'ancien emplacement (un des 5 addons cuisine) par le noyau.

Lot F1 (ce fichier) : config, helpers bas niveau (get/post/household/ctx) et
les 5 lectures (view). Lot F2 : les méthodes d'écriture (item/recipe/planner).

Cache : ``sdk.cache`` (par worker) + un fichier d'horodatage partagé dans
``sdk.data_dir/.stamp`` pour invalider le cache de TOUS les workers gunicorn
après une écriture (chaque worker a son propre cache mémoire).
"""
import os
import time
import unicodedata
from datetime import datetime, timezone


class KitchenOwlAPI:
    """API publique du hub KitchenOwl. Capture le SDK du fournisseur : config,
    cache et data_dir sont ceux de « kitchenowl », jamais du consommateur."""

    def __init__(self, sdk):
        self._sdk = sdk
        self._stamp_file = os.path.join(sdk.data_dir, ".stamp")

    # ------------------------------------------------------------------ config
    def cfg(self):
        """(url, token, want) depuis la config du service. url None si vide."""
        c = self._sdk.config()
        url = (c.get("url") or "").strip().rstrip("/")
        token = (c.get("token") or "").strip()
        want = c.get("household") or ""
        if not (url and token):
            return None, None, None
        return url, token, want

    # ------------------------------------------------------- cache multi-worker
    def _stamp(self):
        try:
            return os.path.getmtime(self._stamp_file)
        except OSError:
            return 0.0

    def invalidate(self):
        """Signale une écriture à tous les workers (touche le fichier stamp)."""
        try:
            with open(self._stamp_file, "w") as f:
                f.write(str(time.time()))
        except OSError:
            pass

    def _cached(self, key, max_age):
        rec = self._sdk.cache_get(key, max_age)
        if rec is not None and rec[0] > self._stamp():
            return rec[1]
        return None

    def _store(self, key, value):
        self._sdk.cache_set(key, (time.time(), value))
        return value

    # -------------------------------------------------------------- HTTP bas niveau
    def get(self, path):
        url, token, _ = self.cfg()
        if not url:
            raise RuntimeError("KitchenOwl non configuré")
        r = self._sdk.requests.get(
            f"{url}/api{path}",
            headers={"Authorization": f"Bearer {token}"}, timeout=10)
        if r.status_code == 401:
            raise RuntimeError("jeton refusé (401)")
        if r.status_code == 404:
            raise RuntimeError(f"introuvable ({path})")
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}")
        return r.json()

    def post(self, path, payload=None, method="POST"):
        url, token, _ = self.cfg()
        if not url:
            raise RuntimeError("KitchenOwl non configuré")
        r = self._sdk.requests.request(
            method, f"{url}/api{path}", json=payload or {},
            headers={"Authorization": f"Bearer {token}"}, timeout=10)
        if r.status_code == 401:
            raise RuntimeError("jeton refusé (401)")
        if r.status_code not in (200, 201, 204):
            raise RuntimeError(f"HTTP {r.status_code}")
        try:
            return r.json()
        except ValueError:
            return {}

    def household(self):
        """Maison KitchenOwl visée (cache 600 s). Lève si ambiguë/absente."""
        url, token, want = self.cfg()
        if not url:
            raise RuntimeError("KitchenOwl non configuré")
        ck = f"hh:{url}"
        hhs = self._sdk.cache_get(ck, 600)
        if hhs is None:
            hhs = self.get("/household")
            self._sdk.cache_set(ck, hhs)
        if not hhs:
            raise RuntimeError("aucune maison (household) dans KitchenOwl")
        if want:
            for h in hhs:
                if (str(h.get("id")) == str(want)
                        or (h.get("name") or "").strip().lower() == want.strip().lower()):
                    return h
            noms = ", ".join(f"{h.get('name')} (id {h.get('id')})" for h in hhs)
            raise RuntimeError(f"maison « {want} » introuvable. Disponibles : {noms}")
        if len(hhs) > 1:
            noms = ", ".join(f"{h.get('name')} (id {h.get('id')})" for h in hhs)
            raise RuntimeError(f"plusieurs maisons : précise laquelle (⚙) ({noms})")
        return hhs[0]

    def ctx(self):
        """(url, token, household_id) — raccourci pour les écritures (lot F2)."""
        url, token, _ = self.cfg()
        if not url:
            raise RuntimeError("KitchenOwl non configuré")
        return url, token, self.household()["id"]

    # ----------------------------------------------------------------- dates
    @staticmethod
    def parse_date(v):
        """cooking_date KitchenOwl (« Wed, 15 Jul 2026 … », ISO, epoch) -> date|None."""
        if v in (None, ""):
            return None
        if isinstance(v, (int, float)):
            try:
                return datetime.fromtimestamp(
                    v / 1000 if v > 1e11 else v, timezone.utc).date()
            except (OverflowError, OSError, ValueError):
                return None
        txt = str(v)
        try:
            return datetime.fromisoformat(txt.replace("Z", "+00:00")).date()
        except ValueError:
            pass
        import re
        m = re.search(r"\b(\d{4})\b", txt)
        if m and int(m.group(1)) < 1900:
            return None
        try:
            from email.utils import parsedate_to_datetime
            d = parsedate_to_datetime(txt).date()
            return d if d.year >= 1900 else None
        except (TypeError, ValueError, IndexError):
            return None

    @staticmethod
    def date_ms(ymd):
        """« 2026-07-14 » -> epoch ms à 12 h UTC (planner, lot F2)."""
        d = datetime.strptime(ymd, "%Y-%m-%d").replace(hour=12, tzinfo=timezone.utc)
        return int(d.timestamp() * 1000)

    # ------------------------------------------------------------- LECTURES
    def view(self, kind, **opts):
        """Vue d'un module cuisine (courses/stock/congelateur/recettes/repas).

        ``opts`` porte les réglages spécifiques au consommateur — actuellement
        ``category`` (filtre du congélateur), que l'addon congelateur passera
        depuis SA propre config au lot G.
        """
        url, token, _ = self.cfg()
        if not url:
            return {"ok": False, "reason": "URL/jeton KitchenOwl non configurés"}
        ck = f"view:{kind}:{url}"
        hit = self._cached(ck, 60)
        if hit is not None:
            return hit
        try:
            hh = self.household()
            hid = hh.get("id")
            out = {"ok": True, "household": hh.get("name", "")}
            if kind == "courses":
                items, lists = [], self.get(f"/household/{hid}/shoppinglist") or []
                for sl in lists:
                    for it in self.get(f"/shoppinglist/{sl['id']}/items") or []:
                        items.append({"id": it.get("id"), "name": it.get("name", "?"),
                                      "desc": it.get("description") or "",
                                      "list": sl.get("name", ""), "list_id": sl.get("id")})
                items.sort(key=lambda x: x["name"].lower())
                out["items"] = items
                out["lists"] = [{"id": sl.get("id"), "name": sl.get("name")} for sl in lists]
                out["default_list"] = lists[0]["id"] if lists else None
            elif kind in ("stock", "congelateur"):
                items = []
                for it in self.get(f"/household/{hid}/item") or []:
                    c0 = it.get("category") or {}
                    items.append({"id": it.get("id"), "name": it.get("name", "?"),
                                  "category": c0.get("name", "") or "Sans catégorie",
                                  "category_id": c0.get("id"),
                                  "desc": it.get("description") or ""})
                try:
                    cats = self.get(f"/household/{hid}/category") or []
                    out["categories"] = [{"id": c2.get("id"), "name": c2.get("name")}
                                         for c2 in cats]
                except RuntimeError:
                    out["categories"] = []
                if kind == "congelateur":
                    def _n(x):
                        return unicodedata.normalize("NFKD", x or "").encode(
                            "ascii", "ignore").decode().lower()
                    wanted = _n(opts.get("category") or "")

                    def _match(cat):
                        c = _n(cat)
                        return (wanted in c) if wanted else ("congel" in c or "surgel" in c)
                    items = [x for x in items if _match(x["category"])]
                items.sort(key=lambda x: (x["category"].lower(), x["name"].lower()))
                out["items"] = items
            elif kind == "recettes":
                rc = self.get(f"/household/{hid}/recipe") or []

                def _tags(r):
                    res = []
                    for t in (r.get("tags") or []):
                        n = t.get("name") if isinstance(t, dict) else str(t)
                        if n:
                            res.append(n)
                    return res
                out["items"] = sorted(
                    [{"id": r.get("id"), "name": r.get("name", "?"),
                      "time": r.get("time") or 0, "yields": r.get("yields") or 0,
                      "photo": r.get("photo") or "", "tags": _tags(r),
                      "desc": (r.get("description") or "")[:90]} for r in rc],
                    key=lambda x: x["name"].lower())
                vus = []
                for it in out["items"]:
                    for t in it["tags"]:
                        if t not in vus:
                            vus.append(t)
                out["tags"] = sorted(vus, key=str.lower)
            elif kind == "repas":
                pl = self.get(f"/household/{hid}/planner") or []
                items = []
                for p in pl:
                    r = p.get("recipe") or {}
                    d0 = self.parse_date(p.get("cooking_date"))
                    planned = bool(d0 and d0.year >= 1900)
                    items.append({"recipe_id": r.get("id"), "name": r.get("name", "?"),
                                  "photo": r.get("photo") or "", "time": r.get("time") or 0,
                                  "yields": p.get("yields") or r.get("yields") or 0,
                                  "date": d0.isoformat() if planned else "",
                                  "day": p.get("day") if p.get("day") not in (None, -1) else None})
                out["items"] = items
                out["planned"] = [x for x in items if x["date"]]
                out["backlog"] = [x for x in items if not x["date"]]
                try:
                    rc = self.get(f"/household/{hid}/recipe") or []
                    out["recipes"] = sorted(
                        [{"id": r.get("id"), "name": r.get("name", "?"),
                          "photo": r.get("photo") or "", "time": r.get("time") or 0,
                          "yields": r.get("yields") or 0} for r in rc],
                        key=lambda x: x["name"].lower())
                except RuntimeError:
                    out["recipes"] = []
            else:
                return {"ok": False, "reason": "module inconnu"}
        except RuntimeError as e:
            return {"ok": False, "reason": str(e)}
        except self._sdk.requests.exceptions.RequestException as e:
            return {"ok": False, "reason": type(e).__name__}
        except (ValueError, KeyError, TypeError) as e:
            return {"ok": False, "reason": f"réponse invalide ({type(e).__name__})"}
        return self._store(ck, out)

    # ------------------------------------------------------------- ÉCRITURES (F2)
    # Chaque méthode renvoie un dict {ok: bool, ...} homogène avec les anciennes
    # routes noyau, pour que le lot G ne soit qu'une délégation. Les *_raw et
    # get/find/photo_fetch sont des briques bas niveau (peuvent lever/retourner
    # None) pour l'orchestration côté consommateur (ex. corbeille recettes).

    def item_add(self, name, category_id=None):
        name = (name or "").strip()[:80]
        if not name:
            return {"ok": False, "reason": "nom vide"}
        try:
            url, token, hid = self.ctx()
            it = self.post(f"/household/{hid}/item", {"name": name})
            if category_id and it.get("id"):
                self.post(f"/item/{it['id']}", {"category": category_id})
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def item_category(self, item_id, category_id):
        if not item_id:
            return {"ok": False, "reason": "article manquant"}
        try:
            url, token, _ = self.ctx()
            self.post(f"/item/{item_id}", {"category": category_id})
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def item_delete(self, item_id):
        if not item_id:
            return {"ok": False, "reason": "article manquant"}
        try:
            url, token, _ = self.ctx()
            self.post(f"/item/{item_id}", method="DELETE")
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def category_add(self, name):
        name = (name or "").strip()[:40]
        if not name:
            return {"ok": False, "reason": "nom vide"}
        try:
            url, token, hid = self.ctx()
            self.post(f"/household/{hid}/category", {"name": name})
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def courses_add(self, name, list_id=None):
        name = (name or "").strip()[:80]
        if not name:
            return {"ok": False, "reason": "nom vide"}
        url, token, _ = self.cfg()
        if not url:
            return {"ok": False, "reason": "KitchenOwl non configuré"}
        try:
            hh = self.household()
            lists = self.get(f"/household/{hh['id']}/shoppinglist") or []
            lid = list_id or (lists[0]["id"] if lists else None)
            if not lid:
                return {"ok": False, "reason": "aucune liste de courses"}
            self.post(f"/shoppinglist/{lid}/add-item-by-name", {"name": name})
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def courses_remove(self, item_id, list_id=None):
        if not item_id:
            return {"ok": False, "reason": "article manquant"}
        url, token, want = self.cfg()
        if not url:
            return {"ok": False, "reason": "KitchenOwl non configuré"}
        try:
            lid = list_id
            if not lid:
                hh = self.household()
                lists = self.get(f"/household/{hh['id']}/shoppinglist") or []
                lid = lists[0]["id"] if lists else None
            errs = []
            for meth, path, payload in (
                    ("DELETE", f"/shoppinglist/{lid}/item", {"item_id": item_id}),
                    ("POST", f"/shoppinglist/{lid}/remove-item", {"item_id": item_id}),
                    ("DELETE", f"/shoppinglist/{lid}/item/{item_id}", None)):
                try:
                    self.post(path, payload, method=meth)
                    self.invalidate()
                    return {"ok": True}
                except RuntimeError as e:
                    errs.append(f"{meth} {path}: {e}")
            return {"ok": False, "reason": " · ".join(errs)}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def recipe_scrape(self, src):
        import re
        src = (src or "").strip()[:500]
        if not re.match(r"^https?://[\w.-]+/", src):
            return {"ok": False, "reason": "URL invalide"}
        try:
            url, token, hid = self.ctx()
            data, errs = None, []
            for path in (f"/household/{hid}/recipe/scrape", "/recipe/scrape"):
                try:
                    r = self._sdk.requests.get(
                        f"{url}/api{path}", params={"url": src},
                        headers={"Authorization": f"Bearer {token}"}, timeout=25)
                    if r.status_code == 200:
                        data = r.json()
                        break
                    errs.append(f"{path}: HTTP {r.status_code}")
                except (self._sdk.requests.exceptions.RequestException, ValueError) as e:
                    errs.append(f"{path}: {type(e).__name__}")
            if data is None:
                return {"ok": False, "reason": "extraction impossible · " + " · ".join(errs)}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}
        raw = data.get("recipe") or data
        items = raw.get("items") or data.get("items") or {}
        if isinstance(items, dict):
            noms = list(items.keys())
        elif isinstance(items, list):
            noms = [(x.get("name") if isinstance(x, dict) else str(x)) for x in items]
        else:
            noms = []
        photo = ""
        for k in ("photo", "image", "image_url", "picture", "thumbnail"):
            v = raw.get(k) or data.get(k)
            if v and isinstance(v, str) and v.startswith("http"):
                photo = v
                break
        return {"ok": True, "name": raw.get("name") or "",
                "description": (raw.get("description") or "")[:2000],
                "time": raw.get("time") or 0, "yields": raw.get("yields") or 0,
                "source": raw.get("source") or src, "photo": photo,
                "items": noms[:40], "raw": raw}

    def find_recipe(self, name):
        """Recette existante de même nom (insensible à la casse) ou None."""
        try:
            url, token, hid = self.ctx()
            rc = self.get(f"/household/{hid}/recipe") or []
        except RuntimeError:
            return None
        n = (name or "").strip().lower()
        for r in rc:
            if (r.get("name") or "").strip().lower() == n:
                return r
        return None

    def recipe_get(self, rid):
        """Détail d'une recette (essaie /recipe puis /household/…/recipe). None si absente."""
        url, token, hid = self.ctx()
        for path in (f"/recipe/{rid}", f"/household/{hid}/recipe/{rid}"):
            try:
                detail = self.get(path)
                if detail:
                    return detail
            except RuntimeError:
                continue
        return None

    def recipe_create(self, payload):
        """Crée une recette (utilisé aussi pour restaurer). {ok, ...}."""
        try:
            url, token, hid = self.ctx()
            errs = []
            for path in (f"/household/{hid}/recipe", "/recipe"):
                try:
                    self.post(path, payload)
                    self.invalidate()
                    return {"ok": True, "name": payload.get("name", "")}
                except RuntimeError as e:
                    errs.append(f"{path}: {e}")
            return {"ok": False, "reason": " · ".join(errs)}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def recipe_delete_raw(self, rid):
        """Supprime une recette SANS archivage (l'archivage corbeille est
        orchestré par l'addon recettes au lot G). {ok, ...}."""
        try:
            url, token, hid = self.ctx()
            errs = []
            for meth, path in (("DELETE", f"/recipe/{rid}"),
                               ("DELETE", f"/household/{hid}/recipe/{rid}")):
                try:
                    self.post(path, None, method=meth)
                    self.invalidate()
                    return {"ok": True}
                except RuntimeError as e:
                    errs.append(f"{meth} {path}: {e}")
            return {"ok": False, "reason": " · ".join(errs)}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def recipe_add(self, data, mode=""):
        """Crée une recette depuis des données extraites. Gère le conflit de nom
        (mode « » = signale, « replace » = écrase, « duplicate » = force)."""
        raw = data.get("raw") or {}
        name = (data.get("name") or raw.get("name") or "").strip()[:120]
        if not name:
            return {"ok": False, "reason": "nom manquant"}
        payload = {
            "name": name,
            "description": (data.get("description") or raw.get("description") or "")[:5000],
            "time": int(data.get("time") or raw.get("time") or 0),
            "yields": int(data.get("yields") or raw.get("yields") or 0),
            "source": (data.get("source") or raw.get("source") or "")[:400],
        }
        photo = (data.get("photo") or raw.get("photo") or raw.get("image") or "")[:500]
        if photo.startswith("http"):
            payload["photo"] = photo
        tg = data.get("tags") or raw.get("tags") or []
        noms = [(t.get("name") if isinstance(t, dict) else str(t)) for t in tg]
        noms = [n.strip()[:40] for n in noms if n and n.strip()]
        if noms:
            payload["tags"] = noms[:8]
        items = raw.get("items") or {}
        if isinstance(items, dict):
            payload["items"] = [
                {"name": k.strip(),
                 "description": (v.get("description", "") if isinstance(v, dict) else "")}
                for k, v in items.items() if k and k.strip()]
        elif isinstance(items, list):
            tmp = []
            for x in items:
                n = (x.get("name") if isinstance(x, dict) else str(x)) or ""
                if n.strip():
                    tmp.append({"name": n.strip(),
                                "description": (x.get("description", "")
                                                if isinstance(x, dict) else "")})
            payload["items"] = tmp
        try:
            url, token, hid = self.ctx()
            existing = self.find_recipe(name)
            if existing and not mode:
                return {"ok": False, "conflict": True,
                        "existing_id": existing.get("id"),
                        "reason": f"« {name} » existe déjà"}
            if existing and mode == "replace":
                rid = existing.get("id")
                try:
                    self.post(f"/recipe/{rid}", payload, method="POST")
                    self.invalidate()
                    return {"ok": True, "name": name, "replaced": True}
                except RuntimeError as e:
                    return {"ok": False, "reason": f"remplacement impossible · /recipe/{rid}: {e}"}
            return self.recipe_create(payload)
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def recipe_tag(self, rid, tags):
        if not rid or not isinstance(tags, list):
            return {"ok": False, "reason": "recette ou étiquettes manquantes"}
        tags = [str(t).strip()[:40] for t in tags if str(t).strip()][:8]
        try:
            detail = self.recipe_get(rid)
            if not detail:
                return {"ok": False, "reason": "recette introuvable"}
            try:
                self.post(f"/recipe/{rid}", {"tags": tags}, method="POST")
                self.invalidate()
                return {"ok": True, "tags": tags}
            except RuntimeError as e:
                return {"ok": False, "reason": f"/recipe/{rid}: {e}"}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException, KeyError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def planner_add(self, recipe_id, date="", yields=None):
        import re
        ymd = (date or "").strip()
        if recipe_id is None:
            return {"ok": False, "reason": "recette manquante"}
        if ymd and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", ymd):
            return {"ok": False, "reason": "date invalide"}
        try:
            url, token, hid = self.ctx()
            payload = {"recipe_id": int(recipe_id)}
            if ymd:
                payload["cooking_date"] = self.date_ms(ymd)
            if yields:
                payload["yields"] = int(yields)
            try:
                self.post(f"/household/{hid}/planner/recipe", payload)
            except RuntimeError as e:
                if not ymd:
                    raise
                legacy = {"recipe_id": int(recipe_id),
                          "day": datetime.strptime(ymd, "%Y-%m-%d").weekday()}
                if yields:
                    legacy["yields"] = int(yields)
                try:
                    self.post(f"/household/{hid}/planner/recipe", legacy)
                except RuntimeError:
                    raise e
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException,
                KeyError, ValueError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def planner_remove(self, recipe_id, date=""):
        import re
        ymd = (date or "").strip()
        if recipe_id is None:
            return {"ok": False, "reason": "recette manquante"}
        if ymd and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", ymd):
            return {"ok": False, "reason": "date invalide"}
        try:
            url, token, hid = self.ctx()
            payload = {"cooking_date": self.date_ms(ymd)} if ymd else {}
            path = f"/household/{hid}/planner/recipe/{int(recipe_id)}"
            try:
                self.post(path, payload, method="DELETE")
            except RuntimeError as e:
                if not ymd:
                    raise
                legacy = {"day": datetime.strptime(ymd, "%Y-%m-%d").weekday()}
                try:
                    self.post(path, legacy, method="DELETE")
                except RuntimeError:
                    raise e
            self.invalidate()
            return {"ok": True}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException,
                KeyError, ValueError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def planner_shop(self, recipe_id, list_id=None):
        if recipe_id is None:
            return {"ok": False, "reason": "recette manquante"}
        try:
            url, token, hid = self.ctx()
            rec = self.get(f"/recipe/{int(recipe_id)}") or {}
            items = [it for it in (rec.get("items") or []) if it.get("id")]
            if not items:
                return {"ok": False, "reason": "cette recette n'a aucun ingrédient"}
            lists = self.get(f"/household/{hid}/shoppinglist") or []
            lid = list_id or (lists[0]["id"] if lists else None)
            if not lid:
                return {"ok": False, "reason": "aucune liste de courses"}
            payload = {"items": [{"id": it["id"], "name": it.get("name") or "?",
                                  "description": it.get("description") or "",
                                  "optional": bool(it.get("optional"))}
                                 for it in items]}
            self.post(f"/shoppinglist/{lid}/recipeitems", payload)
            self.invalidate()
            return {"ok": True, "count": len(items), "name": rec.get("name", "")}
        except (RuntimeError, self._sdk.requests.exceptions.RequestException,
                KeyError, ValueError) as e:
            return {"ok": False, "reason": str(e) or type(e).__name__}

    def photo_fetch(self, name):
        """Relaie une photo servie par KitchenOwl. Retourne (bytes, content_type)
        ou None. Le nom est validé par l'appelant (route consommatrice)."""
        url, token, _ = self.cfg()
        if not url:
            return None
        try:
            up = self._sdk.requests.get(
                f"{url}/api/upload/{name}",
                headers={"Authorization": f"Bearer {token}"}, timeout=10)
        except self._sdk.requests.exceptions.RequestException:
            return None
        if up.status_code != 200:
            return None
        return up.content, up.headers.get("Content-Type", "image/jpeg")


_API = None


def provide(sdk):
    """Point d'entrée fournisseur (lot E) : rend l'API du hub KitchenOwl."""
    global _API
    _API = KitchenOwlAPI(sdk)
    return _API


def register(sdk):
    """Routes du hub (lot I) : /status agrège l'état pour la tuile « Hub
    cuisine ». Réutilise l'instance de provide() (même cache)."""
    from flask import Blueprint, jsonify
    bp = Blueprint("kitchenowl", __name__)
    api = _API or KitchenOwlAPI(sdk)

    @bp.route("/status")
    def status():
        url, _, _ = api.cfg()
        if not url:
            return jsonify({"ok": False, "reason": "KitchenOwl non configuré", "host": ""})
        try:
            hh = api.household()
            out = {"ok": True, "household": hh.get("name", ""), "host": url}

            def _cnt(kind, key="items"):
                v = api.view(kind)
                return len(v.get(key, [])) if v.get("ok") else None
            out["stock"] = _cnt("stock")
            out["recipes"] = _cnt("recettes")
            out["courses"] = _cnt("courses")
            out["planned"] = _cnt("repas", "planned")
            return jsonify(out)
        except Exception as e:
            return jsonify({"ok": False, "reason": str(e)[:120], "host": url})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » (si une tuile est ajoutée un jour) : joignabilité."""
    api = KitchenOwlAPI(sdk)
    try:
        hh = api.household()
        return True, f"KitchenOwl ✓ — maison « {hh.get('name')} »"
    except RuntimeError as e:
        return False, f"KitchenOwl ✗ ({e})"
    except Exception as e:
        return False, f"KitchenOwl ✗ ({type(e).__name__})"
