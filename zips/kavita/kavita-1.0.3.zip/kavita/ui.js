/* Kavita — stats, en cours + nouveautés, recherche, couvertures. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.kavita = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  let baseUrl = '', query = '', searchRes = null;
  const CSS =
    "  .kvwrap{flex:1;display:flex;flex-direction:column;min-height:0;--kv:#4ac694}\n" +
    "  .kvtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .kvlibs{display:flex;gap:8px;flex-wrap:wrap;flex:1}\n" +
    "  .kvlib{display:flex;align-items:center;gap:6px;background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:6px 11px;font-size:12.5px}\n" +
    "  .kvvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .kvvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .kvvtoggle button.on{background:var(--tile);color:var(--kv)}\n" +
    "  .kvsearch{padding:12px 22px 0}\n" +
    "  .kvsearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .kvscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .kvsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px;display:flex;align-items:center;gap:7px}\n" +
    "  .kvsec:first-child{margin-top:0}\n" +
    /* cards couverture */
    "  .kvcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:14px}\n" +
    "  .kvcard{cursor:pointer;display:flex;flex-direction:column;gap:6px}\n" +
    "  .kvcover-wrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .kvcard:hover .kvcover-wrap{border-color:var(--kv)}\n" +
    "  .kvcover{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .kvcover-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:34px;color:var(--dim)}\n" +
    "  .kvprog{position:absolute;left:0;right:0;bottom:0;height:5px;background:rgba(0,0,0,.4)}\n" +
    "  .kvprog i{display:block;height:100%;background:var(--kv)}\n" +
    "  .kvpct{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:7px}\n" +
    "  .kvcname{font-size:12.5px;font-weight:600;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    /* liste */
    "  .kvrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .kvrow:hover{border-color:var(--kv)}\n" +
    "  .kvrcover{width:40px;height:60px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .kvrph{width:40px;height:60px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--dim);flex:none}\n" +
    "  .kvrtx{min-width:0;flex:1}\n" +
    "  .kvrname{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kvrprog{height:6px;background:var(--bg);border-radius:3px;overflow:hidden;margin-top:5px}\n" +
    "  .kvrprog i{display:block;height:100%;background:var(--kv)}\n" +
    "  .kvrmeta{font-size:11.5px;color:var(--dim);margin-top:3px}\n" +
    "  .kvempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    /* fiche série */
    "  .kvdet{position:absolute;inset:0;background:var(--bg);z-index:40;display:flex;flex-direction:column}\n" +
    "  .kvdtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .kvdback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .kvdtitle{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kvdopen{font-size:12px;color:var(--kv);cursor:pointer;background:rgba(74,198,148,.12);border:1px solid rgba(74,198,148,.35);border-radius:9px;padding:7px 12px}\n" +
    "  .kvdbody{flex:1;min-height:0;overflow:auto;padding:14px 18px}\n" +
    "  .kvdhead{display:flex;gap:14px;margin-bottom:14px}\n" +
    "  .kvdcover{width:96px;aspect-ratio:2/3;border-radius:9px;object-fit:cover;background:var(--tile);flex:none}\n" +
    "  .kvdresume{margin-top:10px;background:var(--kv);color:#fff;border:0;border-radius:10px;padding:11px 18px;font-size:13.5px;font-weight:700;cursor:pointer}\n" +
    "  .kvvol{font-size:11.5px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:12px 0 7px}\n" +
    "  .kvchap{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:11px 13px;margin-bottom:7px;cursor:pointer}\n" +
    "  .kvchap:hover{border-color:var(--kv)}\n" +
    "  .kvchtx{flex:1;min-width:0}\n" +
    "  .kvchnm{font-weight:600;font-size:13.5px}\n" +
    "  .kvchmeta{font-size:11px;color:var(--dim);margin-top:1px}\n" +
    "  .kvchpct{font-size:11px;color:var(--kv);font-weight:700;flex:none}\n" +
    /* lecteur */
    "  .kvreader{position:fixed;inset:0;background:#000;z-index:9999;overflow:hidden}\n" +
    "  .kvrimg-wrap{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}\n" +
    "  .kvrimg{max-width:100%;max-height:100%;object-fit:contain;display:block}\n" +
    "  .kvrload{position:absolute;color:rgba(255,255,255,.6);font-size:14px}\n" +
    "  .kvtapL{position:absolute;left:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .kvtapC{position:absolute;left:33%;top:0;bottom:0;width:34%;z-index:2}\n" +
    "  .kvtapR{position:absolute;right:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .kvrtop{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:12px;padding:11px 16px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .kvrback{background:transparent;border:0;color:#fff;font-size:19px;cursor:pointer;padding:6px 10px}\n" +
    "  .kvrtt{min-width:0;flex:1}\n" +
    "  .kvrnm{color:#fff;font-size:13.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kvrch{color:rgba(255,255,255,.6);font-size:11.5px}\n" +
    "  .kvrpg{color:rgba(255,255,255,.75);font-size:12.5px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .kvrbot{position:absolute;bottom:0;left:0;right:0;padding:12px 16px 14px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .kvrbot input[type=range]{width:100%}";
  function ensureCss() { let s = document.getElementById('kvUiCss'); if (!s) { s = document.createElement('style'); s.id = 'kvUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const coverUrl = id => '/addons/kavita/api/cover?series=' + encodeURIComponent(id);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de la bibliothèque…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openInKavita(id, libId) {
    if (!baseUrl) { S.toast('URL non configurée'); return; }
    const u = baseUrl + '/library/' + (libId || 0) + '/series/' + id;
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  /* ===== fiche série (volumes / chapitres) ===== */
  async function openSeries(id, libId, name) {
    const host = root.closest ? (root.closest('.aui') || root) : root;
    const det = document.createElement('div');
    det.className = 'kvdet';
    det.innerHTML = '<div class="kvdtop"><button class="kvdback">‹ Retour</button>' +
      '<span class="kvdtitle">' + esc(name || 'Série') + '</span>' +
      '<span class="kvdopen">Kavita ↗</span></div>' +
      '<div class="kvdbody"><div class="kvempty">Chargement…</div></div>';
    root.style.position = 'relative';
    root.appendChild(det);
    det.querySelector('.kvdback').addEventListener('click', () => det.remove());
    det.querySelector('.kvdopen').addEventListener('click', () => openInKavita(id, libId));
    let d = null;
    try { const r = await S.api('/series-detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'injoignable' }; }
    const body = det.querySelector('.kvdbody');
    if (!d || !d.ok) { body.innerHTML = '<div class="kvempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    // aplatir les chapitres (ordre volumes puis chapitres)
    const flat = [];
    (d.volumes || []).forEach(v => (v.chapters || []).forEach(c => flat.push(Object.assign({}, c, { seriesId: id, libraryId: libId }))));
    // point de reprise : premier chapitre entamé non fini, sinon premier non lu, sinon le premier
    let resume = flat.find(c => c.pagesRead > 0 && c.pagesRead < c.pages) ||
                 flat.find(c => !c.pagesRead) || flat[0];
    let h = '<div class="kvdhead">' +
      '<img class="kvdcover" src="' + coverUrl(id) + '" onerror="this.style.display=\'none\'">' +
      '<div><div style="font-weight:700;font-size:16px">' + esc(name || '') + '</div>' +
      '<div style="font-size:12px;color:var(--dim);margin-top:3px">' + flat.length + ' chapitre(s)</div>' +
      (resume ? '<button class="kvdresume">▶ ' + (resume.pagesRead > 0 ? 'Reprendre' : 'Commencer') + ' la lecture</button>' : '') +
      '</div></div>';
    (d.volumes || []).forEach(v => {
      if (v.name || (d.volumes.length > 1)) h += '<div class="kvvol">Volume ' + esc(v.name || v.minNumber || '') + '</div>';
      (v.chapters || []).forEach(c => {
        const pct = c.pages ? Math.round(c.pagesRead / c.pages * 100) : 0;
        h += '<div class="kvchap" data-ch="' + c.id + '">' +
          '<span>📖</span><div class="kvchtx"><div class="kvchnm">' + esc(c.title) + '</div>' +
          '<div class="kvchmeta">' + nf(c.pages) + ' pages' + (pct > 0 && pct < 100 ? ' · ' + pct + '% lu' : pct >= 100 ? ' · terminé ✓' : '') + '</div></div>' +
          (pct > 0 && pct < 100 ? '<span class="kvchpct">' + pct + '%</span>' : '') + '</div>';
      });
    });
    body.innerHTML = h;
    const rbtn = body.querySelector('.kvdresume');
    if (rbtn && resume) rbtn.addEventListener('click', () =>
      openReader(flat, flat.indexOf(resume), name, Math.max(0, (resume.pagesRead || 1) - 1)));
    body.querySelectorAll('.kvchap').forEach(n => n.addEventListener('click', () => {
      const c = flat.find(x => String(x.id) === n.getAttribute('data-ch'));
      if (c) openReader(flat, flat.indexOf(c), name, (c.pagesRead > 0 && c.pagesRead < c.pages) ? c.pagesRead - 1 : 0);
    }));
  }

  /* ===== lecteur plein écran ===== */
  function pageUrl(chapId, pg) { return '/addons/kavita/api/page?chapter=' + chapId + '&page=' + pg; }
  function openReader(chapters, idx, seriesName, startPage) {
    let ci = idx, pg = startPage || 0, controls = true, saveT = null;
    const ov = document.createElement('div');
    ov.className = 'kvreader';
    document.body.appendChild(ov);
    function chap() { return chapters[ci]; }
    function saveProgress() {
      if (saveT) clearTimeout(saveT);
      saveT = setTimeout(() => {
        const c = chap(); if (!c) return;
        S.api('/progress', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ seriesId: c.seriesId, volumeId: c.volumeId, chapterId: c.id, page: pg + 1, libraryId: c.libraryId }) }).catch(() => {});
      }, 700);
    }
    function preload() {
      const c = chap(); if (!c) return;
      for (let k = 1; k <= 2; k++) {
        if (pg + k < c.pages) { const im = new Image(); im.src = pageUrl(c.id, pg + k); }
      }
    }
    function draw() {
      const c = chap(); if (!c) { close(); return; }
      ov.innerHTML = '<div class="kvrimg-wrap"><span class="kvrload">Chargement…</span></div>' +
        '<div class="kvtapL"></div><div class="kvtapC"></div><div class="kvtapR"></div>' +
        (controls ?
          '<div class="kvrtop"><button class="kvrback">‹</button>' +
          '<div class="kvrtt"><div class="kvrnm">' + esc(seriesName || '') + '</div>' +
          '<div class="kvrch">' + esc(c.title) + '</div></div>' +
          '<span class="kvrpg">' + (pg + 1) + ' / ' + c.pages + '</span></div>' +
          '<div class="kvrbot"><input type="range" min="1" max="' + c.pages + '" step="1" value="' + (pg + 1) + '"></div>'
          : '');
      const wrap = ov.querySelector('.kvrimg-wrap');
      const img = new Image();
      img.className = 'kvrimg';
      img.onload = () => { wrap.innerHTML = ''; wrap.appendChild(img); preload(); };
      img.onerror = () => { wrap.innerHTML = '<span class="kvrload">⚠ page indisponible</span>'; };
      img.src = pageUrl(c.id, pg);
      ov.querySelector('.kvtapL').addEventListener('click', () => turn(-1));
      ov.querySelector('.kvtapR').addEventListener('click', () => turn(1));
      ov.querySelector('.kvtapC').addEventListener('click', () => { controls = !controls; draw(); });
      const bk = ov.querySelector('.kvrback'); if (bk) bk.addEventListener('click', close);
      const sl = ov.querySelector('.kvrbot input'); if (sl) sl.addEventListener('change', () => { pg = parseInt(sl.value, 10) - 1; draw(); saveProgress(); });
    }
    function turn(d) {
      const c = chap(); if (!c) return;
      const np = pg + d;
      if (np < 0) {
        if (ci > 0) { ci--; pg = Math.max(0, (chap().pages || 1) - 1); S.toast(chap().title); }
      } else if (np >= c.pages) {
        if (ci < chapters.length - 1) { ci++; pg = 0; S.toast(chap().title); }
        else { S.toast('Fin de la série 🎉'); }
      } else { pg = np; }
      draw(); saveProgress();
    }
    function close() {
      if (saveT) clearTimeout(saveT);
      ov.remove();
      render(root, S, tile);  // recharge (progression à jour)
    }
    draw(); saveProgress();
  }

  function card(s) {
    const ph = '<div class=\'kvcover-ph\'>📖</div>';
    return '<div class="kvcard" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<div class="kvcover-wrap">' +
      '<img class="kvcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      (s.percent ? '<span class="kvpct">' + s.percent + '%</span>' : '') +
      (s.percent ? '<div class="kvprog"><i style="width:' + s.percent + '%"></i></div>' : '') +
      '</div>' +
      '<div class="kvcname">' + esc(s.name) + '</div></div>';
  }
  function row(s) {
    const ph = '<div class=\'kvrph\'>📖</div>';
    return '<div class="kvrow" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<img class="kvrcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      '<div class="kvrtx"><div class="kvrname">' + esc(s.name) + '</div>' +
      (s.pages ? '<div class="kvrprog"><i style="width:' + s.percent + '%"></i></div>' +
        '<div class="kvrmeta">' + nf(s.pagesRead) + ' / ' + nf(s.pages) + ' pages · ' + s.percent + '%</div>' : '') +
      '</div></div>';
  }
  function renderSeries(list) {
    if (!list || !list.length) return '<div class="kvempty">Rien à afficher.</div>';
    if (viewMode === 'cards') return '<div class="kvcards">' + list.map(card).join('') + '</div>';
    return list.map(row).join('');
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📚</div><div class="t1">Kavita indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Compte → Clé API).</div>' +
        '<button class="btnpill install" id="kvRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('kvRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="kvwrap"><div class="kvtopbar">' +
      '<div class="kvlibs">' +
      (d.libraries.length ? d.libraries.map(l => '<span class="kvlib">📚 ' + esc(l.name) + '</span>').join('') : '<span class="kvempty">Aucune bibliothèque</span>') +
      '</div>' +
      '<div class="kvvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="kvsearch"><input id="kvQ" type="search" placeholder="Rechercher une série…" value="' + esc(query) + '"></div>';
    h += '<div class="kvscroll">';

    if (query && searchRes) {
      h += '<div class="kvsec">' + nf(searchRes.count) + ' résultat(s)</div>';
      h += renderSeries(searchRes.series);
    } else if (query) {
      h += '<div class="kvempty">Recherche…</div>';
    } else {
      if (d.reading && d.reading.length) {
        h += '<div class="kvsec">▶️ Lectures en cours · ' + nf(d.reading_count) + '</div>';
        h += renderSeries(d.reading);
      }
      if (d.recent && d.recent.length) {
        h += '<div class="kvsec">✨ Nouveautés</div>';
        h += renderSeries(d.recent);
      }
      if ((!d.reading || !d.reading.length) && (!d.recent || !d.recent.length)) {
        h += '<div class="kvempty">Aucune série à afficher.</div>';
      }
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.kvvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    const qin = document.getElementById('kvQ');
    if (qin) qin.addEventListener('input', () => { query = qin.value; scheduleSearch(); });
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openSeries(n.getAttribute('data-id'), n.getAttribute('data-lib'), n.getAttribute('data-nm'))));
  }

  let _t = null;
  function scheduleSearch() {
    if (_t) clearTimeout(_t);
    const q = query;
    _t = setTimeout(async () => {
      if (!q) { searchRes = null; paint(); refocus(); return; }
      try { const r = await S.api('/search?q=' + encodeURIComponent(q)); searchRes = await r.json(); }
      catch (e) { searchRes = { ok: false, count: 0, series: [] }; }
      if (query === q) { paint(); refocus(); }
    }, 350);
  }
  function refocus() {
    const nq = document.getElementById('kvQ');
    if (nq) { nq.focus(); const l = nq.value.length; try { nq.setSelectionRange(l, l); } catch (e) {} }
  }

  return { render };
})();
