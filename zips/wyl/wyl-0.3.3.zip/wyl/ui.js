/* WatchYourLAN — hôtes du réseau, bascule liste/cards, hors-ligne grisés. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.wyl = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'list';
  const ACCENT = '#2dd4bf';
  const CSS =
    "  .wywrap{flex:1;display:flex;flex-direction:column;min-height:0;--wy:" + ACCENT + "}\n" +
    "  .wytopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .wytotals{display:flex;gap:16px;flex:1}\n" +
    "  .wytk{text-align:center}\n" +
    "  .wytk b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--wy)}\n" +
    "  .wytk.off b{color:var(--dim)}\n" +
    "  .wytk span{font-size:11px;color:var(--dim)}\n" +
    "  .wyvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .wyvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .wyvtoggle button.on{background:var(--tile);color:var(--wy)}\n" +
    "  .wyscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .wygrp{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:10px 0 8px}\n" +
    /* liste */
    "  .wyrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:10px 14px;margin-bottom:7px}\n" +
    "  .wyrow.off{opacity:.5}\n" +
    "  .wydot{width:10px;height:10px;border-radius:50%;flex:none;background:var(--green)}\n" +
    "  .wyrow.off .wydot{background:var(--dim)}\n" +
    "  .wyrtx{min-width:0;flex:1}\n" +
    "  .wyrnm{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wyrsub{font-family:var(--mono);font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wyrip{font-family:var(--mono);font-size:13px;font-variant-numeric:tabular-nums;flex:none;color:var(--fg)}\n" +
    /* cards */
    "  .wycards{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:11px}\n" +
    "  .wycard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px;border-left:3px solid var(--green)}\n" +
    "  .wycard.off{opacity:.5;border-left-color:var(--dim)}\n" +
    "  .wyctop{display:flex;align-items:center;gap:8px;margin-bottom:9px}\n" +
    "  .wycdot{width:10px;height:10px;border-radius:50%;flex:none;background:var(--green)}\n" +
    "  .wycard.off .wycdot{background:var(--dim)}\n" +
    "  .wycnm{font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wycip{font-family:var(--mono);font-size:16px;font-weight:600;font-variant-numeric:tabular-nums;margin-bottom:6px}\n" +
    "  .wycmac{font-family:var(--mono);font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wychw{font-size:11px;color:var(--dim);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wyempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { let s = document.getElementById('wyUiCss'); if (!s) { s = document.createElement('style'); s.id = 'wyUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture du réseau…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/hosts'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function hostRow(h) {
    return '<div class="wyrow' + (h.online ? '' : ' off') + '">' +
      '<span class="wydot"></span>' +
      '<div class="wyrtx"><div class="wyrnm">' + esc(h.name || '(sans nom)') + '</div>' +
      '<div class="wyrsub">' + esc(h.mac || '') + (h.hw ? ' · ' + esc(h.hw) : '') + '</div></div>' +
      '<span class="wyrip">' + esc(h.ip || '—') + '</span></div>';
  }
  function hostCard(h) {
    return '<div class="wycard' + (h.online ? '' : ' off') + '">' +
      '<div class="wyctop"><span class="wycdot"></span><span class="wycnm">' + esc(h.name || '(sans nom)') + '</span></div>' +
      '<div class="wycip">' + esc(h.ip || '—') + '</div>' +
      '<div class="wycmac">' + esc(h.mac || '') + '</div>' +
      (h.hw ? '<div class="wychw">' + esc(h.hw) + '</div>' : '') +
      '</div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📡</div><div class="t1">WatchYourLAN indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL dans ⚙ (ex : http://192.168.1.10:8840).</div>' +
        '<button class="btnpill install" id="wyRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('wyRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="wywrap"><div class="wytopbar">' +
      '<div class="wytotals">' +
      '<div class="wytk"><b>' + nf(d.total) + '</b><span>hôtes</span></div>' +
      '<div class="wytk"><b>' + nf(d.online) + '</b><span>en ligne</span></div>' +
      '<div class="wytk off"><b>' + nf(d.offline) + '</b><span>hors ligne</span></div>' +
      '</div>' +
      '<div class="wyvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';

    h += '<div class="wyscroll">';
    if (!d.hosts || !d.hosts.length) {
      h += '<div class="wyempty">Aucun hôte détecté.</div>';
    } else if (viewMode === 'cards') {
      h += '<div class="wycards">' + d.hosts.map(hostCard).join('') + '</div>';
    } else {
      h += d.hosts.map(hostRow).join('');
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.wyvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v');
      if (v === viewMode) return;
      viewMode = v;
      try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
  }

  return { render };
})();
