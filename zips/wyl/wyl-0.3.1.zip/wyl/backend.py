"""Addon « wyl » — WatchYourLAN (Furet) : hôtes du réseau.

    register(sdk) -> flask.Blueprint   (routes sous /addons/wyl/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:8840). Interroge /api/all (WatchYourLAN 1.x/2.x).
Regroupe et trie les hôtes ; l'UI propose une bascule liste / cards.
"""


def _norm_url(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url


def _hosts(sdk, cfg):
    url = _norm_url(cfg)
    if not url:
        return {"ok": False, "reason": "URL non configurée"}
    ck = f"wyl:{url}"
    c = sdk.cache_get(ck, 60)
    if c is not None:
        return c
    try:
        r = sdk.requests.get(f"{url}/api/all", timeout=10, verify=False)
        if r.status_code == 404:
            return {"ok": False, "reason": "API introuvable (/api/all) — WatchYourLAN 1.x/2.x attendu"}
        if r.status_code != 200:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        raw = r.json()
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": f"injoignable ({type(e).__name__})"}
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}

    if not isinstance(raw, list):
        raw = raw.get("data", []) if isinstance(raw, dict) else []

    hosts = []
    for h in raw:
        if not isinstance(h, dict):
            continue
        online = str(h.get("Now", h.get("now", "0"))) in ("1", "true", "True")
        hosts.append({
            "name": h.get("Name") or h.get("name") or "",
            "ip": h.get("IP") or h.get("ip") or "",
            "mac": h.get("Mac") or h.get("mac") or "",
            "hw": h.get("Hw") or h.get("hw") or "",
            "online": online,
            "known": str(h.get("Known", h.get("known", "1"))) in ("1", "true", "True"),
            "date": h.get("Date") or h.get("date") or "",
        })

    def ip_key(x):
        try:
            return tuple(int(p) for p in (x.get("ip") or "0.0.0.0").split("."))
        except (ValueError, AttributeError):
            return (0, 0, 0, 0)
    # en ligne d'abord, puis par IP
    hosts.sort(key=lambda x: (not x["online"], ip_key(x)))

    online = sum(1 for h in hosts if h["online"])
    out = {
        "ok": True,
        "hosts": hosts,
        "total": len(hosts),
        "online": online,
        "offline": len(hosts) - online,
    }
    return sdk.cache_set(ck, out)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("wyl", __name__)

    @bp.route("/hosts")
    def hosts():
        try:
            return jsonify(_hosts(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("wyl")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    h = _hosts(sdk, cfg)
    if h.get("ok"):
        return True, (f"WatchYourLAN ✓ — {h['online']}/{h['total']} hôte(s) en ligne")
    return False, f"WatchYourLAN ✗ ({h.get('reason')})"
