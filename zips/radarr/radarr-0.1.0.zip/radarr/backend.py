"""Addon « radarr » — statut & activité Radarr (API v3).

    register(sdk) -> flask.Blueprint   (routes sous /addons/radarr/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:7878) + apikey (Settings → General → API Key).
Même patron que Sonarr, adapté aux films.
"""


def _cfg(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _get(sdk, url, key, path, params=None, timeout=8):
    try:
        r = sdk.requests.get(url + "/api/v3" + path,
                             headers={"X-Api-Key": key},
                             params=params, timeout=timeout)
        if r.status_code == 401:
            return {"__err": "clé API refusée (401)"}
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    status = _get(sdk, url, key, "/system/status")
    if isinstance(status, dict) and status.get("__err"):
        return {"ok": False, "reason": status["__err"]}
    if not status:
        return {"ok": False, "reason": "Radarr injoignable"}

    out = {"ok": True, "version": status.get("version"),
           "name": status.get("instanceName") or "Radarr"}

    # File d'attente
    q = _get(sdk, url, key, "/queue",
             params={"pageSize": 50, "includeMovie": "true"})
    records = (q or {}).get("records") or []
    queue = []
    for it in records:
        size = it.get("size") or 0
        left = it.get("sizeleft") or 0
        pct = round((1 - left / size) * 100, 1) if size else 0
        mv = it.get("movie") or {}
        queue.append({
            "title": mv.get("title") or it.get("title") or "?",
            "year": mv.get("year"),
            "status": it.get("status"),
            "percent": pct,
            "size": _fmt_bytes(size),
            "timeleft": it.get("timeleft"),
            "protocol": it.get("protocol"),
        })
    out["queue"] = queue
    out["queue_count"] = (q or {}).get("totalRecords", len(queue))

    # Calendrier : prochaines sorties (30 jours — les films sortent moins souvent)
    import datetime
    today = datetime.date.today()
    end = today + datetime.timedelta(days=30)
    cal = _get(sdk, url, key, "/calendar",
               params={"start": today.isoformat(), "end": end.isoformat()})
    upcoming = []
    for it in (cal or [])[:20]:
        # date de sortie physique/cinéma la plus proche
        date = (it.get("digitalRelease") or it.get("physicalRelease")
                or it.get("inCinemas"))
        upcoming.append({
            "title": it.get("title") or "?",
            "year": it.get("year"),
            "date": date,
            "has_file": it.get("hasFile", False),
        })
    out["upcoming"] = upcoming

    # Manquants
    miss = _get(sdk, url, key, "/wanted/missing", params={"pageSize": 1})
    out["missing_count"] = (miss or {}).get("totalRecords", 0)

    # Films suivis + stats
    movies = _get(sdk, url, key, "/movie")
    if isinstance(movies, list):
        out["movies_count"] = len(movies)
        out["movies_monitored"] = sum(1 for m in movies if m.get("monitored"))
        out["movies_have"] = sum(1 for m in movies if m.get("hasFile"))
        total_size = sum((m.get("sizeOnDisk") or 0) for m in movies)
        out["library_size"] = _fmt_bytes(total_size)

    # Espace disque
    disks = _get(sdk, url, key, "/diskspace")
    if isinstance(disks, list) and disks:
        out["disks"] = [{"path": d.get("path"),
                         "free": _fmt_bytes(d.get("freeSpace")),
                         "total": _fmt_bytes(d.get("totalSpace")),
                         "free_pct": round((d.get("freeSpace") or 0) /
                                           (d.get("totalSpace") or 1) * 100)}
                        for d in disks[:4]]

    # Santé
    health = _get(sdk, url, key, "/health")
    if isinstance(health, list):
        out["health"] = [{"type": h.get("type"), "message": h.get("message")}
                         for h in health[:6]]

    # Historique
    hist = _get(sdk, url, key, "/history",
                params={"pageSize": 8, "sortKey": "date", "sortDirection": "descending"})
    hrecords = (hist or {}).get("records") or []
    out["history"] = [{"title": (h.get("movie") or {}).get("title") or h.get("sourceTitle") or "?",
                       "event": h.get("eventType"),
                       "date": h.get("date")} for h in hrecords[:8]]

    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("radarr", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("radarr")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _data(sdk, cfg)
    if d.get("ok"):
        return True, (f"Radarr ✓ — v{d.get('version', '?')}, "
                      f"{d.get('movies_count', 0)} film(s), "
                      f"{d.get('queue_count', 0)} en file")
    return False, f"Radarr ✗ ({d.get('reason')})"
