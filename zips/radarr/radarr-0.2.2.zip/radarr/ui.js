/* Radarr — stats, films récents (affiches), à venir, file, liste/cards, fiche détail. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.radarr = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  const ACCENT = '#f0b429';
  const CSS =
    "  .rrwrap{flex:1;display:flex;flex-direction:column;min-height:0;--rr:" + ACCENT + "}\n" +
    "  .rrtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .rrtotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .rrtk{text-align:center}\n" +
    "  .rrtk b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--rr)}\n" +
    "  .rrtk.have b{color:var(--green)}.rrtk.miss b{color:var(--warn)}\n" +
    "  .rrtk span{font-size:11px;color:var(--dim)}\n" +
    "  .rrvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .rrvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .rrvtoggle button.on{background:var(--tile);color:var(--rr)}\n" +
    "  .rrscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .rrsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .rrsec:first-child{margin-top:0}\n" +
    "  .rrsec .c{color:var(--rr)}\n" +
    /* affiches */
    "  .rrposters{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:13px}\n" +
    "  .rrcard{cursor:pointer;display:flex;flex-direction:column;gap:5px}\n" +
    "  .rrpwrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .rrcard:hover .rrpwrap{border-color:var(--rr)}\n" +
    "  .rrposter{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .rrph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:32px;color:var(--dim)}\n" +
    "  .rrbadge{position:absolute;top:6px;right:6px;font-size:14px}\n" +
    "  .rrctit{font-size:12px;font-weight:600;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    "  .rrcsub{font-size:10.5px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    /* liste */
    "  .rrrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .rrrow:hover{border-color:var(--rr)}\n" +
    "  .rrrposter{width:34px;height:51px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .rrrph{width:34px;height:51px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--dim);flex:none}\n" +
    "  .rrrtx{min-width:0;flex:1}\n" +
    "  .rrrtit{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .rrrmeta{font-size:11.5px;color:var(--dim)}\n" +
    "  .rrrstat{font-size:11px;flex:none}\n" +
    /* à venir */
    "  .rrup{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 13px;margin-bottom:6px}\n" +
    "  .rrupdate{font-size:11px;color:var(--rr);font-weight:600;min-width:88px;flex:none}\n" +
    "  .rrqueue{display:flex;flex-direction:column;gap:6px}\n" +
    "  .rrq{background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:9px 12px}\n" +
    "  .rrqtop{display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px}\n" +
    "  .rrqbar{height:5px;border-radius:3px;background:var(--bg);overflow:hidden}\n" +
    "  .rrqbar>i{display:block;height:100%;background:var(--rr)}\n" +
    "  .rrempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    /* détail */
    "  .rrdet{position:absolute;inset:0;background:var(--bg);z-index:40;display:flex;flex-direction:column}\n" +
    "  .rrdtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .rrdback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .rrdttl{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .rrdopen{font-size:12px;color:var(--rr);cursor:pointer;background:rgba(240,180,41,.12);border:1px solid rgba(240,180,41,.3);border-radius:9px;padding:7px 12px}\n" +
    "  .rrdbody{flex:1;min-height:0;overflow:auto;padding:16px 18px;display:flex;gap:16px}\n" +
    "  .rrdposter{width:110px;aspect-ratio:2/3;border-radius:10px;object-fit:cover;background:var(--tile);flex:none}\n" +
    "  .rrdinfo{min-width:0;flex:1}\n" +
    "  .rrdmeta{font-size:12.5px;color:var(--dim);margin-bottom:10px}\n" +
    "  .rrdchips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}\n" +
    "  .rrchip{font-size:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:7px;padding:3px 9px;color:var(--dim)}\n" +
    "  .rrchip.ok{color:var(--green);border-color:var(--green)}.rrchip.no{color:var(--warn);border-color:var(--warn)}\n" +
    "  .rrdover{font-size:13.5px;line-height:1.55}";
  function ensureCss() { if (document.getElementById('rrUiCss')) return; const s = document.createElement('style'); s.id = 'rrUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const img = p => p ? '/addons/radarr/api/image?p=' + encodeURIComponent(p) : '';
  function fdate(iso) { if (!iso) return ''; try { return new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }); } catch (e) { return iso.slice(0, 10); } }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Radarr…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function movieCard(m) {
    const poster = m.poster
      ? '<img class="rrposter" loading="lazy" src="' + img(m.poster) + '" data-ph="rrph">'
      : '<div class="rrph">🎬</div>';
    return '<div class="rrcard" data-id="' + esc(m.id) + '">' +
      '<div class="rrpwrap">' + poster +
      (m.has_file ? '<span class="rrbadge">✅</span>' : (m.monitored ? '<span class="rrbadge">👁️</span>' : '')) + '</div>' +
      '<div class="rrctit">' + esc(m.title) + '</div>' +
      '<div class="rrcsub">' + (m.year || '') + (m.rating ? ' · ★' + m.rating : '') + '</div></div>';
  }
  function movieRow(m) {
    const poster = m.poster
      ? '<img class="rrrposter" loading="lazy" src="' + img(m.poster) + '" data-ph="rrrph">'
      : '<div class="rrrph">🎬</div>';
    return '<div class="rrrow" data-id="' + esc(m.id) + '">' + poster +
      '<div class="rrrtx"><div class="rrrtit">' + esc(m.title) + '</div>' +
      '<div class="rrrmeta">' + (m.year || '') + (m.runtime ? ' · ' + m.runtime + ' min' : '') + (m.rating ? ' · ★' + m.rating : '') + '</div></div>' +
      '<span class="rrrstat">' + (m.has_file ? '<span style="color:var(--green)">✅</span>' : '<span style="color:var(--warn)">manquant</span>') + '</span></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🎬</div><div class="t1">Radarr indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Settings → General).</div>' +
        '<button class="btnpill install" id="rrRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('rrRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="rrwrap"><div class="rrtopbar"><div class="rrtotals">' +
      '<div class="rrtk"><b>' + nf(d.movies_count) + '</b><span>films</span></div>' +
      '<div class="rrtk have"><b>' + nf(d.movies_have) + '</b><span>disponibles</span></div>' +
      '<div class="rrtk miss"><b>' + nf(d.missing_count) + '</b><span>manquants</span></div>' +
      '<div class="rrtk"><b>' + nf(d.queue_count) + '</b><span>en file</span></div>' +
      (d.library_size ? '<div class="rrtk"><b style="font-size:15px">' + esc(d.library_size) + '</b><span>bibliothèque</span></div>' : '') +
      '</div><div class="rrvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div><div class="rrscroll">';

    // file d'attente
    if (d.queue && d.queue.length) {
      h += '<div class="rrsec">⬇️ En téléchargement <span class="c">' + nf(d.queue_count) + '</span></div><div class="rrqueue">';
      h += d.queue.slice(0, 6).map(q => '<div class="rrq"><div class="rrqtop"><span>' + esc(q.title) + (q.year ? ' (' + q.year + ')' : '') + '</span>' +
        '<span style="color:var(--dim)">' + (q.percent || 0) + '% · ' + (q.timeleft || '—') + '</span></div>' +
        '<div class="rrqbar"><i style="width:' + (q.percent || 0) + '%"></i></div></div>').join('') + '</div>';
    }
    // à venir
    if (d.upcoming && d.upcoming.length) {
      h += '<div class="rrsec">📅 Prochaines sorties</div>';
      h += d.upcoming.slice(0, 8).map(u => '<div class="rrup"><span class="rrupdate">' + fdate(u.date) + '</span>' +
        '<span style="flex:1">' + esc(u.title) + (u.year ? ' (' + u.year + ')' : '') + '</span>' +
        (u.has_file ? '<span style="color:var(--green);font-size:12px">✅</span>' : '') + '</div>').join('');
    }
    // récents (grille affiches)
    h += '<div class="rrsec">🆕 Récemment ajoutés</div>';
    if (!d.recent || !d.recent.length) h += '<div class="rrempty">Aucun film récent.</div>';
    else if (viewMode === 'cards') h += '<div class="rrposters">' + d.recent.map(movieCard).join('') + '</div>';
    else h += d.recent.map(movieRow).join('');

    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.rrvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openDetail(n.getAttribute('data-id'))));
    wirePosters(el);
  }

  function wirePosters(scope) {
    (scope || document).querySelectorAll('img[data-ph]').forEach(im => {
      im.addEventListener('error', function () {
        const cls = this.getAttribute('data-ph') || 'rrph';
        const dv = document.createElement('div');
        dv.className = cls; dv.textContent = '🎬';
        if (this.parentNode) this.parentNode.replaceChild(dv, this);
      }, { once: true });
    });
  }

  async function openDetail(id) {
    const det = document.createElement('div');
    det.className = 'rrdet';
    det.innerHTML = '<div class="rrdtop"><button class="rrdback">‹ Retour</button><span class="rrdttl">Film</span></div>' +
      '<div class="rrdbody"><div class="rrempty">Chargement…</div></div>';
    root.style.position = 'relative';
    root.appendChild(det);
    det.querySelector('.rrdback').addEventListener('click', () => det.remove());
    let d = null;
    try { const r = await S.api('/detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false }; }
    if (!d || !d.ok) { det.querySelector('.rrdbody').innerHTML = '<div class="rrempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    const m = d.movie;
    det.querySelector('.rrdttl').textContent = m.title + (m.year ? ' (' + m.year + ')' : '');
    const phHtml = '<div class="rrdposter" style="display:flex;align-items:center;justify-content:center;font-size:40px;color:var(--dim)">🎬</div>';
    det.querySelector('.rrdbody').innerHTML =
      (m.poster ? '<img class="rrdposter" src="' + img(m.poster) + '" data-ph="det">' : phHtml) +
      '<div class="rrdinfo">' +
      '<div class="rrdmeta">' + [m.year, m.runtime ? m.runtime + ' min' : '', m.studio, m.rating ? '★ ' + m.rating : ''].filter(Boolean).join(' · ') + '</div>' +
      '<div class="rrdchips">' +
      (m.hasFile ? '<span class="rrchip ok">✅ Disponible' + (m.quality ? ' · ' + esc(m.quality) : '') + '</span>' : '<span class="rrchip no">Manquant</span>') +
      (m.monitored ? '<span class="rrchip">👁️ Suivi</span>' : '') +
      (m.size ? '<span class="rrchip">💾 ' + esc(m.size) + '</span>' : '') +
      (m.status ? '<span class="rrchip">' + esc(m.status) + '</span>' : '') +
      (m.genres || []).slice(0, 4).map(g => '<span class="rrchip">' + esc(g) + '</span>').join('') +
      '</div>' +
      '<div class="rrdover">' + esc(m.overview || 'Pas de résumé.') + '</div></div>';
    const dimg = det.querySelector('img.rrdposter[data-ph]');
    if (dimg) dimg.addEventListener('error', function () {
      const dv = document.createElement('div');
      dv.className = 'rrdposter';
      dv.style.cssText = 'display:flex;align-items:center;justify-content:center;font-size:40px;color:var(--dim)';
      dv.textContent = '🎬';
      if (this.parentNode) this.parentNode.replaceChild(dv, this);
    }, { once: true });
  }

  return { render };
})();
