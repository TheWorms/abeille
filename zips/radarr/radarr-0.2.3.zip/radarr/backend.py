"""Addon « radarr » — statut & activité Radarr (API v3).

    register(sdk) -> flask.Blueprint   (routes sous /addons/radarr/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:7878) + apikey (Settings → General → API Key).
Même patron que Sonarr, adapté aux films.
"""


def _cfg(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _get(sdk, url, key, path, params=None, timeout=8):
    try:
        r = sdk.requests.get(url + "/api/v3" + path,
                             headers={"X-Api-Key": key},
                             params=params, timeout=timeout)
        if r.status_code == 401:
            return {"__err": "clé API refusée (401)"}
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _poster_path(images):
    """Chemin relatif de l'affiche (poster) depuis le champ images[] *arr.
    Le champ url contient déjà l'URLBase (ex. /theworms/radarr/MediaCover/..)."""
    if not isinstance(images, list):
        return None
    for want in ("poster", "fanart"):
        for im in images:
            if im.get("coverType") == want:
                u = im.get("url") or ""
                if u:
                    return u
    return None


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    status = _get(sdk, url, key, "/system/status")
    if isinstance(status, dict) and status.get("__err"):
        return {"ok": False, "reason": status["__err"]}
    if not status:
        return {"ok": False, "reason": "Radarr injoignable"}

    out = {"ok": True, "version": status.get("version"),
           "name": status.get("instanceName") or "Radarr"}

    # File d'attente
    q = _get(sdk, url, key, "/queue",
             params={"pageSize": 50, "includeMovie": "true"})
    records = (q or {}).get("records") or []
    queue = []
    for it in records:
        size = it.get("size") or 0
        left = it.get("sizeleft") or 0
        pct = round((1 - left / size) * 100, 1) if size else 0
        mv = it.get("movie") or {}
        queue.append({
            "title": mv.get("title") or it.get("title") or "?",
            "year": mv.get("year"),
            "status": it.get("status"),
            "percent": pct,
            "size": _fmt_bytes(size),
            "timeleft": it.get("timeleft"),
            "protocol": it.get("protocol"),
        })
    out["queue"] = queue
    out["queue_count"] = (q or {}).get("totalRecords", len(queue))

    # Calendrier : prochaines sorties (30 jours — les films sortent moins souvent)
    import datetime
    today = datetime.date.today()
    end = today + datetime.timedelta(days=30)
    cal = _get(sdk, url, key, "/calendar",
               params={"start": today.isoformat(), "end": end.isoformat()})
    upcoming = []
    for it in (cal or [])[:20]:
        date = (it.get("digitalRelease") or it.get("physicalRelease")
                or it.get("inCinemas"))
        upcoming.append({
            "id": it.get("id"),
            "title": it.get("title") or "?",
            "year": it.get("year"),
            "date": date,
            "has_file": it.get("hasFile", False),
            "poster": _poster_path(it.get("images")),
        })
    out["upcoming"] = upcoming

    # Manquants
    miss = _get(sdk, url, key, "/wanted/missing", params={"pageSize": 1})
    out["missing_count"] = (miss or {}).get("totalRecords", 0)

    # Films suivis + stats + récents (avec affiches)
    movies = _get(sdk, url, key, "/movie")
    if isinstance(movies, list):
        out["movies_count"] = len(movies)
        out["movies_monitored"] = sum(1 for m in movies if m.get("monitored"))
        out["movies_have"] = sum(1 for m in movies if m.get("hasFile"))
        total_size = sum((m.get("sizeOnDisk") or 0) for m in movies)
        out["library_size"] = _fmt_bytes(total_size)

        # récemment ajoutés (tri par dateAdded desc), limité pour la grille
        def _added(m):
            return m.get("added") or ""
        recent = sorted((m for m in movies if m.get("hasFile")),
                        key=_added, reverse=True)[:40]
        out["recent"] = [{
            "id": m.get("id"),
            "title": m.get("title") or "?",
            "year": m.get("year"),
            "poster": _poster_path(m.get("images")),
            "has_file": m.get("hasFile", False),
            "monitored": m.get("monitored", False),
            "runtime": m.get("runtime"),
            "rating": (m.get("ratings") or {}).get("value")
                      if isinstance(m.get("ratings"), dict) else None,
        } for m in recent]

    # Espace disque
    disks = _get(sdk, url, key, "/diskspace")
    if isinstance(disks, list) and disks:
        out["disks"] = [{"path": d.get("path"),
                         "free": _fmt_bytes(d.get("freeSpace")),
                         "total": _fmt_bytes(d.get("totalSpace")),
                         "free_pct": round((d.get("freeSpace") or 0) /
                                           (d.get("totalSpace") or 1) * 100)}
                        for d in disks[:4]]

    # Santé
    health = _get(sdk, url, key, "/health")
    if isinstance(health, list):
        out["health"] = [{"type": h.get("type"), "message": h.get("message")}
                         for h in health[:6]]

    # Historique
    hist = _get(sdk, url, key, "/history",
                params={"pageSize": 8, "sortKey": "date", "sortDirection": "descending"})
    hrecords = (hist or {}).get("records") or []
    out["history"] = [{"title": (h.get("movie") or {}).get("title") or h.get("sourceTitle") or "?",
                       "event": h.get("eventType"),
                       "date": h.get("date")} for h in hrecords[:8]]

    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("radarr", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("radarr")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/detail")
    def detail():
        from flask import request
        try:
            mid = (request.args.get("id") or "").strip()
            url, key = _cfg(sdk.config())
            if not (url and key and mid.isdigit()):
                return jsonify({"ok": False, "reason": "paramètres manquants"})
            m = _get(sdk, url, key, f"/movie/{mid}")
            if not isinstance(m, dict):
                return jsonify({"ok": False, "reason": "film introuvable"})
            return jsonify({"ok": True, "movie": {
                "id": m.get("id"), "title": m.get("title"), "year": m.get("year"),
                "overview": m.get("overview") or "",
                "status": m.get("status"), "runtime": m.get("runtime"),
                "hasFile": m.get("hasFile"), "monitored": m.get("monitored"),
                "studio": m.get("studio"), "genres": m.get("genres") or [],
                "rating": (m.get("ratings") or {}).get("value") if isinstance(m.get("ratings"), dict) else None,
                "size": _fmt_bytes(m.get("sizeOnDisk")),
                "poster": _poster_path(m.get("images")),
                "quality": ((m.get("movieFile") or {}).get("quality") or {}).get("quality", {}).get("name") if m.get("movieFile") else None,
            }})
        except Exception as e:
            sdk.log.exception("radarr detail")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}"[:80]})

    @bp.route("/image")
    def image():
        from flask import Response, request
        import re as _re
        url, key = _cfg(sdk.config())
        path = (request.args.get("p") or "").strip()
        if not (url and key and path):
            return Response("", status=400)
        # Le champ url de l'API contient l'URLBase (/theworms/radarr/MediaCover/<id>/poster.jpg)
        # qui n'est PAS servi en accès direct. On extrait l'id + le type d'image
        # et on requête l'endpoint API v3 (seul à accepter la clé) :
        #   /api/v3/mediacover/<id>/<poster|fanart>.jpg   avec header X-Api-Key
        m = _re.search(r"/MediaCover/(\d+)/([a-zA-Z]+)", path)
        if m:
            mid, kind = m.group(1), m.group(2)
            api_path = f"/api/v3/mediacover/{mid}/{kind}.jpg"
        elif path.startswith("/api/"):
            api_path = path
        else:
            api_path = path if path.startswith("/") else "/" + path
        try:
            r = sdk.requests.get(url + api_path,
                                 headers={"X-Api-Key": key}, timeout=15)
            if r.status_code != 200:
                return Response("", status=r.status_code)
            ct = r.headers.get("Content-Type", "image/jpeg")
            return Response(r.content, mimetype=ct,
                            headers={"Cache-Control": "private, max-age=86400"})
        except sdk.requests.exceptions.RequestException:
            return Response("", status=502)

    return bp


def test(sdk, cfg):
    d = _data(sdk, cfg)
    if d.get("ok"):
        return True, (f"Radarr ✓ — v{d.get('version', '?')}, "
                      f"{d.get('movies_count', 0)} film(s), "
                      f"{d.get('queue_count', 0)} en file")
    return False, f"Radarr ✗ ({d.get('reason')})"
