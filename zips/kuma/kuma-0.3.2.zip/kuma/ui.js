/* Kuma — Uptime Kuma : stats, moniteurs liste/cards, ping + uptime + sparkline. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.kuma = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  const CSS =
    "  .kmwrap{flex:1;display:flex;flex-direction:column;min-height:0;--km:#5cdd8b}\n" +
    "  .kmtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .kmtotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .kmtk{text-align:center}\n" +
    "  .kmtk b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .kmtk.up b{color:var(--green)}.kmtk.down b{color:var(--bad)}\n" +
    "  .kmtk span{font-size:11px;color:var(--dim)}\n" +
    "  .kmvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .kmvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .kmvtoggle button.on{background:var(--tile);color:var(--km)}\n" +
    "  .kmscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    /* cards */
    "  .kmcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px}\n" +
    "  .kmcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px;border-left:3px solid var(--green)}\n" +
    "  .kmcard.down{border-left-color:var(--bad)}\n" +
    "  .kmctop{display:flex;align-items:center;gap:8px;margin-bottom:10px}\n" +
    "  .kmdot{width:10px;height:10px;border-radius:50%;flex:none;background:var(--green)}\n" +
    "  .kmcard.down .kmdot{background:var(--bad)}\n" +
    "  .kmcnm{font-weight:700;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .kmring{position:relative;width:60px;height:60px;border-radius:50%;background:conic-gradient(var(--c) 0 calc(var(--p)*1%),var(--bg) calc(var(--p)*1%) 100%);display:flex;align-items:center;justify-content:center;margin:0 auto 8px}\n" +
    "  .kmring::before{content:'';position:absolute;width:46px;height:46px;border-radius:50%;background:var(--tile)}\n" +
    "  .kmring span{position:relative;font-size:12px;font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .kmcmeta{display:flex;justify-content:space-between;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .kmspark{display:flex;gap:1px;height:16px;align-items:flex-end;margin-top:8px}\n" +
    "  .kmspark i{flex:1;border-radius:1px;background:var(--green);min-height:3px}\n" +
    "  .kmspark i.d{background:var(--bad)}\n" +
    /* liste */
    "  .kmrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:10px 14px;margin-bottom:7px}\n" +
    "  .kmrow.down{border-color:var(--bad)}\n" +
    "  .kmrtx{min-width:0;flex:1}\n" +
    "  .kmrnm{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kmrgrp{font-size:11px;color:var(--dim)}\n" +
    "  .kmrspark{display:flex;gap:1px;height:20px;align-items:flex-end;width:80px;flex:none}\n" +
    "  .kmrspark i{flex:1;border-radius:1px;background:var(--green);min-height:3px}\n" +
    "  .kmrspark i.d{background:var(--bad)}\n" +
    "  .kmrstat{text-align:right;flex:none;font-variant-numeric:tabular-nums}\n" +
    "  .kmrup{font-size:13px;font-weight:600}\n" +
    "  .kmrping{font-size:11px;color:var(--dim)}\n" +
    "  .kmempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { let s = document.getElementById('kmUiCss'); if (!s) { s = document.createElement('style'); s.id = 'kmUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des moniteurs…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/kuma/detail'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function spark(arr, cls) {
    if (!arr || !arr.length) return '';
    return '<div class="' + cls + '">' + arr.map(v => '<i class="' + (v ? '' : 'd') + '" style="height:' + (v ? 100 : 40) + '%"></i>').join('') + '</div>';
  }
  function ringColor(m) {
    const p = m.uptime != null ? m.uptime : (m.up ? 100 : 0);
    return !m.up ? 'var(--bad)' : (p >= 99.95 ? 'var(--green)' : 'var(--warn)');
  }
  function card(m) {
    const p = m.uptime != null ? m.uptime : (m.up ? 100 : 0);
    return '<div class="kmcard' + (m.up ? '' : ' down') + '">' +
      '<div class="kmctop"><span class="kmdot"></span><span class="kmcnm">' + esc(m.name) + '</span></div>' +
      '<div class="kmring" style="--p:' + p + ';--c:' + ringColor(m) + '"><span>' + (m.uptime != null ? m.uptime + '%' : (m.up ? 'up' : 'down')) + '</span></div>' +
      '<div class="kmcmeta"><span>' + (m.up ? 'En ligne' : 'Hors ligne') + '</span><span>' + (m.ping != null ? Math.round(m.ping) + ' ms' : '—') + '</span></div>' +
      spark(m.spark, 'kmspark') + '</div>';
  }
  function row(m) {
    return '<div class="kmrow' + (m.up ? '' : ' down') + '">' +
      '<span class="kmdot"></span>' +
      '<div class="kmrtx"><div class="kmrnm">' + esc(m.name) + '</div>' +
      (m.group ? '<div class="kmrgrp">' + esc(m.group) + '</div>' : '') + '</div>' +
      spark(m.spark, 'kmrspark') +
      '<div class="kmrstat"><div class="kmrup" style="color:' + (m.up ? 'var(--green)' : 'var(--bad)') + '">' + (m.uptime != null ? m.uptime + '%' : (m.up ? 'up' : 'down')) + '</div>' +
      '<div class="kmrping">' + (m.ping != null ? Math.round(m.ping) + ' ms' : '—') + '</div></div></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📡</div><div class="t1">Kuma indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et le slug de la page de statut dans ⚙.</div>' +
        '<button class="btnpill install" id="kmRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('kmRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="kmwrap"><div class="kmtopbar">' +
      '<div class="kmtotals">' +
      '<div class="kmtk up"><b>' + nf(d.up) + '</b><span>en ligne</span></div>' +
      '<div class="kmtk down"><b>' + nf(d.down) + '</b><span>hors ligne</span></div>' +
      '<div class="kmtk"><b>' + nf(d.total) + '</b><span>moniteurs</span></div>' +
      '<div class="kmtk"><b>' + (d.avg_ping != null ? d.avg_ping + '<span style="font-size:12px"> ms</span>' : '—') + '</b><span>ping moyen</span></div>' +
      '</div>' +
      '<div class="kmvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="kmscroll">';
    if (!d.monitors || !d.monitors.length) {
      h += '<div class="kmempty">Aucun moniteur sur cette page de statut.</div>';
    } else if (viewMode === 'cards') {
      h += '<div class="kmcards">' + d.monitors.map(card).join('') + '</div>';
    } else {
      h += d.monitors.map(row).join('');
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.kmvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
  }

  return { render };
})();
