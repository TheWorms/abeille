/* Kuma — état de la flotte via Uptime Kuma status page (Phase 3, lot B).
   Conteneur unique : le module construit son propre entête + grille. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.kuma = (function () {
  let S = null, root = null, tile = null;
  const CSS = ".khead{font-size:15px;font-weight:600;margin-bottom:12px}\n.kgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}\n.kcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:14px 12px;display:flex;flex-direction:column;align-items:center;gap:10px}\n.kcard.down{border-color:var(--bad)}\n.kctop{display:flex;align-items:center;gap:8px;width:100%}\n.kname2{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.ring{position:relative;width:66px;height:66px;border-radius:50%;background:conic-gradient(var(--c) 0 calc(var(--p)*1%),var(--tile-2) calc(var(--p)*1%) 100%);display:flex;align-items:center;justify-content:center}\n.ring::before{content:\"\";position:absolute;width:50px;height:50px;border-radius:50%;background:var(--tile)}\n.ring span{position:relative;font-size:12.5px;font-weight:700;font-variant-numeric:tabular-nums}\n.kstate{font-family:var(--mono);font-size:10.5px;color:var(--dim)}\n#tmBar.ring{background:rgba(224,82,82,.16);border-color:var(--bad);color:var(--bad);animation:tmpulse 1s infinite}";
  function ensureCss() { if (document.getElementById('kmUiCss')) return; const s = document.createElement('style'); s.id = 'kmUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="khead" id="kumaHead">Chargement de l\'état de la flotte…</div><div class="kgrid" id="kumaList"></div>';
    const head = document.getElementById('kumaHead'), list = document.getElementById('kumaList');
    if (!list) return;
    try {
      const [r, rf] = await Promise.all([sdk.api('/kuma'), sdk.api('/kuma/fleet')]);
      const d = await r.json();
      let fleet = null; try { fleet = await rf.json(); } catch (e) {}
      const fleetTotal = (fleet && fleet.ok) ? fleet.total : null;
      if (!d.ok) {
        if (fleet && fleet.ok) {
          const allUp = (fleet.down === 0);
          head.innerHTML = 'Flotte — <b style="color:' + (allUp ? 'var(--green)' : 'var(--warn)') + '">' + fleet.up + '/' + fleet.total + '</b> up' + (fleet.down ? (' · <span style="color:var(--bad)">' + fleet.down + ' hors ligne</span>') : '');
          list.innerHTML = '<div style="grid-column:1/-1;font-size:12px;color:var(--faint);padding:8px 2px;line-height:1.5">Détail par service : renseigne un <b>slug</b> de status page Uptime Kuma dans \u2699 Réglages.</div>';
          return;
        }
        head.innerHTML = '<span style="color:var(--bad)">Kuma indisponible — ' + (d.reason || '') + '</span><div style="font-size:12px;color:var(--dim);margin-top:6px;font-weight:400">Configure l\'URL + le slug dans Paramètres → Applications → \u2699.</div>'; list.innerHTML = ''; return;
      }
      const sur = (fleetTotal != null && fleetTotal > d.total) ? (' <span style="color:var(--dim);font-weight:400;font-size:13px">(surveillés sur ' + fleetTotal + ')</span>') : '';
      head.innerHTML = 'Flotte — <b style="color:' + (d.up >= d.total ? 'var(--green)' : 'var(--warn)') + '">' + d.up + '/' + d.total + '</b> up' + sur;
      list.innerHTML = d.services.map(s => {
        const p = s.uptime != null ? s.uptime : (s.up ? 100 : 0);
        const c = !s.up ? 'var(--bad)' : (p >= 99.95 ? 'var(--green)' : 'var(--warn)');
        return '<div class="kcard' + (s.up ? '' : ' down') + '">' +
          '<div class="kctop"><span class="kdot2" style="background:' + (s.up ? 'var(--green)' : 'var(--bad)') + '"></span><span class="kname2">' + s.name + '</span></div>' +
          '<div class="ring" style="--p:' + p + ';--c:' + c + '"><span>' + (s.uptime != null ? s.uptime + '%' : (s.up ? 'up' : 'down')) + '</span></div>' +
          '<div class="kstate">' + (s.up ? 'En ligne' : 'Hors ligne') + '</div></div>';
      }).join('');
    } catch (e) { if (head) head.textContent = 'Serveur injoignable'; }
  }
  return { render };
})();
