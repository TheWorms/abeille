"""Addon « kuma » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/kuma/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Deux sources Uptime Kuma :
  - page de statut publique (slug) -> détail par service (heartbeat + uptime 24 h)
  - endpoint /metrics (clé API) -> comptage global up/down/pending/maint
La pastille « flotte » privilégie /metrics (voit les monitors en pause) et
retombe sur la page de statut si la clé n'est pas fournie.
"""


def _kuma_status(sdk, cfg):
    """Lit l'état de la flotte depuis une page de statut Uptime Kuma."""
    url = (cfg.get("url") or "").rstrip("/")
    slug = (cfg.get("slug") or "").strip()
    if not url or not slug:
        return {"ok": False, "reason": "non configuré"}
    try:
        names = {}
        rp = sdk.requests.get(f"{url}/api/status-page/{slug}", timeout=4, verify=False)
        if rp.status_code == 200:
            for g in rp.json().get("publicGroupList", []):
                for m in g.get("monitorList", []):
                    names[m.get("id")] = m.get("name")
        rh = sdk.requests.get(f"{url}/api/status-page/heartbeat/{slug}",
                              timeout=4, verify=False)
        if rh.status_code != 200:
            return {"ok": False, "reason": f"HTTP {rh.status_code}"}
        data = rh.json()
        hbl = data.get("heartbeatList", {})
        upl = data.get("uptimeList", {})
        services, up = [], 0
        for mid_, beats in hbl.items():
            if not beats:
                continue
            is_up = beats[-1].get("status") == 1
            up += 1 if is_up else 0
            uptime = upl.get(f"{mid_}_24")
            try:
                name = names.get(int(mid_))
            except (TypeError, ValueError):
                name = None
            services.append({
                "name": name or names.get(mid_) or f"#{mid_}",
                "up": is_up,
                "uptime": round(uptime * 100, 1) if isinstance(uptime, (int, float)) else None,
            })
        services.sort(key=lambda s: (s["up"], s["name"].lower()))
        return {"ok": True, "up": up, "total": len(services), "services": services}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError):
        return {"ok": False, "reason": "réponse invalide"}


def _kuma_metrics(sdk, url, key):
    """Compte tous les monitors ACTIFS via /metrics (clé API). Les monitors
    en pause ne sont pas exposés par l'API Kuma."""
    try:
        r = sdk.requests.get(f"{url}/metrics", timeout=4, verify=False, auth=("", key))
    except sdk.requests.exceptions.RequestException as e:
        return None, type(e).__name__
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"
    up = down = pending = maint = 0
    for line in r.text.splitlines():
        if line.startswith("monitor_status") and " " in line:
            try:
                val = int(float(line.rsplit(" ", 1)[1]))
            except ValueError:
                continue
            if val == 1:
                up += 1
            elif val == 0:
                down += 1
            elif val == 2:
                pending += 1
            elif val == 3:
                maint += 1
    return {"up": up, "down": down, "pending": pending, "maint": maint,
            "total": up + down + pending + maint}, None


def _kuma_fleet(sdk, cfg):
    url = (cfg.get("url") or "").rstrip("/")
    out = {"label": cfg.get("label") or "M\u00e9nagerie",
           "format": cfg.get("format") or "compact"}
    key = cfg.get("apikey") or ""
    if url and key:
        m, err = _kuma_metrics(sdk, url, key)
        if m:
            out.update(ok=True, source="metrics", **m)
            return out
        out["reason"] = err or "metrics"
    st = _kuma_status(sdk, cfg)
    if st.get("ok"):
        out.update(ok=True, source="statuspage", up=st["up"],
                   down=st["total"] - st["up"], pending=0, maint=0,
                   total=st["total"])
        return out
    out.setdefault("ok", False)
    out.setdefault("reason", st.get("reason", "non configur\u00e9"))
    return out


def _kuma_detail(sdk, cfg):
    """Vue détaillée : par moniteur, état + ping + uptime 24 h, groupes."""
    url = (cfg.get("url") or "").rstrip("/")
    slug = (cfg.get("slug") or "").strip()
    if not url or not slug:
        return {"ok": False, "reason": "URL + slug requis (page de statut)"}
    ck = f"kuma:detail:{url}:{slug}"
    c = sdk.cache_get(ck, 30)
    if c is not None:
        return c
    try:
        groups_meta = []
        names = {}
        rp = sdk.requests.get(f"{url}/api/status-page/{slug}", timeout=5, verify=False)
        if rp.status_code == 200:
            for g in rp.json().get("publicGroupList", []):
                gname = g.get("name") or "Services"
                mids = []
                for m in g.get("monitorList", []):
                    names[m.get("id")] = {"name": m.get("name"), "type": m.get("type"), "group": gname}
                    mids.append(m.get("id"))
                groups_meta.append({"name": gname, "monitors": mids})
        rh = sdk.requests.get(f"{url}/api/status-page/heartbeat/{slug}",
                              timeout=5, verify=False)
        if rh.status_code != 200:
            return {"ok": False, "reason": f"HTTP {rh.status_code}"}
        data = rh.json()
        hbl = data.get("heartbeatList", {})
        upl = data.get("uptimeList", {})
        monitors = []
        up = down = 0
        for mid_, beats in hbl.items():
            if not beats:
                continue
            last = beats[-1]
            status = last.get("status")
            is_up = status == 1
            up += 1 if is_up else 0
            down += 0 if is_up else 1
            try:
                meta = names.get(int(mid_)) or names.get(mid_) or {}
            except (TypeError, ValueError):
                meta = names.get(mid_) or {}
            uptime = upl.get(f"{mid_}_24")
            # mini-historique des derniers battements (pour sparkline)
            spark = [1 if b.get("status") == 1 else 0 for b in beats[-20:]]
            monitors.append({
                "id": mid_,
                "name": (meta.get("name") if isinstance(meta, dict) else None) or f"#{mid_}",
                "type": meta.get("type") if isinstance(meta, dict) else None,
                "group": meta.get("group") if isinstance(meta, dict) else None,
                "up": is_up,
                "status": status,
                "ping": last.get("ping"),
                "uptime": round(uptime * 100, 1) if isinstance(uptime, (int, float)) else None,
                "msg": last.get("msg") or "",
                "spark": spark,
            })
        monitors.sort(key=lambda m: (m["up"], (m["name"] or "").lower()))
        pings = [m["ping"] for m in monitors if isinstance(m.get("ping"), (int, float))]
        avg_ping = round(sum(pings) / len(pings)) if pings else None
        out = {"ok": True, "up": up, "down": down, "total": len(monitors),
               "avg_ping": avg_ping, "monitors": monitors, "groups": groups_meta}
        return sdk.cache_set(ck, out)
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError):
        return {"ok": False, "reason": "réponse invalide"}


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("kuma", __name__)

    @bp.route("/kuma")
    def kuma():
        try:
            return jsonify(_kuma_status(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("kuma")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/kuma/detail")
    def kuma_detail():
        try:
            return jsonify(_kuma_detail(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("kuma detail")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/kuma/fleet")
    def kuma_fleet():
        try:
            return jsonify(_kuma_fleet(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("kuma_fleet")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    url = (cfg.get("url") or "").rstrip("/")
    if not url:
        return False, "URL manquante"
    slug = (cfg.get("slug") or "").strip()
    if slug:
        r = sdk.requests.get(f"{url}/api/status-page/heartbeat/{slug}",
                             timeout=4, verify=False)
        if r.status_code == 200:
            hb = r.json().get("heartbeatList", {})
            total = len(hb)
            up = sum(1 for v in hb.values()
                     if v and v[-1].get("status") == 1)
            return True, f"OK — {up}/{total} services up"
        return False, f"HTTP {r.status_code} (slug « {slug} » introuvable ?)"
    if cfg.get("apikey"):
        r = sdk.requests.get(f"{url}/metrics", timeout=4, verify=False,
                             auth=("", cfg["apikey"]))
        return (r.status_code == 200), f"metrics: HTTP {r.status_code}"
    return False, "Renseigne un slug ou une clé API"
