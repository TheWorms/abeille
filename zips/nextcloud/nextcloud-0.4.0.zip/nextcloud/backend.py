"""Addon « nextcloud » — client Nextcloud OCS + WebDAV (lot L).

Migré du noyau vers un backend autonome. Auth par mot de passe d'application
(jamais exposé côté client). Résumé (quota, version, récents, partages) mis en
cache 2 min via ``sdk.cache``. Le download relaie le fichier en flux (le drive
n'est jamais exposé). ``_safe_path`` neutralise toute traversée de répertoire.
"""
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from urllib.parse import quote, unquote

_NS = {"d": "DAV:"}


def _safe_path(p):
    """Chemin relatif propre, sans traversée (« .. » et « . » retirés)."""
    p = (p or "").strip().strip("/")
    parts = [x for x in p.split("/") if x and x not in (".", "..")]
    return "/".join(parts)


def _recent(sdk, url, user, pw, limit=10):
    """Fichiers récents via SEARCH WebDAV (RFC 5323), triés par date de modif."""
    body = f'''<?xml version="1.0" encoding="UTF-8"?>
<d:searchrequest xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns">
  <d:basicsearch>
    <d:select><d:prop><d:getlastmodified/><d:getcontentlength/>
      <d:getcontenttype/><oc:fileid/></d:prop></d:select>
    <d:from><d:scope><d:href>/files/{user}</d:href><d:depth>infinity</d:depth></d:scope></d:from>
    <d:orderby><d:order><d:prop><d:getlastmodified/></d:prop>
      <d:descending/></d:order></d:orderby>
    <d:limit><d:nresults>{limit}</d:nresults></d:limit>
  </d:basicsearch>
</d:searchrequest>'''
    r = sdk.requests.request("SEARCH", f"{url}/remote.php/dav/", data=body.encode(),
                             auth=(user, pw), headers={"Content-Type": "text/xml"}, timeout=12)
    if r.status_code not in (200, 207):
        return []
    out = []
    for resp in ET.fromstring(r.content).findall("d:response", _NS):
        href = resp.find("d:href", _NS)
        if href is None or not href.text:
            continue
        path = unquote(href.text)
        if path.endswith("/"):
            continue
        name = path.rstrip("/").split("/")[-1]
        prop = resp.find(".//d:prop", _NS)
        mod = prop.find("d:getlastmodified", _NS) if prop is not None else None
        size = prop.find("d:getcontentlength", _NS) if prop is not None else None
        ctype = prop.find("d:getcontenttype", _NS) if prop is not None else None
        when = ""
        if mod is not None and mod.text:
            try:
                when = datetime.strptime(mod.text, "%a, %d %b %Y %H:%M:%S %Z") \
                    .replace(tzinfo=timezone.utc).astimezone().strftime("%d/%m %H:%M")
            except ValueError:
                when = mod.text[:16]
        folder = "/".join(path.split(f"/files/{user}/", 1)[-1].split("/")[:-1])
        out.append({"name": name, "folder": folder, "when": when,
                    "size_mb": round(int(size.text) / 1048576, 2) if (size is not None and size.text) else 0,
                    "type": (ctype.text if ctype is not None and ctype.text else "")})
    return out[:limit]


def _shares(sdk, url, user, pw):
    r = sdk.requests.get(f"{url}/ocs/v2.php/apps/files_sharing/api/v1/shares",
                         headers={"OCS-APIRequest": "true", "Accept": "application/json"},
                         auth=(user, pw), timeout=10)
    if r.status_code != 200:
        return []
    try:
        data = r.json()["ocs"]["data"]
    except (ValueError, KeyError, TypeError):
        return []
    types = {0: "utilisateur", 1: "groupe", 3: "lien public", 4: "e-mail"}
    out = []
    for sh in data:
        out.append({"name": (sh.get("path") or "").split("/")[-1],
                    "with": sh.get("share_with_displayname") or sh.get("share_with") or "",
                    "kind": types.get(sh.get("share_type"), "?"),
                    "expires": sh.get("expiration") or "",
                    "folder": sh.get("item_type") == "folder"})
    return out


def _summary(sdk, cfg):
    url = (cfg.get("url") or "").rstrip("/")
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not (url and user and pw):
        return {"ok": False, "reason": "URL/identifiants non configurés (⚙ Nextcloud)"}
    key = f"nc:{url}:{user}"
    hit = sdk.cache_get(key, 120)
    if hit is not None:
        return hit
    hdr = {"OCS-APIRequest": "true", "Accept": "application/json"}
    try:
        r = sdk.requests.get(f"{url}/ocs/v1.php/cloud/users/{user}",
                             headers=hdr, auth=(user, pw), timeout=10)
        if r.status_code == 401:
            return {"ok": False, "reason": "identifiants refusés (401) — mot de passe d'application"}
        if r.status_code != 200:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        data = r.json()["ocs"]["data"]
        q = data.get("quota", {})
        cap = {}
        rc = sdk.requests.get(f"{url}/ocs/v1.php/cloud/capabilities",
                              headers=hdr, auth=(user, pw), timeout=8)
        if rc.ok:
            cap = rc.json()["ocs"]["data"].get("version", {})
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2) as pool:
            f_rec = pool.submit(_recent, sdk, url, user, pw, 10)
            f_sh = pool.submit(_shares, sdk, url, user, pw)
            try:
                recent = f_rec.result()
            except Exception:
                recent = []
            try:
                shares = f_sh.result()
            except Exception:
                shares = []
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}
    used, total = q.get("used") or 0, q.get("total") or 0
    res = {"ok": True, "recent": recent, "shares": shares,
           "display": data.get("displayname") or user,
           "used_gb": round(used / 1073741824, 2),
           "total_gb": round(total / 1073741824, 2) if total > 0 else None,
           "pct": round(q.get("relative") or 0, 1),
           "free_gb": round((q.get("free") or 0) / 1073741824, 2),
           "version": cap.get("string", ""), "email": data.get("email") or ""}
    return sdk.cache_set(key, res)


def _ls(sdk, cfg, path):
    url = (cfg.get("url") or "").rstrip("/")
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not (url and user and pw):
        return {"ok": False, "reason": "Nextcloud non configuré (⚙)"}
    rel = _safe_path(path)
    dav = f"{url}/remote.php/dav/files/{quote(user)}/" + (quote(rel) + "/" if rel else "")
    body = ('<?xml version="1.0"?><d:propfind xmlns:d="DAV:">'
            '<d:prop><d:getlastmodified/><d:getcontentlength/>'
            '<d:getcontenttype/><d:resourcetype/></d:prop></d:propfind>')
    try:
        r = sdk.requests.request("PROPFIND", dav, data=body.encode(), auth=(user, pw),
                                 headers={"Depth": "1", "Content-Type": "text/xml"}, timeout=12)
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    if r.status_code == 401:
        return {"ok": False, "reason": "identifiants refusés (401)"}
    if r.status_code == 404:
        return {"ok": False, "reason": "dossier introuvable"}
    if r.status_code not in (200, 207):
        return {"ok": False, "reason": f"HTTP {r.status_code}"}
    dirs, files = [], []
    base = f"/remote.php/dav/files/{user}/"
    for resp in ET.fromstring(r.content).findall("d:response", _NS):
        href = resp.find("d:href", _NS)
        if href is None or not href.text:
            continue
        p = unquote(href.text)
        if base not in p:
            continue
        rp = p.split(base, 1)[-1].strip("/")
        if rp == rel:
            continue
        name = rp.split("/")[-1]
        prop = resp.find(".//d:prop", _NS)
        is_dir = prop is not None and prop.find("d:resourcetype/d:collection", _NS) is not None
        mod = prop.find("d:getlastmodified", _NS) if prop is not None else None
        when = ""
        if mod is not None and mod.text:
            try:
                when = datetime.strptime(mod.text, "%a, %d %b %Y %H:%M:%S %Z") \
                    .replace(tzinfo=timezone.utc).astimezone().strftime("%d/%m/%Y %H:%M")
            except ValueError:
                when = mod.text[:16]
        if is_dir:
            dirs.append({"name": name, "path": rp, "when": when})
        else:
            size = prop.find("d:getcontentlength", _NS) if prop is not None else None
            ctype = prop.find("d:getcontenttype", _NS) if prop is not None else None
            files.append({"name": name, "path": rp, "when": when,
                          "size_mb": round(int(size.text) / 1048576, 2)
                          if (size is not None and size.text) else 0,
                          "type": (ctype.text if ctype is not None and ctype.text else "")})
    dirs.sort(key=lambda x: x["name"].lower())
    files.sort(key=lambda x: x["name"].lower())
    return {"ok": True, "path": rel, "dirs": dirs, "files": files}


def register(sdk):
    from flask import Blueprint, jsonify, request, Response, stream_with_context
    bp = Blueprint("nextcloud", __name__)

    @bp.route("/summary")
    def summary():
        return jsonify(_summary(sdk, sdk.config()))

    @bp.route("/ls")
    def ls():
        return jsonify(_ls(sdk, sdk.config(), request.args.get("path", "")))

    @bp.route("/dl")
    def dl():
        cfg = sdk.config()
        url = (cfg.get("url") or "").rstrip("/")
        user = (cfg.get("user") or "").strip()
        pw = (cfg.get("pass") or "").strip()
        rel = _safe_path(request.args.get("path", ""))
        if not (url and user and pw and rel):
            return jsonify({"ok": False, "reason": "requête invalide"}), 400
        dav = f"{url}/remote.php/dav/files/{quote(user)}/{quote(rel)}"
        try:
            r = sdk.requests.get(dav, auth=(user, pw), stream=True, timeout=20)
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": type(e).__name__}), 502
        if r.status_code != 200:
            return jsonify({"ok": False, "reason": f"HTTP {r.status_code}"}), 502
        if int(r.headers.get("Content-Length") or 0) > 100 * 1048576:
            return jsonify({"ok": False, "reason": "fichier > 100 Mo — ouvre Nextcloud"}), 413
        ctype = r.headers.get("Content-Type", "application/octet-stream")
        fname = rel.split("/")[-1].replace('"', "")
        return Response(stream_with_context(r.iter_content(65536)), content_type=ctype,
                        headers={"Content-Disposition": f'inline; filename="{fname}"',
                                 "Cache-Control": "no-store"})

    @bp.route("/thumb")
    def thumb():
        """Miniature d'un fichier via l'API de preview Nextcloud.

        Utilise /index.php/core/preview.png?file=<chemin>&x=&y=. Retour 204 si
        Nextcloud ne sait pas prévisualiser (le front retombe alors sur l'icône)."""
        cfg = sdk.config()
        url = (cfg.get("url") or "").rstrip("/")
        user = (cfg.get("user") or "").strip()
        pw = (cfg.get("pass") or "").strip()
        rel = _safe_path(request.args.get("path", ""))
        if not (url and user and pw and rel):
            return Response(status=400)
        try:
            sz = max(32, min(256, int(request.args.get("s", 128))))
        except (TypeError, ValueError):
            sz = 128
        prev = f"{url}/index.php/core/preview.png"
        try:
            r = sdk.requests.get(prev, auth=(user, pw),
                                 params={"file": "/" + rel, "x": sz, "y": sz,
                                         "a": 0, "mode": "cover", "forceIcon": 0},
                                 stream=True, timeout=12)
        except sdk.requests.exceptions.RequestException:
            return Response(status=204)
        if r.status_code != 200:
            return Response(status=204)   # pas de preview : le front garde l'icône
        return Response(stream_with_context(r.iter_content(32768)),
                        content_type=r.headers.get("Content-Type", "image/png"),
                        headers={"Cache-Control": "private, max-age=3600"})

    return bp


def test(sdk, cfg):
    n = _summary(sdk, cfg)
    if n.get("ok"):
        q = f"{n['used_gb']} Go" + (f" / {n['total_gb']} Go" if n["total_gb"] else "")
        return True, f"Nextcloud \u2713 ({n['version']}) \u2014 {q} utilisés"
    return False, f"Nextcloud \u2717 ({n.get('reason')})"
