/* Nextcloud — quota, récents, partages + explorateur WebDAV et visionneuse
   (Phase 3, lot B). Réutilise les classes partagées wsec/wsrc/grafhead. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.nextcloud = (function () {
  let S = null, root = null, tile = null, ncPath = '', ncView = 'list';
  const CSS = ".ncrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);\n         border-radius:10px;padding:9px 13px;margin-bottom:6px}\n.ncw{font-family:var(--mono);font-size:10.5px;color:var(--faint);min-width:82px;flex:none}\n.ncn{font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.ncf{font-size:10.5px;color:var(--dim)}\n.ncs{margin-left:auto;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n.nckind{font-size:10px;padding:3px 8px;border-radius:6px;background:var(--accent-tint);color:var(--accent);flex:none}\n.nckind.pub{background:rgba(240,180,41,.16);color:var(--warn)}\n.ncthumb{width:38px;height:38px;flex:none;border-radius:8px;object-fit:cover;background:var(--bg);border:1px solid var(--border-soft)}\n.ncthico{width:38px;height:38px;flex:none;display:flex;align-items:center;justify-content:center;font-size:20px;\n         border-radius:8px;background:var(--bg);border:1px solid var(--border-soft)}\n.nccols{display:grid;grid-template-columns:1.3fr 1fr;gap:14px}\n#ncExp{flex:1;min-height:0;display:flex;flex-direction:column}\n.ncexplist{flex:1;min-height:140px}\n.quota{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:16px 18px;margin-bottom:12px}\n.quotab{height:12px;border-radius:7px;background:var(--border-soft);overflow:hidden;margin:10px 0 6px}\n.quotaf{height:100%;border-radius:7px;background:var(--accent)}\n.quotaf.warn{background:var(--warn)}\n.quotaf.bad{background:var(--bad)}\n.quotal{display:flex;justify-content:space-between;font-size:12px;color:var(--dim)}\n.ncvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:2px;margin-left:auto}\n.ncvtoggle button{background:transparent;border:0;color:var(--dim);font-size:14px;width:32px;height:28px;border-radius:6px;cursor:pointer}\n.ncvtoggle button.on{background:var(--tile);color:var(--accent)}\n.ncgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:10px;padding:4px}\n.nccard{cursor:pointer;display:flex;flex-direction:column;gap:5px}\n.nccard .ncgthumb{width:100%;aspect-ratio:1;border-radius:9px;object-fit:cover;background:var(--bg);border:1px solid var(--border-soft)}\n.nccard .ncgico{width:100%;aspect-ratio:1;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:34px;background:var(--bg);border:1px solid var(--border-soft)}\n.nccard .ncgn{font-size:11px;font-weight:600;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}";
  function ensureCss() { let s = document.getElementById('ncUiCss'); if (!s) { s = document.createElement('style'); s.id = 'ncUiCss'; document.head.appendChild(s); } s.textContent = CSS; }

  const fmtSize = mb => mb >= 1 ? ('' + mb).replace('.', ',') + ' Mo' : Math.max(1, Math.round(mb * 1024)) + ' Ko';
  function kind(f) {
    const t = (f.type || '').toLowerCase(), n = f.name.toLowerCase();
    if (t.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|svg)$/.test(n)) return 'image';
    if (t === 'application/pdf' || n.endsWith('.pdf')) return 'pdf';
    if (t.startsWith('text/') || /\.(txt|md|log|csv|json|ya?ml|conf|ini|sh|py)$/.test(n)) return 'text';
    if (t.startsWith('audio/') || /\.(mp3|flac|ogg|m4a|wav)$/.test(n)) return 'audio';
    if (t.startsWith('video/') || /\.(mp4|mkv|webm|mov)$/.test(n)) return 'video';
    return '';
  }
  const icon = f => ({ image: '🖼️', pdf: '📕', text: '📄', audio: '🎵', video: '🎬' }[kind(f)] || '📄');
  // Types que Nextcloud sait prévisualiser en vignette (image + pdf + vidéo)
  const previewable = f => { const k = kind(f); return k === 'image' || k === 'pdf' || k === 'video'; };
  function thumbTag(f) {
    const ic = icon(f);
    if (!previewable(f)) return '<span class="ncthico">' + ic + '</span>';
    const src = '/addons/nextcloud/api/thumb?s=96&path=' + encodeURIComponent(f.path);
    // data-fallback porte l'icône ; wireThumbs() branchera onerror après injection
    return '<img class="ncthumb" loading="lazy" src="' + src + '" data-fallback="' + ic + '">';
  }
  function wireThumbs(scope) {
    (scope || document).querySelectorAll('img.ncthumb[data-fallback]').forEach(im => {
      im.addEventListener('error', function () {
        const fb = this.getAttribute('data-fallback') || '📄';
        const sp = document.createElement('span');
        sp.className = 'ncthico'; sp.textContent = fb;
        if (this.parentNode) this.parentNode.replaceChild(sp, this);
      }, { once: true });
    });
    (scope || document).querySelectorAll('img.ncgthumb[data-fallback]').forEach(im => {
      im.addEventListener('error', function () {
        const fb = this.getAttribute('data-fallback') || '📄';
        const dv = document.createElement('div');
        dv.className = 'ncgico'; dv.textContent = fb;
        if (this.parentNode) this.parentNode.replaceChild(dv, this);
      }, { once: true });
    });
  }

  async function browse(path) {
    const box = document.getElementById('ncExp'); if (!box) return;
    ncPath = path || '';
    box.innerHTML = '<div class="stub" style="padding:16px"><div class="t2">Chargement…</div></div>';
    let d = null;
    try { const r = await S.api('/ls?path=' + encodeURIComponent(ncPath)); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d || !d.ok) { box.innerHTML = '<div class="stub" style="padding:16px"><div class="t2">' + ((d && d.reason) || 'erreur') + '</div></div>'; return; }
    const parts = ncPath ? ncPath.split('/') : [];
    let bc = '<div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:2px 0 8px;font-size:13px">' +
      '<span class="wch" data-ncp="">☁️ Racine</span>';
    let acc = '';
    parts.forEach(p => { acc = acc ? (acc + '/' + p) : p;
      bc += '<span style="color:var(--faint)">›</span><span class="wch" data-ncp="' + acc.replace(/"/g, '&quot;') + '">' + p + '</span>'; });
    bc += '</div>';
    // bascule liste/cards dans le fil d'ariane
    bc = bc.replace('</div>', '<span class="ncvtoggle">' +
      '<button data-ncv="list"' + (ncView === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-ncv="cards"' + (ncView === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button></span></div>');
    let rows = '';
    if (ncView === 'cards') {
      let grid = '';
      (d.dirs || []).forEach(x => { grid += '<div class="nccard ncnav" data-ncp="' + x.path.replace(/"/g, '&quot;') + '">' +
        '<div class="ncgico">📁</div><div class="ncgn">' + x.name + '</div></div>'; });
      (d.files || []).forEach((x, i) => { const k = kind(x);
        const src = '/addons/nextcloud/api/thumb?s=128&path=' + encodeURIComponent(x.path);
        const ic = icon(x);
        const thumb = previewable(x) ? '<img class="ncgthumb" loading="lazy" src="' + src + '" data-fallback="' + ic + '">'
                        : '<div class="ncgico">' + ic + '</div>';
        grid += '<div class="nccard' + (k ? ' ncfile' : '') + '" data-nci="' + i + '">' +
          thumb + '<div class="ncgn">' + x.name + '</div></div>'; });
      rows = grid ? '<div class="ncgrid">' + grid + '</div>' : '';
    } else {
      (d.dirs || []).forEach(x => { rows += '<div class="ncrow ncnav" data-ncp="' + x.path.replace(/"/g, '&quot;') + '" style="cursor:pointer;min-height:48px">' +
        '<span class="ncthico">📁</span><span style="min-width:0"><span class="ncn">' + x.name + '</span></span>' +
        '<span class="ncs">' + x.when + '</span></div>'; });
      (d.files || []).forEach((x, i) => { const k = kind(x);
        rows += '<div class="ncrow' + (k ? ' ncfile' : '') + '" data-nci="' + i + '"' + (k ? ' style="cursor:pointer;min-height:48px"' : ' style="min-height:48px"') + '>' +
          thumbTag(x) +
          '<span style="min-width:0"><span class="ncn">' + x.name + '</span>' + (k ? '' : '<span class="ncf">aperçu non pris en charge</span>') + '</span>' +
          '<span class="ncs">' + fmtSize(x.size_mb) + '</span></div>'; });
    }
    if (!rows) rows = '<div class="stub" style="padding:16px"><div class="t2">Dossier vide</div></div>';
    box.innerHTML = bc + '<div class="ncexplist" style="overflow:auto;border:1px solid var(--border-soft);border-radius:12px;padding:4px 8px">' + rows + '</div>';
    box.querySelectorAll('.ncvtoggle button').forEach(b => b.addEventListener('click', async (e) => {
      e.stopPropagation(); const v = b.getAttribute('data-ncv'); if (v === ncView) return;
      ncView = v; try { await S.store.save({ ncview: v }); } catch (er) {}
      browse(ncPath);
    }));
    box.querySelectorAll('[data-ncp]').forEach(el => el.addEventListener('click', () => browse(el.dataset.ncp)));
    box.querySelectorAll('.ncfile').forEach(el => el.addEventListener('click', () => viewer(d.files[parseInt(el.dataset.nci)])));
    wireThumbs(box);
  }
  function viewer(f) {
    if (!f) return;
    const k = kind(f); if (!k) { S.toast('Format non pris en charge — ouvre Nextcloud'); return; }
    const url = '/addons/nextcloud/api/dl?path=' + encodeURIComponent(f.path);
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.92);display:flex;flex-direction:column';
    ov.innerHTML = '<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;flex:0 0 auto">' +
      '<span style="font-size:18px">' + icon(f) + '</span>' +
      '<span style="color:#fff;font-size:14.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1">' + f.name + '</span>' +
      '<span class="ncs" style="color:#aaa">' + fmtSize(f.size_mb) + '</span>' +
      '<button id="ncvX" style="width:48px;height:48px;border-radius:12px;border:1px solid #555;background:#222;color:#fff;font-size:20px">✕</button></div>' +
      '<div id="ncvBody" style="flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:0 12px 12px"></div>';
    document.body.appendChild(ov);
    const close = () => ov.remove();
    ov.querySelector('#ncvX').addEventListener('click', close);
    ov.addEventListener('click', e => { if (e.target === ov) close(); });
    const body = ov.querySelector('#ncvBody');
    if (k === 'image') body.innerHTML = '<img src="' + url + '" style="max-width:100%;max-height:100%;object-fit:contain;border-radius:8px">';
    else if (k === 'pdf') body.innerHTML = '<embed src="' + url + '" type="application/pdf" style="width:100%;height:100%;border-radius:8px;background:#fff">';
    else if (k === 'audio') body.innerHTML = '<audio src="' + url + '" controls autoplay style="width:90%"></audio>';
    else if (k === 'video') body.innerHTML = '<video src="' + url + '" controls autoplay style="max-width:100%;max-height:100%;border-radius:8px"></video>';
    else {
      body.innerHTML = '<div class="t2" style="color:#aaa">Chargement…</div>';
      fetch(url).then(r => { if (!r.ok) throw 0; return r.text(); }).then(t => {
        body.innerHTML = '<pre style="width:100%;height:100%;overflow:auto;background:#111;color:#ddd;border-radius:8px;padding:14px;font-size:13px;margin:0;white-space:pre-wrap"></pre>';
        body.firstChild.textContent = t.slice(0, 300000);
      }).catch(() => { body.innerHTML = '<div class="t2" style="color:#e8635a">Lecture impossible</div>'; });
    }
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Nextcloud…</div></div>';
    const cfg = await sdk.config();
    const url = ((cfg.url || '').trim()) || 'http://192.168.1.10';
    let d = null; try { const r = await sdk.api('/summary'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead"><button class="lgbtn" id="ncOpen" style="margin:0;padding:9px 18px;font-size:14px">Ouvrir Nextcloud \u2197</button><button class="wch" id="ncRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">☁️</div><div class="t1">Écureuil — Nextcloud</div><div class="t2">' + ((d && d.reason) || '') + '<br>Crée un <b>mot de passe d\'application</b> (Paramètres → Sécurité) et renseigne-le dans \u2699.</div></div>';
    } else {
      const cls = d.pct >= 90 ? 'bad' : (d.pct >= 75 ? 'warn' : '');
      h += '<div class="quota"><div style="display:flex;align-items:center;gap:10px">' +
        '<span style="font-size:22px">☁️</span><div><div style="font-weight:700;font-size:15px">' + d.display + '</div>' +
        '<div style="font-size:11.5px;color:var(--dim)">Nextcloud ' + (d.version || '') + (d.email ? ' · ' + d.email : '') + '</div></div>' +
        '<div style="margin-left:auto;text-align:right"><div style="font-size:22px;font-weight:700">' + d.pct + ' %</div>' +
        '<div style="font-size:11px;color:var(--dim)">utilisé</div></div></div>' +
        '<div class="quotab"><div class="quotaf ' + cls + '" style="width:' + Math.min(100, d.pct) + '%"></div></div>' +
        '<div class="quotal"><span>' + d.used_gb + ' Go utilisés</span>' +
        '<span>' + (d.total_gb ? (d.free_gb + ' Go libres sur ' + d.total_gb + ' Go') : 'quota illimité') + '</span></div></div>';
      h += '<div class="wsec" style="padding-left:0">📂 Explorateur du drive</div><div id="ncExp"><div class="stub" style="padding:16px"><div class="t2">Chargement…</div></div></div>';
      h += '<div class="nccols"><div>';
      h += '<div class="wsec" style="padding-left:0">Fichiers récents</div>';
      if (!(d.recent || []).length) h += '<div class="stub" style="padding:20px"><div class="t2">Aucun fichier récent</div></div>';
      else h += d.recent.map(f => '<div class="ncrow"><span class="ncw">' + f.when + '</span>' +
        '<span style="min-width:0"><span class="ncn">' + f.name + '</span>' +
        (f.folder ? '<span class="ncf">📁 ' + f.folder + '</span>' : '') + '</span>' +
        '<span class="ncs">' + (f.size_mb >= 1 ? f.size_mb + ' Mo' : Math.round(f.size_mb * 1024) + ' Ko') + '</span></div>').join('');
      h += '</div><div>';
      h += '<div class="wsec" style="padding-left:0">Partages (' + (d.shares || []).length + ')</div>';
      if (!(d.shares || []).length) h += '<div class="stub" style="padding:20px"><div class="t2">Aucun partage actif</div></div>';
      else h += d.shares.map(sh => '<div class="ncrow"><span>' + (sh.folder ? '📁' : '📄') + '</span>' +
        '<span style="min-width:0"><span class="ncn">' + sh.name + '</span>' +
        (sh.with ? '<span class="ncf">avec ' + sh.with + '</span>' : '') +
        (sh.expires ? '<span class="ncf">expire le ' + sh.expires.slice(0, 10).split("-").reverse().join("/") + '</span>' : '') + '</span>' +
        '<span class="nckind' + (sh.kind === 'lien public' ? ' pub' : '') + '">' + sh.kind + '</span></div>').join('');
      h += '</div></div>';
      h += '<div class="wsrc">Nextcloud sur Écureuil · API OCS et WebDAV · vue embarquée v0.3.0</div>';
    }
    el.innerHTML = h;
    const ob = document.getElementById('ncOpen'); if (ob) ob.addEventListener('click', () => sdk.openService(url, (a && (a.nm || a.name)) || 'Nextcloud'));
    const rb = document.getElementById('ncRefresh'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
    try { const st = await S.store.load(); if (st && (st.ncview === 'cards' || st.ncview === 'list')) ncView = st.ncview; } catch (e) {}
    if (document.getElementById('ncExp')) browse(ncPath);
  }
  return { render };
})();
