/* Paperless-ngx — stats, recherche, inbox + récents, liste/cards, vignettes. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.paperless = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  let baseUrl = '', query = '', searchRes = null;
  const ACCENT = '#17541f';  // vert Paperless
  const CSS =
    "  .ppwrap{flex:1;display:flex;flex-direction:column;min-height:0;--pp:#2e8b57}\n" +
    "  .pptopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .pptotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .pptk{text-align:center}\n" +
    "  .pptk b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--pp)}\n" +
    "  .pptk.inbox b{color:var(--warn)}\n" +
    "  .pptk span{font-size:11px;color:var(--dim)}\n" +
    "  .ppvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .ppvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .ppvtoggle button.on{background:var(--tile);color:var(--pp)}\n" +
    "  .ppsearch{padding:12px 22px 0}\n" +
    "  .ppsearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .ppscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .ppsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px;display:flex;align-items:center;gap:7px}\n" +
    "  .ppsec:first-child{margin-top:0}\n" +
    "  .ppsec .cnt{color:var(--warn);font-weight:700}\n" +
    /* cards avec vignette */
    "  .ppcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}\n" +
    "  .ppcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;overflow:hidden;cursor:pointer;display:flex;flex-direction:column}\n" +
    "  .ppcard:hover{border-color:var(--pp)}\n" +
    "  .ppthumb{width:100%;aspect-ratio:3/4;object-fit:cover;object-position:top;background:var(--bg);display:block;border-bottom:1px solid var(--border-soft)}\n" +
    "  .ppthumb-ph{width:100%;aspect-ratio:3/4;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:34px;color:var(--dim);border-bottom:1px solid var(--border-soft)}\n" +
    "  .ppcbody{padding:9px 11px;display:flex;flex-direction:column;gap:3px}\n" +
    "  .ppctitle{font-weight:600;font-size:12.5px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;min-height:2.5em}\n" +
    "  .ppccorr{font-size:10.5px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ppcdate{font-size:10px;color:var(--faint)}\n" +
    /* liste */
    "  .pprow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .pprow:hover{border-color:var(--pp)}\n" +
    "  .pprthumb{width:38px;height:50px;object-fit:cover;object-position:top;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .pprph{width:38px;height:50px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--dim);flex:none}\n" +
    "  .pprtx{min-width:0;flex:1}\n" +
    "  .pprtitle{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .pprmeta{font-size:11.5px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .pprtags{display:flex;gap:4px;flex-wrap:wrap;margin-top:2px}\n" +
    "  .pptag{font-size:9.5px;background:var(--bg);border:1px solid var(--border-soft);border-radius:5px;padding:0 5px;color:var(--dim)}\n" +
    "  .pprdate{font-size:11px;color:var(--dim);flex:none}\n" +
    "  .ppempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { if (document.getElementById('ppUiCss')) return; const s = document.createElement('style'); s.id = 'ppUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const rel = v => S && S.rel ? S.rel(v) : (v || '—');
  const thumbUrl = id => '/addons/paperless/api/thumb?id=' + encodeURIComponent(id);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Paperless…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openDoc(id) {
    if (!baseUrl) { S.toast('URL non configurée'); return; }
    const u = baseUrl + '/documents/' + id + '/';
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  function docCard(d) {
    return '<div class="ppcard" data-id="' + esc(d.id) + '">' +
      '<img class="ppthumb" loading="lazy" src="' + thumbUrl(d.id) + '" ' +
      'onerror="this.outerHTML=\'<div class=&quot;ppthumb-ph&quot;>📄</div>\'">' +
      '<div class="ppcbody"><div class="ppctitle">' + esc(d.title) + '</div>' +
      (d.correspondent ? '<div class="ppccorr">' + esc(d.correspondent) + '</div>' : '') +
      '<div class="ppcdate">' + rel(d.created) + '</div></div></div>';
  }
  function docRow(d) {
    return '<div class="pprow" data-id="' + esc(d.id) + '">' +
      '<img class="pprthumb" loading="lazy" src="' + thumbUrl(d.id) + '" ' +
      'onerror="this.outerHTML=\'<div class=&quot;pprph&quot;>📄</div>\'">' +
      '<div class="pprtx"><div class="pprtitle">' + esc(d.title) + '</div>' +
      '<div class="pprmeta">' + (d.correspondent ? esc(d.correspondent) : '—') + (d.type ? ' · ' + esc(d.type) : '') + '</div>' +
      (d.tags && d.tags.length ? '<div class="pprtags">' + d.tags.slice(0, 4).map(t => '<span class="pptag">' + esc(t) + '</span>').join('') + '</div>' : '') +
      '</div><span class="pprdate">' + rel(d.created) + '</span></div>';
  }
  function renderDocs(docs) {
    if (!docs || !docs.length) return '<div class="ppempty">Aucun document.</div>';
    if (viewMode === 'cards') return '<div class="ppcards">' + docs.map(docCard).join('') + '</div>';
    return docs.map(docRow).join('');
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📄</div><div class="t1">Paperless indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et un jeton API dans ⚙ (Paramètres → Jeton API).</div>' +
        '<button class="btnpill install" id="ppRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('ppRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="ppwrap"><div class="pptopbar">' +
      '<div class="pptotals">' +
      '<div class="pptk"><b>' + nf(d.total) + '</b><span>documents</span></div>' +
      '<div class="pptk inbox"><b>' + nf(d.inbox_count) + '</b><span>réception</span></div>' +
      '<div class="pptk"><b>' + nf(d.correspondents) + '</b><span>correspondants</span></div>' +
      '<div class="pptk"><b>' + nf(d.types) + '</b><span>types</span></div>' +
      '<div class="pptk"><b>' + nf(d.tags) + '</b><span>tags</span></div>' +
      '</div>' +
      '<div class="ppvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="ppsearch"><input id="ppQ" type="search" placeholder="Rechercher un document…" value="' + esc(query) + '"></div>';
    h += '<div class="ppscroll">';

    if (query && searchRes) {
      h += '<div class="ppsec">' + nf(searchRes.count) + ' résultat(s)</div>';
      h += renderDocs(searchRes.documents);
    } else if (query) {
      h += '<div class="ppempty">Recherche…</div>';
    } else {
      if (d.inbox && d.inbox.length) {
        h += '<div class="ppsec">📥 Boîte de réception <span class="cnt">' + nf(d.inbox_count) + '</span></div>';
        h += renderDocs(d.inbox);
      }
      h += '<div class="ppsec">🕐 Documents récents</div>';
      h += renderDocs(d.recent);
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.ppvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    const qin = document.getElementById('ppQ');
    if (qin) qin.addEventListener('input', () => { query = qin.value; scheduleSearch(); });
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openDoc(n.getAttribute('data-id'))));
  }

  let _t = null;
  function scheduleSearch() {
    if (_t) clearTimeout(_t);
    const q = query;
    _t = setTimeout(async () => {
      if (!q) { searchRes = null; paint(); refocus(); return; }
      try { const r = await S.api('/search?q=' + encodeURIComponent(q)); searchRes = await r.json(); }
      catch (e) { searchRes = { ok: false, count: 0, documents: [] }; }
      if (query === q) { paint(); refocus(); }
    }, 350);
  }
  function refocus() {
    const nq = document.getElementById('ppQ');
    if (nq) { nq.focus(); const l = nq.value.length; try { nq.setSelectionRange(l, l); } catch (e) {} }
  }

  return { render };
})();
