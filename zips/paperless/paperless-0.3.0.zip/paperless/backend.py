"""Addon « paperless » — Paperless-ngx (Méduse) : stats, recherche, vignettes.

    register(sdk) -> flask.Blueprint   (routes sous /addons/paperless/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:8010) + token (jeton API).
- /overview : stats + inbox + documents récents (correspondants/types résolus)
- /search?q= : recherche plein-texte de documents
- /thumb?id= : PROXY de la vignette (l'auth par token empêche le <img> direct)
- /docs?... : listing paginé générique
"""


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("token") or "").strip()


def _hdr(token):
    return {"Authorization": f"Token {token}"}


def _get(sdk, url, token, path, params=None):
    try:
        r = sdk.requests.get(f"{url}{path}", headers=_hdr(token),
                             params=params, timeout=10, verify=False)
        if r.status_code == 401:
            return None, 401
        if not r.ok:
            return None, r.status_code
        return r.json(), 200
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None, None


def _lookup(sdk, url, token, path):
    """{id: name} pour correspondents / document_types / tags."""
    out = {}
    data, _ = _get(sdk, url, token, path, {"page_size": 250})
    if isinstance(data, dict):
        for x in data.get("results", []) or []:
            if isinstance(x, dict) and x.get("id") is not None:
                out[x["id"]] = x.get("name", "")
    return out


def _shape_doc(d, corr, types, tags):
    tag_names = []
    for t in (d.get("tags") or []):
        if t in tags:
            tag_names.append(tags[t])
    return {
        "id": d.get("id"),
        "title": d.get("title") or f"Document {d.get('id')}",
        "created": d.get("created"),
        "added": d.get("added"),
        "correspondent": corr.get(d.get("correspondent"), "") if d.get("correspondent") else "",
        "type": types.get(d.get("document_type"), "") if d.get("document_type") else "",
        "tags": tag_names,
        "archive_serial_number": d.get("archive_serial_number"),
    }


def _overview(sdk, cfg):
    url, token = _base(cfg)
    if not (url and token):
        return {"ok": False, "reason": "URL/jeton non configurés"}
    ck = f"ppl:{url}"
    c = sdk.cache_get(ck, 90)
    if c is not None:
        return c

    stats, code = _get(sdk, url, token, "/api/statistics/")
    if code == 401:
        return {"ok": False, "reason": "jeton refusé (401) — Paramètres → Jeton API"}
    if stats is None:
        return {"ok": False, "reason": "Paperless injoignable"}

    corr = _lookup(sdk, url, token, "/api/correspondents/")
    types = _lookup(sdk, url, token, "/api/document_types/")
    tags = _lookup(sdk, url, token, "/api/tags/")

    recent_raw, _ = _get(sdk, url, token, "/api/documents/",
                         {"ordering": "-created", "page_size": 12})
    recent = [_shape_doc(x, corr, types, tags)
              for x in (recent_raw or {}).get("results", [])]

    # inbox : documents ayant un tag "inbox" (is_inbox_tag)
    inbox = []
    inbox_tag_ids = []
    tdata, _ = _get(sdk, url, token, "/api/tags/", {"page_size": 250})
    if isinstance(tdata, dict):
        for t in tdata.get("results", []) or []:
            if t.get("is_inbox_tag"):
                inbox_tag_ids.append(t.get("id"))
    if inbox_tag_ids:
        ib_raw, _ = _get(sdk, url, token, "/api/documents/",
                         {"tags__id__in": ",".join(str(i) for i in inbox_tag_ids),
                          "ordering": "-created", "page_size": 12})
        inbox = [_shape_doc(x, corr, types, tags)
                 for x in (ib_raw or {}).get("results", [])]

    out = {
        "ok": True,
        "total": stats.get("documents_total", 0),
        "inbox_count": stats.get("documents_inbox", 0),
        "correspondents": len(corr),
        "types": len(types),
        "tags": len(tags),
        "recent": recent,
        "inbox": inbox,
    }
    return sdk.cache_set(ck, out)


def _search(sdk, cfg, q):
    url, token = _base(cfg)
    if not (url and token):
        return {"ok": False, "reason": "non configuré"}
    corr = _lookup(sdk, url, token, "/api/correspondents/")
    types = _lookup(sdk, url, token, "/api/document_types/")
    tags = _lookup(sdk, url, token, "/api/tags/")
    data, code = _get(sdk, url, token, "/api/documents/",
                      {"query": q, "page_size": 40})
    if code == 401:
        return {"ok": False, "reason": "jeton refusé (401)"}
    if data is None:
        return {"ok": False, "reason": "recherche indisponible"}
    docs = [_shape_doc(x, corr, types, tags) for x in data.get("results", [])]
    return {"ok": True, "count": data.get("count", len(docs)), "documents": docs}


def register(sdk):
    from flask import Blueprint, Response, jsonify, request
    bp = Blueprint("paperless", __name__)

    @bp.route("/overview")
    def overview():
        try:
            return jsonify(_overview(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("paperless overview")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/search")
    def search():
        try:
            q = (request.args.get("q") or "").strip()
            if not q:
                return jsonify({"ok": True, "count": 0, "documents": []})
            return jsonify(_search(sdk, sdk.config(), q))
        except Exception as e:
            sdk.log.exception("paperless search")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/thumb")
    def thumb():
        cfg = sdk.config()
        url, token = _base(cfg)
        did = (request.args.get("id") or "").strip()
        if not (url and token and did.isdigit()):
            return Response("", status=400)
        try:
            r = sdk.requests.get(f"{url}/api/documents/{did}/thumb/",
                                 headers=_hdr(token), timeout=15, verify=False)
            if r.status_code != 200:
                return Response("", status=r.status_code)
            ct = r.headers.get("Content-Type", "image/webp")
            return Response(r.content, mimetype=ct,
                            headers={"Cache-Control": "private, max-age=600"})
        except sdk.requests.exceptions.RequestException:
            return Response("", status=502)

    return bp


def test(sdk, cfg):
    d = _overview(sdk, cfg)
    if d.get("ok"):
        return True, (f"Paperless ✓ — {d['total']} document(s), "
                      f"{d['inbox_count']} en réception, {d['correspondents']} correspondant(s)")
    return False, f"Paperless ✗ ({d.get('reason')})"
