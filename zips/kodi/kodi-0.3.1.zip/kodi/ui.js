/* Kodi — télécommande JSON-RPC + bibliothèque (films/épisodes récents). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.kodi = (function () {
  let S = null, root = null, tile = null, tab = 'remote';
  const CSS = ".kdtabs{display:flex;gap:4px;margin-bottom:12px}\n" +
    ".kdtab{background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:8px 16px;font-size:13px;color:var(--dim);cursor:pointer}\n" +
    ".kdtab.on{background:var(--tile);color:var(--accent);border-color:var(--accent)}\n" +
    ".kdot{width:10px;height:10px;border-radius:50%;flex:none}\n.kdot2{width:9px;height:9px;border-radius:50%;flex:none}\n.kdnow{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:14px 18px;margin-bottom:12px}\n.kdt{font-size:16px;font-weight:700}\n.kdsub{font-size:12px;color:var(--dim);margin-top:2px}\n.kdbar{height:7px;border-radius:5px;background:var(--border-soft);overflow:hidden;margin:10px 0 5px}\n.kdfill{height:100%;background:var(--accent);border-radius:5px}\n.kdtimes{display:flex;justify-content:space-between;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n.kdpad{display:grid;grid-template-columns:repeat(3,72px);grid-gap:8px;justify-content:center;margin:14px 0}\n.kdbtn{height:64px;border-radius:12px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;user-select:none}\n.kdbtn:active{background:var(--accent-tint);border-color:var(--accent)}\n.kdbtn.wide{grid-column:span 3;height:52px;font-size:15px;gap:8px}\n.kdrow{display:flex;gap:8px;justify-content:center;margin-bottom:10px}\n.kdrow .kdbtn{width:72px}\n.kdvol{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 16px}\n.kdvol input{flex:1;height:26px}\n" +
    ".kdlibsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 9px}\n" +
    ".kdlibsec:first-child{margin-top:0}\n" +
    ".kdposters{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:12px}\n" +
    ".kdmov{display:flex;flex-direction:column;gap:5px}\n" +
    ".kdposter{width:100%;aspect-ratio:2/3;border-radius:9px;object-fit:cover;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    ".kdposter-ph{width:100%;aspect-ratio:2/3;border-radius:9px;background:var(--tile);border:1px solid var(--border-soft);display:flex;align-items:center;justify-content:center;font-size:30px;color:var(--dim)}\n" +
    ".kdmovtit{font-size:11.5px;font-weight:600;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    ".kdmovsub{font-size:10.5px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    ".kdeprow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px}\n" +
    ".kdepthumb{width:56px;height:32px;object-fit:cover;border-radius:5px;background:var(--bg);flex:none}\n" +
    ".kdepph{width:56px;height:32px;border-radius:5px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:15px;color:var(--dim);flex:none}\n" +
    ".kdeptx{min-width:0;flex:1}\n.kdepshow{font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.kdepmeta{font-size:11px;color:var(--dim)}\n" +
    ".kdempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { let s = document.getElementById('kdUiCss'); if (!s) { s = document.createElement('style'); s.id = 'kdUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const imgUrl = u => u ? '/addons/kodi/api/kodi/image?u=' + encodeURIComponent(u) : '';

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    let h = '<div class="kdtabs">' +
      '<button class="kdtab' + (tab === 'remote' ? ' on' : '') + '" data-t="remote">📺 Lecture</button>' +
      '<button class="kdtab' + (tab === 'library' ? ' on' : '') + '" data-t="library">🎬 Bibliothèque</button>' +
      '</div><div id="kdBody"></div>';
    el.innerHTML = h;
    el.querySelectorAll('.kdtab').forEach(b => b.addEventListener('click', () => { tab = b.getAttribute('data-t'); render(el, S, tile); }));
    if (tab === 'remote') await renderRemote();
    else await renderLibrary();
  }

  async function renderRemote() {
    const body = document.getElementById('kdBody'); if (!body) return;
    let d = null; try { const r = await S.api('/kodi'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead"><button class="wch" id="kdRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">📺</div><div class="t1">Kodi — télécommande</div><div class="t2">' + ((d && d.reason) || '') +
        '<br>Active le contrôle distant dans Kodi (Paramètres → Services → Contrôle) et renseigne l\'URL + les identifiants dans \u2699.</div></div>';
      body.innerHTML = h; const r0 = document.getElementById('kdRefresh'); if (r0) r0.addEventListener('click', () => renderRemote()); return;
    }
    if (d.playing) {
      const sub = [d.show, (d.season ? ('S' + String(d.season).padStart(2, '0') + 'E' + String(d.episode).padStart(2, '0')) : ''), d.artist].filter(Boolean).join(' · ');
      h += '<div class="kdnow"><div class="kdt">' + (d.paused ? '⏸ ' : '▶️ ') + esc(d.title) + '</div>' +
        (sub ? '<div class="kdsub">' + esc(sub) + '</div>' : '') +
        '<div class="kdbar"><div class="kdfill" style="width:' + d.percent + '%"></div></div>' +
        '<div class="kdtimes"><span>' + d.time + '</span><span>' + d.total + '</span></div></div>';
    } else {
      h += '<div class="kdnow"><div class="kdt">Kodi au repos</div><div class="kdsub">Version ' + (d.version || '?') + '</div></div>';
    }
    h += '<div class="kdrow"><div class="kdbtn" data-k="rewind">⏪</div><div class="kdbtn" data-k="playpause">' + (d.paused ? '▶️' : '⏸') + '</div>' +
      '<div class="kdbtn" data-k="forward">⏩</div><div class="kdbtn" data-k="stop">⏹</div></div>';
    h += '<div class="kdpad">' +
      '<div class="kdbtn" data-k="back">↩</div><div class="kdbtn" data-k="up">▲</div><div class="kdbtn" data-k="info">ℹ️</div>' +
      '<div class="kdbtn" data-k="left">◀</div><div class="kdbtn" data-k="select">OK</div><div class="kdbtn" data-k="right">▶</div>' +
      '<div class="kdbtn" data-k="home">🏠</div><div class="kdbtn" data-k="down">▼</div><div class="kdbtn" data-k="osd">🎛️</div></div>';
    h += '<div class="kdvol"><span class="kdbtn" data-k="mute" style="width:52px;height:44px;font-size:17px">' + (d.muted ? '🔇' : '🔊') + '</span>' +
      '<input type="range" id="kdVol" min="0" max="100" value="' + (d.volume || 0) + '">' +
      '<span id="kdVolLab" style="min-width:48px;text-align:right;font-variant-numeric:tabular-nums">' + (d.volume || 0) + ' %</span></div>';
    h += '<div class="kotoast" id="kdErr"></div><div class="wsrc">Kodi · JSON-RPC · v0.3.0</div>';
    body.innerHTML = h;
    const err = document.getElementById('kdErr');
    const send = async (action, extra) => {
      try {
        const r = await S.api('/kodi/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ action }, extra || {})) });
        const j = await r.json();
        if (!j.ok) err.textContent = j.reason || 'action refusée'; else err.textContent = '';
      } catch (e) { err.textContent = 'Serveur injoignable'; }
    };
    body.querySelectorAll('[data-k]').forEach(b => b.addEventListener('click', async () => {
      await send(b.dataset.k);
      if (['playpause', 'stop', 'mute', 'next', 'previous'].includes(b.dataset.k)) setTimeout(() => renderRemote(), 350);
    }));
    const v = document.getElementById('kdVol'), vl = document.getElementById('kdVolLab');
    if (v) {
      v.addEventListener('input', () => { if (vl) vl.textContent = v.value + ' %'; });
      v.addEventListener('change', async () => { await send('volume', { value: parseInt(v.value) }); setTimeout(() => renderRemote(), 300); });
    }
    const rb = document.getElementById('kdRefresh'); if (rb) rb.addEventListener('click', () => renderRemote());
  }

  async function renderLibrary() {
    const body = document.getElementById('kdBody'); if (!body) return;
    body.innerHTML = '<div class="stub"><div class="t2">Lecture de la bibliothèque…</div></div>';
    let d = null; try { const r = await S.api('/kodi/library'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d || !d.ok) {
      body.innerHTML = '<div class="stub"><div class="big">🎬</div><div class="t1">Bibliothèque indisponible</div><div class="t2">' + esc((d && d.reason) || '') +
        '<br>Vérifie que la bibliothèque vidéo de Kodi est renseignée.</div>' +
        '<button class="btnpill install" id="kdLibRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('kdLibRetry'); if (rb) rb.addEventListener('click', () => renderLibrary()); return;
    }
    let h = '';
    if (d.movies && d.movies.length) {
      h += '<div class="kdlibsec">🎬 Films récemment ajoutés</div><div class="kdposters">';
      h += d.movies.map(m => {
        const ph = '<div class=\'kdposter-ph\'>🎬</div>';
        const img = m.poster ? '<img class="kdposter" loading="lazy" src="' + imgUrl(m.poster) + '" onerror="this.outerHTML=\'' + ph + '\'">' : ph;
        return '<div class="kdmov">' + img +
          '<div class="kdmovtit">' + esc(m.title) + '</div>' +
          '<div class="kdmovsub">' + (m.year || '') + (m.rating ? ' · ★' + m.rating : '') + '</div></div>';
      }).join('');
      h += '</div>';
    }
    if (d.episodes && d.episodes.length) {
      h += '<div class="kdlibsec">📺 Épisodes récents</div>';
      h += d.episodes.map(e => {
        const ph = '<div class=\'kdepph\'>📺</div>';
        const img = e.poster ? '<img class="kdepthumb" loading="lazy" src="' + imgUrl(e.poster) + '" onerror="this.outerHTML=\'' + ph + '\'">' : ph;
        const se = (e.season != null ? 'S' + String(e.season).padStart(2, '0') : '') + (e.episode != null ? 'E' + String(e.episode).padStart(2, '0') : '');
        return '<div class="kdeprow">' + img +
          '<div class="kdeptx"><div class="kdepshow">' + esc(e.show || e.title) + '</div>' +
          '<div class="kdepmeta">' + (se ? se + ' · ' : '') + esc(e.title) + (e.aired ? ' · ' + e.aired : '') + '</div></div></div>';
      }).join('');
    }
    if (!h) h = '<div class="kdempty">Aucun ajout récent dans la bibliothèque.</div>';
    body.innerHTML = h;
  }

  return { render };
})();
