"""Addon « kodi » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/kodi/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : Kodi via JSON-RPC (endpoint /jsonrpc, auth basique optionnelle).
Deux routes : /kodi (état de lecture, GET) et /kodi/action (télécommande,
POST). Pas de cache : l'état doit être temps réel. L'auth du noyau protège
les deux (guard before_request sur /addons/…/api/), la POST comprise.
"""


def _kodi_rpc(sdk, cfg, method, params=None):
    url = (cfg.get("url") or "").rstrip("/")
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not url:
        raise RuntimeError("URL non configurée")
    auth = (user, pw) if user else None
    r = sdk.requests.post(f"{url}/jsonrpc",
                          json={"jsonrpc": "2.0", "id": 1, "method": method,
                                "params": params or {}},
                          auth=auth, timeout=6)
    if r.status_code == 401:
        raise RuntimeError("identifiants refusés (401)")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    j = r.json()
    if "error" in j:
        raise RuntimeError(j["error"].get("message", "erreur Kodi"))
    return j.get("result")


def _kodi_state(sdk, cfg):
    try:
        players = _kodi_rpc(sdk, cfg, "Player.GetActivePlayers") or []
        info = {"ok": True, "playing": False}
        try:
            app_props = _kodi_rpc(sdk, cfg, "Application.GetProperties",
                                  {"properties": ["volume", "muted", "version"]})
            info["volume"] = app_props.get("volume")
            info["muted"] = app_props.get("muted")
            v = app_props.get("version") or {}
            info["version"] = f"{v.get('major','?')}.{v.get('minor','')}"
        except RuntimeError:
            pass
        if players:
            pid = players[0]["playerid"]
            item = _kodi_rpc(sdk, cfg, "Player.GetItem",
                             {"playerid": pid,
                              "properties": ["title", "showtitle", "season",
                                             "episode", "artist", "album", "thumbnail"]})
            props = _kodi_rpc(sdk, cfg, "Player.GetProperties",
                              {"playerid": pid,
                               "properties": ["speed", "percentage", "time", "totaltime"]})
            it = (item or {}).get("item", {})
            tm = props.get("time", {})
            tt = props.get("totaltime", {})
            fmt = lambda t: f"{t.get('hours',0):d}:{t.get('minutes',0):02d}:{t.get('seconds',0):02d}"
            info.update(playing=True, playerid=pid,
                        paused=(props.get("speed") == 0),
                        title=it.get("title") or it.get("label") or "—",
                        show=it.get("showtitle") or "",
                        artist=", ".join(it.get("artist") or []),
                        season=it.get("season"), episode=it.get("episode"),
                        percent=round(props.get("percentage") or 0, 1),
                        time=fmt(tm), total=fmt(tt))
        return info
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}


def _kodi_image_url(art_path):
    """Extrait l'URL d'image exploitable depuis un chemin art Kodi.
    Kodi renvoie soit une URL http directe, soit un chemin image://<url encodé>/."""
    if not art_path:
        return None
    from urllib.parse import unquote
    if art_path.startswith("image://"):
        inner = art_path[len("image://"):]
        if inner.endswith("/"):
            inner = inner[:-1]
        return unquote(inner)
    return art_path


def _kodi_library(sdk, cfg):
    """Films + épisodes récemment ajoutés (avec chemins d'affiches)."""
    try:
        movies_raw = _kodi_rpc(sdk, cfg, "VideoLibrary.GetRecentlyAddedMovies",
                               {"properties": ["title", "year", "art", "rating", "runtime"],
                                "limits": {"end": 20}}) or {}
        eps_raw = _kodi_rpc(sdk, cfg, "VideoLibrary.GetRecentlyAddedEpisodes",
                            {"properties": ["title", "showtitle", "season", "episode", "art", "firstaired"],
                             "limits": {"end": 20}}) or {}
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}

    movies = []
    for i, mv in enumerate(movies_raw.get("movies", []) or []):
        art = mv.get("art", {}) or {}
        movies.append({
            "id": mv.get("movieid"),
            "idx": i,
            "title": mv.get("title") or "?",
            "year": mv.get("year"),
            "rating": round(mv.get("rating"), 1) if isinstance(mv.get("rating"), (int, float)) else None,
            "runtime": mv.get("runtime"),
            "poster": _kodi_image_url(art.get("poster") or art.get("thumb")),
        })
    episodes = []
    for i, ep in enumerate(eps_raw.get("episodes", []) or []):
        art = ep.get("art", {}) or {}
        episodes.append({
            "id": ep.get("episodeid"),
            "idx": i,
            "title": ep.get("title") or "?",
            "show": ep.get("showtitle") or "",
            "season": ep.get("season"),
            "episode": ep.get("episode"),
            "aired": ep.get("firstaired"),
            "poster": _kodi_image_url(art.get("thumb") or art.get("season.poster") or art.get("tvshow.poster")),
        })
    return {"ok": True, "movies": movies, "episodes": episodes,
            "movie_count": len(movies), "episode_count": len(episodes)}


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("kodi", __name__)

    @bp.route("/kodi")
    def kodi():
        try:
            return jsonify(_kodi_state(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("kodi")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/kodi/library")
    def kodi_library():
        try:
            return jsonify(_kodi_library(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("kodi library")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/kodi/image")
    def kodi_image():
        from flask import Response, request
        cfg = sdk.config()
        url = (cfg.get("url") or "").rstrip("/")
        user = (cfg.get("user") or "").strip()
        pw = (cfg.get("pass") or "").strip()
        img = (request.args.get("u") or "").strip()
        if not (url and img):
            return Response("", status=400)
        from urllib.parse import quote
        # Kodi sert les images via /image/<image:// encodé>
        proxy = f"{url}/image/" + quote("image://" + quote(img, safe="") + "/", safe="")
        try:
            auth = (user, pw) if user else None
            r = sdk.requests.get(proxy, auth=auth, timeout=15)
            if r.status_code != 200:
                # repli : essayer l'URL directe si http
                if img.startswith("http"):
                    r = sdk.requests.get(img, auth=auth, timeout=15)
                if r.status_code != 200:
                    return Response("", status=r.status_code)
            ct = r.headers.get("Content-Type", "image/jpeg")
            return Response(r.content, mimetype=ct,
                            headers={"Cache-Control": "private, max-age=3600"})
        except sdk.requests.exceptions.RequestException:
            return Response("", status=502)

    @bp.route("/kodi/action", methods=["POST"])
    def kodi_action():
        j = request.get_json(force=True, silent=True) or {}
        act = (j.get("action") or "").strip()
        cfg = sdk.config()
        ACTIONS = {
            "playpause": ("Player.PlayPause", {"playerid": 1}),
            "stop": ("Player.Stop", {"playerid": 1}),
            "next": ("Player.GoTo", {"playerid": 1, "to": "next"}),
            "previous": ("Player.GoTo", {"playerid": 1, "to": "previous"}),
            "up": ("Input.Up", {}), "down": ("Input.Down", {}),
            "left": ("Input.Left", {}), "right": ("Input.Right", {}),
            "select": ("Input.Select", {}), "back": ("Input.Back", {}),
            "home": ("Input.Home", {}), "info": ("Input.Info", {}),
            "osd": ("Input.ShowOSD", {}),
            "mute": ("Application.SetMute", {"mute": "toggle"}),
            "rewind": ("Player.Seek", {"playerid": 1, "value": {"seconds": -30}}),
            "forward": ("Player.Seek", {"playerid": 1, "value": {"seconds": 30}}),
        }
        try:
            if act == "volume":
                vol = max(0, min(100, int(j.get("value", 50))))
                _kodi_rpc(sdk, cfg, "Application.SetVolume", {"volume": vol})
                return jsonify({"ok": True})
            if act not in ACTIONS:
                return jsonify({"ok": False, "reason": "action inconnue"}), 400
            method, params = ACTIONS[act]
            if act in ("playpause", "stop", "next", "previous", "rewind", "forward"):
                players = _kodi_rpc(sdk, cfg, "Player.GetActivePlayers") or []
                if not players:
                    return jsonify({"ok": False, "reason": "rien en lecture"})
                params = dict(params, playerid=players[0]["playerid"])
            _kodi_rpc(sdk, cfg, method, params)
            return jsonify({"ok": True})
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": type(e).__name__})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    k = _kodi_state(sdk, cfg)
    if k.get("ok"):
        etat = ("lecture : " + k.get("title", "")) if k.get("playing") else "au repos"
        return True, f"Kodi ✓ (v{k.get('version','?')}) — {etat}"
    return False, f"Kodi ✗ ({k.get('reason')})"
