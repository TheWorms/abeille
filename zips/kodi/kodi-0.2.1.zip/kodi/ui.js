/* Kodi — télécommande JSON-RPC (Phase 3, lot A). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.kodi = (function () {
  let S = null, root = null, tile = null;
  const CSS = ".kdot{width:10px;height:10px;border-radius:50%;flex:none}\n.kdot2{width:9px;height:9px;border-radius:50%;flex:none}\n.kdnow{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:14px 18px;margin-bottom:12px}\n.kdt{font-size:16px;font-weight:700}\n.kdsub{font-size:12px;color:var(--dim);margin-top:2px}\n.kdbar{height:7px;border-radius:5px;background:var(--border-soft);overflow:hidden;margin:10px 0 5px}\n.kdfill{height:100%;background:var(--accent);border-radius:5px}\n.kdtimes{display:flex;justify-content:space-between;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n.kdpad{display:grid;grid-template-columns:repeat(3,72px);grid-gap:8px;justify-content:center;margin:14px 0}\n.kdbtn{height:64px;border-radius:12px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);\n         font-size:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;user-select:none}\n.kdbtn:active{background:var(--accent-tint);border-color:var(--accent)}\n.kdbtn.wide{grid-column:span 3;height:52px;font-size:15px;gap:8px}\n.kdrow{display:flex;gap:8px;justify-content:center;margin-bottom:10px}\n.kdrow .kdbtn{width:72px}\n.kdvol{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);\n         border-radius:11px;padding:11px 16px}\n.kdvol input{flex:1;height:26px}";
  function ensureCss() { if (document.getElementById('kdUiCss')) return; const s = document.createElement('style'); s.id = 'kdUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    let d = null; try { const r = await sdk.api('/kodi'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead"><button class="wch" id="kdRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">📺</div><div class="t1">Kodi — télécommande</div><div class="t2">' + ((d && d.reason) || '') +
        '<br>Active le contrôle distant dans Kodi (Paramètres → Services → Contrôle) et renseigne l\'URL + les identifiants dans \u2699.</div></div>';
      el.innerHTML = h; const r0 = document.getElementById('kdRefresh'); if (r0) r0.addEventListener('click', () => render(el, S, tile)); return;
    }
    if (d.playing) {
      const sub = [d.show, (d.season ? ('S' + String(d.season).padStart(2, '0') + 'E' + String(d.episode).padStart(2, '0')) : ''), d.artist].filter(Boolean).join(' · ');
      h += '<div class="kdnow"><div class="kdt">' + (d.paused ? '⏸ ' : '▶️ ') + d.title + '</div>' +
        (sub ? '<div class="kdsub">' + sub + '</div>' : '') +
        '<div class="kdbar"><div class="kdfill" style="width:' + d.percent + '%"></div></div>' +
        '<div class="kdtimes"><span>' + d.time + '</span><span>' + d.total + '</span></div></div>';
    } else {
      h += '<div class="kdnow"><div class="kdt">Kodi au repos</div><div class="kdsub">Version ' + (d.version || '?') + '</div></div>';
    }
    h += '<div class="kdrow"><div class="kdbtn" data-k="rewind">⏪</div><div class="kdbtn" data-k="playpause">' + (d.paused ? '▶️' : '⏸') + '</div>' +
      '<div class="kdbtn" data-k="forward">⏩</div><div class="kdbtn" data-k="stop">⏹</div></div>';
    h += '<div class="kdpad">' +
      '<div class="kdbtn" data-k="back">↩</div><div class="kdbtn" data-k="up">▲</div><div class="kdbtn" data-k="info">ℹ️</div>' +
      '<div class="kdbtn" data-k="left">◀</div><div class="kdbtn" data-k="select">OK</div><div class="kdbtn" data-k="right">▶</div>' +
      '<div class="kdbtn" data-k="home">🏠</div><div class="kdbtn" data-k="down">▼</div><div class="kdbtn" data-k="osd">🎛️</div></div>';
    h += '<div class="kdvol"><span class="kdbtn" data-k="mute" style="width:52px;height:44px;font-size:17px">' + (d.muted ? '🔇' : '🔊') + '</span>' +
      '<input type="range" id="kdVol" min="0" max="100" value="' + (d.volume || 0) + '">' +
      '<span id="kdVolLab" style="min-width:48px;text-align:right;font-variant-numeric:tabular-nums">' + (d.volume || 0) + ' %</span></div>';
    h += '<div class="kotoast" id="kdErr"></div><div class="wsrc">Kodi · JSON-RPC · vue embarquée v0.2.0</div>';
    el.innerHTML = h;
    const err = document.getElementById('kdErr');
    const send = async (action, extra) => {
      try {
        const r = await sdk.api('/kodi/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ action }, extra || {})) });
        const j = await r.json();
        if (!j.ok) err.textContent = j.reason || 'action refusée'; else err.textContent = '';
      } catch (e) { err.textContent = 'Serveur injoignable'; }
    };
    el.querySelectorAll('[data-k]').forEach(b => b.addEventListener('click', async () => {
      await send(b.dataset.k);
      if (['playpause', 'stop', 'mute', 'next', 'previous'].includes(b.dataset.k)) setTimeout(() => render(el, S, tile), 350);
    }));
    const v = document.getElementById('kdVol'), vl = document.getElementById('kdVolLab');
    if (v) {
      v.addEventListener('input', () => { if (vl) vl.textContent = v.value + ' %'; });
      v.addEventListener('change', async () => { await send('volume', { value: parseInt(v.value) }); setTimeout(() => render(el, S, tile), 300); });
    }
    const rb = document.getElementById('kdRefresh'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
  }
  return { render };
})();
