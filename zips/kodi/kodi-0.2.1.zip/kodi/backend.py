"""Addon « kodi » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/kodi/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : Kodi via JSON-RPC (endpoint /jsonrpc, auth basique optionnelle).
Deux routes : /kodi (état de lecture, GET) et /kodi/action (télécommande,
POST). Pas de cache : l'état doit être temps réel. L'auth du noyau protège
les deux (guard before_request sur /addons/…/api/), la POST comprise.
"""


def _kodi_rpc(sdk, cfg, method, params=None):
    url = (cfg.get("url") or "").rstrip("/")
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not url:
        raise RuntimeError("URL non configurée")
    auth = (user, pw) if user else None
    r = sdk.requests.post(f"{url}/jsonrpc",
                          json={"jsonrpc": "2.0", "id": 1, "method": method,
                                "params": params or {}},
                          auth=auth, timeout=6)
    if r.status_code == 401:
        raise RuntimeError("identifiants refusés (401)")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    j = r.json()
    if "error" in j:
        raise RuntimeError(j["error"].get("message", "erreur Kodi"))
    return j.get("result")


def _kodi_state(sdk, cfg):
    try:
        players = _kodi_rpc(sdk, cfg, "Player.GetActivePlayers") or []
        info = {"ok": True, "playing": False}
        try:
            app_props = _kodi_rpc(sdk, cfg, "Application.GetProperties",
                                  {"properties": ["volume", "muted", "version"]})
            info["volume"] = app_props.get("volume")
            info["muted"] = app_props.get("muted")
            v = app_props.get("version") or {}
            info["version"] = f"{v.get('major','?')}.{v.get('minor','')}"
        except RuntimeError:
            pass
        if players:
            pid = players[0]["playerid"]
            item = _kodi_rpc(sdk, cfg, "Player.GetItem",
                             {"playerid": pid,
                              "properties": ["title", "showtitle", "season",
                                             "episode", "artist", "album", "thumbnail"]})
            props = _kodi_rpc(sdk, cfg, "Player.GetProperties",
                              {"playerid": pid,
                               "properties": ["speed", "percentage", "time", "totaltime"]})
            it = (item or {}).get("item", {})
            tm = props.get("time", {})
            tt = props.get("totaltime", {})
            fmt = lambda t: f"{t.get('hours',0):d}:{t.get('minutes',0):02d}:{t.get('seconds',0):02d}"
            info.update(playing=True, playerid=pid,
                        paused=(props.get("speed") == 0),
                        title=it.get("title") or it.get("label") or "—",
                        show=it.get("showtitle") or "",
                        artist=", ".join(it.get("artist") or []),
                        season=it.get("season"), episode=it.get("episode"),
                        percent=round(props.get("percentage") or 0, 1),
                        time=fmt(tm), total=fmt(tt))
        return info
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("kodi", __name__)

    @bp.route("/kodi")
    def kodi():
        try:
            return jsonify(_kodi_state(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("kodi")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/kodi/action", methods=["POST"])
    def kodi_action():
        j = request.get_json(force=True, silent=True) or {}
        act = (j.get("action") or "").strip()
        cfg = sdk.config()
        ACTIONS = {
            "playpause": ("Player.PlayPause", {"playerid": 1}),
            "stop": ("Player.Stop", {"playerid": 1}),
            "next": ("Player.GoTo", {"playerid": 1, "to": "next"}),
            "previous": ("Player.GoTo", {"playerid": 1, "to": "previous"}),
            "up": ("Input.Up", {}), "down": ("Input.Down", {}),
            "left": ("Input.Left", {}), "right": ("Input.Right", {}),
            "select": ("Input.Select", {}), "back": ("Input.Back", {}),
            "home": ("Input.Home", {}), "info": ("Input.Info", {}),
            "osd": ("Input.ShowOSD", {}),
            "mute": ("Application.SetMute", {"mute": "toggle"}),
            "rewind": ("Player.Seek", {"playerid": 1, "value": {"seconds": -30}}),
            "forward": ("Player.Seek", {"playerid": 1, "value": {"seconds": 30}}),
        }
        try:
            if act == "volume":
                vol = max(0, min(100, int(j.get("value", 50))))
                _kodi_rpc(sdk, cfg, "Application.SetVolume", {"volume": vol})
                return jsonify({"ok": True})
            if act not in ACTIONS:
                return jsonify({"ok": False, "reason": "action inconnue"}), 400
            method, params = ACTIONS[act]
            if act in ("playpause", "stop", "next", "previous", "rewind", "forward"):
                players = _kodi_rpc(sdk, cfg, "Player.GetActivePlayers") or []
                if not players:
                    return jsonify({"ok": False, "reason": "rien en lecture"})
                params = dict(params, playerid=players[0]["playerid"])
            _kodi_rpc(sdk, cfg, method, params)
            return jsonify({"ok": True})
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": type(e).__name__})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    k = _kodi_state(sdk, cfg)
    if k.get("ok"):
        etat = ("lecture : " + k.get("title", "")) if k.get("playing") else "au repos"
        return True, f"Kodi ✓ (v{k.get('version','?')}) — {etat}"
    return False, f"Kodi ✗ ({k.get('reason')})"
