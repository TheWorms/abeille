"""Addon « emby » — statut & activité du serveur Emby.

    register(sdk) -> flask.Blueprint   (routes sous /addons/emby/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:8096) + apikey (Dashboard → Advanced → API Keys).
Auth par query ?api_key= (accepté par toutes les routes Emby).
"""


def _cfg(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _get(sdk, url, key, path, params=None, timeout=8):
    p = dict(params or {})
    p["api_key"] = key
    try:
        r = sdk.requests.get(url + path, params=p, timeout=timeout)
        if r.status_code == 401:
            return {"__err": "clé API refusée (401)"}
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _ticks_to_pct(pos, run):
    try:
        if run:
            return round(pos / run * 100, 1)
    except (TypeError, ZeroDivisionError):
        pass
    return 0


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    info = _get(sdk, url, key, "/System/Info")
    if isinstance(info, dict) and info.get("__err"):
        return {"ok": False, "reason": info["__err"]}
    if not info:
        return {"ok": False, "reason": "Emby injoignable"}

    out = {"ok": True,
           "name": info.get("ServerName") or "Emby",
           "version": info.get("Version")}

    # Sessions en cours (qui regarde quoi)
    sessions = _get(sdk, url, key, "/Sessions")
    active = []
    if isinstance(sessions, list):
        for s in sessions:
            now = s.get("NowPlayingItem")
            if not now:
                continue
            play = s.get("PlayState") or {}
            active.append({
                "user": s.get("UserName") or "?",
                "device": s.get("DeviceName") or s.get("Client") or "",
                "item": _now_label(now),
                "type": now.get("Type"),
                "percent": _ticks_to_pct(play.get("PositionTicks"),
                                         now.get("RunTimeTicks")),
                "paused": play.get("IsPaused", False),
                "method": play.get("PlayMethod"),
            })
    out["sessions"] = active
    out["sessions_count"] = len(active)

    # Bibliothèques : compte par type
    counts = _get(sdk, url, key, "/Items/Counts")
    if isinstance(counts, dict):
        out["counts"] = {
            "films": counts.get("MovieCount"),
            "séries": counts.get("SeriesCount"),
            "épisodes": counts.get("EpisodeCount"),
            "albums": counts.get("AlbumCount"),
            "morceaux": counts.get("SongCount"),
            "artistes": counts.get("ArtistCount"),
        }

    # Vues/bibliothèques configurées
    views = _get(sdk, url, key, "/Library/VirtualFolders")
    if isinstance(views, list):
        out["libraries"] = [{"name": v.get("Name"),
                             "type": v.get("CollectionType")}
                            for v in views[:12]]

    # Derniers ajouts
    latest = _get(sdk, url, key, "/Items",
                  params={"SortBy": "DateCreated", "SortOrder": "Descending",
                          "Recursive": "true",
                          "IncludeItemTypes": "Movie,Series,Episode",
                          "Limit": 10, "Fields": "DateCreated"})
    items = (latest or {}).get("Items") if isinstance(latest, dict) else None
    if items:
        out["latest"] = [{"name": _now_label(it),
                          "type": it.get("Type"),
                          "date": it.get("DateCreated")} for it in items[:10]]

    # Utilisateurs
    users = _get(sdk, url, key, "/Users")
    if isinstance(users, list):
        out["users_count"] = len(users)

    # Activité récente (journal)
    act = _get(sdk, url, key, "/System/ActivityLog/Entries",
               params={"Limit": 8})
    entries = (act or {}).get("Items") if isinstance(act, dict) else None
    if entries:
        out["activity"] = [{"name": e.get("Name"),
                           "type": e.get("Type"),
                           "date": e.get("Date"),
                           "severity": e.get("Severity")} for e in entries[:8]]

    return out


def _now_label(item):
    t = item.get("Type")
    if t == "Episode":
        series = item.get("SeriesName") or ""
        s = item.get("ParentIndexNumber")
        e = item.get("IndexNumber")
        tag = f" S{int(s):02d}E{int(e):02d}" if (s is not None and e is not None) else ""
        return f"{series}{tag} — {item.get('Name', '')}".strip(" —")
    name = item.get("Name") or "?"
    year = item.get("ProductionYear")
    return f"{name} ({year})" if year and t == "Movie" else name


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("emby", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("emby")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _data(sdk, cfg)
    if d.get("ok"):
        c = d.get("counts") or {}
        return True, (f"Emby ✓ — {d.get('name')} v{d.get('version', '?')}, "
                      f"{d.get('sessions_count', 0)} session(s), "
                      f"{c.get('films') or 0} films / {c.get('séries') or 0} séries")
    return False, f"Emby ✗ ({d.get('reason')})"
