/* Emby — statut & activité du serveur média. Pleine page. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.emby = (function () {
  let S = null, root = null, tile = null, data = null;
  const ACCENT = "#52b54b";  // vert Emby
  const CSS =
    "  .emwrap{flex:1;display:flex;flex-direction:column;min-height:0;--em:" + ACCENT + "}\n" +
    "  .emscroll{flex:1;min-height:0;overflow:auto;padding:14px 22px}\n" +
    "  .emhead{display:flex;align-items:center;gap:12px;margin-bottom:14px}\n" +
    "  .emname{font-size:18px;font-weight:700;cursor:pointer}\n" +
    "  .emname .go{font-size:12px;color:var(--dim)}\n" +
    "  .emver{font-size:11px;color:var(--dim)}\n" +
    "  .emkpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-bottom:16px}\n" +
    "  .emkpi{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px 12px;text-align:center}\n" +
    "  .emkpi b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--em)}\n" +
    "  .emkpi span{font-size:11px;color:var(--dim);display:block;margin-top:3px}\n" +
    "  .emsec{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .emsec .cnt{background:var(--bg);border:1px solid var(--border-soft);border-radius:10px;padding:1px 8px;font-size:11px;color:var(--text)}\n" +
    "  .emplay{background:var(--tile);border:1px solid var(--border-soft);border-left:4px solid var(--em);border-radius:11px;padding:11px 14px;margin-bottom:8px}\n" +
    "  .emptop{display:flex;align-items:center;gap:10px}\n" +
    "  .empuser{font-weight:700;font-size:13.5px;color:var(--em)}\n" +
    "  .empitem{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;flex:1}\n" +
    "  .empdev{margin-left:auto;font-size:11px;color:var(--dim);flex:none}\n" +
    "  .empbar{height:6px;border-radius:3px;background:var(--bg);overflow:hidden;margin-top:8px}\n" +
    "  .empbar>i{display:block;height:100%;background:var(--em)}\n" +
    "  .empstate{font-size:11px;color:var(--dim);margin-top:5px}\n" +
    "  .emrow{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border-soft);font-size:13px}\n" +
    "  .emrow:last-child{border-bottom:0}\n" +
    "  .emrt{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .emrtype{font-size:11px;color:var(--em);flex:none}\n" +
    "  .emrmeta{margin-left:auto;font-size:11.5px;color:var(--dim);flex:none}\n" +
    "  .emlibs{display:flex;flex-wrap:wrap;gap:8px}\n" +
    "  .emlib{background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:7px 13px;font-size:12.5px}\n" +
    "  .emlib .lt{font-size:10.5px;color:var(--dim);margin-left:5px}\n" +
    "  .emempty{color:var(--dim);font-size:12.5px;padding:6px 0}";
  function ensureCss() { if (document.getElementById('emUiCss')) return; const s = document.createElement('style'); s.id = 'emUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const TYPE_FR = { Movie: 'Film', Series: 'Série', Episode: 'Épisode', Audio: 'Musique', MusicAlbum: 'Album' };

  function relTime(iso) {
    if (!iso) return '';
    const d = new Date(iso), now = new Date();
    if (isNaN(d)) return '';
    const days = Math.floor((now - d) / 86400000);
    if (days <= 0) return "aujourd'hui";
    if (days === 1) return 'hier';
    if (days < 30) return 'il y a ' + days + ' j';
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Interrogation d\'Emby…</div></div>';
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🎞️</div><div class="t1">Emby indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et une clé API dans ⚙ (Dashboard → Advanced → API Keys).</div>' +
        '<button class="btnpill install" id="emRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('emRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="emwrap"><div class="emscroll">';
    h += '<div class="emhead"><span style="font-size:26px">🎞️</span><div>' +
      '<div class="emname" data-open>' + esc(d.name) + ' <span class="go">↗</span></div>' +
      (d.version ? '<div class="emver">Emby v' + esc(d.version) + '</div>' : '') + '</div></div>';

    // KPIs bibliothèque
    const c = d.counts || {};
    h += '<div class="emkpis">' +
      kpi(c.films, 'films') + kpi(c['séries'], 'séries') + kpi(c['épisodes'], 'épisodes') +
      kpi(c.morceaux, 'morceaux') + kpi(d.sessions_count, 'en lecture') + kpi(d.users_count, 'comptes') +
      '</div>';

    // Sessions en cours
    h += '<div class="emsec">En lecture' + (d.sessions_count ? '<span class="cnt">' + d.sessions_count + '</span>' : '') + '</div>';
    if (!d.sessions || !d.sessions.length) h += '<div class="emempty">Personne ne regarde actuellement</div>';
    else h += d.sessions.map(s =>
      '<div class="emplay"><div class="emptop"><span class="empuser">' + esc(s.user) + '</span>' +
      '<span class="empitem">' + esc(s.item) + '</span>' +
      '<span class="empdev">' + esc(s.device) + '</span></div>' +
      '<div class="empbar"><i style="width:' + (s.percent || 0) + '%"></i></div>' +
      '<div class="empstate">' + (s.paused ? '⏸ en pause' : '▶ lecture') + ' · ' + (s.percent || 0) + '%' +
      (s.method ? ' · ' + esc(s.method) : '') + '</div></div>').join('');

    // Bibliothèques
    if (d.libraries && d.libraries.length) {
      h += '<div class="emsec">Bibliothèques</div><div class="emlibs">' +
        d.libraries.map(l => '<span class="emlib">' + esc(l.name) +
          (l.type ? '<span class="lt">' + esc(l.type) + '</span>' : '') + '</span>').join('') + '</div>';
    }

    // Derniers ajouts
    if (d.latest && d.latest.length) {
      h += '<div class="emsec">Derniers ajouts</div>';
      h += d.latest.map(it =>
        '<div class="emrow"><span class="emrt">' + esc(it.name) + '</span>' +
        '<span class="emrtype">' + esc(TYPE_FR[it.type] || it.type || '') + '</span>' +
        '<span class="emrmeta">' + relTime(it.date) + '</span></div>').join('');
    }

    // Activité récente
    if (d.activity && d.activity.length) {
      h += '<div class="emsec">Activité serveur</div>';
      h += d.activity.map(x =>
        '<div class="emrow"><span class="emrt">' + esc(x.name) + '</span>' +
        '<span class="emrmeta">' + relTime(x.date) + '</span></div>').join('');
    }

    h += '</div></div>';
    el.innerHTML = h;
    const nm = el.querySelector('[data-open]');
    if (nm) nm.addEventListener('click', async () => {
      let cfg = {}; try { cfg = await S.config(); } catch (e) {}
      if (cfg.url) S.openService(cfg.url, d.name || 'Emby');
    });
  }
  function kpi(val, label) {
    if (val == null) return '';
    return '<div class="emkpi"><b>' + nf(val) + '</b><span>' + label + '</span></div>';
  }

  return { render };
})();
