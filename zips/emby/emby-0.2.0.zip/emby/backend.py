"""Addon « emby » — statut & activité du serveur Emby.

    register(sdk) -> flask.Blueprint   (routes sous /addons/emby/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:8096) + apikey (Dashboard → Advanced → API Keys).
Auth par query ?api_key= (accepté par toutes les routes Emby).
"""


def _cfg(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _get(sdk, url, key, path, params=None, timeout=8):
    p = dict(params or {})
    p["api_key"] = key
    try:
        r = sdk.requests.get(url + path, params=p, timeout=timeout)
        if r.status_code == 401:
            return {"__err": "clé API refusée (401)"}
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _ticks_to_pct(pos, run):
    try:
        if run:
            return round(pos / run * 100, 1)
    except (TypeError, ZeroDivisionError):
        pass
    return 0


def _user_id(sdk, url, key):
    """Retourne un userId (premier admin), mis en cache."""
    ck = f"emby:uid:{url}"
    u = sdk.cache_get(ck, 3600)
    if u:
        return u
    users = _get(sdk, url, key, "/Users")
    if isinstance(users, list) and users:
        admin = next((x for x in users if (x.get("Policy") or {}).get("IsAdministrator")), users[0])
        uid = admin.get("Id")
        if uid:
            sdk.cache_set(ck, uid)
            return uid
    return None


def _shape_item(it):
    """Projection d'un item Emby (film/série/épisode) pour l'UI."""
    tags = it.get("ImageTags") or {}
    return {
        "id": it.get("Id"),
        "name": it.get("Name") or "?",
        "type": it.get("Type"),
        "year": it.get("ProductionYear"),
        "series": it.get("SeriesName"),
        "season": it.get("ParentIndexNumber"),
        "episode": it.get("IndexNumber"),
        "has_primary": bool(tags.get("Primary")),
        "primary_tag": tags.get("Primary"),
        "percent": round((it.get("UserData") or {}).get("PlayedPercentage") or 0),
    }


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    info = _get(sdk, url, key, "/System/Info")
    if isinstance(info, dict) and info.get("__err"):
        return {"ok": False, "reason": info["__err"]}
    if not info:
        return {"ok": False, "reason": "Emby injoignable"}

    out = {"ok": True,
           "name": info.get("ServerName") or "Emby",
           "version": info.get("Version")}

    # Sessions en cours (qui regarde quoi)
    sessions = _get(sdk, url, key, "/Sessions")
    active = []
    if isinstance(sessions, list):
        for s in sessions:
            now = s.get("NowPlayingItem")
            if not now:
                continue
            play = s.get("PlayState") or {}
            active.append({
                "user": s.get("UserName") or "?",
                "device": s.get("DeviceName") or s.get("Client") or "",
                "item": _now_label(now),
                "type": now.get("Type"),
                "percent": _ticks_to_pct(play.get("PositionTicks"),
                                         now.get("RunTimeTicks")),
                "paused": play.get("IsPaused", False),
                "method": play.get("PlayMethod"),
            })
    out["sessions"] = active
    out["sessions_count"] = len(active)

    # Bibliothèques : compte par type
    counts = _get(sdk, url, key, "/Items/Counts")
    if isinstance(counts, dict):
        out["counts"] = {
            "films": counts.get("MovieCount"),
            "séries": counts.get("SeriesCount"),
            "épisodes": counts.get("EpisodeCount"),
            "albums": counts.get("AlbumCount"),
            "morceaux": counts.get("SongCount"),
            "artistes": counts.get("ArtistCount"),
        }

    # Vues/bibliothèques configurées
    views = _get(sdk, url, key, "/Library/VirtualFolders")
    if isinstance(views, list):
        out["libraries"] = [{"name": v.get("Name"),
                             "type": v.get("CollectionType")}
                            for v in views[:12]]

    # Derniers ajouts
    latest = _get(sdk, url, key, "/Items",
                  params={"SortBy": "DateCreated", "SortOrder": "Descending",
                          "Recursive": "true",
                          "IncludeItemTypes": "Movie,Series,Episode",
                          "Limit": 10, "Fields": "DateCreated"})
    items = (latest or {}).get("Items") if isinstance(latest, dict) else None
    if items:
        out["latest"] = [{"name": _now_label(it),
                          "type": it.get("Type"),
                          "date": it.get("DateCreated")} for it in items[:10]]

    # Utilisateurs
    users = _get(sdk, url, key, "/Users")
    if isinstance(users, list):
        out["users_count"] = len(users)

    uid = _user_id(sdk, url, key)
    out["server_id"] = info.get("Id")
    if uid:
        # Récents (avec Id + jaquettes) via l'espace utilisateur
        latest2 = _get(sdk, url, key, f"/Users/{uid}/Items/Latest",
                       params={"Limit": 24, "Fields": "ProductionYear",
                               "IncludeItemTypes": "Movie,Series"})
        if isinstance(latest2, list):
            out["recent"] = [_shape_item(it) for it in latest2]
        # En cours de visionnage (reprise)
        resume = _get(sdk, url, key, f"/Users/{uid}/Items/Resume",
                      params={"Limit": 12, "Recursive": "true",
                              "Fields": "ProductionYear,SeriesName",
                              "MediaTypes": "Video"})
        ritems = (resume or {}).get("Items") if isinstance(resume, dict) else None
        if ritems:
            out["resume"] = [_shape_item(it) for it in ritems]

    # Activité récente (journal)
    act = _get(sdk, url, key, "/System/ActivityLog/Entries",
               params={"Limit": 8})
    entries = (act or {}).get("Items") if isinstance(act, dict) else None
    if entries:
        out["activity"] = [{"name": e.get("Name"),
                           "type": e.get("Type"),
                           "date": e.get("Date"),
                           "severity": e.get("Severity")} for e in entries[:8]]

    return out


def _now_label(item):
    t = item.get("Type")
    if t == "Episode":
        series = item.get("SeriesName") or ""
        s = item.get("ParentIndexNumber")
        e = item.get("IndexNumber")
        tag = f" S{int(s):02d}E{int(e):02d}" if (s is not None and e is not None) else ""
        return f"{series}{tag} — {item.get('Name', '')}".strip(" —")
    name = item.get("Name") or "?"
    year = item.get("ProductionYear")
    return f"{name} ({year})" if year and t == "Movie" else name


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("emby", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("emby")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/detail")
    def detail():
        from flask import request
        try:
            iid = (request.args.get("id") or "").strip()
            url, key = _cfg(sdk.config())
            uid = _user_id(sdk, url, key)
            if not (url and key and uid and iid):
                return jsonify({"ok": False, "reason": "paramètres manquants"})
            it = _get(sdk, url, key, f"/Users/{uid}/Items/{iid}",
                      params={"Fields": "Overview,Genres,ProductionYear,RunTimeTicks,"
                                        "SeriesName,CommunityRating,OfficialRating,Studios"})
            if not isinstance(it, dict) or not it.get("Id"):
                return jsonify({"ok": False, "reason": "média introuvable"})
            tags = it.get("ImageTags") or {}
            run = it.get("RunTimeTicks")
            mins = round(run / 600000000) if run else None
            return jsonify({"ok": True, "item": {
                "id": it.get("Id"), "name": it.get("Name"), "type": it.get("Type"),
                "year": it.get("ProductionYear"),
                "overview": it.get("Overview") or "",
                "genres": it.get("Genres") or [],
                "runtime": mins,
                "series": it.get("SeriesName"),
                "rating": it.get("CommunityRating"),
                "official": it.get("OfficialRating"),
                "studios": [x.get("Name") for x in (it.get("Studios") or []) if x.get("Name")][:3],
                "has_primary": bool(tags.get("Primary")),
                "primary_tag": tags.get("Primary"),
                "percent": round((it.get("UserData") or {}).get("PlayedPercentage") or 0),
                "server_id": it.get("ServerId"),
            }})
        except Exception as e:
            sdk.log.exception("emby detail")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}"[:80]})

    @bp.route("/image")
    def image():
        from flask import Response, request
        url, key = _cfg(sdk.config())
        iid = (request.args.get("id") or "").strip()
        tag = (request.args.get("tag") or "").strip()
        if not (url and key and iid):
            return Response("", status=400)
        params = {"maxWidth": 300, "quality": 90, "api_key": key}
        if tag:
            params["tag"] = tag
        try:
            r = sdk.requests.get(url + f"/Items/{iid}/Images/Primary",
                                 params=params, timeout=15)
            if r.status_code != 200:
                return Response("", status=r.status_code)
            ct = r.headers.get("Content-Type", "image/jpeg")
            return Response(r.content, mimetype=ct,
                            headers={"Cache-Control": "private, max-age=86400"})
        except sdk.requests.exceptions.RequestException:
            return Response("", status=502)

    @bp.route("/config")
    def whoami():
        # Expose l'URL publique (pour construire le lien "lire" côté client)
        from flask import jsonify as _j
        url, _ = _cfg(sdk.config())
        return _j({"url": url})

    return bp


def test(sdk, cfg):
    d = _data(sdk, cfg)
    if d.get("ok"):
        c = d.get("counts") or {}
        return True, (f"Emby ✓ — {d.get('name')} v{d.get('version', '?')}, "
                      f"{d.get('sessions_count', 0)} session(s), "
                      f"{c.get('films') or 0} films / {c.get('séries') or 0} séries")
    return False, f"Emby ✗ ({d.get('reason')})"
