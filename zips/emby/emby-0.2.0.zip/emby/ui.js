/* Emby — stats, bibliothèques, reprise, récents (jaquettes), liste/cards, fiche + bouton lire. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.emby = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards', embyUrl = '';
  const ACCENT = '#52b54b';
  const CSS =
    "  .ebwrap{flex:1;display:flex;flex-direction:column;min-height:0;--eb:" + ACCENT + "}\n" +
    "  .ebtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .ebtotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .ebtk{text-align:center}\n" +
    "  .ebtk b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--eb)}\n" +
    "  .ebtk span{font-size:11px;color:var(--dim)}\n" +
    "  .ebvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .ebvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .ebvtoggle button.on{background:var(--tile);color:var(--eb)}\n" +
    "  .ebscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .ebsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .ebsec:first-child{margin-top:0}\n" +
    "  .ebsec .c{color:var(--eb)}\n" +
    "  .ebnow{display:flex;align-items:center;gap:11px;background:rgba(82,181,75,.1);border:1px solid rgba(82,181,75,.3);border-radius:10px;padding:9px 13px;margin-bottom:6px}\n" +
    "  .ebnowu{font-size:11px;color:var(--eb);font-weight:700;min-width:80px;flex:none}\n" +
    "  .ebnowi{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px}\n" +
    "  .ebnowd{font-size:10.5px;color:var(--dim);flex:none}\n" +
    "  .ebposters{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:13px}\n" +
    "  .ebcard{cursor:pointer;display:flex;flex-direction:column;gap:5px}\n" +
    "  .ebpwrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .ebcard:hover .ebpwrap{border-color:var(--eb)}\n" +
    "  .ebposter{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .ebph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:30px;color:var(--dim)}\n" +
    "  .ebtypebadge{position:absolute;top:6px;left:6px;font-size:13px}\n" +
    "  .ebprog{position:absolute;left:0;right:0;bottom:0;height:4px;background:rgba(0,0,0,.4)}\n" +
    "  .ebprog>i{display:block;height:100%;background:var(--eb)}\n" +
    "  .ebctit{font-size:12px;font-weight:600;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    "  .ebcsub{font-size:10.5px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .ebrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .ebrow:hover{border-color:var(--eb)}\n" +
    "  .ebrposter{width:34px;height:51px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .ebrph{width:34px;height:51px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:15px;color:var(--dim);flex:none}\n" +
    "  .ebrtx{min-width:0;flex:1}\n" +
    "  .ebrtit{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ebrmeta{font-size:11.5px;color:var(--dim)}\n" +
    "  .ebrtype{font-size:15px;flex:none}\n" +
    "  .eblibs{display:flex;flex-wrap:wrap;gap:8px}\n" +
    "  .eblib{background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:8px 13px;font-size:12.5px;display:flex;align-items:center;gap:7px}\n" +
    "  .eblib b{color:var(--eb);font-variant-numeric:tabular-nums}\n" +
    "  .ebempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    "  .ebdet{position:fixed;inset:0;background:var(--bg);z-index:9999;display:flex;flex-direction:column}\n" +
    "  .ebdtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .ebdback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .ebdttl{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ebdbody{flex:1;min-height:0;overflow:auto;padding:16px 18px;display:flex;gap:16px}\n" +
    "  .ebdposter{width:100px;height:150px;border-radius:10px;object-fit:cover;object-position:center;background:var(--tile);flex:none}\n" +
    "  .ebdinfo{min-width:0;flex:1}\n" +
    "  .ebdmeta{font-size:12.5px;color:var(--dim);margin-bottom:10px}\n" +
    "  .ebdchips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}\n" +
    "  .ebchip{font-size:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:7px;padding:3px 9px;color:var(--dim)}\n" +
    "  .ebplay{display:inline-flex;align-items:center;gap:8px;background:var(--eb);color:#062a05;font-weight:700;font-size:14px;border:0;border-radius:10px;padding:11px 20px;cursor:pointer;margin-bottom:14px}\n" +
    "  .ebplay:active{opacity:.85}\n" +
    "  .ebdover{font-size:13.5px;line-height:1.55}";
  function ensureCss() { if (document.getElementById('ebUiCss')) return; const s = document.createElement('style'); s.id = 'ebUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const icon = t => t === 'Series' ? '📺' : (t === 'Episode' ? '🎬' : '🎞️');
  const img = (id, tag) => '/addons/emby/api/image?id=' + encodeURIComponent(id) + (tag ? '&tag=' + encodeURIComponent(tag) : '');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture d\'Emby…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    try { const rc = await sdk.api('/config'); const cj = await rc.json(); embyUrl = cj.url || ''; } catch (e) {}
    paint();
  }

  function itemCard(it) {
    const poster = it.has_primary
      ? '<img class="ebposter" loading="lazy" src="' + img(it.id, it.primary_tag) + '" data-ph="ebph">'
      : '<div class="ebph">' + icon(it.type) + '</div>';
    const prog = (it.percent && it.percent > 0 && it.percent < 100)
      ? '<div class="ebprog"><i style="width:' + it.percent + '%"></i></div>' : '';
    return '<div class="ebcard" data-id="' + esc(it.id) + '">' +
      '<div class="ebpwrap">' + poster +
      '<span class="ebtypebadge">' + icon(it.type) + '</span>' + prog + '</div>' +
      '<div class="ebctit">' + esc(it.series || it.name) + '</div>' +
      '<div class="ebcsub">' + (it.type === 'Series' ? 'Série' : (it.year || '')) + '</div></div>';
  }
  function itemRow(it) {
    const poster = it.has_primary
      ? '<img class="ebrposter" loading="lazy" src="' + img(it.id, it.primary_tag) + '" data-ph="ebrph">'
      : '<div class="ebrph">' + icon(it.type) + '</div>';
    return '<div class="ebrow" data-id="' + esc(it.id) + '">' + poster +
      '<div class="ebrtx"><div class="ebrtit">' + esc(it.series || it.name) + '</div>' +
      '<div class="ebrmeta">' + (it.type === 'Series' ? 'Série' : 'Film') + (it.year ? ' · ' + it.year : '') +
      (it.percent > 0 && it.percent < 100 ? ' · repris ' + it.percent + '%' : '') + '</div></div>' +
      '<span class="ebrtype">' + icon(it.type) + '</span></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🎬</div><div class="t1">Emby indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙.</div>' +
        '<button class="btnpill install" id="ebRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('ebRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const c = d.counts || {};
    let h = '<div class="ebwrap"><div class="ebtopbar"><div class="ebtotals">' +
      '<div class="ebtk"><b>' + nf(c['films']) + '</b><span>films</span></div>' +
      '<div class="ebtk"><b>' + nf(c['séries']) + '</b><span>séries</span></div>' +
      '<div class="ebtk"><b>' + nf(c['épisodes']) + '</b><span>épisodes</span></div>' +
      '<div class="ebtk"><b>' + nf(d.sessions_count) + '</b><span>en lecture</span></div>' +
      (d.users_count != null ? '<div class="ebtk"><b>' + nf(d.users_count) + '</b><span>utilisateurs</span></div>' : '') +
      '</div><div class="ebvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div><div class="ebscroll">';

    // En lecture maintenant
    if (d.sessions && d.sessions.length) {
      h += '<div class="ebsec">▶️ En lecture <span class="c">' + d.sessions.length + '</span></div>';
      h += d.sessions.map(s => '<div class="ebnow"><span class="ebnowu">' + esc(s.user) + '</span>' +
        '<span class="ebnowi">' + esc(s.item) + '</span>' +
        '<span class="ebnowd">' + (s.paused ? '⏸ ' : '') + (s.percent || 0) + '% · ' + esc(s.device || '') + '</span></div>').join('');
    }
    // Reprise
    if (d.resume && d.resume.length) {
      h += '<div class="ebsec">⏯️ Reprendre</div>';
      if (viewMode === 'cards') h += '<div class="ebposters">' + d.resume.map(itemCard).join('') + '</div>';
      else h += d.resume.map(itemRow).join('');
    }
    // Bibliothèques
    if (d.libraries && d.libraries.length) {
      h += '<div class="ebsec">📚 Bibliothèques</div><div class="eblibs">';
      const lmap = { movies: ['🎞️', 'films', c['films']], tvshows: ['📺', 'séries', c['séries']], boxsets: ['🗂️', 'collections', null], music: ['🎵', 'albums', c['albums']] };
      h += d.libraries.map(l => {
        const m = lmap[l.type] || ['📁', l.name, null];
        return '<div class="eblib">' + m[0] + ' ' + esc(l.name) + (m[2] != null ? ' <b>' + nf(m[2]) + '</b>' : '') + '</div>';
      }).join('') + '</div>';
    }
    // Récemment ajoutés
    h += '<div class="ebsec">🆕 Récemment ajoutés</div>';
    if (!d.recent || !d.recent.length) h += '<div class="ebempty">Aucun ajout récent.</div>';
    else if (viewMode === 'cards') h += '<div class="ebposters">' + d.recent.map(itemCard).join('') + '</div>';
    else h += d.recent.map(itemRow).join('');

    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.ebvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openDetail(n.getAttribute('data-id'))));
    wirePosters(el);
  }

  function wirePosters(scope) {
    (scope || document).querySelectorAll('img[data-ph]').forEach(im => {
      im.addEventListener('error', function () {
        const cls = this.getAttribute('data-ph') || 'ebph';
        const dv = document.createElement('div');
        dv.className = cls; dv.textContent = '🎞️';
        if (this.parentNode) this.parentNode.replaceChild(dv, this);
      }, { once: true });
    });
  }

  async function openDetail(id) {
    const det = document.createElement('div');
    det.className = 'ebdet';
    det.innerHTML = '<div class="ebdtop"><button class="ebdback">‹ Retour</button><span class="ebdttl">Média</span></div>' +
      '<div class="ebdbody"><div class="ebempty">Chargement…</div></div>';
    document.body.appendChild(det);
    det.querySelector('.ebdback').addEventListener('click', () => det.remove());
    let d = null;
    try { const r = await S.api('/detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false }; }
    if (!d || !d.ok) { det.querySelector('.ebdbody').innerHTML = '<div class="ebempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    const it = d.item;
    det.querySelector('.ebdttl').textContent = it.name + (it.year ? ' (' + it.year + ')' : '');
    const phHtml = '<div class="ebdposter" style="display:flex;align-items:center;justify-content:center;font-size:38px;color:var(--dim)">' + icon(it.type) + '</div>';
    const playUrl = embyUrl ? (embyUrl + '/web/index.html#!/item?id=' + encodeURIComponent(it.id) + (it.server_id ? '&serverId=' + encodeURIComponent(it.server_id) : '')) : '';
    det.querySelector('.ebdbody').innerHTML =
      (it.has_primary ? '<img class="ebdposter" src="' + img(it.id, it.primary_tag) + '" data-ph="det">' : phHtml) +
      '<div class="ebdinfo">' +
      '<div class="ebdmeta">' + [it.type === 'Series' ? 'Série' : 'Film', it.year, it.runtime ? it.runtime + ' min' : '', (it.studios || [])[0], it.rating ? '★ ' + it.rating : ''].filter(Boolean).join(' · ') + '</div>' +
      (playUrl ? '<button class="ebplay" id="ebPlay">▶ Lire dans Emby</button><br>' : '') +
      '<div class="ebdchips">' +
      (it.percent > 0 && it.percent < 100 ? '<span class="ebchip" style="color:var(--eb);border-color:var(--eb)">⏯ Repris ' + it.percent + '%</span>' : '') +
      (it.official ? '<span class="ebchip">' + esc(it.official) + '</span>' : '') +
      (it.genres || []).slice(0, 4).map(g => '<span class="ebchip">' + esc(g) + '</span>').join('') +
      '</div>' +
      '<div class="ebdover">' + esc(it.overview || 'Pas de résumé.') + '</div></div>';
    const body = det.querySelector('.ebdbody'); if (body) body.scrollTop = 0;
    const pb = det.querySelector('#ebPlay');
    if (pb && playUrl) pb.addEventListener('click', () => { try { S.openService(playUrl); } catch (e) { window.open(playUrl, '_blank'); } });
    const dimg = det.querySelector('img.ebdposter[data-ph]');
    if (dimg) dimg.addEventListener('error', function () {
      const dv = document.createElement('div');
      dv.className = 'ebdposter';
      dv.style.cssText = 'display:flex;align-items:center;justify-content:center;font-size:38px;color:var(--dim)';
      dv.textContent = icon(it.type);
      if (this.parentNode) this.parentNode.replaceChild(dv, this);
    }, { once: true });
  }

  return { render };
})();
