"""Addon OVH — signature SHA1 des requêtes, sections à toggles (lecture seule)."""
import hashlib
import time

ENDPOINTS = {"eu": "https://eu.api.ovh.com/1.0", "ca": "https://ca.api.ovh.com/1.0"}


def _cfg(cfg):
    m = (cfg or {}).get("modules", {}).get("ovh", {}) if "modules" in (cfg or {}) else (cfg or {})
    show = lambda k: m.get(k) is not False and str(m.get(k)).lower() != "false"
    return {
        "base": ENDPOINTS.get((m.get("region") or "eu").strip(), ENDPOINTS["eu"]),
        "ak": (m.get("app_key") or "").strip(),
        "as_": (m.get("app_secret") or "").strip(),
        "ck": (m.get("consumer_key") or "").strip(),
        "show_domains": show("show_domains"),
        "show_hosting": show("show_hosting"),
        "show_vps": show("show_vps"),
        "show_dedicated": show("show_dedicated"),
        "show_cloud": show("show_cloud"),
    }


class _OVH:
    """Client minimal signé pour l'API OVH (GET uniquement)."""
    def __init__(self, sdk, base, ak, as_, ck):
        self.sdk, self.base, self.ak, self.as_, self.ck = sdk, base, ak, as_, ck
        self._delta = None

    def _time(self):
        # décalage horaire avec le serveur OVH (requis pour la signature)
        if self._delta is None:
            try:
                r = self.sdk.requests.get(self.base + "/auth/time", timeout=8)
                self._delta = int(r.text) - int(time.time())
            except Exception:
                self._delta = 0
        return int(time.time()) + self._delta

    def get(self, path, timeout=12):
        url = self.base + path
        ts = str(self._time())
        raw = "+".join([self.as_, self.ck, "GET", url, "", ts])
        sig = "$1$" + hashlib.sha1(raw.encode("utf-8")).hexdigest()
        r = self.sdk.requests.get(url, timeout=timeout, headers={
            "X-Ovh-Application": self.ak,
            "X-Ovh-Consumer": self.ck,
            "X-Ovh-Timestamp": ts,
            "X-Ovh-Signature": sig,
        })
        if r.status_code == 403:
            raise PermissionError("accès non autorisé (droits du token)")
        if r.status_code == 401:
            raise PermissionError("clés invalides")
        r.raise_for_status()
        return r.json()


def _days_left(iso_date):
    if not iso_date:
        return None
    try:
        # formats "2027-06-09" ou ISO complet
        s = iso_date[:10]
        t = time.mktime(time.strptime(s, "%Y-%m-%d"))
        return int((t - time.time()) / 86400)
    except Exception:
        return None


def _data(sdk, cfg):
    c = _cfg(cfg)
    if not (c["ak"] and c["as_"] and c["ck"]):
        return {"ok": False, "reason": "clés API requises (⚙)"}
    api = _OVH(sdk, c["base"], c["ak"], c["as_"], c["ck"])
    out = {"ok": True}

    # Domaines
    if c["show_domains"]:
        try:
            names = api.get("/domain")
            doms = []
            for n in (names if isinstance(names, list) else []):
                d = {"name": n}
                try:
                    info = api.get("/domain/" + n)
                    d["offer"] = info.get("offer")
                    d["state"] = info.get("state")
                    d["dnssec"] = info.get("dnssecState") == "enabled"
                    d["lock"] = info.get("transferLockStatus") == "locked"
                    d["renew_auto"] = info.get("renewalState") == "automatic_renew"
                except Exception:
                    pass
                try:
                    si = api.get("/domain/" + n + "/serviceInfos")
                    d["expiration"] = si.get("expiration")
                    d["days_left"] = _days_left(si.get("expiration"))
                    d["renew_auto"] = (si.get("renew") or {}).get("automatic", d.get("renew_auto"))
                except Exception:
                    d["days_left"] = None
                doms.append(d)
            doms.sort(key=lambda x: x["days_left"] if x.get("days_left") is not None else 99999)
            out["domains"] = doms
        except PermissionError as e:
            out["domains_error"] = str(e)
        except Exception:
            out["domains_error"] = "lecture domaines impossible"

    # Hébergements web
    if c["show_hosting"]:
        try:
            names = api.get("/hosting/web")
            hosts = []
            for n in (names if isinstance(names, list) else []):
                h = {"name": n}
                try:
                    info = api.get("/hosting/web/" + n)
                    h["offer"] = info.get("offer")
                    h["state"] = info.get("state")
                    h["quota_size"] = (info.get("quotaSize") or {}).get("value")
                    h["quota_used"] = (info.get("quotaUsed") or {}).get("value")
                    h["cluster"] = info.get("cluster")
                except Exception:
                    pass
                hosts.append(h)
            out["hosting"] = hosts
        except PermissionError as e:
            out["hosting_error"] = str(e)
        except Exception:
            out["hosting_error"] = "lecture hébergements impossible"

    # VPS
    if c["show_vps"]:
        try:
            names = api.get("/vps")
            vps = []
            for n in (names if isinstance(names, list) else []):
                v = {"name": n}
                try:
                    info = api.get("/vps/" + n)
                    v["state"] = info.get("state")
                    v["display"] = info.get("displayName") or n
                    v["cluster"] = info.get("cluster")
                    v["vcore"] = info.get("vcore")
                    v["memory"] = info.get("memoryLimit")
                    v["offer"] = info.get("offerType")
                    v["zone"] = info.get("zone")
                except Exception:
                    pass
                vps.append(v)
            out["vps"] = vps
        except PermissionError as e:
            out["vps_error"] = str(e)
        except Exception:
            out["vps_error"] = "lecture VPS impossible"

    # Serveurs dédiés
    if c["show_dedicated"]:
        try:
            names = api.get("/dedicated/server")
            ded = []
            for n in (names if isinstance(names, list) else []):
                s = {"name": n}
                try:
                    info = api.get("/dedicated/server/" + n)
                    s["state"] = info.get("state")
                    s["display"] = info.get("reverse") or n
                    s["dc"] = info.get("datacenter")
                    s["os"] = info.get("os")
                    s["ip"] = info.get("ip")
                    s["commercial"] = info.get("commercialRange")
                except Exception:
                    pass
                ded.append(s)
            out["dedicated"] = ded
        except PermissionError as e:
            out["dedicated_error"] = str(e)
        except Exception:
            out["dedicated_error"] = "lecture dédiés impossible"

    # Public Cloud
    if c["show_cloud"]:
        try:
            ids = api.get("/cloud/project")
            projs = []
            for pid in (ids if isinstance(ids, list) else []):
                p = {"id": pid}
                try:
                    info = api.get("/cloud/project/" + pid)
                    p["name"] = info.get("description") or info.get("projectName") or pid
                    p["status"] = info.get("status")
                    p["created"] = info.get("creationDate")
                except Exception:
                    p["name"] = pid
                projs.append(p)
            out["cloud"] = projs
        except PermissionError as e:
            out["cloud_error"] = str(e)
        except Exception:
            out["cloud_error"] = "lecture Public Cloud impossible"

    # compteurs + expirations
    out["domains_count"] = len(out.get("domains", []))
    out["hosting_count"] = len(out.get("hosting", []))
    out["vps_count"] = len(out.get("vps", []))
    out["dedicated_count"] = len(out.get("dedicated", []))
    out["cloud_count"] = len(out.get("cloud", []))
    exp = [d for d in out.get("domains", []) if d.get("days_left") is not None and d["days_left"] <= 60]
    out["expiring_count"] = len(exp)
    out["expiring"] = sorted(exp, key=lambda x: x["days_left"])
    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("addon_ovh", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except PermissionError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": f"connexion : {type(e).__name__}"[:100]})
        except Exception as e:
            sdk.log.exception("ovh")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    c = _cfg(cfg)
    if not (c["ak"] and c["as_"] and c["ck"]):
        return False, "clés API requises"
    try:
        api = _OVH(sdk, c["base"], c["ak"], c["as_"], c["ck"])
        me = api.get("/me", timeout=8)
        return True, f"connecté : {me.get('nichandle')}"
    except PermissionError as e:
        return False, str(e)
    except Exception as e:
        return False, f"{type(e).__name__}"[:60]
