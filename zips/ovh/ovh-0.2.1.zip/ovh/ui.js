/* OVH — domaines, hébergements, VPS, dédiés, Public Cloud (API signée). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.ovh = (function () {
  const UIVER = '0.2.0';
  let S = null, root = null, tile = null, data = null, activeTab = '__all__', viewMode = 'cards';
  const ACCENT = '#000e9c';
  const CSS =
    "  .ovwrap{--ov:" + ACCENT + "}\n" +
    "  .ovhead{display:flex;align-items:center;gap:24px;padding:18px 26px 14px;border-bottom:1px solid var(--border-soft);flex-wrap:wrap}\n" +
    "  .ovtk{display:flex;flex-direction:column}\n" +
    "  .ovtk b{font-size:26px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums;color:var(--ov)}\n" +
    "  .ovtk.warn b{color:var(--warn)}\n" +
    "  .ovtk span{font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:.05em;margin-top:5px}\n" +
    "  .ovver{margin-left:auto;font-size:10px;color:var(--dim);align-self:flex-start}\n" +
    "  .ovscroll{padding:18px 26px 24px}\n" +
    "  .ovsec{font-size:13px;font-weight:800;color:var(--fg);margin:22px 0 12px;display:flex;align-items:center;gap:9px}\n" +
    "  .ovsec:first-child{margin-top:0}\n" +
    "  .ovsec .ic{font-size:17px}\n" +
    "  .ovsec .c{background:var(--ov);color:#fff;font-size:11px;font-weight:700;border-radius:20px;padding:1px 9px;min-width:20px;text-align:center}\n" +
    "  .ovgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:13px}\n" +
    "  .ovcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;padding:14px 16px;display:flex;flex-direction:column;gap:9px}\n" +
    "  .ovcard.warn{border-color:var(--warn)}.ovcard.crit{border-color:var(--bad)}\n" +
    "  .ovchead{display:flex;align-items:center;gap:9px}\n" +
    "  .ovdot{width:10px;height:10px;border-radius:50%;background:var(--green);flex:none}\n" +
    "  .ovdot.off{background:var(--bad)}\n" +
    "  .ovname{font-weight:700;font-size:15px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ovexp{font-size:12px;font-weight:700;font-variant-numeric:tabular-nums;flex:none;padding:2px 9px;border-radius:8px}\n" +
    "  .ovexp.ok{color:var(--green);background:color-mix(in srgb,var(--green) 12%,transparent)}\n" +
    "  .ovexp.warn{color:var(--warn);background:color-mix(in srgb,var(--warn) 14%,transparent)}\n" +
    "  .ovexp.crit{color:#fff;background:var(--bad)}\n" +
    "  .ovchips{display:flex;flex-wrap:wrap;gap:6px}\n" +
    "  .ovchip{font-size:11px;background:var(--bg);border:1px solid var(--border-soft);border-radius:7px;padding:2px 8px;color:var(--dim)}\n" +
    "  .ovchip.on{color:var(--ov);border-color:var(--ov)}\n" +
    "  .ovbar{height:8px;border-radius:5px;background:var(--bg);overflow:hidden}\n" +
    "  .ovbar>i{display:block;height:100%;background:var(--ov)}\n" +
    "  .ovbarlbl{font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .ovfoot{font-size:11px;color:var(--dim);border-top:1px solid var(--border-soft);padding-top:8px}\n" +
    "  .overr{font-size:12.5px;color:var(--warn);background:color-mix(in srgb,var(--warn) 9%,transparent);border:1px solid color-mix(in srgb,var(--warn) 30%,transparent);border-radius:10px;padding:9px 13px;margin-bottom:10px}\n" +
    "  .ovalert{display:flex;align-items:center;gap:10px;background:color-mix(in srgb,var(--warn) 9%,transparent);border:1px solid color-mix(in srgb,var(--warn) 30%,transparent);border-radius:11px;padding:11px 15px;margin-bottom:14px}\n" +
    "  .ovalert .n{font-weight:800;color:var(--warn);flex:none}\n" +
    "  .ovempty{color:var(--dim);font-size:13px;padding:10px 0}\n" +
    "  .ovbar2{display:flex;align-items:center;gap:10px;padding:12px 26px 0}\n" +
    "  .ovtabs{display:flex;gap:4px;flex:1;overflow-x:auto;scrollbar-width:none}\n" +
    "  .ovtabs::-webkit-scrollbar{display:none}\n" +
    "  .ovtab{flex:none;background:transparent;border:1px solid var(--border-soft);color:var(--dim);font-size:13px;font-weight:600;padding:7px 15px;border-radius:9px;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:7px}\n" +
    "  .ovtab.on{background:var(--ov);border-color:var(--ov);color:#fff}\n" +
    "  .ovtab .n{font-size:11px;opacity:.8;font-variant-numeric:tabular-nums}\n" +
    "  .ovvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .ovvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .ovvtoggle button.on{background:var(--tile);color:var(--ov)}\n" +
    "  .ovrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 14px;margin-bottom:6px}\n" +
    "  .ovrow.warn{border-color:var(--warn)}.ovrow.crit{border-color:var(--bad)}\n" +
    "  .ovrtx{min-width:0;flex:1}\n" +
    "  .ovrname{font-weight:600;font-size:13.5px;display:flex;align-items:center;gap:7px}\n" +
    "  .ovrmeta{font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n";
  function ensureCss() { let s = document.getElementById('ovUiCss'); if (!s) { s = document.createElement('style'); s.id = 'ovUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  function fdate(s) { if (!s) return '—'; try { return new Date(s).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) { return s; } }
  function expClass(d) { if (d == null) return 'ok'; if (d <= 15) return 'crit'; if (d <= 60) return 'warn'; return 'ok'; }
  function expLabel(d) { if (d == null) return '∞'; if (d < 0) return 'expiré'; return d + ' j'; }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture d\'OVH…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function domCard(d) {
    const cls = expClass(d.days_left);
    return '<div class="ovcard' + (cls === 'crit' ? ' crit' : (cls === 'warn' ? ' warn' : '')) + '"><div class="ovchead">' +
      '<span class="ovdot' + (d.state === 'ok' ? '' : ' off') + '"></span>' +
      '<span class="ovname">' + esc(d.name) + '</span>' +
      '<span class="ovexp ' + cls + '">' + expLabel(d.days_left) + '</span></div>' +
      '<div class="ovchips">' +
      (d.offer ? '<span class="ovchip on">' + esc(d.offer) + '</span>' : '') +
      (d.dnssec ? '<span class="ovchip">DNSSEC</span>' : '') +
      (d.lock ? '<span class="ovchip">🔒 lock</span>' : '') +
      (d.renew_auto ? '<span class="ovchip">renouv. auto</span>' : '<span class="ovchip">renouv. manuel</span>') +
      '</div>' +
      '<div class="ovfoot">expire le ' + fdate(d.expiration) + '</div></div>';
  }
  function hostCard(h) {
    const pct = (h.quota_size && h.quota_used) ? Math.min(100, Math.round(h.quota_used / h.quota_size * 100)) : null;
    return '<div class="ovcard"><div class="ovchead">' +
      '<span class="ovdot' + (h.state === 'active' || h.state === 'ok' ? '' : '') + '"></span>' +
      '<span class="ovname">' + esc(h.name) + '</span>' +
      (h.offer ? '<span class="ovchip on">' + esc(h.offer) + '</span>' : '') + '</div>' +
      (h.cluster ? '<div class="ovchips"><span class="ovchip">' + esc(h.cluster) + '</span></div>' : '') +
      (pct != null ? '<div class="ovbar"><i style="width:' + pct + '%"></i></div><div class="ovbarlbl">' + nf(h.quota_used) + ' / ' + nf(h.quota_size) + ' Mo (' + pct + '%)</div>' : '') +
      '</div>';
  }
  function vpsCard(v) {
    return '<div class="ovcard"><div class="ovchead">' +
      '<span class="ovdot' + (v.state === 'running' ? '' : ' off') + '"></span>' +
      '<span class="ovname">' + esc(v.display || v.name) + '</span></div>' +
      '<div class="ovchips">' +
      (v.offer ? '<span class="ovchip on">' + esc(v.offer) + '</span>' : '') +
      (v.vcore ? '<span class="ovchip">' + v.vcore + ' vCore</span>' : '') +
      (v.memory ? '<span class="ovchip">' + Math.round(v.memory / 1024) + ' Go</span>' : '') +
      (v.zone ? '<span class="ovchip">📍 ' + esc(v.zone) + '</span>' : '') + '</div>' +
      '<div class="ovfoot">' + esc(v.name) + ' · ' + esc(v.state || '') + '</div></div>';
  }
  function dedCard(s) {
    return '<div class="ovcard"><div class="ovchead">' +
      '<span class="ovdot' + (s.state === 'ok' ? '' : ' off') + '"></span>' +
      '<span class="ovname">' + esc(s.display || s.name) + '</span></div>' +
      '<div class="ovchips">' +
      (s.commercial ? '<span class="ovchip on">' + esc(s.commercial) + '</span>' : '') +
      (s.dc ? '<span class="ovchip">📍 ' + esc(s.dc) + '</span>' : '') +
      (s.os ? '<span class="ovchip">' + esc(s.os) + '</span>' : '') + '</div>' +
      '<div class="ovfoot">' + esc(s.ip || s.name) + '</div></div>';
  }
  function cloudCard(p) {
    return '<div class="ovcard"><div class="ovchead">' +
      '<span class="ovdot' + (p.status === 'ok' ? '' : ' off') + '"></span>' +
      '<span class="ovname">' + esc(p.name) + '</span></div>' +
      '<div class="ovfoot">' + esc(p.id) + (p.created ? ' · créé le ' + fdate(p.created) : '') + '</div></div>';
  }

  // Catégories pour les onglets : clé de données -> libellé + icône + fonction carte/ligne
  const CATS = [
    { key: 'domains', label: 'Domaines', ic: '🌐', card: domCard, count: 'domains_count' },
    { key: 'hosting', label: 'Hébergements', ic: '🌍', card: hostCard, count: 'hosting_count' },
    { key: 'vps', label: 'VPS', ic: '🖥', card: vpsCard, count: 'vps_count' },
    { key: 'dedicated', label: 'Dédiés', ic: '🗄', card: dedCard, count: 'dedicated_count' },
    { key: 'cloud', label: 'Public Cloud', ic: '☁️', card: cloudCard, count: 'cloud_count' },
  ];
  function rowFor(cat, item) {
    // ligne compacte générique selon la catégorie
    let meta = '', badge = '';
    if (cat.key === 'domains') {
      const cls = expClass(item.days_left);
      meta = (item.offer || '') + (item.expiration ? ' · expire le ' + fdate(item.expiration) : '');
      badge = '<span class="ovexp ' + cls + '">' + expLabel(item.days_left) + '</span>';
      return '<div class="ovrow ' + (cls === 'crit' ? 'crit' : (cls === 'warn' ? 'warn' : '')) + '"><div class="ovrtx">' +
        '<div class="ovrname">' + esc(item.name) + '</div><div class="ovrmeta">' + esc(meta) + '</div></div>' + badge + '</div>';
    }
    if (cat.key === 'hosting') meta = (item.offer || '') + (item.cluster ? ' · ' + item.cluster : '');
    else if (cat.key === 'vps') meta = [item.offer, item.zone, item.state].filter(Boolean).join(' · ');
    else if (cat.key === 'dedicated') meta = [item.commercial, item.dc, item.ip].filter(Boolean).join(' · ');
    else if (cat.key === 'cloud') meta = item.id + (item.status ? ' · ' + item.status : '');
    return '<div class="ovrow"><div class="ovrtx"><div class="ovrname">' + esc(item.display || item.name) +
      '</div><div class="ovrmeta">' + esc(meta) + '</div></div></div>';
  }
  function renderCat(cat) {
    const items = data[cat.key];
    if (!items || !items.length) return '';
    let h = '<div class="ovsec"><span class="ic">' + cat.ic + '</span> ' + cat.label + ' <span class="c">' + items.length + '</span></div>';
    if (viewMode === 'list') h += items.map(x => rowFor(cat, x)).join('');
    else h += '<div class="ovgrid">' + items.map(cat.card).join('') + '</div>';
    return h;
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">☁️</div><div class="t1">OVH indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne tes clés API (AK / AS / CK) dans ⚙.</div>' +
        '<button class="btnpill install" id="ovRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('ovRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="ovwrap"><div class="ovhead">';
    if (d.domains_count) h += '<div class="ovtk"><b>' + nf(d.domains_count) + '</b><span>domaines</span></div>';
    if (d.hosting_count) h += '<div class="ovtk"><b>' + nf(d.hosting_count) + '</b><span>hébergements</span></div>';
    if (d.vps_count) h += '<div class="ovtk"><b>' + nf(d.vps_count) + '</b><span>VPS</span></div>';
    if (d.dedicated_count) h += '<div class="ovtk"><b>' + nf(d.dedicated_count) + '</b><span>dédiés</span></div>';
    if (d.cloud_count) h += '<div class="ovtk"><b>' + nf(d.cloud_count) + '</b><span>public cloud</span></div>';
    if (d.expiring_count) h += '<div class="ovtk warn"><b>' + nf(d.expiring_count) + '</b><span>expirent bientôt</span></div>';
    h += '<span class="ovver">ui v' + UIVER + '</span></div>';

    // Barre : onglets par catégorie (présentes seulement) + toggle liste/cards
    const present = CATS.filter(c => (d[c.key] || []).length);
    h += '<div class="ovbar2"><div class="ovtabs">';
    const totalAll = present.reduce((a, c) => a + d[c.key].length, 0);
    h += '<button class="ovtab' + (activeTab === '__all__' ? ' on' : '') + '" data-tab="__all__">Tous <span class="n">' + totalAll + '</span></button>';
    present.forEach(c => {
      h += '<button class="ovtab' + (activeTab === c.key ? ' on' : '') + '" data-tab="' + c.key + '">' +
        c.ic + ' ' + c.label + ' <span class="n">' + d[c.key].length + '</span></button>';
    });
    h += '</div><div class="ovvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';

    h += '<div class="ovscroll">';
    for (const k of ['domains_error', 'hosting_error', 'vps_error', 'dedicated_error', 'cloud_error']) {
      if (d[k]) h += '<div class="overr">⚠ ' + esc(d[k]) + '</div>';
    }
    if (d.expiring && d.expiring.length) {
      const soon = d.expiring.filter(x => x.days_left != null && x.days_left <= 15);
      if (soon.length) h += '<div class="ovalert"><span class="n">⚠</span><span>' +
        soon.map(x => esc(x.name) + ' (' + expLabel(x.days_left) + ')').join(', ') + ' — renouvellement à surveiller</span></div>';
    }

    // Rendu : soit toutes les catégories, soit celle de l'onglet actif
    const toRender = activeTab === '__all__' ? present : present.filter(c => c.key === activeTab);
    if (!toRender.length) h += '<div class="ovempty">Aucun produit.</div>';
    else toRender.forEach(c => { h += renderCat(c); });
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.ovtab').forEach(b => b.addEventListener('click', () => {
      const t = b.getAttribute('data-tab'); if (t === activeTab) return;
      activeTab = t; paint();
    }));
    el.querySelectorAll('.ovvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
  }

  return { render };
})();
