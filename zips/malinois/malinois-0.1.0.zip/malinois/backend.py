"""Addon Malinois — état des visites tracker-autovisit via /api/status (clé API)."""
import re


def _cfg(cfg):
    m = (cfg or {}).get("modules", {}).get("malinois", {}) if "modules" in (cfg or {}) else (cfg or {})
    url = (m.get("url") or "").strip().rstrip("/")
    key = (m.get("apikey") or "").strip()
    return url, key


def _get_status(sdk, url, key, timeout=10):
    r = sdk.requests.get(url + "/api/status",
                         headers={"X-API-Key": key},
                         timeout=timeout, verify=False)
    r.raise_for_status()
    return r.json()


# Extraction des métriques usuelles depuis la chaîne stats libre du tracker.
# Exemples réels :
#   "upload: 48,43 To | download: 4,13 To | ratio: 11,72 | bonus: 562183,54 | class: Normal"
#   "upload: 802.2 GiB | download: 168.69 GiB | ratio: 4.76 | seeding: 99"
_METRIC = re.compile(r"([a-zA-Zéèêà_ ]+):\s*([^|]+)")


def _parse_stats(s):
    """Retourne un dict {clé: valeur} depuis la chaîne stats (best effort)."""
    out = {}
    if not s:
        return out
    for m in _METRIC.finditer(s):
        k = m.group(1).strip().lower()
        v = m.group(2).strip()
        if k and v:
            out[k] = v
    return out


def _shape_site(s):
    st = _parse_stats(s.get("stats"))
    return {
        "name": s.get("name") or "?",
        "url": s.get("url") or "",
        "ok": bool(s.get("ok")),
        "alert": s.get("alert"),
        "last_ok": s.get("last_ok"),
        "ratio": st.get("ratio"),
        "upload": st.get("upload"),
        "download": st.get("download"),
        "bonus": st.get("bonus"),
        "klass": st.get("class"),
        "raw_stats": s.get("stats") or "",
    }


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL et clé API requises (⚙)"}
    d = _get_status(sdk, url, key)
    if not isinstance(d, dict) or not d.get("ok"):
        return {"ok": False, "reason": (d or {}).get("error") or "réponse invalide"}
    sites = [_shape_site(s) for s in d.get("sites", [])]
    # sites en échec d'abord, puis alphabétique
    sites.sort(key=lambda s: (s["ok"], s["name"].lower()))
    alerts = [s for s in sites if s.get("alert")]
    return {
        "ok": True,
        "updated": d.get("updated"),
        "total": d.get("total", len(sites)),
        "sites_ok": d.get("sites_ok"),
        "sites_ko": d.get("sites_ko"),
        "alerts_count": len(alerts),
        "sites": sites,
    }


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("addon_malinois", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": f"connexion : {type(e).__name__}"[:100]})
        except Exception as e:
            sdk.log.exception("malinois")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return False, "URL et clé API requises"
    try:
        d = _get_status(sdk, url, key, timeout=6)
        if d.get("ok"):
            return True, f"{d.get('sites_ok')}/{d.get('total')} sites OK"
        return False, d.get("error") or "réponse invalide"
    except Exception as e:
        return False, f"{type(e).__name__}"[:60]
