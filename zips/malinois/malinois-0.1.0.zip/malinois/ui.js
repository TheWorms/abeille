/* Malinois — état des visites tracker-autovisit : OK/KO, alertes, ratio, upload. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.malinois = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  const ACCENT = '#e0892b';
  const CSS =
    "  .mlwrap{flex:1;display:flex;flex-direction:column;min-height:0;--ml:" + ACCENT + "}\n" +
    "  .mltopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .mltotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .mltk{text-align:center}\n" +
    "  .mltk b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--ml)}\n" +
    "  .mltk.ok b{color:var(--green)}.mltk.ko b{color:var(--bad)}.mltk.al b{color:var(--warn)}\n" +
    "  .mltk span{font-size:11px;color:var(--dim)}\n" +
    "  .mlvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .mlvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .mlvtoggle button.on{background:var(--tile);color:var(--ml)}\n" +
    "  .mlscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .mlsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .mlsec:first-child{margin-top:0}\n" +
    "  .mlupd{font-size:11px;color:var(--dim);font-weight:400;text-transform:none;letter-spacing:0;margin-left:auto}\n" +
    /* alerte bandeau */
    "  .mlalert{display:flex;align-items:flex-start;gap:10px;background:rgba(224,137,43,.1);border:1px solid rgba(224,137,43,.35);border-radius:10px;padding:10px 13px;margin-bottom:7px}\n" +
    "  .mlalert .n{font-weight:700;flex:none;color:var(--warn)}\n" +
    "  .mlalert .t{font-size:12.5px;min-width:0}\n" +
    /* cartes */
    "  .mlgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:11px}\n" +
    "  .mlcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 13px;display:flex;flex-direction:column;gap:7px}\n" +
    "  .mlcard.ko{border-color:var(--bad);background:rgba(224,80,80,.06)}\n" +
    "  .mlchead{display:flex;align-items:center;gap:8px}\n" +
    "  .mlcdot{width:9px;height:9px;border-radius:50%;background:var(--green);flex:none}\n" +
    "  .mlcard.ko .mlcdot{background:var(--bad)}\n" +
    "  .mlcname{font-weight:700;font-size:14px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .mlcratio{font-size:13px;font-weight:700;color:var(--ml);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .mlcstats{display:flex;flex-wrap:wrap;gap:5px}\n" +
    "  .mlchip{font-size:10.5px;background:var(--bg);border:1px solid var(--border-soft);border-radius:6px;padding:2px 7px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .mlchip.warn{color:var(--warn);border-color:var(--warn)}\n" +
    "  .mlclast{font-size:10.5px;color:var(--dim)}\n" +
    /* liste */
    "  .mlrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 13px;margin-bottom:6px}\n" +
    "  .mlrow.ko{border-color:var(--bad);background:rgba(224,80,80,.06)}\n" +
    "  .mlrtx{min-width:0;flex:1}\n" +
    "  .mlrname{font-weight:600;font-size:13.5px}\n" +
    "  .mlrmeta{font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .mlrratio{font-size:13px;font-weight:700;color:var(--ml);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .mlempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { if (document.getElementById('mlUiCss')) return; const s = document.createElement('style'); s.id = 'mlUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  function fdate(iso) { if (!iso) return ''; try { const d = new Date(iso); return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }); } catch (e) { return iso; } }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Malinois…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function siteCard(s) {
    const chips = [];
    if (s.upload) chips.push('<span class="mlchip">⬆ ' + esc(s.upload) + '</span>');
    if (s.download) chips.push('<span class="mlchip">⬇ ' + esc(s.download) + '</span>');
    if (s.bonus) chips.push('<span class="mlchip">🎁 ' + esc(s.bonus) + '</span>');
    if (s.klass) chips.push('<span class="mlchip">' + esc(s.klass) + '</span>');
    if (s.alert) chips.push('<span class="mlchip warn">⚠ alerte</span>');
    return '<div class="mlcard' + (s.ok ? '' : ' ko') + '">' +
      '<div class="mlchead"><span class="mlcdot"></span>' +
      '<span class="mlcname">' + esc(s.name) + '</span>' +
      (s.ratio ? '<span class="mlcratio">' + esc(s.ratio) + '</span>' : '') + '</div>' +
      (chips.length ? '<div class="mlcstats">' + chips.join('') + '</div>' : '') +
      '<div class="mlclast">' + (s.ok ? '✓ ' + fdate(s.last_ok) : '✗ échec — dernière réussite ' + fdate(s.last_ok)) + '</div>' +
      '</div>';
  }
  function siteRow(s) {
    const meta = [s.upload ? '⬆' + s.upload : '', s.download ? '⬇' + s.download : '', s.klass || ''].filter(Boolean).join(' · ');
    return '<div class="mlrow' + (s.ok ? '' : ' ko') + '">' +
      '<span class="mlcdot"></span>' +
      '<div class="mlrtx"><div class="mlrname">' + esc(s.name) + (s.alert ? ' <span style="color:var(--warn)">⚠</span>' : '') + '</div>' +
      '<div class="mlrmeta">' + esc(meta || s.url) + '</div></div>' +
      (s.ratio ? '<span class="mlrratio">' + esc(s.ratio) + '</span>' : '') +
      '</div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🐕</div><div class="t1">Malinois indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙.</div>' +
        '<button class="btnpill install" id="mlRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('mlRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="mlwrap"><div class="mltopbar"><div class="mltotals">' +
      '<div class="mltk"><b>' + nf(d.total) + '</b><span>trackers</span></div>' +
      '<div class="mltk ok"><b>' + nf(d.sites_ok) + '</b><span>OK</span></div>' +
      '<div class="mltk ko"><b>' + nf(d.sites_ko) + '</b><span>en échec</span></div>' +
      (d.alerts_count ? '<div class="mltk al"><b>' + nf(d.alerts_count) + '</b><span>alertes</span></div>' : '') +
      '</div><div class="mlvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div><div class="mlscroll">';

    // alertes en bandeau
    const alerts = (d.sites || []).filter(s => s.alert);
    if (alerts.length) {
      h += '<div class="mlsec">⚠️ Alertes</div>';
      h += alerts.map(s => '<div class="mlalert"><span class="n">' + esc(s.name) + '</span><span class="t">' + esc(s.alert) + '</span></div>').join('');
    }

    h += '<div class="mlsec">🌐 Trackers' +
      (d.updated ? '<span class="mlupd">visite : ' + esc(d.updated) + '</span>' : '') + '</div>';
    if (!d.sites || !d.sites.length) h += '<div class="mlempty">Aucun site suivi.</div>';
    else if (viewMode === 'cards') h += '<div class="mlgrid">' + d.sites.map(siteCard).join('') + '</div>';
    else h += d.sites.map(siteRow).join('');

    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.mlvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
  }

  return { render };
})();
