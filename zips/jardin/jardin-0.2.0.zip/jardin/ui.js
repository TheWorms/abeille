/* Jardin — calendrier lunaire du potager (Phase 3, lot D). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.jardin = (function () {
  const CSS = "  .gdhero{display:flex;gap:18px;align-items:center;background:var(--tile);border:1px solid var(--border-soft);\n          border-radius:14px;padding:16px 20px;margin-bottom:12px}\n  .gdicon{font-size:46px;flex:none}\n  .gdlab{font-size:19px;font-weight:700}\n  .gdsub{font-size:12.5px;color:var(--dim);margin-top:3px}\n  .gdconseil{font-size:13px;margin-top:8px;color:var(--text)}\n  .gdmoon{margin-left:auto;text-align:right;flex:none}\n  .gdmoon .m1{font-size:30px}\n  .gdmoon .m2{font-size:11.5px;color:var(--dim)}\n  .gdrise{display:inline-block;font-size:11px;font-weight:600;padding:3px 9px;border-radius:7px;margin-top:6px}\n  .gdrise.up{background:var(--accent-tint);color:var(--accent)}\n  .gdrise.down{background:rgba(240,180,41,.15);color:var(--warn)}\n  .gdweek{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:14px}\n  .gdcell{background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:8px 4px;text-align:center}\n  .gdcell.today{border-color:var(--accent);background:var(--accent-tint)}\n  .gdd{font-size:10px;color:var(--dim);text-transform:capitalize}\n  .gdi{font-size:20px;margin:3px 0}\n  .gdk{font-size:9.5px;color:var(--faint)}\n  .gdcols{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}\n  .gdcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 13px}\n  .gdch{font-size:12px;font-weight:700;margin-bottom:7px}\n  .gdchip{display:inline-block;font-size:11.5px;background:var(--bg);border:1px solid var(--border-soft);\n          border-radius:7px;padding:3px 8px;margin:0 5px 5px 0}";
  function ensureCss(){if(document.getElementById('gdUiCss'))return;const s=document.createElement('style');s.id='gdUiCss';s.textContent=CSS;document.head.appendChild(s);}
  async function render(el, sdk, a) {
    ensureCss();
    let lun=null,cal=null;
    try{const r=await sdk.api('/lunar?days=7');lun=await r.json();}catch(e){}
    try{const r=await sdk.api('/calendar');cal=await r.json();}catch(e){}
    if(!lun||!lun.ok){el.innerHTML='<div class="stub"><div class="big">🌱</div><div class="t1">Jardin</div><div class="t2">Calcul indisponible</div></div>';return;}
    const t=lun.days[0];
    let h='<div class="gdhero"><div class="gdicon">'+t.icon+'</div>'+
      '<div><div class="gdlab">'+t.label+'</div>'+
      '<div class="gdsub">Lune en '+t.sign+' · élément '+t.element+'</div>'+
      '<div class="gdconseil">'+t.conseil+'</div>'+
      '<span class="gdrise '+(t.rising?'up':'down')+'">'+(t.rising?'↑ Lune montante — semer, greffer':'↓ Lune descendante — planter, tailler, récolter')+'</span></div>'+
      '<div class="gdmoon"><div class="m1">'+t.moon_icon+'</div><div class="m2">'+t.illumination+' %<br>'+(t.waxing?'croissante':'décroissante')+'</div></div></div>';
    h+='<div class="wsec" style="padding-left:0">Les 7 prochains jours</div><div class="gdweek">'+
      lun.days.map((x,i)=>{const dd=new Date(x.date+'T12:00:00');
        return '<div class="gdcell'+(i===0?' today':'')+'"><div class="gdd">'+dd.toLocaleDateString('fr-FR',{weekday:'short'})+' '+dd.getDate()+'</div>'+
          '<div class="gdi">'+x.icon+'</div><div class="gdk">'+x.kind+'</div>'+
          '<div class="gdk">'+(x.rising?'↑':'↓')+' '+x.moon_icon+'</div></div>';}).join('')+'</div>';
    if(cal&&cal.ok){
      const card=(t2,arr,ic)=>'<div class="gdcard"><div class="gdch">'+ic+' '+t2+'</div>'+
        (arr.length?arr.map(x=>'<span class="gdchip">'+x+'</span>').join(''):'<span class="gdk">rien ce mois-ci</span>')+'</div>';
      h+='<div class="wsec" style="padding-left:0">Au potager en '+cal.month_name+'</div><div class="gdcols">'+
        card('Semis sous abri',cal.semis_abri,'🏠')+card('Semis en pleine terre',cal.semis_terre,'🌾')+
        card('Plantations',cal.plantation,'🪴')+card('Récoltes',cal.recolte,'🧺')+'</div>';
    }
    h+='<div class="wsrc">Éphémérides calculées localement · le calendrier lunaire relève de la tradition biodynamique, pas d\'un consensus scientifique · vue embarquée v0.2.0</div>';
    el.innerHTML=h;
  }
  return { render };
})();
