"""Addon « jardin » — calendrier lunaire du jardinier (contrat SDK, lot D).

    register(sdk) -> Blueprint   (routes /addons/jardin/api/lunar, /calendar)
    test(sdk, cfg) -> (bool, str)

Calcul 100 % local (aucun réseau). Le socle astro (_jd, _sun_moon_ecl,
_moon_phase) est identique à celui de l'addon lune : chaque addon embarque le
sien pour rester autonome et installable séparément — la duplication est le
prix de l'indépendance, assumée.
"""
import math
from datetime import datetime, timedelta, timezone

SYNODIC = 29.530588853

def _jd(dt):
    """Jour julien depuis un datetime UTC."""
    return dt.replace(tzinfo=timezone.utc).timestamp() / 86400.0 + 2440587.5

def _sun_moon_ecl(jd):
    """Positions écliptiques (deg), éléments de Schlyter.
    d compté depuis 1999-12-31 00:00 UT (epoch 2000.0 de Schlyter)."""
    d = jd - 2451543.5
    # Soleil
    w = 282.9404 + 4.70935e-5 * d
    e = 0.016709 - 1.151e-9 * d
    M = (356.0470 + 0.9856002585 * d) % 360
    Mr = math.radians(M)
    E = M + math.degrees(e) * math.sin(Mr) * (1 + e * math.cos(Mr))
    Er = math.radians(E)
    xv = math.cos(Er) - e
    yv = math.sqrt(1 - e * e) * math.sin(Er)
    v = math.degrees(math.atan2(yv, xv))
    sun_lon = (v + w) % 360
    # Lune
    N = (125.1228 - 0.0529538083 * d) % 360
    i = 5.1454
    wm = (318.0634 + 0.1643573223 * d) % 360
    a = 60.2666
    em = 0.054900
    Mm = (115.3654 + 13.0649929509 * d) % 360
    Emm = Mm + math.degrees(em) * math.sin(math.radians(Mm)) * (1 + em * math.cos(math.radians(Mm)))
    for _ in range(3):
        Emm = Emm - (Emm - math.degrees(em) * math.sin(math.radians(Emm)) - Mm) / \
              (1 - em * math.cos(math.radians(Emm)))
    xv = a * (math.cos(math.radians(Emm)) - em)
    yv = a * math.sqrt(1 - em * em) * math.sin(math.radians(Emm))
    vm = math.degrees(math.atan2(yv, xv))
    rm = math.hypot(xv, yv)
    xh = rm * (math.cos(math.radians(N)) * math.cos(math.radians(vm + wm)) -
               math.sin(math.radians(N)) * math.sin(math.radians(vm + wm)) * math.cos(math.radians(i)))
    yh = rm * (math.sin(math.radians(N)) * math.cos(math.radians(vm + wm)) +
               math.cos(math.radians(N)) * math.sin(math.radians(vm + wm)) * math.cos(math.radians(i)))
    zh = rm * math.sin(math.radians(vm + wm)) * math.sin(math.radians(i))
    moon_lon = math.degrees(math.atan2(yh, xh)) % 360
    moon_lat = math.degrees(math.atan2(zh, math.hypot(xh, yh)))

    # perturbations principales (Schlyter) : évection, variation, équation annuelle...
    Ls = (w + M) % 360
    Lm = (N + wm + Mm) % 360
    D = (Lm - Ls) % 360
    F = (Lm - N) % 360
    sr = lambda x: math.sin(math.radians(x))
    moon_lon += (-1.274 * sr(Mm - 2 * D) + 0.658 * sr(2 * D) - 0.186 * sr(M)
                 - 0.059 * sr(2 * Mm - 2 * D) - 0.057 * sr(Mm - 2 * D + M)
                 + 0.053 * sr(Mm + 2 * D) + 0.046 * sr(2 * D - M)
                 + 0.041 * sr(Mm - M) - 0.035 * sr(D) - 0.031 * sr(Mm + M)
                 - 0.015 * sr(2 * F - 2 * D) + 0.011 * sr(Mm - 4 * D))
    moon_lat += (-0.173 * sr(F - 2 * D) - 0.055 * sr(Mm - F - 2 * D)
                 - 0.046 * sr(Mm + F - 2 * D) + 0.033 * sr(F + 2 * D)
                 + 0.017 * sr(2 * Mm + F))
    moon_lon %= 360
    return sun_lon, moon_lon, moon_lat, rm

def _moon_phase(dt):
    jd = _jd(dt)
    sun_lon, moon_lon, _, _ = _sun_moon_ecl(jd)
    elong = (moon_lon - sun_lon) % 360           # 0 = nouvelle lune, 180 = pleine
    illum = (1 - math.cos(math.radians(elong))) / 2
    age = elong / 360.0 * SYNODIC
    names = [(1.5, "Nouvelle lune", "🌑"), (5.8, "Premier croissant", "🌒"),
             (9.7, "Premier quartier", "🌓"), (13.8, "Lune gibbeuse croissante", "🌔"),
             (16.0, "Pleine lune", "🌕"), (20.0, "Lune gibbeuse décroissante", "🌖"),
             (23.9, "Dernier quartier", "🌗"), (27.9, "Dernier croissant", "🌘"),
             (29.6, "Nouvelle lune", "🌑")]
    name, icon = next((n, i) for lim, n, i in names if age < lim)
    return {"elong": elong, "illumination": round(illum * 100, 1),
            "age": round(age, 1), "name": name, "icon": icon,
            "waxing": elong < 180}

_SIGNS = [
    ("Bélier", "Feu", "fruit"), ("Taureau", "Terre", "racine"),
    ("Gémeaux", "Air", "fleur"), ("Cancer", "Eau", "feuille"),
    ("Lion", "Feu", "fruit"), ("Vierge", "Terre", "racine"),
    ("Balance", "Air", "fleur"), ("Scorpion", "Eau", "feuille"),
    ("Sagittaire", "Feu", "fruit"), ("Capricorne", "Terre", "racine"),
    ("Verseau", "Air", "fleur"), ("Poissons", "Eau", "feuille"),
]

_JOUR = {
    "racine": {"icon": "🥕", "label": "Jour racine",
               "conseil": "Carottes, radis, pommes de terre, betteraves, oignons"},
    "feuille": {"icon": "🥬", "label": "Jour feuille",
                "conseil": "Salades, épinards, choux, poireaux, herbes aromatiques"},
    "fleur": {"icon": "🌸", "label": "Jour fleur",
              "conseil": "Fleurs, brocolis, choux-fleurs, artichauts"},
    "fruit": {"icon": "🍅", "label": "Jour fruit",
              "conseil": "Tomates, courgettes, haricots, fraises, arbres fruitiers"},
}

def _moon_dec(jd):
    """Déclinaison de la Lune (deg) — sert à distinguer montante / descendante."""
    _, mlon, mlat, _ = _sun_moon_ecl(jd)
    ecl = math.radians(23.4393 - 3.563e-7 * (jd - 2451545.0))
    lam, beta = math.radians(mlon), math.radians(mlat)
    return math.degrees(math.asin(math.sin(beta) * math.cos(ecl) +
                                  math.cos(beta) * math.sin(ecl) * math.sin(lam)))

def _garden_day(dt):
    """Jour lunaire du jardinier : signe, élément, type de jour, montante/descendante."""
    jd = _jd(dt)
    _, mlon, _, _ = _sun_moon_ecl(jd)
    idx = int(mlon // 30) % 12
    name, elem, kind = _SIGNS[idx]
    d0 = _moon_dec(jd - 0.5)
    d1 = _moon_dec(jd + 0.5)
    rising = d1 > d0                    # déclinaison qui monte = lune montante
    ph = _moon_phase(dt)
    return {"date": dt.astimezone().date().isoformat(),
            "sign": name, "element": elem, "kind": kind,
            "icon": _JOUR[kind]["icon"], "label": _JOUR[kind]["label"],
            "conseil": _JOUR[kind]["conseil"],
            "rising": rising,
            "moon_icon": ph["icon"], "phase": ph["name"],
            "illumination": ph["illumination"], "waxing": ph["waxing"]}

_CULTURES = {
    1: {"semis_abri": ["Poireau", "Oignon", "Aubergine", "Piment"],
        "semis_terre": [], "plantation": ["Ail", "Échalote"],
        "recolte": ["Poireau", "Mâche", "Chou de Bruxelles", "Panais"]},
    2: {"semis_abri": ["Tomate", "Poivron", "Céleri", "Laitue"],
        "semis_terre": ["Fève", "Pois"], "plantation": ["Ail", "Oignon"],
        "recolte": ["Poireau", "Épinard", "Topinambour"]},
    3: {"semis_abri": ["Tomate", "Courgette", "Basilic"],
        "semis_terre": ["Carotte", "Radis", "Épinard", "Pois"],
        "plantation": ["Pomme de terre", "Échalote"],
        "recolte": ["Épinard", "Radis", "Poireau"]},
    4: {"semis_abri": ["Concombre", "Melon", "Courge"],
        "semis_terre": ["Betterave", "Carotte", "Haricot", "Laitue"],
        "plantation": ["Pomme de terre", "Artichaut"],
        "recolte": ["Radis", "Asperge", "Épinard", "Salade"]},
    5: {"semis_abri": [],
        "semis_terre": ["Haricot", "Courgette", "Concombre", "Betterave", "Maïs"],
        "plantation": ["Tomate", "Poivron", "Aubergine", "Courgette"],
        "recolte": ["Asperge", "Radis", "Fraise", "Salade"]},
    6: {"semis_abri": [],
        "semis_terre": ["Haricot", "Carotte", "Chicorée", "Poireau d'hiver"],
        "plantation": ["Poireau", "Céleri", "Chou"],
        "recolte": ["Fraise", "Petits pois", "Courgette", "Salade"]},
    7: {"semis_abri": [],
        "semis_terre": ["Haricot", "Radis", "Mâche", "Épinard", "Chicorée"],
        "plantation": ["Poireau", "Chou", "Fraisier"],
        "recolte": ["Tomate", "Courgette", "Haricot", "Framboise", "Pomme de terre"]},
    8: {"semis_abri": [],
        "semis_terre": ["Mâche", "Épinard", "Radis", "Navet", "Laitue d'hiver"],
        "plantation": ["Fraisier", "Chou"],
        "recolte": ["Tomate", "Aubergine", "Haricot", "Melon", "Oignon"]},
    9: {"semis_abri": [], "semis_terre": ["Mâche", "Épinard", "Oignon blanc"],
        "plantation": ["Fraisier", "Ail"],
        "recolte": ["Courge", "Pomme", "Haricot", "Betterave", "Poireau"]},
    10: {"semis_abri": [], "semis_terre": ["Fève", "Pois", "Mâche"],
         "plantation": ["Ail", "Échalote", "Arbres fruitiers"],
         "recolte": ["Courge", "Pomme", "Poire", "Panais", "Chou"]},
    11: {"semis_abri": [], "semis_terre": ["Fève"],
         "plantation": ["Ail", "Arbres fruitiers", "Petits fruits"],
         "recolte": ["Poireau", "Mâche", "Chou", "Topinambour"]},
    12: {"semis_abri": [], "semis_terre": [],
         "plantation": ["Arbres fruitiers (hors gel)"],
         "recolte": ["Poireau", "Mâche", "Chou de Bruxelles", "Endive"]},
}

# ---------------------------------------------------------------------------
# Contrat SDK
# ---------------------------------------------------------------------------

def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("jardin", __name__)

    @bp.route("/lunar")
    def lunar():
        try:
            n = max(1, min(31, int(request.args.get("days", 7))))
        except ValueError:
            n = 7
        base = datetime.now(timezone.utc).replace(hour=12, minute=0,
                                                  second=0, microsecond=0)
        return jsonify({"ok": True,
                        "days": [_garden_day(base + timedelta(days=i))
                                 for i in range(n)]})

    @bp.route("/calendar")
    def calendar():
        try:
            m = int(request.args.get("month", datetime.now().month))
            m = m if 1 <= m <= 12 else datetime.now().month
        except ValueError:
            m = datetime.now().month
        MOIS = ["", "janvier", "février", "mars", "avril", "mai", "juin",
                "juillet", "août", "septembre", "octobre", "novembre",
                "décembre"]
        return jsonify({"ok": True, "month": m, "month_name": MOIS[m],
                        **_CULTURES[m]})

    return bp


def test(sdk, cfg):
    g = _garden_day(datetime.now(timezone.utc))
    return True, (f"Calcul local ✓ — {g['icon']} {g['label']} "
                  f"(Lune en {g['sign']}, "
                  f"{'montante' if g['rising'] else 'descendante'})")
