"""Addon « congelateur » — consommateur de KitchenOwl (lot G-b).

Coquille sans logique KitchenOwl : délègue au fournisseur « kitchenowl »
(déclaré dans requires) via sdk.use("kitchenowl"). Vue congélateur : filtre passé depuis SA propre config (champ category).
"""


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("congelateur", __name__)

    def _ko():
        return sdk.use("kitchenowl")

    def _guard(fn):
        try:
            return jsonify(fn(_ko()))
        except LookupError:
            return jsonify({"ok": False, "reason": "hub KitchenOwl indisponible"})
        except Exception as e:
            sdk.log.exception("congelateur")
            return jsonify({"ok": False, "reason": f"{{type(e).__name__}}: {{e}}"[:120]})

    @bp.route("/view")
    def view():
        return _guard(lambda ko: ko.view("congelateur",
                                         category=sdk.config().get("category")))

    @bp.route("/item/add", methods=["POST"])
    def item_add():
        j = request.get_json(force=True, silent=True) or {}
        name = (j.get("name") or "").strip()[:80]
        if not name:
            return jsonify({"ok": False, "reason": "nom vide"}), 400
        return _guard(lambda ko: ko.item_add(name, j.get("category_id")))

    @bp.route("/item/category", methods=["POST"])
    def item_category():
        j = request.get_json(force=True, silent=True) or {}
        iid = j.get("item_id")
        if not iid:
            return jsonify({"ok": False, "reason": "article manquant"}), 400
        return _guard(lambda ko: ko.item_category(iid, j.get("category_id")))

    @bp.route("/item/delete", methods=["POST"])
    def item_delete():
        j = request.get_json(force=True, silent=True) or {}
        iid = j.get("item_id")
        if not iid:
            return jsonify({"ok": False, "reason": "article manquant"}), 400
        return _guard(lambda ko: ko.item_delete(iid))

    @bp.route("/category/add", methods=["POST"])
    def category_add():
        j = request.get_json(force=True, silent=True) or {}
        name = (j.get("name") or "").strip()[:40]
        if not name:
            return jsonify({"ok": False, "reason": "nom vide"}), 400
        return _guard(lambda ko: ko.category_add(name))

    return bp


def test(sdk, cfg):
    """Bouton « Tester » : vérifie la connexion via le hub KitchenOwl."""
    try:
        hh = sdk.use("kitchenowl").household()
        return True, f"KitchenOwl \u2713 \u2014 maison \u00ab {hh.get('name')} \u00bb"
    except LookupError:
        return False, "hub KitchenOwl indisponible"
    except Exception as e:
        return False, f"KitchenOwl \u2717 ({e})"
