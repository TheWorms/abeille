"""Addon « sonarr » — statut & activité Sonarr (API v3).

    register(sdk) -> flask.Blueprint   (routes sous /addons/sonarr/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:8989) + apikey (Settings → General → API Key).
Auth par en-tête X-Api-Key. Tous les appels sont défensifs : une section
absente est simplement omise, jamais d'erreur bloquante.
"""


def _cfg(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _get(sdk, url, key, path, params=None, timeout=8):
    try:
        r = sdk.requests.get(url + "/api/v3" + path,
                             headers={"X-Api-Key": key},
                             params=params, timeout=timeout)
        if r.status_code == 401:
            return {"__err": "clé API refusée (401)"}
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _data(sdk, cfg):
    url, key = _cfg(cfg)
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    status = _get(sdk, url, key, "/system/status")
    if isinstance(status, dict) and status.get("__err"):
        return {"ok": False, "reason": status["__err"]}
    if not status:
        return {"ok": False, "reason": "Sonarr injoignable"}

    out = {"ok": True, "version": status.get("version"),
           "name": status.get("instanceName") or "Sonarr"}

    # File d'attente (téléchargements en cours)
    q = _get(sdk, url, key, "/queue",
             params={"pageSize": 50, "includeSeries": "true"})
    records = (q or {}).get("records") or []
    queue = []
    for it in records:
        size = it.get("size") or 0
        left = it.get("sizeleft") or 0
        pct = round((1 - left / size) * 100, 1) if size else 0
        ser = it.get("series") or {}
        queue.append({
            "title": ser.get("title") or it.get("title") or "?",
            "episode": _ep_label(it),
            "status": it.get("status"),
            "percent": pct,
            "size": _fmt_bytes(size),
            "timeleft": it.get("timeleft"),
            "protocol": it.get("protocol"),
        })
    out["queue"] = queue
    out["queue_count"] = (q or {}).get("totalRecords", len(queue))

    # Calendrier : prochains épisodes (14 jours)
    import datetime
    today = datetime.date.today()
    end = today + datetime.timedelta(days=14)
    cal = _get(sdk, url, key, "/calendar",
               params={"start": today.isoformat(), "end": end.isoformat(),
                       "includeSeries": "true"})
    upcoming = []
    for it in (cal or [])[:20]:
        ser = it.get("series") or {}
        upcoming.append({
            "title": ser.get("title") or "?",
            "episode": _ep_label(it),
            "ep_title": it.get("title"),
            "airdate": it.get("airDateUtc") or it.get("airDate"),
            "has_file": it.get("hasFile", False),
        })
    out["upcoming"] = upcoming

    # Manquants (wanted/missing)
    miss = _get(sdk, url, key, "/wanted/missing",
                params={"pageSize": 1})
    out["missing_count"] = (miss or {}).get("totalRecords", 0)

    # Séries suivies + stats
    series = _get(sdk, url, key, "/series")
    if isinstance(series, list):
        out["series_count"] = len(series)
        out["series_monitored"] = sum(1 for s in series if s.get("monitored"))
        ep_total = ep_have = 0
        for s in series:
            st = s.get("statistics") or {}
            ep_total += st.get("episodeCount") or 0
            ep_have += st.get("episodeFileCount") or 0
        out["episodes_total"] = ep_total
        out["episodes_have"] = ep_have

    # Espace disque
    disks = _get(sdk, url, key, "/diskspace")
    if isinstance(disks, list) and disks:
        out["disks"] = [{"path": d.get("path"),
                         "free": _fmt_bytes(d.get("freeSpace")),
                         "total": _fmt_bytes(d.get("totalSpace")),
                         "free_pct": round((d.get("freeSpace") or 0) /
                                           (d.get("totalSpace") or 1) * 100)}
                        for d in disks[:4]]

    # Santé
    health = _get(sdk, url, key, "/health")
    if isinstance(health, list):
        out["health"] = [{"type": h.get("type"), "message": h.get("message")}
                         for h in health[:6]]

    # Historique récent (derniers grabs/imports)
    hist = _get(sdk, url, key, "/history",
                params={"pageSize": 8, "sortKey": "date", "sortDirection": "descending"})
    hrecords = (hist or {}).get("records") or []
    out["history"] = [{"title": (h.get("series") or {}).get("title") or h.get("sourceTitle") or "?",
                       "event": h.get("eventType"),
                       "date": h.get("date")} for h in hrecords[:8]]

    return out


def _ep_label(it):
    s = it.get("seasonNumber")
    e = it.get("episodeNumber")
    ep = it.get("episode") or {}
    if s is None:
        s = ep.get("seasonNumber")
    if e is None:
        e = ep.get("episodeNumber")
    if s is not None and e is not None:
        return f"S{int(s):02d}E{int(e):02d}"
    return ""


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("sonarr", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("sonarr")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _data(sdk, cfg)
    if d.get("ok"):
        return True, (f"Sonarr ✓ — v{d.get('version', '?')}, "
                      f"{d.get('series_count', 0)} série(s), "
                      f"{d.get('queue_count', 0)} en file")
    return False, f"Sonarr ✗ ({d.get('reason')})"
