/* Sonarr — statut & activité (API v3). Pleine page, sections riches. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.sonarr = (function () {
  let S = null, root = null, tile = null, data = null;
  const ACCENT = "#35c5f0";  // bleu Sonarr
  const CSS =
    "  .arwrap{flex:1;display:flex;flex-direction:column;min-height:0;--ar:" + ACCENT + "}\n" +
    "  .arscroll{flex:1;min-height:0;overflow:auto;padding:14px 22px}\n" +
    "  .arhead{display:flex;align-items:center;gap:12px;margin-bottom:14px}\n" +
    "  .arname{font-size:18px;font-weight:700;cursor:pointer}\n" +
    "  .arname .go{font-size:12px;color:var(--dim)}\n" +
    "  .arver{font-size:11px;color:var(--dim)}\n" +
    "  .arkpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:16px}\n" +
    "  .arkpi{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px 15px;text-align:center}\n" +
    "  .arkpi b{display:block;font-size:22px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--ar)}\n" +
    "  .arkpi span{font-size:11px;color:var(--dim);display:block;margin-top:3px}\n" +
    "  .arsec{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .arsec .cnt{background:var(--bg);border:1px solid var(--border-soft);border-radius:10px;padding:1px 8px;font-size:11px;color:var(--text)}\n" +
    "  .arq{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 14px;margin-bottom:8px}\n" +
    "  .arqtop{display:flex;align-items:center;gap:10px;font-size:13.5px}\n" +
    "  .arqtitle{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .arqep{font-family:var(--mono);font-size:12px;color:var(--ar);flex:none}\n" +
    "  .arqmeta{margin-left:auto;font-size:11px;color:var(--dim);flex:none}\n" +
    "  .arqbar{height:6px;border-radius:3px;background:var(--bg);overflow:hidden;margin-top:7px}\n" +
    "  .arqbar>i{display:block;height:100%;background:var(--ar)}\n" +
    "  .arrow{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border-soft);font-size:13px}\n" +
    "  .arrow:last-child{border-bottom:0}\n" +
    "  .arrt{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .arrep{font-family:var(--mono);font-size:11.5px;color:var(--ar);flex:none}\n" +
    "  .arrmeta{margin-left:auto;font-size:11.5px;color:var(--dim);flex:none}\n" +
    "  .arrmeta.ok{color:var(--green)}\n" +
    "  .ardisks{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}\n" +
    "  .ardisk{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 14px}\n" +
    "  .ardisk .dp{font-family:var(--mono);font-size:11.5px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ardisk .df{font-size:14px;font-weight:600;margin-top:3px}\n" +
    "  .ardbar{height:6px;border-radius:3px;background:var(--bg);overflow:hidden;margin-top:7px}\n" +
    "  .ardbar>i{display:block;height:100%;background:var(--ar)}\n" +
    "  .arhealth{background:rgba(240,173,78,.1);border:1px solid rgba(240,173,78,.3);border-radius:10px;padding:9px 13px;margin-bottom:7px;font-size:12.5px;color:var(--warn)}\n" +
    "  .arempty{color:var(--dim);font-size:12.5px;padding:6px 0}";
  function ensureCss() { if (document.getElementById('arSonCss')) return; const s = document.createElement('style'); s.id = 'arSonCss'; s.textContent = CSS; document.head.appendChild(s); }
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);

  function relTime(iso) {
    if (!iso) return '';
    const d = new Date(iso), now = new Date();
    if (isNaN(d)) return '';
    const diff = (d - now) / 3600000;
    if (diff >= 0 && diff < 24) return "aujourd'hui " + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    if (diff >= 24 && diff < 48) return 'demain';
    if (diff < 0 && diff > -24) return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Interrogation de Sonarr…</div></div>';
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📺</div><div class="t1">Sonarr indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Settings → General → API Key).</div>' +
        '<button class="btnpill install" id="arRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('arRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="arwrap"><div class="arscroll">';
    h += '<div class="arhead"><span style="font-size:26px">📺</span><div>' +
      '<div class="arname" data-open>' + esc(d.name) + ' <span class="go">↗</span></div>' +
      (d.version ? '<div class="arver">Sonarr v' + esc(d.version) + '</div>' : '') + '</div></div>';

    // KPIs
    h += '<div class="arkpis">' +
      kpi(d.series_count, 'séries') +
      kpi(d.series_monitored, 'surveillées') +
      kpi(d.episodes_have != null ? d.episodes_have + '/' + d.episodes_total : null, 'épisodes') +
      kpi(d.queue_count, 'en file') +
      kpi(d.missing_count, 'manquants') +
      '</div>';

    // Santé
    if (d.health && d.health.length)
      h += d.health.map(x => '<div class="arhealth">⚠️ ' + esc(x.message) + '</div>').join('');

    // File d'attente
    h += '<div class="arsec">Téléchargements' + (d.queue && d.queue.length ? '<span class="cnt">' + d.queue.length + '</span>' : '') + '</div>';
    if (!d.queue || !d.queue.length) h += '<div class="arempty">Aucun téléchargement en cours</div>';
    else h += d.queue.map(q =>
      '<div class="arq"><div class="arqtop"><span class="arqtitle">' + esc(q.title) + '</span>' +
      (q.episode ? '<span class="arqep">' + esc(q.episode) + '</span>' : '') +
      '<span class="arqmeta">' + esc(q.status || '') + (q.timeleft ? ' · ' + esc(q.timeleft) : '') + (q.size ? ' · ' + esc(q.size) : '') + '</span></div>' +
      '<div class="arqbar"><i style="width:' + (q.percent || 0) + '%"></i></div></div>').join('');

    // Calendrier à venir
    h += '<div class="arsec">À venir (14 j)' + (d.upcoming && d.upcoming.length ? '<span class="cnt">' + d.upcoming.length + '</span>' : '') + '</div>';
    if (!d.upcoming || !d.upcoming.length) h += '<div class="arempty">Rien de prévu</div>';
    else h += d.upcoming.map(u =>
      '<div class="arrow"><span class="arrt">' + esc(u.title) + '</span>' +
      (u.episode ? '<span class="arrep">' + esc(u.episode) + '</span>' : '') +
      '<span class="arrmeta' + (u.has_file ? ' ok' : '') + '">' + (u.has_file ? '✓ ' : '') + relTime(u.airdate) + '</span></div>').join('');

    // Historique récent
    if (d.history && d.history.length) {
      h += '<div class="arsec">Activité récente</div>';
      h += d.history.map(x =>
        '<div class="arrow"><span class="arrt">' + esc(x.title) + '</span>' +
        '<span class="arrmeta">' + esc(evLabel(x.event)) + ' · ' + relTime(x.date) + '</span></div>').join('');
    }

    // Disques
    if (d.disks && d.disks.length) {
      h += '<div class="arsec">Espace disque</div><div class="ardisks">' +
        d.disks.map(dk => '<div class="ardisk"><div class="dp">' + esc(dk.path) + '</div>' +
          '<div class="df">' + esc(dk.free || '—') + ' libre / ' + esc(dk.total || '—') + '</div>' +
          '<div class="ardbar"><i style="width:' + (100 - (dk.free_pct || 0)) + '%"></i></div></div>').join('') + '</div>';
    }

    h += '</div></div>';
    el.innerHTML = h;
    const nm = el.querySelector('[data-open]');
    if (nm) nm.addEventListener('click', async () => {
      let cfg = {}; try { cfg = await S.config(); } catch (e) {}
      if (cfg.url) S.openService(cfg.url, d.name || 'Sonarr');
    });
  }
  function kpi(val, label) {
    if (val == null) return '';
    return '<div class="arkpi"><b>' + (typeof val === 'number' ? nf(val) : esc(val)) + '</b><span>' + label + '</span></div>';
  }
  function evLabel(e) {
    return { grabbed: 'récupéré', downloadFolderImported: 'importé', seriesFolderImported: 'importé',
      downloadFailed: 'échec', episodeFileDeleted: 'supprimé', episodeFileRenamed: 'renommé' }[e] || e || '';
  }

  return { render };
})();
