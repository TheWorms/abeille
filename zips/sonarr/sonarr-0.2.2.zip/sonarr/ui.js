/* Sonarr — stats, séries récentes (affiches), épisodes à venir, file, liste/cards, détail. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.sonarr = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  const ACCENT = '#3778dd';
  const CSS =
    "  .snwrap{flex:1;display:flex;flex-direction:column;min-height:0;--sn:" + ACCENT + "}\n" +
    "  .sntopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .sntotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .sntk{text-align:center}\n" +
    "  .sntk b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--sn)}\n" +
    "  .sntk.have b{color:var(--green)}\n" +
    "  .sntk span{font-size:11px;color:var(--dim)}\n" +
    "  .snvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .snvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .snvtoggle button.on{background:var(--tile);color:var(--sn)}\n" +
    "  .snscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .snsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .snsec:first-child{margin-top:0}\n" +
    "  .snsec .c{color:var(--sn)}\n" +
    "  .snposters{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:13px}\n" +
    "  .sncard{cursor:pointer;display:flex;flex-direction:column;gap:5px}\n" +
    "  .snpwrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .sncard:hover .snpwrap{border-color:var(--sn)}\n" +
    "  .snposter{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .snph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:32px;color:var(--dim)}\n" +
    "  .snbadge{position:absolute;top:6px;right:6px;font-size:11px;background:rgba(0,0,0,.72);color:#fff;padding:1px 6px;border-radius:7px;font-weight:600}\n" +
    "  .snctit{font-size:12px;font-weight:600;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    "  .sncsub{font-size:10.5px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .snrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .snrow:hover{border-color:var(--sn)}\n" +
    "  .snrposter{width:34px;height:51px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .snrph{width:34px;height:51px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--dim);flex:none}\n" +
    "  .snrtx{min-width:0;flex:1}\n" +
    "  .snrtit{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .snrmeta{font-size:11.5px;color:var(--dim)}\n" +
    "  .snrstat{font-size:11px;flex:none;text-align:right;font-variant-numeric:tabular-nums}\n" +
    "  .snup{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 13px;margin-bottom:6px}\n" +
    "  .snupdate{font-size:11px;color:var(--sn);font-weight:600;min-width:96px;flex:none}\n" +
    "  .snupep{font-size:11px;color:var(--dim);flex:none}\n" +
    "  .snq{background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:9px 12px;margin-bottom:6px}\n" +
    "  .snqtop{display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px}\n" +
    "  .snqbar{height:5px;border-radius:3px;background:var(--bg);overflow:hidden}\n" +
    "  .snqbar>i{display:block;height:100%;background:var(--sn)}\n" +
    "  .snempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    "  .sndet{position:absolute;inset:0;background:var(--bg);z-index:40;display:flex;flex-direction:column}\n" +
    "  .sndtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .sndback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .sndttl{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .sndbody{flex:1;min-height:0;overflow:auto;padding:16px 18px;display:flex;gap:16px}\n" +
    "  .sndposter{width:110px;aspect-ratio:2/3;border-radius:10px;object-fit:cover;background:var(--tile);flex:none}\n" +
    "  .sndinfo{min-width:0;flex:1}\n" +
    "  .sndmeta{font-size:12.5px;color:var(--dim);margin-bottom:10px}\n" +
    "  .sndchips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}\n" +
    "  .snchip{font-size:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:7px;padding:3px 9px;color:var(--dim)}\n" +
    "  .snchip.ok{color:var(--green);border-color:var(--green)}\n" +
    "  .sndover{font-size:13.5px;line-height:1.55}";
  function ensureCss() { if (document.getElementById('snUiCss')) return; const s = document.createElement('style'); s.id = 'snUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const img = p => p ? '/addons/sonarr/api/image?p=' + encodeURIComponent(p) : '';
  function fdate(iso) { if (!iso) return ''; try { return new Date(iso).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' }); } catch (e) { return iso.slice(0, 10); } }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Sonarr…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function serieCard(s) {
    const poster = s.poster
      ? '<img class="snposter" loading="lazy" src="' + img(s.poster) + '" data-ph="snph">'
      : '<div class="snph">📺</div>';
    const done = (s.ep_total && s.ep_have >= s.ep_total);
    return '<div class="sncard" data-id="' + esc(s.id) + '">' +
      '<div class="snpwrap">' + poster +
      (s.ep_total ? '<span class="snbadge">' + s.ep_have + '/' + s.ep_total + '</span>' : '') + '</div>' +
      '<div class="snctit">' + esc(s.title) + '</div>' +
      '<div class="sncsub">' + (s.year || '') + (s.seasons ? ' · ' + s.seasons + ' sais.' : '') + '</div></div>';
  }
  function serieRow(s) {
    const poster = s.poster
      ? '<img class="snrposter" loading="lazy" src="' + img(s.poster) + '" data-ph="snrph">'
      : '<div class="snrph">📺</div>';
    const pct = s.ep_total ? Math.round((s.ep_have || 0) / s.ep_total * 100) : 0;
    return '<div class="snrow" data-id="' + esc(s.id) + '">' + poster +
      '<div class="snrtx"><div class="snrtit">' + esc(s.title) + '</div>' +
      '<div class="snrmeta">' + (s.year || '') + (s.network ? ' · ' + esc(s.network) : '') + (s.status ? ' · ' + esc(s.status) : '') + '</div></div>' +
      '<span class="snrstat">' + (s.ep_have || 0) + '/' + (s.ep_total || 0) + '<br><span style="color:' + (pct >= 100 ? 'var(--green)' : 'var(--dim)') + '">' + pct + '%</span></span></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📺</div><div class="t1">Sonarr indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Settings → General).</div>' +
        '<button class="btnpill install" id="snRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('snRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="snwrap"><div class="sntopbar"><div class="sntotals">' +
      '<div class="sntk"><b>' + nf(d.series_count) + '</b><span>séries</span></div>' +
      '<div class="sntk have"><b>' + nf(d.episodes_have) + '</b><span>épisodes</span></div>' +
      '<div class="sntk"><b>' + nf(d.episodes_total) + '</b><span>attendus</span></div>' +
      '<div class="sntk"><b>' + nf(d.queue_count) + '</b><span>en file</span></div>' +
      (d.missing_count != null ? '<div class="sntk"><b>' + nf(d.missing_count) + '</b><span>manquants</span></div>' : '') +
      '</div><div class="snvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div><div class="snscroll">';

    if (d.queue && d.queue.length) {
      h += '<div class="snsec">⬇️ En téléchargement <span class="c">' + nf(d.queue_count) + '</span></div>';
      h += d.queue.slice(0, 6).map(q => '<div class="snq"><div class="snqtop"><span>' + esc(q.title || q.series || '?') + (q.episode ? ' · ' + esc(q.episode) : '') + '</span>' +
        '<span style="color:var(--dim)">' + (q.percent || 0) + '% · ' + (q.timeleft || '—') + '</span></div>' +
        '<div class="snqbar"><i style="width:' + (q.percent || 0) + '%"></i></div></div>').join('');
    }
    if (d.upcoming && d.upcoming.length) {
      h += '<div class="snsec">📅 Épisodes à venir</div>';
      h += d.upcoming.slice(0, 10).map(u => '<div class="snup"><span class="snupdate">' + fdate(u.airdate) + '</span>' +
        '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(u.title || u.series || '?') + '</span>' +
        (u.episode ? '<span class="snupep">' + esc(u.episode) + '</span>' : '') + '</div>').join('');
    }
    h += '<div class="snsec">🆕 Séries récemment ajoutées</div>';
    if (!d.recent || !d.recent.length) h += '<div class="snempty">Aucune série récente.</div>';
    else if (viewMode === 'cards') h += '<div class="snposters">' + d.recent.map(serieCard).join('') + '</div>';
    else h += d.recent.map(serieRow).join('');

    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.snvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openDetail(n.getAttribute('data-id'))));
    wirePosters(el);
  }

  function wirePosters(scope) {
    (scope || document).querySelectorAll('img[data-ph]').forEach(im => {
      im.addEventListener('error', function () {
        const cls = this.getAttribute('data-ph') || 'snph';
        const dv = document.createElement('div');
        dv.className = cls; dv.textContent = '📺';
        if (this.parentNode) this.parentNode.replaceChild(dv, this);
      }, { once: true });
    });
  }

  async function openDetail(id) {
    const det = document.createElement('div');
    det.className = 'sndet';
    det.innerHTML = '<div class="sndtop"><button class="sndback">‹ Retour</button><span class="sndttl">Série</span></div>' +
      '<div class="sndbody"><div class="snempty">Chargement…</div></div>';
    root.style.position = 'relative';
    root.appendChild(det);
    det.querySelector('.sndback').addEventListener('click', () => det.remove());
    let d = null;
    try { const r = await S.api('/detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false }; }
    if (!d || !d.ok) { det.querySelector('.sndbody').innerHTML = '<div class="snempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    const s = d.series;
    det.querySelector('.sndttl').textContent = s.title + (s.year ? ' (' + s.year + ')' : '');
    const phHtml = '<div class="sndposter" style="display:flex;align-items:center;justify-content:center;font-size:40px;color:var(--dim)">📺</div>';
    const pct = s.ep_total ? Math.round((s.ep_have || 0) / s.ep_total * 100) : 0;
    det.querySelector('.sndbody').innerHTML =
      (s.poster ? '<img class="sndposter" src="' + img(s.poster) + '" data-ph="det">' : phHtml) +
      '<div class="sndinfo">' +
      '<div class="sndmeta">' + [s.year, s.network, s.runtime ? s.runtime + ' min' : '', s.rating ? '★ ' + s.rating : ''].filter(Boolean).join(' · ') + '</div>' +
      '<div class="sndchips">' +
      '<span class="snchip ' + (pct >= 100 ? 'ok' : '') + '">' + (s.ep_have || 0) + '/' + (s.ep_total || 0) + ' épisodes · ' + pct + '%</span>' +
      (s.seasons ? '<span class="snchip">' + s.seasons + ' saison' + (s.seasons > 1 ? 's' : '') + '</span>' : '') +
      (s.monitored ? '<span class="snchip">👁️ Suivi</span>' : '') +
      (s.size ? '<span class="snchip">💾 ' + esc(s.size) + '</span>' : '') +
      (s.status ? '<span class="snchip">' + esc(s.status) + '</span>' : '') +
      (s.genres || []).slice(0, 4).map(g => '<span class="snchip">' + esc(g) + '</span>').join('') +
      '</div>' +
      '<div class="sndover">' + esc(s.overview || 'Pas de résumé.') + '</div></div>';
    const dimg = det.querySelector('img.sndposter[data-ph]');
    if (dimg) dimg.addEventListener('error', function () {
      const dv = document.createElement('div');
      dv.className = 'sndposter';
      dv.style.cssText = 'display:flex;align-items:center;justify-content:center;font-size:40px;color:var(--dim)';
      dv.textContent = '📺';
      if (this.parentNode) this.parentNode.replaceChild(dv, this);
    }, { once: true });
  }

  return { render };
})();
