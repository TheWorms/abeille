/* Soleil & Lune — addon neuf, écrit directement pour le SDK v1 (^1.3).
   Démonstration : aucune ligne dans le socle. Cadran solaire (arc jour/nuit
   avec position courante) + carte lunaire (phase, illumination, échéances).
   ⚙ : saisie lat/lon/tz + bouton de géolocalisation par ville (Open-Meteo). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons["soleil-lune"] = (function () {
  let S = null, root = null, tile = null;

  const CSS = [
    '.slwrap{display:flex;flex-direction:column;gap:14px;max-width:520px;margin:0 auto}',
    '.slcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:16px;padding:18px 20px}',
    '.slsun{position:relative}',
    '.slrow{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}',
    '.sltitle{font-weight:700;font-size:15px;display:flex;gap:8px;align-items:center}',
    '.slnow{font-size:12px;color:var(--faint)}',
    '.slarcbox{position:relative;height:120px;margin:6px 4px 2px}',
    '.slstat{display:flex;justify-content:space-around;margin-top:10px;text-align:center}',
    '.slstat div span{display:block}',
    '.slk{font-size:11px;color:var(--dim)}',
    '.slv{font-size:17px;font-weight:700;margin-top:2px}',
    '.slmoon{display:flex;gap:18px;align-items:center}',
    '.slmface{font-size:58px;line-height:1;flex:none;filter:drop-shadow(0 2px 8px rgba(0,0,0,.35))}',
    '.slmoon .slinfo{flex:1;min-width:0}',
    '.slphase{font-size:16px;font-weight:700}',
    '.slbar{height:8px;border-radius:6px;background:var(--tile-2);overflow:hidden;margin:8px 0 6px}',
    '.slbar > i{display:block;height:100%;background:linear-gradient(90deg,var(--accent-dim),var(--warn))}',
    '.slnext{display:flex;gap:14px;font-size:12px;color:var(--dim);flex-wrap:wrap}',
    '.slnext b{color:var(--text)}'
  ].join('\n');
  function ensureCss() { let st = document.getElementById('slUiCss'); if (!st) { st = document.createElement('style'); st.id = 'slUiCss'; document.head.appendChild(st); } st.textContent = CSS; }

  function toMin(hm) { if (!hm) return null; const p = hm.split(':'); return (+p[0]) * 60 + (+p[1]); }

  function sunArc(d) {
    const rise = toMin(d.sun.rise), set = toMin(d.sun.set), now = toMin(d.now);
    const W = 480, H = 118, pad = 24;
    // arc de cercle : lever à gauche, coucher à droite, midi solaire au sommet
    const arc = (x) => {
      const t = (x - pad) / (W - 2 * pad);          // 0..1
      return H - 10 - Math.sin(Math.PI * t) * (H - 34);
    };
    let path = '';
    for (let i = 0; i <= 60; i++) {
      const x = pad + (W - 2 * pad) * i / 60;
      path += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + arc(x).toFixed(1) + ' ';
    }
    // position du soleil courant
    let dot = '';
    if (rise != null && set != null && now != null && now >= rise && now <= set) {
      const frac = (now - rise) / (set - rise);
      const x = pad + (W - 2 * pad) * frac;
      dot = '<circle cx="' + x.toFixed(1) + '" cy="' + arc(x).toFixed(1) + '" r="8" fill="var(--warn)" stroke="#fff" stroke-width="1.5"/>';
    }
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:100%">' +
      '<line x1="' + pad + '" y1="' + (H - 10) + '" x2="' + (W - pad) + '" y2="' + (H - 10) + '" stroke="var(--border)" stroke-width="1"/>' +
      '<path d="' + path + '" fill="none" stroke="var(--warn)" stroke-width="2" stroke-opacity="0.55" stroke-dasharray="3 3"/>' +
      dot +
      '<text x="' + pad + '" y="' + (H - 14) + '" font-size="11" fill="var(--dim)" text-anchor="start">' + (d.sun.rise || '—') + '</text>' +
      '<text x="' + (W - pad) + '" y="' + (H - 14) + '" font-size="11" fill="var(--dim)" text-anchor="end">' + (d.sun.set || '—') + '</text>' +
      '</svg>';
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile;
    ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Calcul des éphémérides…</div></div>';
    let d = null;
    try { const r = await sdk.api('/summary'); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🌙</div><div class="t1">Soleil & Lune</div>' +
        '<div class="t2">' + sdk.esc(d.reason || '') + '<br>Renseigne latitude et longitude dans le ⚙.</div></div>';
      return;
    }
    const m = d.moon;
    const polar = d.sun.polar;
    el.innerHTML =
      '<div class="slwrap">' +
      '<div class="slcard slsun">' +
      '<div class="slrow"><span class="sltitle">☀️ Soleil</span><span class="slnow">' + d.date + ' · ' + d.now + '</span></div>' +
      (polar
        ? '<div class="t2" style="padding:14px 0;text-align:center">Jour ou nuit polaire — pas de lever/coucher aujourd\'hui à cette latitude.</div>'
        : '<div class="slarcbox">' + sunArc(d) + '</div>' +
          '<div class="slstat">' +
          '<div><span class="slk">Lever</span><span class="slv">' + (d.sun.rise || '—') + '</span></div>' +
          '<div><span class="slk">Durée du jour</span><span class="slv">' + (d.sun.daylength || '—') + '</span></div>' +
          '<div><span class="slk">Coucher</span><span class="slv">' + (d.sun.set || '—') + '</span></div>' +
          '</div>') +
      '</div>' +
      '<div class="slcard"><div class="slrow"><span class="sltitle">🌙 Lune</span>' +
      '<span class="slnow">' + (m.waxing ? 'croissante' : 'décroissante') + '</span></div>' +
      '<div class="slmoon"><div class="slface">' + m.emoji + '</div>' +
      '<div class="slinfo"><div class="slphase">' + m.phase + '</div>' +
      '<div class="slbar"><i style="width:' + m.illumination + '%"></i></div>' +
      '<div class="slk">' + m.illumination + ' % illuminée · ' + m.age_days + ' j dans le cycle</div>' +
      '<div class="slnext"><span>🌑 Nouvelle dans <b>' + m.next_new + ' j</b></span>' +
      '<span>🌕 Pleine dans <b>' + m.next_full + ' j</b></span></div>' +
      '</div></div></div>' +
      '<div class="wsrc">Calcul local (NOAA + âge synodique) · aucune connexion · lat ' +
      d.lat.toFixed(3) + ', lon ' + d.lon.toFixed(3) + ' · addon v1.0.0</div>' +
      '</div>';
  }

  /* ⚙ : géolocalisation par ville (comme l'addon météo, mais autonome) */
  function configPanel(box, sdk) {
    box.innerHTML = '<button class="btnpill" id="slGeo" type="button">📍 Trouver les coordonnées depuis la ville</button>' +
      '<div id="slGeoRes" style="margin-top:8px;font-size:12px"></div>';
    const res = box.querySelector('#slGeoRes');
    const setv = (k, v) => { const el = document.querySelector('#cfgBody [data-k="' + k + '"]');
      if (el && v != null && v !== '') { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); } };
    box.querySelector('#slGeo').addEventListener('click', () => {
      const q = (document.querySelector('#cfgBody [data-k="lat"]') || {}).value || '';
      const ville = prompt('Nom de la ville ?');
      if (!ville) return;
      res.textContent = 'recherche…';
      fetch('https://geocoding-api.open-meteo.com/v1/search?count=1&language=fr&name=' + encodeURIComponent(ville))
        .then(r => r.json())
        .then(j => {
          const c = (j.results || [])[0];
          if (!c) { res.innerHTML = '<span style="color:var(--bad)">ville introuvable</span>'; return; }
          setv('lat', c.latitude); setv('lon', c.longitude);
          res.innerHTML = '<span style="color:var(--green)">✓ ' + c.name + ' — ' +
            c.latitude.toFixed(4) + ', ' + c.longitude.toFixed(4) + '. Pense à <b>enregistrer</b>.</span>';
        })
        .catch(() => { res.innerHTML = '<span style="color:var(--bad)">serveur injoignable</span>'; });
    });
  }

  return { render, configPanel };
})();
