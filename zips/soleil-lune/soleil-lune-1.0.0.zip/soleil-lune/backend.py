"""Addon « soleil-lune » — éphémérides locales, sans dépendance externe.

Calcule le lever/coucher du soleil (algorithme NOAA), la durée du jour, et
la phase de la lune (âge synodique + illumination) pour la position
configurée. Aucune bibliothèque astro n'étant présente sur Panda, tout est
calculé en Python pur. Précision : quelques minutes sur le soleil, ~1 % sur
l'illumination lunaire — largement suffisant pour un cadran de kiosque.

Config (⚙) : lat, lon (degrés décimaux), tz (décalage horaire en heures,
défaut 2 = heure d'été française). Réutilise le geoPicker du socle via les
champs lat/lon comme l'addon météo.
"""
import math
import time
from datetime import datetime, timedelta, timezone

_PHASES = [
    ("Nouvelle lune", "\U0001F311"),
    ("Premier croissant", "\U0001F312"),
    ("Premier quartier", "\U0001F313"),
    ("Gibbeuse croissante", "\U0001F314"),
    ("Pleine lune", "\U0001F315"),
    ("Gibbeuse décroissante", "\U0001F316"),
    ("Dernier quartier", "\U0001F317"),
    ("Dernier croissant", "\U0001F318"),
]
_SYNODIC = 29.53058867
# Nouvelle lune de référence : 2000-01-06 18:14 UTC (JD 2451550.1)
_NEW_MOON_REF = 2451550.1


def _julian(dt):
    """Jour julien d'un datetime UTC."""
    ts = dt.replace(tzinfo=timezone.utc).timestamp()
    return ts / 86400.0 + 2440587.5


def _moon(now_utc):
    jd = _julian(now_utc)
    age = (jd - _NEW_MOON_REF) % _SYNODIC
    if age < 0:
        age += _SYNODIC
    frac = age / _SYNODIC                       # 0 … 1 dans le cycle
    # illumination : 0 à la nouvelle lune, 1 à la pleine
    illum = (1 - math.cos(2 * math.pi * frac)) / 2
    idx = int((frac * 8) + 0.5) % 8
    name, emoji = _PHASES[idx]
    waxing = frac < 0.5
    return {
        "age_days": round(age, 1),
        "illumination": round(illum * 100),
        "phase": name,
        "emoji": emoji,
        "waxing": waxing,
        "next_new": round(_SYNODIC - age, 1),
        "next_full": round((_SYNODIC / 2 - age) % _SYNODIC, 1),
    }


def _sun_event(date, lat, lon, tz, rising):
    """Heure locale (h décimales) du lever (rising=True) ou coucher, algo NOAA.

    Retourne None en cas de nuit/jour polaire (pas d'événement ce jour-là).
    """
    N = date.timetuple().tm_yday
    lng_hour = lon / 15.0
    t = N + ((6 if rising else 18) - lng_hour) / 24.0
    M = (0.9856 * t) - 3.289
    L = M + (1.916 * math.sin(math.radians(M))) + \
        (0.020 * math.sin(math.radians(2 * M))) + 282.634
    L %= 360
    RA = math.degrees(math.atan(0.91764 * math.tan(math.radians(L)))) % 360
    RA += (math.floor(L / 90) * 90) - (math.floor(RA / 90) * 90)
    RA /= 15.0
    sin_dec = 0.39782 * math.sin(math.radians(L))
    cos_dec = math.cos(math.asin(sin_dec))
    zenith = 90.833                              # centre du disque + réfraction
    cos_H = (math.cos(math.radians(zenith)) - (sin_dec * math.sin(math.radians(lat)))) / \
            (cos_dec * math.cos(math.radians(lat)))
    if cos_H > 1 or cos_H < -1:
        return None
    H = (360 - math.degrees(math.acos(cos_H))) if rising else math.degrees(math.acos(cos_H))
    H /= 15.0
    T = H + RA - (0.06571 * t) - 6.622
    UT = (T - lng_hour) % 24
    return (UT + tz) % 24


def _hm(h):
    if h is None:
        return None
    total = int(round(h * 60))
    return f"{(total // 60) % 24:02d}:{total % 60:02d}"


def _summary(cfg):
    try:
        lat = float(cfg.get("lat") or 48.8566)
        lon = float(cfg.get("lon") or 2.3522)
        tz = float(cfg.get("tz") if cfg.get("tz") not in (None, "") else 2)
    except (TypeError, ValueError):
        return {"ok": False, "reason": "coordonnées invalides — vérifie le ⚙"}
    now = datetime.now(timezone.utc)
    local = now + timedelta(hours=tz)
    rise = _sun_event(local.date(), lat, lon, tz, True)
    sett = _sun_event(local.date(), lat, lon, tz, False)
    daylen = None
    if rise is not None and sett is not None:
        d = (sett - rise) % 24
        daylen = f"{int(d)} h {int(round((d % 1) * 60)):02d}"
    moon = _moon(now)
    return {
        "ok": True,
        "date": local.strftime("%Y-%m-%d"),
        "now": local.strftime("%H:%M"),
        "lat": lat, "lon": lon, "tz": tz,
        "sun": {
            "rise": _hm(rise),
            "set": _hm(sett),
            "daylength": daylen,
            "polar": rise is None or sett is None,
        },
        "moon": moon,
    }


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("soleil_lune", __name__)

    @bp.route("/summary")
    def summary():
        # cache 5 min : la position change rarement, la lune bouge lentement
        hit = sdk.cache_get("sl:summary", 300)
        if hit is not None:
            return jsonify(hit)
        out = _summary(sdk.config())
        if out.get("ok"):
            sdk.cache_set("sl:summary", out)
        return jsonify(out)

    return bp


def test(sdk, cfg):
    out = _summary(cfg)
    if out.get("ok"):
        s = out["sun"]
        return True, (f"OK — lever {s['rise'] or '—'}, coucher {s['set'] or '—'}, "
                      f"lune {out['moon']['illumination']} %")
    return False, out.get("reason", "échec du calcul")
