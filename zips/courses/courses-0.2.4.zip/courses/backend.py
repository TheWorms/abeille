"""Addon « courses » — consommateur de KitchenOwl (lot G-a).

Ne contient AUCUNE logique KitchenOwl : il délègue tout au fournisseur
``kitchenowl`` (déclaré dans ``requires``) via ``sdk.use("kitchenowl")``. Les
routes ne sont que de fines coquilles : parse la requête → appelle la méthode
du hub → renvoie son résultat. La connexion (url/token/household) et le cache
vivent dans kitchenowl, jamais ici (bac à sable).
"""


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("courses", __name__)

    def _ko():
        return sdk.use("kitchenowl")

    def _guard(fn):
        try:
            return jsonify(fn(_ko()))
        except LookupError:
            return jsonify({"ok": False, "reason": "hub KitchenOwl indisponible"})
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("courses")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/view")
    def view():
        return _guard(lambda ko: ko.view("courses"))

    @bp.route("/courses/add", methods=["POST"])
    def add():
        j = request.get_json(force=True, silent=True) or {}
        name = (j.get("name") or "").strip()[:80]
        if not name:
            return jsonify({"ok": False, "reason": "nom vide"}), 400
        return _guard(lambda ko: ko.courses_add(name, j.get("list_id")))

    @bp.route("/courses/remove", methods=["POST"])
    def remove():
        j = request.get_json(force=True, silent=True) or {}
        item_id = j.get("item_id")
        if not item_id:
            return jsonify({"ok": False, "reason": "article manquant"}), 400
        return _guard(lambda ko: ko.courses_remove(item_id, j.get("list_id")))

    return bp
