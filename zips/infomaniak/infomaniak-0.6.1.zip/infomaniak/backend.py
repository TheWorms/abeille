"""Addon Infomaniak — multi-organisations : balaie tous les comptes via /accounts,
puis /products?account_id=X par orga. Agrège domaines, mail, cloud/VPS, hosting."""
import time

API = "https://api.infomaniak.com"


def _cfg(cfg):
    m = (cfg or {}).get("modules", {}).get("infomaniak", {}) if "modules" in (cfg or {}) else (cfg or {})
    # Un toggle absent OU vrai => section affichée. Seul False explicite masque.
    show = lambda k: m.get(k) is not False and str(m.get(k)).lower() != "false"
    return {
        "token": (m.get("token") or "").strip(),
        "show_domains": show("show_domains"),
        "show_mail": show("show_mail"),
        "show_cloud": show("show_cloud"),
        "show_certs": show("show_certs"),
        "show_other": show("show_other"),
    }


def _get(sdk, token, path, timeout=12):
    r = sdk.requests.get(API + path, timeout=timeout,
                         headers={"Authorization": "Bearer " + token})
    if r.status_code == 401:
        raise PermissionError("token invalide")
    if r.status_code == 403:
        raise PermissionError("scope manquant sur le token")
    r.raise_for_status()
    return r.json()


def _unwrap(d):
    return d.get("data", d) if isinstance(d, dict) else d


_TAG_COLORS = {1: "#e2504a", 2: "#e0892b", 3: "#f0b429", 4: "#63991a",
               5: "#0098ff", 6: "#7a52d4", 7: "#d4537e", 8: "#888780"}

# Regroupement des service_name Infomaniak en familles d affichage
_FAMILY = {
    "domain": "domain",
    "email_hosting": "mail", "mail_hosting": "mail", "mail": "mail",
    "cloud": "cloud", "vps": "cloud", "public_cloud": "cloud",
    "hosting": "hosting", "web_hosting": "hosting",
    "mailing": "other",
}


def _shape(p, org_name):
    exp = p.get("expired_at")
    days = int((exp - time.time()) / 86400) if exp else None
    svc = p.get("service_name")
    return {
        "id": p.get("id"),
        "name": p.get("customer_name") or p.get("internal_name") or "?",
        "internal": p.get("internal_name"),
        "service": svc,
        "family": _FAMILY.get(svc, "other"),
        "org": org_name,
        "org_id": p.get("account_id"),
        "created": p.get("created_at"),
        "expired": exp,
        "days_left": days,
        "locked": bool(p.get("locked") or p.get("is_locked")),
        "maintenance": bool(p.get("maintenance") or p.get("has_maintenance")),
        "operation": bool(p.get("operation_in_progress") or p.get("has_operation_in_progress")),
        "free": bool(p.get("is_free") or p.get("is_zero_price")),
        "trial": bool(p.get("is_trial")),
        "distribution": p.get("distribution"),
        "location": p.get("location"),
        "managed": p.get("managed"),
        "tags": [{"name": t.get("name"), "color": _TAG_COLORS.get(t.get("color"), "#888780")}
                 for t in (p.get("tags") or [])],
    }


def _data(sdk, cfg):
    c = _cfg(cfg)
    if not c["token"]:
        return {"ok": False, "reason": "token requis (\u2699)"}

    # 1. Découvrir les organisations
    orgs = []
    try:
        accs = _unwrap(_get(sdk, c["token"], "/1/accounts"))
        if isinstance(accs, list):
            orgs = [{"id": a.get("id"), "name": a.get("name") or a.get("display_name") or str(a.get("id"))}
                    for a in accs if a.get("id")]
    except PermissionError:
        pass  # pas de scope accounts : on retombera sur /products global
    except Exception:
        pass

    # 2. Récupérer les produits par organisation (ou global si pas d orgas)
    items, org_errors, certs = [], [], []
    if orgs:
        for o in orgs:
            try:
                prods = _unwrap(_get(sdk, c["token"], f"/1/products?account_id={o['id']}"))
                if isinstance(prods, list):
                    items.extend(_shape(p, o["name"]) for p in prods)
            except Exception:
                org_errors.append(o["name"])
            # Certificats SSL du compte (endpoint distinct, meme format)
            if c["show_certs"]:
                try:
                    cs = _unwrap(_get(sdk, c["token"], f"/1/certificate?account_id={o['id']}"))
                    if isinstance(cs, list):
                        certs.extend(_shape(x, o["name"]) for x in cs)
                except Exception:
                    pass
    else:
        prods = _unwrap(_get(sdk, c["token"], "/1/products"))
        if isinstance(prods, list):
            items.extend(_shape(p, None) for p in prods)

    # 3. Répartir par famille
    fam = lambda f: [i for i in items if i["family"] == f]
    domains = fam("domain"); mail = fam("mail"); cloud = fam("cloud")
    hosting = fam("hosting"); other = fam("other")
    domains.sort(key=lambda x: x["days_left"] if x["days_left"] is not None else 99999)

    certs.sort(key=lambda x: x["days_left"] if x["days_left"] is not None else 99999)
    expiring = [d for d in (domains + cloud + certs) if d["days_left"] is not None and d["days_left"] <= 60]
    expiring.sort(key=lambda x: x["days_left"])

    out = {"ok": True, "total": len(items), "orgs": [o["name"] for o in orgs],
           "orgs_count": len(orgs),
           "domains_count": len(domains), "mail_count": len(mail),
           "cloud_count": len(cloud), "hosting_count": len(hosting),
           "other_count": len(other), "certs_count": len(certs),
           "expiring_count": len(expiring), "expiring": expiring}
    if org_errors:
        out["org_error"] = "orgas illisibles : " + ", ".join(org_errors)
    if c["show_domains"]:
        out["domains"] = domains
    if c["show_mail"]:
        out["mail"] = mail
    if c["show_cloud"]:
        out["cloud"] = cloud
    if c["show_certs"]:
        out["certs"] = certs
    if c["show_other"]:
        out["hosting"] = hosting
        out["other"] = other
    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("addon_infomaniak", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except PermissionError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": f"connexion : {type(e).__name__}"[:100]})
        except Exception as e:
            sdk.log.exception("infomaniak")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    c = _cfg(cfg)
    if not c["token"]:
        return False, "token requis"
    try:
        accs = _unwrap(_get(sdk, c["token"], "/1/accounts", timeout=8))
        n = len(accs) if isinstance(accs, list) else 0
        if n:
            return True, f"{n} organisation(s)"
        prods = _unwrap(_get(sdk, c["token"], "/1/products", timeout=8))
        return True, f"{len(prods) if isinstance(prods, list) else 0} produit(s)"
    except PermissionError as e:
        return False, str(e)
    except Exception as e:
        return False, f"{type(e).__name__}"[:60]
