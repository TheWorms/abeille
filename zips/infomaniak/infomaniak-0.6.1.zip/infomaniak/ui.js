/* Infomaniak — produits (domaines, mail, autres) via /1/products, expirations en avant. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.infomaniak = (function () {
  let S = null, root = null, tile = null, data = null, activeOrg = '__all__', viewMode = 'cards';
  const ACCENT = '#0098ff';
  const CSS =
    "  .imwrap{--im:" + ACCENT + "}\n" +
    "  .imhead{display:flex;align-items:center;gap:26px;padding:18px 26px 14px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .imtk{display:flex;flex-direction:column}\n" +
    "  .imtk b{font-size:28px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums;color:var(--im)}\n" +
    "  .imtk.warn b{color:var(--warn)}\n" +
    "  .imtk span{font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:.05em;margin-top:5px}\n" +
    "  .imscroll{padding:18px 26px 24px}\n" +
    "  .imsec{font-size:13px;font-weight:800;color:var(--fg);margin:22px 0 12px;display:flex;align-items:center;gap:9px}\n" +
    "  .imsec:first-child{margin-top:0}\n" +
    "  .imsec .ic{font-size:17px}\n" +
    "  .imsec .c{background:var(--im);color:#fff;font-size:11px;font-weight:700;border-radius:20px;padding:1px 9px;min-width:20px;text-align:center}\n" +
    "  .imgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:12px}\n" +
    "  .imcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;padding:13px 15px;display:flex;flex-direction:column;gap:9px;transition:border-color .15s}\n" +
    "  .imcard:hover{border-color:var(--im)}\n" +
    "  .imcard.warn{border-color:var(--warn)}\n" +
    "  .imcard.crit{border-color:var(--bad)}\n" +
    "  .imchead{display:flex;align-items:center;gap:9px}\n" +
    "  .imname{font-weight:700;font-size:15px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .imexp{font-size:12px;font-weight:700;font-variant-numeric:tabular-nums;flex:none;padding:2px 9px;border-radius:8px}\n" +
    "  .imexp.ok{color:var(--green);background:color-mix(in srgb,var(--green) 12%,transparent)}\n" +
    "  .imexp.warn{color:var(--warn);background:color-mix(in srgb,var(--warn) 14%,transparent)}\n" +
    "  .imexp.crit{color:#fff;background:var(--bad)}\n" +
    "  .imchips{display:flex;flex-wrap:wrap;gap:6px}\n" +
    "  .imchip{font-size:11px;background:var(--bg);border:1px solid var(--border-soft);border-radius:7px;padding:2px 8px;color:var(--dim)}\n" +
    "  .imchip.org{color:#fff;background:var(--im);border-color:var(--im);font-weight:600}\n" +
    "  .imtag{font-size:10.5px;font-weight:600;border-radius:7px;padding:2px 9px;color:#fff}\n" +
    "  .imfoot{font-size:11px;color:var(--dim);border-top:1px solid var(--border-soft);padding-top:7px}\n" +
    "  .imalert{display:flex;align-items:center;gap:10px;background:color-mix(in srgb,var(--warn) 9%,transparent);border:1px solid color-mix(in srgb,var(--warn) 30%,transparent);border-radius:11px;padding:11px 15px;margin-bottom:14px}\n" +
    "  .imalert .n{font-weight:800;color:var(--warn);flex:none}\n" +
    "  .imalert .t{font-size:13px;min-width:0}\n" +
    "  .imempty{color:var(--dim);font-size:13px;padding:10px 0}\n" +
    "  .imbar{display:flex;align-items:center;gap:10px;padding:12px 26px 0}\n" +
    "  .imtabs{display:flex;gap:4px;flex:1;overflow-x:auto;scrollbar-width:none}\n" +
    "  .imtabs::-webkit-scrollbar{display:none}\n" +
    "  .imtab{flex:none;background:transparent;border:1px solid var(--border-soft);color:var(--dim);font-size:13px;font-weight:600;padding:7px 15px;border-radius:9px;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:7px}\n" +
    "  .imtab.on{background:var(--im);border-color:var(--im);color:#fff}\n" +
    "  .imtab .n{font-size:11px;opacity:.8;font-variant-numeric:tabular-nums}\n" +
    "  .imvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .imvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .imvtoggle button.on{background:var(--tile);color:var(--im)}\n" +
    "  .imrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 14px;margin-bottom:6px}\n" +
    "  .imrow.warn{border-color:var(--warn)}.imrow.crit{border-color:var(--bad)}\n" +
    "  .imrtx{min-width:0;flex:1}\n" +
    "  .imrname{font-weight:600;font-size:13.5px;display:flex;align-items:center;gap:7px}\n" +
    "  .imrmeta{font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n";
  function ensureCss() { let s = document.getElementById('imUiCss'); if (!s) { s = document.createElement('style'); s.id = 'imUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  function fdate(ts) { if (!ts) return '—'; try { return new Date(ts * 1000).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) { return ''; } }
  function expClass(days) { if (days == null) return 'ok'; if (days <= 15) return 'crit'; if (days <= 60) return 'warn'; return 'ok'; }
  function expLabel(days) { if (days == null) return '∞'; if (days < 0) return 'expiré'; if (days === 0) return "aujourd'hui"; return days + ' j'; }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture d\'Infomaniak…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function prodCard(p, showExp) {
    const cls = showExp ? expClass(p.days_left) : 'ok';
    const cardCls = cls === 'crit' ? ' crit' : (cls === 'warn' ? ' warn' : '');
    const chips = [];
    if (p.org) chips.push('<span class="imchip org">' + esc(p.org) + '</span>');
    p.tags.forEach(t => chips.push('<span class="imtag" style="background:' + t.color + '">' + esc(t.name) + '</span>'));
    if (p.distribution) chips.push('<span class="imchip">💿 ' + esc(p.distribution) + '</span>');
    if (p.location) chips.push('<span class="imchip">📍 ' + esc(p.location) + '</span>');
    if (p.managed) chips.push('<span class="imchip">managed</span>');
    if (p.locked) chips.push('<span class="imchip">🔒 verrouillé</span>');
    if (p.maintenance) chips.push('<span class="imchip">🔧 maintenance</span>');
    if (p.trial) chips.push('<span class="imchip">essai</span>');
    if (p.free) chips.push('<span class="imchip">gratuit</span>');
    return '<div class="imcard' + cardCls + '"><div class="imchead">' +
      '<span class="imname">' + esc(p.name) + '</span>' +
      (showExp ? '<span class="imexp ' + cls + '">' + expLabel(p.days_left) + '</span>' : '') + '</div>' +
      (chips.length ? '<div class="imchips">' + chips.join('') + '</div>' : '') +
      (p.internal && p.internal !== p.name ? '<div class="imfoot">' + esc(p.internal) + ' · ' + (p.expired ? 'expire le ' + fdate(p.expired) : 'sans expiration') + '</div>'
        : '<div class="imfoot">' + (p.expired ? 'expire le ' + fdate(p.expired) : 'sans expiration') + '</div>') +
      '</div>';
  }
  function prodRow(p, showExp) {
    const cls = showExp ? expClass(p.days_left) : 'ok';
    const rowCls = cls === 'crit' ? ' crit' : (cls === 'warn' ? ' warn' : '');
    const meta = [p.org, p.distribution, p.location].filter(Boolean).join(' · ');
    return '<div class="imrow' + rowCls + '"><div class="imrtx">' +
      '<div class="imrname">' + esc(p.name) +
      p.tags.map(t => '<span class="imtag" style="background:' + t.color + '">' + esc(t.name) + '</span>').join('') +
      (p.locked ? '<span style="color:var(--dim)">🔒</span>' : '') + '</div>' +
      '<div class="imrmeta">' + esc(meta || (p.expired ? 'expire le ' + fdate(p.expired) : '')) + '</div></div>' +
      (showExp ? '<span class="imexp ' + cls + '">' + expLabel(p.days_left) + '</span>' : '') + '</div>';
  }

  function orgFilter(list) {
    if (activeOrg === '__all__') return list;
    return (list || []).filter(x => x.org === activeOrg);
  }
  function renderList(list, showExp, emptyMsg) {
    const items = orgFilter(list);
    if (!items.length) return '<div class="imempty">' + emptyMsg + '</div>';
    if (viewMode === 'list') return items.map(p => prodRow(p, showExp)).join('');
    return '<div class="imgrid">' + items.map(p => prodCard(p, showExp)).join('') + '</div>';
  }

  const UIVER = '0.6.0';
  function paint() {
    try { paintInner(); }
    catch (e) {
      const el = root; if (!el) return;
      el.innerHTML = '<div style="padding:30px;font-family:monospace;font-size:13px;color:var(--bad)">' +
        '<b>ERREUR UI infomaniak v' + UIVER + '</b><br><br>' +
        String(e && e.message || e).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])) + '<br><br>' +
        String(e && e.stack || '').split('\n').slice(0, 4).join('<br>').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])) +
        '</div>';
    }
  }
  function paintInner() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🌐</div><div class="t1">Infomaniak indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne un token API (accès produits) dans ⚙.</div>' +
        '<button class="btnpill install" id="imRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('imRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="imwrap"><div class="imhead">' +
      '<div class="imtk"><b>' + nf(d.total) + '</b><span>produits</span></div>' +
      (d.orgs_count ? '<div class="imtk"><b>' + nf(d.orgs_count) + '</b><span>organisations</span></div>' : '') +
      '<div class="imtk"><b>' + nf(d.domains_count) + '</b><span>domaines</span></div>' +
      (d.cloud_count ? '<div class="imtk"><b>' + nf(d.cloud_count) + '</b><span>cloud / VPS</span></div>' : '') +
      (d.certs_count ? '<div class="imtk"><b>' + nf(d.certs_count) + '</b><span>certificats</span></div>' : '') +
      (d.expiring_count ? '<div class="imtk warn"><b>' + nf(d.expiring_count) + '</b><span>expirent bientôt</span></div>' : '') +
      '<div style="margin-left:auto;font-size:10px;color:var(--dim);align-self:flex-start">ui v' + UIVER + '</div>' +
      '</div></div>';

    // Barre : onglets organisations + toggle liste/cards
    if (d.orgs && d.orgs.length > 1) {
      h += '<div class="imbar"><div class="imtabs">';
      h += '<button class="imtab' + (activeOrg === '__all__' ? ' on' : '') + '" data-org="__all__">Toutes <span class="n">' + nf(d.total) + '</span></button>';
      d.orgs.forEach(o => {
        const n = countForOrg(d, o);
        h += '<button class="imtab' + (activeOrg === o ? ' on' : '') + '" data-org="' + esc(o) + '">' + esc(o) + ' <span class="n">' + n + '</span></button>';
      });
      h += '</div><div class="imvtoggle">' +
        '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
        '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
        '</div></div>';
    } else {
      h += '<div class="imbar"><div class="imtabs"></div><div class="imvtoggle">' +
        '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
        '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
        '</div></div>';
    }

    h += '<div class="imscroll">';
    if (d.org_error) h += '<div class="imalert"><span class="n">⚠</span><span class="t">' + esc(d.org_error) + '</span></div>';

    // Alerte expiration (filtrée par orga active)
    const exp = orgFilter(d.expiring).filter(x => x.days_left != null && x.days_left <= 15);
    if (exp.length) {
      h += '<div class="imalert"><span class="n">⚠</span><span class="t">' +
        exp.map(x => esc(x.name) + ' (' + expLabel(x.days_left) + ')').join(', ') + ' — pense au renouvellement</span></div>';
    }

    if (d.domains) {
      const n = orgFilter(d.domains).length;
      h += '<div class="imsec"><span class="ic">🌐</span> Domaines <span class="c">' + n + '</span></div>';
      h += renderList(d.domains, true, 'Aucun domaine.');
    }
    if (d.mail) {
      const n = orgFilter(d.mail).length;
      h += '<div class="imsec"><span class="ic">✉️</span> Hébergements mail <span class="c">' + n + '</span></div>';
      h += renderList(d.mail, true, 'Aucun hébergement mail.');
    }
    if (d.cloud) {
      const n = orgFilter(d.cloud).length;
      h += '<div class="imsec"><span class="ic">☁️</span> Cloud / VPS <span class="c">' + n + '</span></div>';
      h += renderList(d.cloud, true, 'Aucun VPS.');
    }
    if (d.certs) {
      const items = orgFilter(d.certs);
      if (items.length) {
        h += '<div class="imsec"><span class="ic">🔒</span> Certificats SSL <span class="c">' + items.length + '</span></div>';
        h += renderList(d.certs, true, 'Aucun certificat.');
      }
    }
    if (d.hosting) {
      const items = orgFilter(d.hosting);
      if (items.length) {
        h += '<div class="imsec"><span class="ic">🌍</span> Hébergements web <span class="c">' + items.length + '</span></div>';
        h += renderList(d.hosting, true, 'Aucun hébergement web.');
      }
    }
    if (d.other) {
      const items = orgFilter(d.other);
      if (items.length) {
        h += '<div class="imsec"><span class="ic">📦</span> Autres produits <span class="c">' + items.length + '</span></div>';
        h += renderList(d.other, true, 'Aucun autre produit.');
      }
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.imtab').forEach(b => b.addEventListener('click', () => {
      const o = b.getAttribute('data-org'); if (o === activeOrg) return;
      activeOrg = o; paint();
    }));
    el.querySelectorAll('.imvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
  }

  function countForOrg(d, org) {
    let n = 0;
    ['domains', 'mail', 'cloud', 'certs', 'hosting', 'other'].forEach(k => {
      if (d[k]) n += d[k].filter(x => x.org === org).length;
    });
    return n;
  }

  return { render };
})();
