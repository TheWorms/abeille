/* PandaKitchen — module partagé du hub cuisine (contrat Phase 3, lot C).
   Un seul module sert les six tuiles : kitchenowl (tableau de bord) + stock,
   congelateur, courses, recettes, repas (vues KitchenOwl). Chaque addon a une
   façade minuscule (ui.js) qui délègue ici. Le module s'auto-installe sous
   garde `|| (…)` : le premier ui.js chargé le définit, les suivants réutilisent.
   Aucune dépendance de code entre addons (le `requires: kitchenowl` du
   manifeste est une dépendance d'INSTALLATION, pas de runtime). */
window.PandaKitchen = window.PandaKitchen || (function () {
  let koTimer = null;
  // état recettes (persistant tant que le module vit)
  let rcQuery = '', rcTag = '', rcAllTags = [];
  let plOffset = 0;
  let plMode = 'week';   // 'day' | 'week' | 'year'
  let plDayOff = 0;      // décalage en jours (vue Jour)
  let plYearOff = 0;     // décalage en années (vue Année)
  const PL_JOURS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
  const RC_SUGG = ['Entrée', 'Plat', 'Dessert', 'Viande', 'Poisson', 'Végétarien', 'Soupe', 'Salade', 'Petit-déjeuner', 'Apéritif', 'Boulangerie'];

  const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const norm = x => (x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  const CSS = "  .stacts{display:flex;gap:10px;margin-top:16px;justify-content:flex-end}\n  .koadd{display:flex;gap:8px;margin-bottom:12px}\n  .koadd input{flex:1;padding:12px 14px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:15px}\n  .koadd button{padding:12px 22px;border-radius:10px;border:none;background:var(--accent);color:#fff;font-size:15px;font-weight:600;cursor:pointer}\n  .koadd button:disabled{opacity:.5}\n  .kobuy{display:grid;grid-template-columns:1fr 1fr;gap:8px}\n  .koitem{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px;cursor:pointer;user-select:none;min-height:52px}\n  .koitem:active{background:var(--accent-tint);border-color:var(--accent)}\n  .koitem.gone{opacity:.35;text-decoration:line-through}\n  .kobox{width:24px;height:24px;border-radius:7px;border:2px solid var(--border-soft);flex:none;display:flex;align-items:center;justify-content:center;font-size:14px;color:#fff}\n  .koitem.gone .kobox{background:var(--accent);border-color:var(--accent)}\n  .koname{font-weight:600;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .kodesc{margin-left:auto;font-size:11.5px;color:var(--dim);flex:none}\n  .kotoast{font-size:12px;color:var(--bad);min-height:16px;margin-top:8px}\n  .stitem{display:flex;align-items:center;gap:10px;background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:10px 13px;min-height:48px}\n  .stname{font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .stacts{margin-left:auto;display:flex;gap:6px;flex:none}\n  .stbtn{width:38px;height:38px;border-radius:9px;border:1px solid var(--border-soft);background:var(--bg);color:var(--dim);\n         display:flex;align-items:center;justify-content:center;font-size:15px;cursor:pointer;user-select:none}\n  .stbtn:active{background:var(--accent-tint);border-color:var(--accent);color:var(--accent)}\n  .stbtn.del:active{background:rgba(224,82,82,.15);border-color:var(--bad);color:var(--bad)}\n  .catsheet{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9998;display:flex;align-items:center;justify-content:center}\n  .catbox{background:var(--panel,#1b1f24);border:1px solid var(--border-soft);border-radius:14px;padding:16px;width:430px;max-height:78vh;overflow:auto}\n  .catbox h4{margin:0 0 4px;font-size:15px}\n  .catbox .sub{font-size:12px;color:var(--dim);margin-bottom:12px}\n  .catopt{display:flex;align-items:center;gap:10px;padding:11px 12px;border-radius:10px;border:1px solid var(--border-soft);\n          background:var(--tile);margin-bottom:6px;cursor:pointer;font-size:14px}\n  .catopt.on{border-color:var(--accent);color:var(--accent);font-weight:600}\n  .fjgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px}\n  .fjcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px;display:flex;flex-direction:column;gap:6px;cursor:pointer}\n  .fjcard:active,.fjrow:active,.fjcm:active{border-color:var(--accent)}\n  .fjmeta{font-size:11.5px;color:var(--faint);margin-top:auto}\n  .igadmin{font-size:11px;color:var(--faint);margin-bottom:9px}\n  .rcbtn{margin-top:8px;padding:7px 12px;border-radius:8px;border:1px solid var(--accent);background:var(--accent-tint);\n         color:var(--accent);font-size:11.5px;font-weight:600;cursor:pointer;display:inline-block}\n  .rcbtn:active{background:var(--accent);color:#fff}\n  .pltool{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}\n  .plnav{width:48px;height:48px;border-radius:11px;border:1px solid var(--border-soft);background:var(--tile);\n         color:var(--text);font-size:17px;display:flex;align-items:center;justify-content:center;cursor:pointer}\n  .plnav:active{background:var(--accent-tint);border-color:var(--accent)}\n  .plrange{font-weight:600;font-size:14px;min-width:190px;text-align:center;text-transform:capitalize}\n  .plweek{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}\n  .plday{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:6px 5px 5px;\n         min-height:190px;display:flex;flex-direction:column}\n  .plday.today{border-color:var(--accent);background:var(--accent-tint)}\n  .plday.we .pldh{color:var(--accent)}\n  .pldh{text-align:center;font-size:10.5px;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}\n  .pldn{text-align:center;font-size:17px;font-weight:700;line-height:1.1;margin-bottom:6px}\n  .plmeals{flex:1;min-height:0;display:flex;flex-direction:column;gap:5px;overflow:auto}\n  .plmeal{background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:6px 6px 5px;\n          font-size:11px;cursor:pointer;min-height:52px;display:flex;flex-direction:column;justify-content:center}\n  .plmeal:active{border-color:var(--accent)}\n  .plmeal .pln{font-weight:600;line-height:1.25;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical}\n  .plmeal .plm{color:var(--faint);font-size:10px;margin-top:2px}\n  .pladd{margin-top:5px;height:50px;flex:0 0 50px;width:100%;border:1px dashed var(--border-soft);border-radius:8px;\n         background:none;color:var(--dim);font-size:19px;cursor:pointer}\n  .pladd:active{border-color:var(--accent);color:var(--accent)}\n  .plback{margin-top:12px}\n  .plchips{display:flex;flex-wrap:wrap;gap:6px}\n  .plchip{background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:0 12px;height:52px;\n          display:flex;align-items:center;gap:8px;font-size:12.5px;cursor:pointer}\n  .plchip:active{border-color:var(--accent)}\n  .plsearch{width:100%;padding:12px 12px;border-radius:10px;border:1px solid var(--border-soft);\n            background:var(--tile);color:var(--text);font-size:14px;margin-bottom:8px}\n  .plact{width:100%;min-height:52px;margin-top:8px;border-radius:11px;border:1px solid var(--border-soft);\n         background:var(--tile);color:var(--text);font-size:14.5px;cursor:pointer;display:flex;align-items:center;\n         justify-content:center;gap:8px}\n  .plact:active{border-color:var(--accent)}\n  .plact.bad{color:var(--bad)}\n  .rcprev .ing{font-size:12px;padding:4px 0;border-bottom:1px solid var(--border-soft)}\n  .rcprev .ing:last-child{border-bottom:none}\n  .rcphoto{width:100%;height:170px;object-fit:cover;border-radius:10px;margin-bottom:12px;background:var(--bg)}\n  .fjcard .rcth{width:100%;height:96px;object-fit:cover;border-radius:8px;margin-bottom:8px;background:var(--bg)}\n  .rcbar{display:flex;gap:8px;align-items:center;margin-bottom:10px}\n  .rcsearch{flex:1;position:relative}\n  .rcsearch input{width:100%;padding:11px 13px 11px 36px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:13.5px}\n  .rcsearch .mag{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--faint);font-size:14px}\n  .rcsearch .clr{position:absolute;right:10px;top:50%;transform:translateY(-50%);color:var(--faint);cursor:pointer;font-size:15px}\n  .rcnew{padding:11px 16px;border-radius:10px;border:1px solid var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600;font-size:13px;cursor:pointer;white-space:nowrap}\n  .rcnew:active{background:var(--accent);color:#fff}\n  .rctags{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:11px}\n  .rctag{font-size:11.5px;padding:6px 11px;border-radius:8px;border:1px solid var(--border-soft);background:var(--tile);cursor:pointer;user-select:none}\n  .rctag.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n  .rcbadges{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}\n  .rcbadge{font-size:9.5px;padding:2px 7px;border-radius:5px;background:var(--bg);color:var(--dim)}\n  .rcempty{text-align:center;color:var(--dim);font-size:13px;padding:30px 0}\n  .rcdel{position:absolute;top:8px;right:46px;width:32px;height:32px;border-radius:9px;\n         background:var(--bg);border:1px solid var(--border-soft);color:var(--dim);\n         display:flex;align-items:center;justify-content:center;font-size:14px;cursor:pointer}\n  .rcdel:active{background:rgba(224,82,82,.18);border-color:var(--bad);color:var(--bad)}\n  .rctagbtn{position:absolute;top:8px;right:8px;width:32px;height:32px;border-radius:9px;background:var(--bg);\n      border:1px solid var(--border-soft);color:var(--dim);display:flex;align-items:center;justify-content:center;\n      font-size:14px;cursor:pointer}\n  .rctagbtn:active{background:var(--accent-tint);border-color:var(--accent);color:var(--accent)}\n  .fjcard{position:relative}\n  .rcacts{display:flex;gap:6px;align-items:center;margin-top:8px}\n  .fjgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}\n  .fjcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:10px 12px}\n  .fjh{display:flex;align-items:center;gap:7px;margin-bottom:5px}\n  .fjn{font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .fjmeta{display:flex;gap:12px;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n  .fjmeta b{color:var(--text)}\n  .plwrap{flex:1;display:flex;flex-direction:column;min-height:0}\n  .plbody{flex:1;min-height:0;display:flex;flex-direction:column;overflow:auto}\n  .plweek{flex:1;min-height:0}\n  .plday{min-height:0}\n  .pldview{flex:1;min-height:0;display:flex;flex-direction:column;gap:10px}\n  .pldmeals{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column;gap:8px}\n  .pldmeal{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:12px;cursor:pointer;min-height:64px}\n  .pldmeal:active{border-color:var(--accent)}\n  .pldmeal .rcth{width:56px;height:56px;object-fit:cover;border-radius:9px;flex:none;background:var(--bg)}\n  .pldmeal .pln{font-weight:600;font-size:15px}\n  .pldmeal .plm{color:var(--faint);font-size:12px;margin-top:2px}\n  .pldadd{flex:0 0 60px;border:1px dashed var(--border-soft);border-radius:11px;background:none;color:var(--dim);font-size:20px;cursor:pointer}\n  .pldadd:active{border-color:var(--accent);color:var(--accent)}\n  .plyear{flex:1;min-height:0;display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(3,1fr);gap:9px}\n  .plycard{background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 10px;display:flex;flex-direction:column;min-height:0;overflow:hidden}\n  .plyh{font-size:12.5px;font-weight:600;margin-bottom:4px;color:var(--dim);flex:none}\n  .plyrow{display:flex;align-items:center;gap:6px;font-size:11px;padding:1.5px 0}\n  .plyl{color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .plyd{margin-left:auto;color:var(--faint);font-variant-numeric:tabular-nums;flex:none}\n  .plymore{font-size:10.5px;color:var(--faint);margin-top:2px}";
  function ensureCss() { let s = document.getElementById('kchUiCss'); if (!s) { s = document.createElement('style'); s.id = 'kchUiCss'; document.head.appendChild(s); } s.textContent = CSS; }

  function stopTimer() { if (koTimer) { clearInterval(koTimer); koTimer = null; } }

  /* API relative à un kind (chaque addon a son propre préfixe /addons/<kind>/api) */
  async function post(kind, path, body) {
    const r = await fetch('/addons/' + kind + '/api' + path, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {})
    });
    return r.json();
  }

  /* ============ KITCHENOWL — tableau de bord d'accueil ============ */
  async function renderHub(el, sdk, tile) {
    ensureCss();
    let cfg = {}; try { cfg = await sdk.config(); } catch (e) {}
    const url = (cfg.url || '').trim();
    let d = null;
    try { const r = await sdk.api('/status'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead">' + (url ? '<button class="lgbtn" id="khOpen" style="margin:0;padding:9px 18px;font-size:14px">Ouvrir KitchenOwl \u2197</button>' : '') +
      '<button class="wch" id="khRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">🥘</div><div class="t1">Hub cuisine — KitchenOwl</div><div class="t2">' + ((d && d.reason) || '') +
        '<br>Configure l\'URL + le <b>jeton</b> KitchenOwl dans \u2699. C\'est la connexion partagée par Stock, Courses, Recettes, Congélateur et Repas.</div></div>';
    } else {
      const nf = x => x == null ? '—' : x.toLocaleString('fr-FR');
      h += '<div class="phwrap"><div class="phcard"><div class="phhead">🥘 Maison « ' + d.household + ' »' +
        '<span class="phstate" style="background:var(--accent-tint);color:var(--accent)">connecté</span></div>' +
        '<div class="phstats">' +
        '<div class="phst"><b>' + nf(d.stock) + '</b><span>en stock</span></div>' +
        '<div class="phst"><b>' + nf(d.courses) + '</b><span>sur la liste</span></div>' +
        '<div class="phst"><b>' + nf(d.recipes) + '</b><span>recettes</span></div>' +
        '<div class="phst"><b>' + nf(d.planned) + '</b><span>repas planifiés</span></div>' +
        '</div></div></div>';
      h += '<div class="wsrc" style="padding-left:0">' + d.host + '</div>';
    }
    el.innerHTML = h;
    const ob = document.getElementById('khOpen'); if (ob) ob.addEventListener('click', () => sdk.openService(url, (tile && (tile.nm || tile.name)) || 'KitchenOwl'));
    const rb = document.getElementById('khRefresh'); if (rb) rb.addEventListener('click', () => renderHub(el, sdk, tile));
  }

  /* ============ STOCK / CONGELATEUR / COURSES / RECETTES / REPAS ============ */
  async function renderKitchen(kind, el, sdk, tile) {
    ensureCss();
    let d = null;
    try { const r = await sdk.api('/view'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead"><button class="wch" id="koRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">' + sdk.ic(tile.ic, tile.color) + '</div><div class="t1">' + ((tile && (tile.nm || tile.name)) || kind) + ' — KitchenOwl</div><div class="t2">' + ((d && d.reason) || '') +
        '<br>Configure l\'URL + un <b>jeton d\'accès</b> KitchenOwl dans \u2699 (un seul des addons cuisine suffit, ils partagent les identifiants).</div></div>';
      el.innerHTML = h;
      const rb0 = document.getElementById('koRefresh'); if (rb0) rb0.addEventListener('click', () => renderKitchen(kind, el, sdk, tile));
      return;
    }
    if (!d.items.length) {
      const vide = { courses: 'Liste de courses vide 🎉', congelateur: 'Congélateur vide', stock: 'Aucun article en stock', recettes: 'Aucune recette', repas: 'Aucun repas planifié' }[kind];
      if (kind === 'recettes') { h += rcToolbar({ tags: [] }); h += '<div class="igadmin">Importe une recette pour commencer. Chaque carte aura ensuite un bouton 🏷️ pour la classer (Entrée, Plat, Dessert, Poisson…).</div>'; }
      h += '<div class="stub"><div class="big">' + sdk.ic(tile.ic, tile.color) + '</div><div class="t2">' + vide + '</div></div>';
    } else {
      h += '<div class="gybadges"><span class="gybadge">🏠 ' + d.household + '</span><span class="gybadge">' + d.items.length + ' élément(s)</span></div>';
      if (kind === 'courses') h += viewCourses(d);
      else if (kind === 'recettes') h += viewRecipes(d, sdk);
      else if (kind === 'repas') h += renderPlanner(d);
      else h += viewStock(d);
      h += '<div class="wsrc">KitchenOwl sur Marmotte · synchronisé avec l\'app Android</div>';
    }
    el.innerHTML = h;
    const rb = document.getElementById('koRefresh'); if (rb) rb.addEventListener('click', () => renderKitchen(kind, el, sdk, tile));
    if (kind === 'courses') wireCourses(kind, el, sdk, tile, d);
    else if (kind === 'stock' || kind === 'congelateur') wireStock(kind, el, sdk, tile, d);
    else if (kind === 'recettes') wireRecipes(kind, el, sdk, tile, d);
    else if (kind === 'repas') wirePlanner(kind, el, sdk, tile, d);
    // rafraîchissement auto (les ajouts faits depuis l'app Android remontent seuls)
    stopTimer();
    koTimer = setInterval(() => {
      if (!document.body.contains(el)) { stopTimer(); return; }
      const inp = document.getElementById('koNew');
      if (inp && (document.activeElement === inp || inp.value.trim())) return;   // ne pas couper une saisie
      renderKitchen(kind, el, sdk, tile);
    }, 30000);
  }

  /* ---- STOCK / CONGELATEUR ---- */
  function viewStock(d) {
    let h = '<div class="koadd"><input id="koNew" placeholder="Ajouter un article…" autocomplete="off">' +
      '<button id="koAdd">Ajouter</button></div><div class="kotoast" id="koErr"></div>';
    const byCat = {}; d.items.forEach(x => { (byCat[x.category] = byCat[x.category] || []).push(x); });
    h += Object.keys(byCat).sort().map(c => '<div class="wsec" style="padding-left:0">' + c + '</div><div class="kobuy">' +
      byCat[c].map(x => '<div class="stitem" data-id="' + x.id + '"><span class="stname">' + x.name + '</span>' +
        '<span class="stacts"><span class="stbtn cat" title="Changer de catégorie">🏷️</span>' +
        '<span class="stbtn del" title="Supprimer">🗑️</span></span></div>').join('') + '</div>').join('');
    return h;
  }
  function wireStock(kind, el, sdk, tile, d) {
    const err = document.getElementById('koErr');
    const fail = m => { if (err) err.textContent = m; };
    const inp = document.getElementById('koNew'), btn = document.getElementById('koAdd');
    const addItem = async () => {
      const name = (inp.value || '').trim(); if (!name) return;
      btn.disabled = true; fail('');
      let cid = null;
      if (kind === 'congelateur' && d.categories) {
        const c = d.categories.find(c2 => norm(c2.name).includes('congel') || norm(c2.name).includes('surgel'));
        if (c) cid = c.id;
      }
      try {
        const j = await post(kind, '/item/add', { name, category_id: cid });
        if (j.ok) { inp.value = ''; sdk.vk.close(); renderKitchen(kind, el, sdk, tile); }
        else fail('Ajout impossible — ' + (j.reason || ''));
      } catch (e) { fail('Serveur injoignable'); }
      btn.disabled = false;
    };
    if (btn) btn.addEventListener('click', addItem);
    if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') addItem(); });
    el.querySelectorAll('.stitem').forEach(row => {
      const id = parseInt(row.dataset.id);
      const name = row.querySelector('.stname').textContent;
      row.querySelector('.stbtn.del').addEventListener('click', async () => {
        if (!confirm('Supprimer « ' + name + ' » ?')) return;
        fail('');
        try {
          const j = await post(kind, '/item/delete', { item_id: id });
          if (j.ok) { row.style.opacity = '.3'; setTimeout(() => renderKitchen(kind, el, sdk, tile), 350); }
          else fail('Suppression impossible — ' + (j.reason || ''));
        } catch (e) { fail('Serveur injoignable'); }
      });
      row.querySelector('.stbtn.cat').addEventListener('click', () => openCatSheet(kind, el, sdk, tile, d, id, name));
    });
  }
  function openCatSheet(kind, el, sdk, tile, d, itemId, itemName) {
    const cats = d.categories || [];
    const sheet = document.createElement('div'); sheet.className = 'catsheet';
    sheet.innerHTML = '<div class="catbox"><h4>Catégorie de « ' + itemName + ' »</h4>' +
      '<div class="sub">Déplacer l\'article dans une autre catégorie.</div>' +
      cats.map(c => '<div class="catopt" data-cid="' + c.id + '">📁 ' + c.name + '</div>').join('') +
      '<div class="catopt" data-cid="">— Sans catégorie</div>' +
      '<button class="catclose">Annuler</button></div>';
    document.body.appendChild(sheet);
    const close = () => sheet.remove();
    sheet.querySelector('.catclose').addEventListener('click', close);
    sheet.addEventListener('click', e => { if (e.target === sheet) close(); });
    sheet.querySelectorAll('.catopt').forEach(o => o.addEventListener('click', async () => {
      const cid = o.dataset.cid ? parseInt(o.dataset.cid) : null;
      try {
        const j = await post(kind, '/item/category', { item_id: itemId, category_id: cid });
        close();
        if (j.ok) renderKitchen(kind, el, sdk, tile);
        else { const err = document.getElementById('koErr'); if (err) err.textContent = 'Déplacement impossible — ' + (j.reason || ''); }
      } catch (e) { close(); }
    }));
  }

  /* ---- COURSES ---- */
  function viewCourses(d) {
    let h = '<div class="koadd"><input id="koNew" placeholder="Ajouter un article…" autocomplete="off">' +
      '<button id="koAdd">Ajouter</button></div><div class="kotoast" id="koErr"></div>';
    h += '<div class="kobuy">' + d.items.map(x => '<div class="koitem" data-id="' + x.id + '" data-list="' + (x.list_id || '') + '">' +
      '<span class="kobox"></span><span class="koname">' + x.name + '</span>' +
      (x.desc ? '<span class="kodesc">' + x.desc + '</span>' : '') + '</div>').join('') + '</div>';
    return h;
  }
  function wireCourses(kind, el, sdk, tile, d) {
    const err = document.getElementById('koErr');
    const fail = m => { if (err) err.textContent = m; };
    const inp = document.getElementById('koNew'), btn = document.getElementById('koAdd');
    const addItem = async () => {
      const name = (inp.value || '').trim(); if (!name) return;
      btn.disabled = true; fail('');
      try {
        const j = await post('courses', '/courses/add', { name });
        if (j.ok) { inp.value = ''; sdk.vk.close(); renderKitchen(kind, el, sdk, tile); }
        else fail('Ajout impossible — ' + (j.reason || ''));
      } catch (e) { fail('Serveur injoignable'); }
      btn.disabled = false;
    };
    if (btn) btn.addEventListener('click', addItem);
    if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') addItem(); });
    el.querySelectorAll('.koitem').forEach(row => {
      row.addEventListener('click', async () => {
        if (row.classList.contains('gone')) return;
        row.classList.add('gone'); row.querySelector('.kobox').textContent = '✓';
        fail('');
        try {
          const j = await post('courses', '/courses/remove', { item_id: parseInt(row.dataset.id), list_id: parseInt(row.dataset.list) || d.default_list });
          if (j.ok) { setTimeout(() => row.remove(), 400); }
          else { row.classList.remove('gone'); row.querySelector('.kobox').textContent = ''; fail('Impossible de cocher — ' + (j.reason || '')); }
        } catch (e) { row.classList.remove('gone'); row.querySelector('.kobox').textContent = ''; fail('Serveur injoignable'); }
      });
    });
  }

  /* ---- RECETTES ---- */
  function rcToolbar(d) {
    const tags = (d && d.tags) || [];
    let h = '<div class="rcbar"><span class="rcsearch"><span class="mag">🔍</span>' +
      '<input id="rcQ" placeholder="Rechercher une recette, un ingrédient, une catégorie…" value="' +
      rcQuery.replace(/"/g, '&quot;') + '" autocomplete="off">' +
      (rcQuery ? '<span class="clr" id="rcClr">✕</span>' : '') + '</span>' +
      '<span class="rcnew" id="rcNew">📥 Importer une recette</span></div>';
    if (tags.length) h += '<div class="rctags"><span class="rctag' + (rcTag ? '' : ' on') + '" data-tag="">Toutes</span>' +
      tags.map(t => '<span class="rctag' + (rcTag === t ? ' on' : '') + '" data-tag="' + t + '">' + t + '</span>').join('') + '</div>';
    h += '<div class="kotoast" id="rcErr"></div>';
    return h;
  }
  function viewRecipes(d, sdk) {
    rcAllTags = (d.tags || []).slice();
    let h = rcToolbar(d);
    const nq0 = rcQuery.trim(), nq = norm(nq0);
    const vis = d.items.filter(x => {
      if (rcTag && !(x.tags || []).includes(rcTag)) return false;
      if (!nq) return true;
      return norm(x.name).includes(nq) || norm(x.desc).includes(nq) || (x.tags || []).some(t => norm(t).includes(nq));
    });
    if (!vis.length) h += '<div class="rcempty">Aucune recette ne correspond à « ' + (nq0 || rcTag) + ' »</div>';
    else h += '<div class="fjgrid">' + vis.map(x => '<div class="fjcard">' +
      (x.photo ? '<img class="rcth" loading="lazy" src="' + (/^https?:/.test(x.photo) ? x.photo : ('/addons/recettes/api/photo/' + encodeURIComponent(x.photo))) + '" onerror="this.style.display=\'none\'">' : '') +
      '<div class="fjh"><span class="fjn">🍽️ ' + x.name + '</span></div>' +
      '<div class="fjmeta"><span>⏱️ <b>' + (x.time || '—') + '</b> min</span><span>👥 <b>' + (x.yields || '—') + '</b></span></div>' +
      (x.desc ? '<div class="bkcsub">' + x.desc + '</div>' : '') +
      ((x.tags || []).length ? '<div class="rcbadges">' + x.tags.map(t => '<span class="rcbadge">' + t + '</span>').join('') + '</div>' : '') +
      (x.id ? '<div class="rcacts"><span class="rcbtn" data-view="' + x.id + '" data-name="' + x.name.replace(/"/g, '&quot;') + '">👁️ Voir</span><span class="rcbtn" data-plan="' + x.id + '" data-name="' + x.name.replace(/"/g, '&quot;') + '">📅 Planifier</span></div>' : '') +
      (x.id && sdk.delMode() ? '<span class="rcdel" data-rcdel="' + x.id + '" data-name="' + x.name + '">🗑</span>' : '') +
      (x.id ? '<span class="rctagbtn" data-rctag="' + x.id + '" data-name="' + x.name + '" data-tags="' + (x.tags || []).join('|') + '">🏷️</span>' : '') +
      '</div>').join('') + '</div>';
    return h;
  }
  function wireRecipes(kind, el, sdk, tile, d) {
    const rerender = () => renderKitchen(kind, el, sdk, tile);
    const refilter = () => { rerender(); setTimeout(() => { const q = document.getElementById('rcQ'); if (q && rcQuery) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 40); };
    const nb = document.getElementById('rcNew');
    if (nb) nb.addEventListener('click', () => rcOpenImport(kind, el, sdk, tile));
    const q = document.getElementById('rcQ');
    if (q) { let t = null; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { rcQuery = q.value; refilter(); }, 200); }); }
    const cl = document.getElementById('rcClr');
    if (cl) cl.addEventListener('click', () => { rcQuery = ''; refilter(); });
    el.querySelectorAll('[data-tag]').forEach(t => t.addEventListener('click', () => { rcTag = t.dataset.tag; refilter(); }));
    el.querySelectorAll('[data-rctag]').forEach(b => b.addEventListener('click', ev => {
      ev.stopPropagation();
      rcTagPicker(kind, el, sdk, tile, parseInt(b.dataset.rctag), b.dataset.name, (b.dataset.tags || '').split('|'));
    }));
    el.querySelectorAll('[data-rcdel]').forEach(b => b.addEventListener('click', async ev => {
      ev.stopPropagation();
      if (!confirm('Supprimer « ' + b.dataset.name + ' » ?\nElle part à la corbeille, un administrateur pourra la restaurer.')) return;
      try {
        const j = await post('recettes', '/recipe/delete', { id: parseInt(b.dataset.rcdel) });
        if (j.ok) { sdk.toast('« ' + (j.name || b.dataset.name) + ' » supprimée'); rerender(); }
        else sdk.toast('Impossible — ' + (j.reason || ''));
      } catch (e) { sdk.toast('Serveur injoignable'); }
    }));
    el.querySelectorAll('[data-plan]').forEach(b => b.addEventListener('click', () => {
      koPickDay(b.dataset.name, async (key, lab) => {
        const j = await post('repas', '/planner/add', { recipe_id: parseInt(b.dataset.plan), date: key });
        if (j.ok) sdk.toast('« ' + b.dataset.name + ' » planifié ' + lab);
        else sdk.toast('Impossible — ' + (j.reason || ''));
      });
    }));
    el.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => rcViewRecipe(kind, el, sdk, tile, parseInt(b.dataset.view), b.dataset.name)));
  }
  async function rcViewRecipe(kind, el, sdk, tile, id, fallbackName) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox rcprev" style="width:520px"><div class="cmeta" style="text-align:center;padding:20px 0">Chargement…</div></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    let j = null;
    try { const r = await sdk.api('/recipe/' + id); j = await r.json(); } catch (e) { j = { ok: false, reason: 'serveur injoignable' }; }
    if (!j || !j.ok) {
      sh.querySelector('.evbox').innerHTML = '<div class="evtitle">' + (fallbackName || 'Recette') + '</div>' +
        '<div class="cmeta" style="padding:10px 0">' + ((j && j.reason) || 'Impossible de charger la recette') + '</div>' +
        '<button class="catclose" id="rcVClose">Fermer</button>';
      sh.querySelector('#rcVClose').addEventListener('click', close);
      return;
    }
    sh.querySelector('.evbox').innerHTML =
      (j.photo ? '<img class="rcphoto" src="' + (/^https?:/.test(j.photo) ? j.photo : ('/addons/recettes/api/photo/' + encodeURIComponent(j.photo))) + '" onerror="this.style.display=\'none\'">' : '') +
      '<div class="evtitle">' + j.name + '</div>' +
      '<div class="evwhen">' + (j.time ? ('⏱️ ' + j.time + ' min') : '') + (j.yields ? ('  ·  👥 ' + j.yields + ' parts') : '') + '</div>' +
      ((j.tags || []).length ? '<div class="rcbadges" style="margin-bottom:10px">' + j.tags.map(t => '<span class="rcbadge">' + t + '</span>').join('') + '</div>' : '') +
      '<div class="evrow" style="display:block"><span class="k">🧺 ' + j.items.length + ' ingrédient(s)</span>' +
      '<div style="margin-top:6px;max-height:180px;overflow:auto">' +
      (j.items.length ? j.items.map(x => '<div class="ing">' + x + '</div>').join('') : '<div class="ing">aucun ingrédient renseigné</div>') +
      '</div></div>' +
      (j.description ? '<div class="evrow" style="display:block"><span class="k">📋 Préparation</span><div class="evdesc" style="margin-top:6px;max-height:220px;overflow:auto;font-size:13px">' + j.description.replace(/</g, '&lt;') + '</div></div>' : '') +
      '<button class="tprecb" id="rcVPlan">📅 Planifier</button>' +
      '<button class="catclose" id="rcVClose">Fermer</button>';
    sh.querySelector('#rcVClose').addEventListener('click', close);
    sh.querySelector('#rcVPlan').addEventListener('click', () => {
      koPickDay(j.name, async (key, lab) => {
        const r2 = await post('repas', '/planner/add', { recipe_id: id, date: key });
        if (r2.ok) sdk.toast('« ' + j.name + ' » planifié ' + lab);
        else sdk.toast('Impossible — ' + (r2.reason || ''));
      });
    });
  }
  function rcOpenImport(kind, el, sdk, tile) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox" style="width:520px"><div class="evtitle">📥 Importer une recette</div>' +
      '<div class="tprecs">Colle l\'adresse d\'une recette (Marmiton, 750g, Cuisine AZ, Ptitchef…). Titre, ingrédients et photo sont extraits automatiquement.</div>' +
      '<input id="rcUrl" class="inp" placeholder="https://www.marmiton.org/recettes/…" autocomplete="off" style="width:100%">' +
      '<div class="kotoast" id="rcErr2" style="margin-top:8px"></div>' +
      '<button class="tprecb" id="rcGo">Extraire la recette</button>' +
      '<button class="catclose" id="rcCancel">Annuler</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('#rcCancel').addEventListener('click', close);
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    const inp = sh.querySelector('#rcUrl');
    const go = async () => {
      const err = sh.querySelector('#rcErr2'), btn = sh.querySelector('#rcGo');
      const u = (inp.value || '').trim(); err.textContent = '';
      if (!/^https?:\/\//.test(u)) { err.textContent = 'Colle une adresse complète (https://…)'; return; }
      btn.disabled = true; btn.textContent = 'Extraction…';
      let j = null;
      try { const r = await post('recettes', '/recipe/scrape', { url: u }); j = r; } catch (e) { err.textContent = 'Serveur injoignable'; }
      btn.disabled = false; btn.textContent = 'Extraire la recette';
      if (!j) return;
      if (!j.ok) { err.textContent = j.reason || 'Extraction impossible'; return; }
      close(); sdk.vk.close(); rcPreview(kind, el, sdk, tile, j);
    };
    sh.querySelector('#rcGo').addEventListener('click', go);
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  }
  function rcTagPicker(kind, el, sdk, tile, id, nom, actuels) {
    const sel = new Set(actuels.filter(Boolean));
    const sh = document.createElement('div'); sh.className = 'evsheet';
    const render = () => {
      const connus = (rcAllTags || []).slice();
      RC_SUGG.forEach(t => { if (!connus.includes(t)) connus.push(t); });
      sh.innerHTML = '<div class="evbox" style="width:480px"><div class="evtitle">🏷️ ' + nom + '</div>' +
        '<div class="tprecs">Choisis une ou plusieurs catégories — elles servent de dossiers et de filtres.</div>' +
        '<div class="rctags" style="margin-bottom:12px">' + connus.map(t => '<span class="rctag' + (sel.has(t) ? ' on' : '') + '" data-t="' + t + '">' + t + '</span>').join('') + '</div>' +
        '<div class="koadd"><input id="rcNewTag" placeholder="Nouvelle catégorie…" autocomplete="off"><button id="rcAddTag">Ajouter</button></div>' +
        '<button class="tprecb" id="rcSaveTag">Enregistrer</button>' +
        '<button class="catclose" id="rcCloseTag">Annuler</button></div>';
      sh.querySelectorAll('[data-t]').forEach(x => x.addEventListener('click', () => { const t = x.dataset.t; if (sel.has(t)) sel.delete(t); else sel.add(t); render(); }));
      sh.querySelector('#rcCloseTag').addEventListener('click', () => sh.remove());
      sh.querySelector('#rcAddTag').addEventListener('click', () => {
        const v = (sh.querySelector('#rcNewTag').value || '').trim();
        if (v) { sel.add(v); if (!rcAllTags.includes(v)) rcAllTags.push(v); }
        sdk.vk.close(); render();
      });
      sh.querySelector('#rcSaveTag').addEventListener('click', async () => {
        try {
          const j = await post('recettes', '/recipe/tag', { id: id, tags: Array.from(sel) });
          sdk.toast(j.ok ? ('« ' + nom + ' » classée') : ('Impossible — ' + (j.reason || '')));
        } catch (e) { sdk.toast('Serveur injoignable'); }
        sh.remove(); renderKitchen(kind, el, sdk, tile);
      });
    };
    document.body.appendChild(sh);
    render();
    sh.addEventListener('click', e => { if (e.target === sh) sh.remove(); });
  }
  function rcConflict(kind, el, sdk, tile, j, closePrev) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox" style="width:460px"><div class="evtitle">⚠️ Recette déjà présente</div>' +
      '<div class="tprecs">« ' + j.name + ' » existe déjà dans KitchenOwl. Que veux-tu faire ?</div>' +
      '<button class="tprecb" id="rcRepl">Remplacer l\'existante</button>' +
      '<button class="tprecb" id="rcDup" style="background:var(--tile);color:var(--text);border:1px solid var(--border-soft);margin-top:8px">Créer un doublon</button>' +
      '<button class="catclose" id="rcAnn">Annuler</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('#rcAnn').addEventListener('click', () => { close(); if (closePrev) closePrev(); });
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    const go = async (mode) => {
      close();
      try {
        const res = await post('recettes', '/recipe/add', { name: j.name, description: j.description, time: j.time, yields: j.yields, source: j.source, photo: j.photo, raw: j.raw, mode });
        if (res.ok) sdk.toast('« ' + res.name + ' » ' + (res.replaced ? 'remplacée' : 'ajoutée en doublon'));
        else sdk.toast('Impossible — ' + (res.reason || ''));
      } catch (e) { sdk.toast('Serveur injoignable'); }
      if (closePrev) closePrev();
      renderKitchen(kind, el, sdk, tile);
    };
    sh.querySelector('#rcRepl').addEventListener('click', () => go('replace'));
    sh.querySelector('#rcDup').addEventListener('click', () => go('duplicate'));
  }
  function rcPreview(kind, el, sdk, tile, j) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox rcprev" style="width:520px">' +
      (j.photo ? '<img class="rcphoto" src="' + j.photo + '" onerror="this.style.display=\'none\'">' : '') +
      '<div class="evtitle">' + (j.name || 'Recette') + '</div>' +
      '<div class="evwhen">' + (j.time ? ('⏱️ ' + j.time + ' min') : '') + (j.yields ? ('  ·  👥 ' + j.yields + ' parts') : '') + '</div>' +
      (j.description ? '<div class="evrow"><span class="evdesc">' + j.description.slice(0, 400).replace(/</g, '&lt;') + '</span></div>' : '') +
      '<div class="evrow" style="display:block"><span class="k">🧺 ' + j.items.length + ' ingrédient(s)</span>' +
      '<div style="margin-top:6px;max-height:220px;overflow:auto">' +
      (j.items.length ? j.items.map(x => '<div class="ing">' + x + '</div>').join('') : '<div class="ing">aucun ingrédient détecté</div>') +
      '</div></div>' +
      '<button class="tprecb" id="rcAdd">Ajouter à KitchenOwl</button>' +
      '<button class="catclose" id="rcCancel">Annuler</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('#rcCancel').addEventListener('click', close);
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    const envoyer = async (mode) => {
      try {
        const res = await post('recettes', '/recipe/add', { name: j.name, description: j.description, time: j.time, yields: j.yields, source: j.source, photo: j.photo, tags: j.tags || [], raw: j.raw, mode: mode || '' });
        if (res.ok) { sdk.toast('« ' + res.name + ' » ' + (res.replaced ? 'remplacée' : 'ajoutée')); close(); renderKitchen(kind, el, sdk, tile); return; }
        if (res.conflict) { rcConflict(kind, el, sdk, tile, j, close); return; }
        const e2 = document.getElementById('rcErr'); if (e2) e2.textContent = res.reason || 'Ajout impossible'; close();
      } catch (e) { sdk.toast('Serveur injoignable'); }
    };
    sh.querySelector('#rcAdd').addEventListener('click', () => envoyer(''));
  }

  /* ---- REPAS (planificateur) ---- */
  function plDays(off) {
    const base = new Date(); base.setHours(0, 0, 0, 0);
    base.setDate(base.getDate() + (off == null ? plOffset : off) * 7);
    const out = [];
    for (let i = 0; i < 7; i++) { const dd = new Date(base); dd.setDate(base.getDate() + i); out.push({ d: dd, key: ymd(dd) }); }
    return out;
  }
  function plThumb(x) {
    if (!x.photo) return '';
    const src = /^https?:/.test(x.photo) ? x.photo : ('/addons/repas/api/photo/' + encodeURIComponent(x.photo));
    return '<img class="rcth" loading="lazy" src="' + src + '" onerror="this.style.display=\'none\'">';
  }
  function plMeta(x) { const p = []; if (x.time) p.push('⏱️ ' + x.time + ' min'); if (x.yields) p.push('👥 ' + x.yields); return p.join(' · '); }
  function plTabs() {
    const tabs = [['day', 'Jour'], ['week', 'Semaine'], ['year', 'Année']];
    return '<span class="wtoggle">' + tabs.map(t => '<span class="wch' + (plMode === t[0] ? ' on' : '') + '" data-plmode="' + t[0] + '">' + t[1] + '</span>').join('') + '</span>';
  }
  function renderWeekView(d) {
    const days = plDays();
    const todayKey = ymd(new Date());
    const byDay = {}; (d.planned || []).forEach(x => { (byDay[x.date] = byDay[x.date] || []).push(x); });
    const f = days[0].d, l = days[6].d;
    const fmt = x => x.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    let h = '<div class="pltool"><span class="plnav" id="plPrev" title="Semaine précédente">◀</span>' +
      '<span class="plrange">' + fmt(f) + ' → ' + fmt(l) + '</span>' +
      '<span class="plnav" id="plNext" title="Semaine suivante">▶</span>' +
      (plOffset ? '<button class="wch" id="plToday">Aujourd\'hui</button>' : '') +
      '<span style="margin-left:auto;font-size:12px;color:var(--faint)">' +
      (d.planned || []).length + ' repas planifié' + ((d.planned || []).length > 1 ? 's' : '') + '</span>' + plTabs() + '</div>';
    h += '<div class="plbody"><div class="plweek">' + days.map(({ d: dd, key }) => {
      const meals = byDay[key] || [];
      const we = dd.getDay() === 0 || dd.getDay() === 6;
      return '<div class="plday' + (key === todayKey ? ' today' : '') + (we ? ' we' : '') + '">' +
        '<div class="pldh">' + PL_JOURS[(dd.getDay() + 6) % 7].slice(0, 3) + '</div>' +
        '<div class="pldn">' + dd.getDate() + '</div>' +
        '<div class="plmeals">' + meals.map(m => '<div class="plmeal" data-meal="' + m.recipe_id + '" data-date="' + key + '">' +
          '<span class="pln">' + m.name + '</span>' + (plMeta(m) ? '<span class="plm">' + plMeta(m) + '</span>' : '') + '</div>').join('') + '</div>' +
        '<button class="pladd" data-addday="' + key + '" title="Ajouter un repas">+</button></div>';
    }).join('') + '</div>';
    const bl = d.backlog || [];
    h += '<div class="plback"><div class="wsec" style="padding-left:0">À planifier' + (bl.length ? ' (' + bl.length + ')' : '') + '</div>';
    if (!bl.length) h += '<div class="cmeta">Aucune recette en attente. Utilise « + » sur un jour, ou planifie sans date depuis Recettes.</div>';
    else h += '<div class="plchips">' + bl.map(m => '<div class="plchip" data-meal="' + m.recipe_id + '" data-date="">🍽️ <span>' + m.name + '</span></div>').join('') + '</div>';
    h += '</div></div>';
    return h;
  }
  function plDayKey(off) {
    const dd = new Date(); dd.setHours(12, 0, 0, 0); dd.setDate(dd.getDate() + (off == null ? plDayOff : off));
    return { d: dd, key: ymd(dd) };
  }
  function renderDayView(d) {
    const { d: dd, key } = plDayKey();
    const todayKey = ymd(new Date());
    const meals = (d.planned || []).filter(x => x.date === key);
    const lab = PL_JOURS[(dd.getDay() + 6) % 7] + ' ' + dd.getDate() + ' ' + dd.toLocaleDateString('fr-FR', { month: 'long' });
    let h = '<div class="pltool"><span class="plnav" id="plDPrev" title="Jour précédent">◀</span>' +
      '<span class="plrange">' + lab + (key === todayKey ? ' · aujourd\'hui' : '') + '</span>' +
      '<span class="plnav" id="plDNext" title="Jour suivant">▶</span>' +
      (plDayOff ? '<button class="wch" id="plDToday">Aujourd\'hui</button>' : '') +
      '<span style="margin-left:auto;font-size:12px;color:var(--faint)">' +
      meals.length + ' repas</span>' + plTabs() + '</div>';
    h += '<div class="plbody"><div class="pldview"><div class="pldmeals">';
    if (!meals.length) h += '<div class="cmeta" style="padding:20px 0;text-align:center">Aucun repas planifié ce jour-là.</div>';
    else h += meals.map(m => '<div class="pldmeal" data-meal="' + m.recipe_id + '" data-date="' + key + '">' +
      plThumb(m) + '<span style="flex:1;min-width:0"><span class="pln">' + m.name + '</span>' +
      (plMeta(m) ? '<div class="plm">' + plMeta(m) + '</div>' : '') + '</span></div>').join('');
    h += '</div><button class="pldadd" data-addday="' + key + '" title="Ajouter un repas">+ Ajouter un repas</button></div></div>';
    return h;
  }
  function plYearRange(off) {
    const y = new Date().getFullYear() + (off == null ? plYearOff : off);
    return y;
  }
  function renderYearView(d) {
    const y = plYearRange();
    const byMonth = {};
    (d.planned || []).forEach(x => {
      const dt = new Date(x.date + 'T12:00:00');
      if (dt.getFullYear() !== y) return;
      const mm = dt.getMonth(); (byMonth[mm] = byMonth[mm] || []).push(Object.assign({ _dt: dt }, x));
    });
    Object.values(byMonth).forEach(arr => arr.sort((a, b) => a._dt - b._dt));
    const total = Object.values(byMonth).reduce((n, a) => n + a.length, 0);
    const MN = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
    let h = '<div class="pltool"><span class="plnav" id="plYPrev" title="Année précédente">◀</span>' +
      '<span class="plrange">' + y + '</span>' +
      '<span class="plnav" id="plYNext" title="Année suivante">▶</span>' +
      (plYearOff ? '<button class="wch" id="plYToday">Année en cours</button>' : '') +
      '<span style="margin-left:auto;font-size:12px;color:var(--faint)">' + total + ' repas planifié' + (total > 1 ? 's' : '') + '</span>' + plTabs() + '</div>';
    const MAXROWS = 5;
    h += '<div class="plbody"><div class="plyear">' + MN.map((nm, i) => {
      const arr = byMonth[i] || [];
      const shown = arr.slice(0, MAXROWS);
      return '<div class="plycard"><div class="plyh">' + nm + '</div>' +
        (shown.length ? shown.map(m => '<div class="plyrow"><span class="plyl">' + m.name + '</span><span class="plyd">' + m._dt.getDate() + '</span></div>').join('') : '<div class="plyrow" style="color:var(--faint)">—</div>') +
        (arr.length > MAXROWS ? '<div class="plymore">+ ' + (arr.length - MAXROWS) + ' autre' + (arr.length - MAXROWS > 1 ? 's' : '') + '</div>' : '') +
        '</div>';
    }).join('') + '</div></div>';
    return h;
  }
  function renderPlanner(d) {
    if (plMode === 'day') return renderDayView(d);
    if (plMode === 'year') return renderYearView(d);
    return renderWeekView(d);
  }
  function plSheet(inner, width) {
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox" style="width:' + (width || 460) + 'px">' + inner + '</div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    const cb = sh.querySelector('.catclose'); if (cb) cb.addEventListener('click', close);
    return { sh, close };
  }
  function koPickDay(nom, cb) {
    const days = plDays(0);
    const opt = ({ d: dd, key }) => {
      const lab = PL_JOURS[(dd.getDay() + 6) % 7] + ' ' + dd.getDate() + ' ' + dd.toLocaleDateString('fr-FR', { month: 'short' });
      return '<div class="catopt" data-key="' + key + '" data-lab="' + lab.toLowerCase() + '" style="min-height:48px">📅 ' + lab + '</div>';
    };
    const sh = document.createElement('div'); sh.className = 'evsheet';
    sh.innerHTML = '<div class="evbox" style="width:420px"><div class="evtitle">📅 ' + nom + '</div>' +
      '<div class="tprecs">Quel jour veux-tu le cuisiner ?</div>' +
      '<div style="max-height:320px;overflow:auto">' + days.map(opt).join('') +
      '<div class="catopt" data-key="" data-lab="sans date" style="min-height:48px">— Sans date (à planifier)</div></div>' +
      '<button class="catclose">Annuler</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('.catclose').addEventListener('click', close);
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    sh.querySelectorAll('[data-key]').forEach(o => o.addEventListener('click', async () => { close(); await cb(o.dataset.key, o.dataset.lab); }));
  }
  function wirePlanner(kind, el, sdk, tile, d) {
    const rerender = () => renderKitchen(kind, el, sdk, tile);
    const days = plDays();
    const nav = (id, fn) => { const b = document.getElementById(id); if (b) b.addEventListener('click', fn); };
    nav('plPrev', () => { plOffset--; rerender(); });
    nav('plNext', () => { plOffset++; rerender(); });
    nav('plToday', () => { plOffset = 0; rerender(); });
    nav('plDPrev', () => { plDayOff--; rerender(); });
    nav('plDNext', () => { plDayOff++; rerender(); });
    nav('plDToday', () => { plDayOff = 0; rerender(); });
    nav('plYPrev', () => { plYearOff--; rerender(); });
    nav('plYNext', () => { plYearOff++; rerender(); });
    nav('plYToday', () => { plYearOff = 0; rerender(); });
    el.querySelectorAll('[data-plmode]').forEach(b => b.addEventListener('click', () => { plMode = b.dataset.plmode; rerender(); }));
    el.querySelectorAll('[data-addday]').forEach(b => b.addEventListener('click', () => {
      const key = b.dataset.addday;
      const recs = d.recipes || [];
      if (!recs.length) { sdk.toast('Aucune recette dans KitchenOwl'); return; }
      const dd = new Date(key + 'T12:00:00');
      const titre = PL_JOURS[(dd.getDay() + 6) % 7] + ' ' + dd.getDate() + ' ' + dd.toLocaleDateString('fr-FR', { month: 'long' });
      const rows = r => '<div class="catopt" data-r="' + r.id + '" data-n="' + r.name.replace(/"/g, '&quot;') + '" style="min-height:48px">' +
        '🍽️ <span style="flex:1;min-width:0">' + r.name + '</span>' +
        (plMeta(r) ? '<span class="cmeta" style="white-space:nowrap">' + plMeta(r) + '</span>' : '') + '</div>';
      const { sh, close } = plSheet('<div class="evtitle">📅 ' + titre + '</div>' +
        '<div class="tprecs">Choisis une recette à planifier.</div>' +
        '<input class="plsearch" id="plQ" placeholder="Rechercher une recette…" autocomplete="off">' +
        '<div id="plList" style="max-height:300px;overflow:auto">' + recs.map(rows).join('') + '</div>' +
        '<button class="catclose">Annuler</button>');
      const q = sh.querySelector('#plQ'), list = sh.querySelector('#plList');
      const wire = () => list.querySelectorAll('[data-r]').forEach(o => o.addEventListener('click', async () => {
        close();
        const j = await post('repas', '/planner/add', { recipe_id: parseInt(o.dataset.r), date: key });
        if (j.ok) sdk.toast('« ' + o.dataset.n + ' » planifié le ' + dd.getDate() + '/' + (dd.getMonth() + 1));
        else sdk.toast('Impossible — ' + (j.reason || ''));
        rerender();
      }));
      q.addEventListener('input', () => {
        const nq = norm(q.value.trim());
        const vis = recs.filter(r => !nq || norm(r.name).includes(nq));
        list.innerHTML = vis.length ? vis.map(rows).join('') : '<div class="cmeta" style="padding:14px;text-align:center">Aucune recette ne correspond.</div>';
        wire();
      });
      wire();
      setTimeout(() => q.focus(), 60);
    }));
    el.querySelectorAll('[data-meal]').forEach(elm => elm.addEventListener('click', () => {
      const rid = parseInt(elm.dataset.meal), key = elm.dataset.date;
      const src = key ? (d.planned || []) : (d.backlog || []);
      const m = src.find(x => x.recipe_id === rid && x.date === key); if (!m) return;
      let dLab = 'sans date';
      if (key) { const dd = new Date(key + 'T12:00:00'); dLab = PL_JOURS[(dd.getDay() + 6) % 7].toLowerCase() + ' ' + dd.getDate() + ' ' + dd.toLocaleDateString('fr-FR', { month: 'long' }); }
      const { sh, close } = plSheet('<div class="evtitle">🍽️ ' + m.name + '</div>' +
        '<div class="tprecs">Planifié ' + (key ? 'le ' : '') + dLab + (plMeta(m) ? ' · ' + plMeta(m) : '') + '</div>' +
        (m.photo ? '<div style="margin:8px 0">' + plThumb(m) + '</div>' : '') +
        '<button class="plact" id="plShop">🛒 Ajouter les ingrédients aux courses</button>' +
        (key ? '<button class="plact" id="plMove">📅 Déplacer à un autre jour</button>' : '<button class="plact" id="plMove">📅 Donner une date</button>') +
        '<button class="plact bad" id="plDel">🗑️ Retirer du planning</button>' +
        '<button class="catclose">Fermer</button>');
      sh.querySelector('#plShop').addEventListener('click', async () => {
        close(); sdk.toast('Envoi des ingrédients…');
        const j = await post('repas', '/planner/shop', { recipe_id: rid });
        sdk.toast(j.ok ? (j.count + ' ingrédient' + (j.count > 1 ? 's ajoutés' : ' ajouté') + ' aux courses') : ('Impossible — ' + (j.reason || '')));
      });
      sh.querySelector('#plDel').addEventListener('click', async () => {
        close();
        const j = await post('repas', '/planner/remove', { recipe_id: rid, date: key });
        if (j.ok) sdk.toast('« ' + m.name + ' » retiré du planning'); else sdk.toast('Impossible — ' + (j.reason || ''));
        rerender();
      });
      sh.querySelector('#plMove').addEventListener('click', () => {
        close();
        const opts = days.map(({ d: dd, key: k }) => '<div class="catopt" data-mv="' + k + '" style="min-height:48px">📅 ' + PL_JOURS[(dd.getDay() + 6) % 7] + ' ' + dd.getDate() + '</div>').join('') +
          (key ? '<div class="catopt" data-mv="" style="min-height:48px">— Retirer la date (à planifier)</div>' : '');
        const { sh: s2, close: c2 } = plSheet('<div class="evtitle">📅 Déplacer « ' + m.name + ' »</div>' +
          '<div style="max-height:320px;overflow:auto;margin-top:8px">' + opts + '</div>' +
          '<button class="catclose">Annuler</button>');
        s2.querySelectorAll('[data-mv]').forEach(o => o.addEventListener('click', async () => {
          const nk = o.dataset.mv; c2();
          if (nk === key) { return; }
          const rm = await post('repas', '/planner/remove', { recipe_id: rid, date: key });
          if (!rm.ok) { sdk.toast('Impossible — ' + (rm.reason || '')); rerender(); return; }
          const ad = await post('repas', '/planner/add', { recipe_id: rid, date: nk });
          sdk.toast(ad.ok ? 'Repas déplacé' : ('Déplacement partiel — ' + (ad.reason || '')));
          rerender();
        }));
      });
    }));
  }

  /* ---- API publique du module ---- */
  return {
    renderHub,
    render(kind, el, sdk, tile) { renderKitchen(kind, el, sdk, tile); },
    unmount() { stopTimer(); document.querySelectorAll('.catsheet,.evsheet').forEach(x => x.remove()); }
  };
})();

window.PandaAddons=window.PandaAddons||{};
window.PandaAddons.repas={render(el,sdk,tile){window.PandaKitchen.render('repas',el,sdk,tile);},unmount(){window.PandaKitchen.unmount();}};
window.PandaAddons.recettes={render(el,sdk,tile){window.PandaKitchen.render('recettes',el,sdk,tile);},unmount(){window.PandaKitchen.unmount();}};
window.PandaAddons.repas={render(el,sdk,tile){window.PandaKitchen.render('repas',el,sdk,tile);},unmount(){window.PandaKitchen.unmount();}};
