"""Addon « repas » — consommateur de KitchenOwl (lot G-d).

Dernier addon cuisine basculé : planificateur de repas. Coquille sans logique
KitchenOwl, délègue au fournisseur « kitchenowl » via sdk.use. Les photos des
repas planifiés (qui sont des photos de recettes) sont relayées ici.
"""


def register(sdk):
    import re
    from flask import Blueprint, jsonify, request, Response
    bp = Blueprint("repas", __name__)

    def _ko():
        return sdk.use("kitchenowl")

    def _guard(fn):
        try:
            return jsonify(fn(_ko()))
        except LookupError:
            return jsonify({"ok": False, "reason": "hub KitchenOwl indisponible"})
        except Exception as e:
            sdk.log.exception("repas")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/view")
    def view():
        return _guard(lambda ko: ko.view("repas"))

    @bp.route("/planner/add", methods=["POST"])
    def planner_add():
        j = request.get_json(force=True, silent=True) or {}
        if j.get("recipe_id") is None:
            return jsonify({"ok": False, "reason": "recette manquante"}), 400
        return _guard(lambda ko: ko.planner_add(
            j.get("recipe_id"), j.get("date") or "", j.get("yields")))

    @bp.route("/planner/remove", methods=["POST"])
    def planner_remove():
        j = request.get_json(force=True, silent=True) or {}
        if j.get("recipe_id") is None:
            return jsonify({"ok": False, "reason": "recette manquante"}), 400
        return _guard(lambda ko: ko.planner_remove(
            j.get("recipe_id"), j.get("date") or ""))

    @bp.route("/planner/shop", methods=["POST"])
    def planner_shop():
        j = request.get_json(force=True, silent=True) or {}
        if j.get("recipe_id") is None:
            return jsonify({"ok": False, "reason": "recette manquante"}), 400
        return _guard(lambda ko: ko.planner_shop(j.get("recipe_id"), j.get("list_id")))

    @bp.route("/photo/<path:name>")
    def photo(name):
        if not re.fullmatch(r"[A-Za-z0-9._/-]{1,160}", name):
            return Response("nom invalide", status=400)
        try:
            ko = _ko()
        except LookupError:
            return Response(status=404)
        res = ko.photo_fetch(name)
        if not res:
            return Response(status=404)
        content, ct = res
        return Response(content, content_type=ct)

    return bp
