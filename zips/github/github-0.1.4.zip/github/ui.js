/* GitHub — repos, notifications, issues/PR ouvertes, activité récente. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.github = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  const ACCENT = '#58a6ff';
  const CSS =
    "  .ghwrap{flex:1;display:flex;flex-direction:column;min-height:0;--gh:" + ACCENT + "}\n" +
    "  .ghtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .ghtotals{display:flex;gap:16px;flex:1;flex-wrap:wrap}\n" +
    "  .ghtk{text-align:center}\n" +
    "  .ghtk b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--gh)}\n" +
    "  .ghtk.warn b{color:var(--warn)}\n" +
    "  .ghtk span{font-size:11px;color:var(--dim)}\n" +
    "  .ghvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .ghvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .ghvtoggle button.on{background:var(--tile);color:var(--gh)}\n" +
    "  .ghscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .ghsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:16px 0 9px;display:flex;align-items:center;gap:8px}\n" +
    "  .ghsec:first-child{margin-top:0}\n" +
    "  .ghsec .c{color:var(--gh)}\n" +
    "  .ghnotif{display:flex;align-items:flex-start;gap:10px;background:rgba(88,166,255,.08);border:1px solid rgba(88,166,255,.3);border-radius:10px;padding:9px 13px;margin-bottom:6px}\n" +
    "  .ghnr{font-size:11px;color:var(--gh);font-weight:600;flex:none;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghnt{font-size:12.5px;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghntype{font-size:10px;color:var(--dim);flex:none}\n" +
    "  .ghitem{display:flex;align-items:center;gap:10px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:6px}\n" +
    "  .ghinum{font-size:11px;color:var(--dim);flex:none;font-variant-numeric:tabular-nums}\n" +
    "  .ghit{font-size:13px;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghir{font-size:10.5px;color:var(--dim);flex:none;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghev{display:flex;align-items:center;gap:9px;padding:6px 4px;font-size:12.5px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .ghev:last-child{border-bottom:0}\n" +
    "  .ghevl{color:var(--dim);flex:none}\n" +
    "  .ghevr{color:var(--gh);font-weight:600;flex:none;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghevd{min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dim)}\n" +
    "  .ghgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(225px,1fr));gap:11px}\n" +
    "  .ghcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:11px 13px;display:flex;flex-direction:column;gap:6px;cursor:pointer}\n" +
    "  .ghcard:hover{border-color:var(--gh)}\n" +
    "  .ghchead{display:flex;align-items:center;gap:7px}\n" +
    "  .ghcname{font-weight:700;font-size:13.5px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .ghpriv{font-size:9.5px;border:1px solid var(--border-soft);border-radius:6px;padding:1px 6px;color:var(--dim);flex:none}\n" +
    "  .ghcdesc{font-size:11.5px;color:var(--dim);line-height:1.35;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;min-height:16px}\n" +
    "  .ghcstats{display:flex;gap:9px;font-size:11px;color:var(--dim);font-variant-numeric:tabular-nums}\n" +
    "  .ghlang{display:inline-flex;align-items:center;gap:4px}\n" +
    "  .ghldot{width:8px;height:8px;border-radius:50%;background:var(--gh)}\n" +
    "  .ghrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 13px;margin-bottom:6px;cursor:pointer}\n" +
    "  .ghrow:hover{border-color:var(--gh)}\n" +
    "  .ghrtx{min-width:0;flex:1}\n" +
    "  .ghrname{font-weight:600;font-size:13.5px}\n" +
    "  .ghrmeta{font-size:11px;color:var(--dim)}\n" +
    "  .ghrstats{font-size:11.5px;color:var(--dim);flex:none;font-variant-numeric:tabular-nums}\n" +
    "  .ghempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    "  .ghcols{display:flex;gap:14px;align-items:flex-start}\n" +
    "  .ghmain{flex:1;min-width:0}\n" +
    "  .ghside{width:295px;flex:none;display:flex;flex-direction:column;gap:12px}\n" +
    "  .ghpanel{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:11px 13px;max-height:46vh;overflow-y:auto}\n" +
    "  .ghptitle{font-size:11.5px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px;display:flex;align-items:center;gap:6px}\n" +
    "  .ghptitle .c{color:var(--gh)}\n" +
    "  .ghside .ghnotif{background:transparent;border:0;border-bottom:1px solid var(--border-soft);border-radius:0;padding:7px 0;margin:0;flex-direction:column;gap:2px}\n" +
    "  .ghside .ghnotif:last-child{border-bottom:0}\n" +
    "  .ghside .ghitem{background:transparent;border:0;border-bottom:1px solid var(--border-soft);border-radius:0;padding:7px 0;margin:0}\n" +
    "  .ghside .ghitem:last-child{border-bottom:0}\n" +
    "  .ghside .ghev{padding:6px 0}";
  function ensureCss() { let s = document.getElementById('ghUiCss'); if (!s) { s = document.createElement('style'); s.id = 'ghUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  function ago(iso) {
    if (!iso) return '';
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 3600) return Math.max(1, Math.round(s / 60)) + ' min';
    if (s < 86400) return Math.round(s / 3600) + ' h';
    if (s < 2592000) return Math.round(s / 86400) + ' j';
    return new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de GitHub…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/data'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function repoCard(r) {
    return '<div class="ghcard" data-url="' + esc(r.url) + '">' +
      '<div class="ghchead"><span class="ghcname">' + esc(r.name) + '</span>' +
      (r.private ? '<span class="ghpriv">privé</span>' : '') + '</div>' +
      '<div class="ghcdesc">' + esc(r.desc || '') + '</div>' +
      '<div class="ghcstats">' +
      (r.lang ? '<span class="ghlang"><span class="ghldot"></span>' + esc(r.lang) + '</span>' : '') +
      '<span>★ ' + nf(r.stars) + '</span>' +
      (r.issues ? '<span>◉ ' + nf(r.issues) + '</span>' : '') +
      '<span style="margin-left:auto">' + ago(r.pushed) + '</span></div></div>';
  }
  function repoRow(r) {
    return '<div class="ghrow" data-url="' + esc(r.url) + '">' +
      '<div class="ghrtx"><div class="ghrname">' + esc(r.name) + (r.private ? ' <span class="ghpriv">privé</span>' : '') + '</div>' +
      '<div class="ghrmeta">' + esc(r.lang || '') + (r.desc ? ' · ' + esc(r.desc) : '') + '</div></div>' +
      '<span class="ghrstats">★ ' + nf(r.stars) + (r.issues ? ' · ◉ ' + nf(r.issues) : '') + ' · ' + ago(r.pushed) + '</span></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🐙</div><div class="t1">GitHub indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne ton token (PAT, scopes repo + notifications) dans ⚙.</div>' +
        '<button class="btnpill install" id="ghRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('ghRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="ghwrap"><div class="ghtopbar"><div class="ghtotals">' +
      '<div class="ghtk"><b>' + nf(d.repos_count) + '</b><span>dépôts</span></div>' +
      '<div class="ghtk"><b>' + nf(d.stars_total) + '</b><span>étoiles</span></div>' +
      (d.issues_open != null ? '<div class="ghtk"><b>' + nf(d.issues_open) + '</b><span>issues</span></div>' : '') +
      (d.prs_open != null ? '<div class="ghtk"><b>' + nf(d.prs_open) + '</b><span>PR</span></div>' : '') +
      (d.notifs_count != null ? '<div class="ghtk warn"><b>' + nf(d.notifs_count) + '</b><span>notifs</span></div>' : '') +
      '</div><div class="ghvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div><div class="ghscroll"><div class="ghcols">';

    // ── Colonne gauche : dépôts
    h += '<div class="ghmain">';
    h += '<div class="ghsec">📦 Dépôts <span class="c">' + nf(d.repos_count) + '</span>' +
      (d.repos_private ? '<span style="font-weight:400;text-transform:none;letter-spacing:0">dont ' + d.repos_private + ' privés</span>' : '') + '</div>';
    if (!d.repos || !d.repos.length) h += '<div class="ghempty">Aucun dépôt.</div>';
    else if (viewMode === 'cards') h += '<div class="ghgrid">' + d.repos.map(repoCard).join('') + '</div>';
    else h += d.repos.map(repoRow).join('');
    h += '</div>';

    // ── Colonne droite : notifications, issues, PR, activité (panneaux empilés)
    h += '<div class="ghside">';
    if (d.notifs && d.notifs.length) {
      h += '<div class="ghpanel"><div class="ghptitle">🔔 Notifications <span class="c">' + d.notifs.length + '</span></div>';
      h += d.notifs.slice(0, 8).map(n => '<div class="ghnotif"><span class="ghnr">' + esc(n.repo) + '</span>' +
        '<span class="ghnt">' + esc(n.title) + '</span></div>').join('') + '</div>';
    }
    if (d.issues && d.issues.length) {
      h += '<div class="ghpanel"><div class="ghptitle">◉ Issues <span class="c">' + nf(d.issues_open) + '</span></div>';
      h += d.issues.slice(0, 6).map(i => '<div class="ghitem"><span class="ghinum">#' + i.number + '</span>' +
        '<span class="ghit">' + esc(i.title) + '</span></div>').join('') + '</div>';
    }
    if (d.prs && d.prs.length) {
      h += '<div class="ghpanel"><div class="ghptitle">⇄ Pull requests <span class="c">' + nf(d.prs_open) + '</span></div>';
      h += d.prs.slice(0, 6).map(p => '<div class="ghitem"><span class="ghinum">#' + p.number + '</span>' +
        '<span class="ghit">' + esc(p.title) + '</span></div>').join('') + '</div>';
    }
    if (d.events && d.events.length) {
      h += '<div class="ghpanel"><div class="ghptitle">⚡ Activité</div>';
      h += d.events.slice(0, 10).map(e => '<div class="ghev"><span class="ghevl">' + esc(e.label) + '</span>' +
        '<span class="ghevr">' + esc((e.repo || '').split('/').pop()) + '</span>' +
        '<span class="ghevl" style="margin-left:auto">' + ago(e.date) + '</span></div>').join('') + '</div>';
    }
    h += '</div>';   // ghside

    h += '</div></div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.ghvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    el.querySelectorAll('[data-url]').forEach(n => n.addEventListener('click', () => {
      const u = n.getAttribute('data-url');
      if (u) { try { S.openService(u); } catch (e) { window.open(u, '_blank'); } }
    }));
  }

  return { render };
})();
