"""Addon GitHub — repos, notifications, issues/PR ouvertes, activité (API v3, PAT)."""

API = "https://api.github.com"


def _cfg(cfg):
    m = (cfg or {}).get("modules", {}).get("github", {}) if "modules" in (cfg or {}) else (cfg or {})
    return (m.get("token") or "").strip()


def _get(sdk, token, path, params=None, timeout=10):
    r = sdk.requests.get(API + path, params=params or {}, timeout=timeout,
                         headers={"Authorization": "Bearer " + token,
                                  "Accept": "application/vnd.github+json",
                                  "X-GitHub-Api-Version": "2022-11-28"})
    if r.status_code == 401:
        raise PermissionError("token invalide")
    if r.status_code == 403:
        raise PermissionError("accès refusé (scope manquant ou rate limit)")
    r.raise_for_status()
    return r.json()


_EVENT_FR = {
    "PushEvent": "a poussé sur",
    "CreateEvent": "a créé",
    "DeleteEvent": "a supprimé",
    "IssuesEvent": "issue sur",
    "IssueCommentEvent": "a commenté",
    "PullRequestEvent": "PR sur",
    "PullRequestReviewEvent": "a relu",
    "WatchEvent": "a étoilé",
    "ForkEvent": "a forké",
    "ReleaseEvent": "release sur",
    "PublicEvent": "a rendu public",
}


def _shape_event(e):
    typ = e.get("type") or ""
    repo = (e.get("repo") or {}).get("name") or ""
    label = _EVENT_FR.get(typ, typ.replace("Event", ""))
    detail = ""
    p = e.get("payload") or {}
    if typ == "PushEvent":
        commits = p.get("commits") or []
        if commits:
            detail = (commits[-1].get("message") or "").split("\n")[0][:80]
    elif typ in ("IssuesEvent", "PullRequestEvent"):
        detail = ((p.get("issue") or p.get("pull_request") or {}).get("title") or "")[:80]
        act = p.get("action")
        if act:
            label = f"{label} ({act})"
    elif typ == "ReleaseEvent":
        detail = ((p.get("release") or {}).get("name") or "")[:80]
    return {"type": typ, "label": label, "repo": repo,
            "detail": detail, "date": e.get("created_at")}


def _data(sdk, cfg):
    token = _cfg(cfg)
    if not token:
        return {"ok": False, "reason": "token requis (⚙)"}

    user = _get(sdk, token, "/user")
    login = user.get("login") or ""

    out = {"ok": True, "login": login, "name": user.get("name") or login,
           "avatar": user.get("avatar_url")}

    # Repos (owner) triés par dernier push
    repos = _get(sdk, token, "/user/repos",
                 params={"affiliation": "owner", "sort": "pushed", "per_page": 50})
    if isinstance(repos, list):
        out["repos_count"] = len(repos)
        out["repos_private"] = sum(1 for r in repos if r.get("private"))
        out["stars_total"] = sum(r.get("stargazers_count") or 0 for r in repos)
        out["repos"] = [{
            "name": r.get("name"),
            "full": r.get("full_name"),
            "private": bool(r.get("private")),
            "stars": r.get("stargazers_count") or 0,
            "forks": r.get("forks_count") or 0,
            "issues": r.get("open_issues_count") or 0,
            "lang": r.get("language"),
            "pushed": r.get("pushed_at"),
            "desc": (r.get("description") or "")[:100],
            "url": r.get("html_url"),
        } for r in repos]

    # Notifications non lues (scope notifications) — tolérant si scope absent
    try:
        notifs = _get(sdk, token, "/notifications", params={"per_page": 15})
        out["notifs"] = [{
            "repo": (n.get("repository") or {}).get("full_name") or "",
            "title": ((n.get("subject") or {}).get("title") or "")[:90],
            "type": (n.get("subject") or {}).get("type") or "",
            "reason": n.get("reason") or "",
            "date": n.get("updated_at"),
        } for n in (notifs if isinstance(notifs, list) else [])]
        out["notifs_count"] = len(out["notifs"])
    except Exception:
        out["notifs"] = []
        out["notifs_count"] = None  # scope manquant

    # Issues et PR ouvertes (à travers tous les repos du compte)
    try:
        iss = _get(sdk, token, "/search/issues",
                   params={"q": f"user:{login} is:open is:issue", "per_page": 10})
        out["issues_open"] = iss.get("total_count", 0)
        out["issues"] = [{
            "title": (i.get("title") or "")[:90],
            "repo": "/".join((i.get("repository_url") or "").split("/")[-2:]),
            "number": i.get("number"),
            "date": i.get("updated_at"),
        } for i in iss.get("items", [])]
    except Exception:
        out["issues_open"], out["issues"] = None, []
    try:
        prs = _get(sdk, token, "/search/issues",
                   params={"q": f"user:{login} is:open is:pr", "per_page": 10})
        out["prs_open"] = prs.get("total_count", 0)
        out["prs"] = [{
            "title": (p.get("title") or "")[:90],
            "repo": "/".join((p.get("repository_url") or "").split("/")[-2:]),
            "number": p.get("number"),
            "date": p.get("updated_at"),
        } for p in prs.get("items", [])]
    except Exception:
        out["prs_open"], out["prs"] = None, []

    # Activité récente
    try:
        events = _get(sdk, token, f"/users/{login}/events", params={"per_page": 15})
        out["events"] = [_shape_event(e) for e in (events if isinstance(events, list) else [])]
    except Exception:
        out["events"] = []

    return out


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("addon_github", __name__)

    @bp.route("/data")
    def data():
        try:
            return jsonify(_data(sdk, sdk.config()))
        except PermissionError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": f"connexion : {type(e).__name__}"[:100]})
        except Exception as e:
            sdk.log.exception("github")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    token = _cfg(cfg)
    if not token:
        return False, "token requis"
    try:
        u = _get(sdk, token, "/user", timeout=6)
        return True, f"connecté : {u.get('login')}"
    except PermissionError as e:
        return False, str(e)
    except Exception as e:
        return False, f"{type(e).__name__}"[:60]
