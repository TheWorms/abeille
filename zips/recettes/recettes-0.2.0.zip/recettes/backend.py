"""Addon « recettes » — consommateur de KitchenOwl + Corbeille (lot G-c).

Délègue l'accès KitchenOwl au fournisseur « kitchenowl » et l'archivage des
suppressions au fournisseur « corbeille » (tous deux dans requires). La
corbeille recettes vit désormais dans le data_dir de « corbeille » (source
« recettes ») — pérenne (survit aux redéploiements) et partagée avec les
autres consommateurs (instagram plus tard).

Sécurité : les routes /recipe/trash* sont réservées à l'admin. Le guard du
noyau n'impose que l'authentification simple ; on revérifie donc ici
``session.get("admin")`` pour ces trois routes (parité avec l'ancien
@require_admin).
"""


def register(sdk):
    import re
    from datetime import datetime
    from flask import Blueprint, jsonify, request, session, Response
    bp = Blueprint("recettes", __name__)

    def _ko():
        return sdk.use("kitchenowl")

    def _trash():
        return sdk.use("corbeille")

    def _guard(fn):
        try:
            return jsonify(fn(_ko()))
        except LookupError:
            return jsonify({"ok": False, "reason": "hub KitchenOwl indisponible"})
        except Exception as e:
            sdk.log.exception("recettes")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    def _admin():
        return bool(session.get("admin"))

    # ------------------------------------------------------------- lecture
    @bp.route("/view")
    def view():
        return _guard(lambda ko: ko.view("recettes"))

    # ------------------------------------------------------------- écritures
    @bp.route("/recipe/scrape", methods=["POST"])
    def scrape():
        j = request.get_json(force=True, silent=True) or {}
        return _guard(lambda ko: ko.recipe_scrape(j.get("url")))

    @bp.route("/recipe/add", methods=["POST"])
    def add():
        j = request.get_json(force=True, silent=True) or {}
        mode = (j.get("mode") or "").strip()
        return _guard(lambda ko: ko.recipe_add(j, mode))

    @bp.route("/recipe/tag", methods=["POST"])
    def tag():
        j = request.get_json(force=True, silent=True) or {}
        return _guard(lambda ko: ko.recipe_tag(j.get("id"), j.get("tags")))

    @bp.route("/recipe/delete", methods=["POST"])
    def delete():
        """Archive la recette dans la corbeille puis la supprime de KitchenOwl.
        En cas d'échec de suppression, l'archive est retirée (pas d'orpheline)."""
        j = request.get_json(force=True, silent=True) or {}
        rid = j.get("id")
        if not rid:
            return jsonify({"ok": False, "reason": "recette manquante"}), 400
        try:
            ko, trash = _ko(), _trash()
        except LookupError:
            return jsonify({"ok": False, "reason": "hub/corbeille indisponible"})
        try:
            detail = ko.recipe_get(rid)
            if not detail:
                return jsonify({"ok": False, "reason": "recette introuvable"})
            trash.put("recettes", rid, detail)
            res = ko.recipe_delete_raw(rid)
            if res.get("ok"):
                return jsonify({"ok": True, "name": detail.get("name", "")})
            trash.restore("recettes", rid)   # suppression KO échouée : pas d'archive orpheline
            return jsonify({"ok": False, "reason": res.get("reason")})
        except Exception as e:
            sdk.log.exception("recettes.delete")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    # ------------------------------------------------------------- corbeille (admin)
    @bp.route("/recipe/trash")
    def trash_list():
        if not _admin():
            return jsonify(error="admin_required"), 403
        try:
            trash = _trash()
        except LookupError:
            return jsonify({"ok": False, "reason": "corbeille indisponible"})
        items = []
        for e in trash.list("recettes"):
            p = e.get("payload") or {}
            items.append({"file": e.get("id"), "name": p.get("name", "?"),
                          "time": p.get("time") or 0,
                          "when": datetime.fromtimestamp(
                              e.get("deleted_at") or 0).strftime("%d/%m %H:%M")})
        return jsonify({"ok": True, "items": items, "count": len(items)})

    @bp.route("/recipe/trash/restore", methods=["POST"])
    def trash_restore():
        if not _admin():
            return jsonify(error="admin_required"), 403
        j = request.get_json(force=True, silent=True) or {}
        fid = str(j.get("file") or "").strip()
        if not fid:
            return jsonify({"ok": False, "reason": "fichier invalide"}), 400
        try:
            ko, trash = _ko(), _trash()
        except LookupError:
            return jsonify({"ok": False, "reason": "hub/corbeille indisponible"})
        entry = trash.get("recettes", fid)
        if not entry:
            return jsonify({"ok": False, "reason": "introuvable"}), 404
        d = entry.get("payload") or {}
        payload = {k: d.get(k) for k in ("name", "description", "time", "yields",
                                         "source", "photo") if d.get(k)}
        tg = d.get("tags") or []
        noms = [(t.get("name") if isinstance(t, dict) else str(t)) for t in tg]
        noms = [n for n in noms if n]
        if noms:
            payload["tags"] = noms
        items = d.get("items") or []
        if items:
            payload["items"] = [{"name": (i.get("name") if isinstance(i, dict) else str(i)),
                                 "description": (i.get("description", "")
                                                 if isinstance(i, dict) else "")}
                                for i in items]
        res = ko.recipe_create(payload)
        if res.get("ok"):
            trash.restore("recettes", fid)   # recréée : on retire de la corbeille
            return jsonify({"ok": True, "name": payload.get("name", "")})
        return jsonify({"ok": False, "reason": res.get("reason")})

    @bp.route("/recipe/trash/purge", methods=["POST"])
    def trash_purge():
        if not _admin():
            return jsonify(error="admin_required"), 403
        j = request.get_json(force=True, silent=True) or {}
        files = j.get("files") or []
        try:
            trash = _trash()
        except LookupError:
            return jsonify({"ok": False, "reason": "corbeille indisponible"})
        if files:
            n = 0
            for f in files:
                if trash.restore("recettes", str(f)) is not None:
                    n += 1
            return jsonify({"ok": True, "removed": n})
        return jsonify({"ok": True, "removed": trash.purge("recettes")})

    # ------------------------------------------------------------- photo (binaire)
    @bp.route("/photo/<path:name>")
    def photo(name):
        if not re.fullmatch(r"[A-Za-z0-9._/-]{1,160}", name):
            return Response("nom invalide", status=400)
        try:
            ko = _ko()
        except LookupError:
            return Response(status=404)
        res = ko.photo_fetch(name)
        if not res:
            return Response(status=404)
        content, ct = res
        return Response(content, content_type=ct)

    return bp
