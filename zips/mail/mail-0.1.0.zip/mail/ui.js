/* Mail — client IMAP (lecture + marquer lu / supprimer). Deux colonnes :
   liste des messages à gauche, lecture du message sélectionné à droite. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.mail = (function () {
  let S = null, root = null, tile = null, sel = null, listCache = null;
  const CSS =
    "  .mlwrap{flex:1;display:flex;flex-direction:column;min-height:0}\n" +
    "  .mlcols{flex:1;display:grid;grid-template-columns:340px 1fr;gap:14px;min-height:0;padding:12px 22px}\n" +
    "  .mllist{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:5px}\n" +
    "  .mlrow{display:flex;flex-direction:column;gap:2px;background:var(--tile);border:1px solid var(--border-soft);\n" +
    "         border-radius:10px;padding:9px 12px;cursor:pointer;min-height:48px}\n" +
    "  .mlrow:active{border-color:var(--accent)}\n" +
    "  .mlrow.sel{border-color:var(--accent);background:var(--accent-tint)}\n" +
    "  .mlrow.unseen{border-left:4px solid var(--accent)}\n" +
    "  .mlrow.unseen .mlfrom,.mlrow.unseen .mlsubj{font-weight:700}\n" +
    "  .mltop{display:flex;align-items:center;gap:8px}\n" +
    "  .mlfrom{font-size:13px;min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n" +
    "  .mldate{font-size:10.5px;color:var(--dim);flex:none;font-variant-numeric:tabular-nums}\n" +
    "  .mlsubj{font-size:12.5px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n" +
    "  .mldot{width:8px;height:8px;border-radius:50%;background:var(--accent);flex:none}\n" +
    "  .mlread{min-height:0;display:flex;flex-direction:column;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px}\n" +
    "  .mlrhead{padding:16px 18px 12px;border-bottom:1px solid var(--border-soft);flex:none}\n" +
    "  .mlrsubj{font-size:17px;font-weight:700;line-height:1.3}\n" +
    "  .mlrmeta{font-size:12px;color:var(--dim);margin-top:6px;line-height:1.5}\n" +
    "  .mlrbody{flex:1;min-height:0;overflow:auto;padding:16px 18px;font-size:13.5px;line-height:1.55;white-space:pre-wrap;word-break:break-word}\n" +
    "  .mlrbody iframe{width:100%;height:100%;border:0;background:#fff;border-radius:8px}\n" +
    "  .mlratt{padding:8px 18px;border-top:1px solid var(--border-soft);font-size:11.5px;color:var(--dim);flex:none}\n" +
    "  .mlract{display:flex;gap:9px;padding:11px 18px;border-top:1px solid var(--border-soft);flex:none}\n" +
    "  .mlbtn{padding:9px 15px;border-radius:9px;border:1px solid var(--border-soft);background:var(--bg);\n" +
    "         color:var(--text);font-size:13px;cursor:pointer;user-select:none}\n" +
    "  .mlbtn:active{border-color:var(--accent);color:var(--accent)}\n" +
    "  .mlbtn.danger{color:var(--bad);border-color:rgba(224,82,82,.4)}\n" +
    "  .mlbtn.danger:active{background:rgba(224,82,82,.14)}\n" +
    "  .mlempty{flex:1;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:14px}\n" +
    "  .mlhead{display:flex;align-items:center;gap:10px;padding:0 22px}\n" +
    "  .mlcount{font-size:12px;color:var(--dim)}";
  function ensureCss() { if (document.getElementById('mlUiCss')) return; const s = document.createElement('style'); s.id = 'mlUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);

  function relDate(iso) {
    if (!iso) return '';
    const d = new Date(iso), now = new Date();
    if (isNaN(d)) return '';
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const days = Math.round((now - d) / 86400000);
    if (days < 7) return d.toLocaleDateString('fr-FR', { weekday: 'short' });
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Connexion IMAP…</div></div>';
    try { const r = await sdk.api('/list'); listCache = await r.json(); }
    catch (e) { listCache = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = listCache;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">✉️</div><div class="t1">Mail indisponible</div>' +
        '<div class="t2">' + esc((d && d.reason) || '') + '<br>Renseigne le serveur IMAP, ton adresse et un <b>mot de passe d\'application</b> dans ⚙.</div>' +
        '<button class="btnpill install" id="mlRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('mlRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const unseen = d.items.filter(x => !x.seen).length;
    let h = '<div class="mlwrap"><div class="wsec mlhead">✉️ ' + esc(d.account || 'Mail') +
      '<span class="mlcount">· ' + esc(d.folder) + ' · ' + d.total + ' message' + (d.total > 1 ? 's' : '') +
      (unseen ? ' · ' + unseen + ' non lu' + (unseen > 1 ? 's' : '') : '') + '</span>' +
      '<button class="wch" id="mlRefresh" style="margin-left:auto">↻</button></div>';
    h += '<div class="mlcols"><div class="mllist" id="mlList">';
    if (!d.items.length) h += '<div class="mlempty">Boîte vide</div>';
    else h += d.items.map(m =>
      '<div class="mlrow' + (m.seen ? '' : ' unseen') + (sel && sel.id === m.id ? ' sel' : '') + '" data-id="' + m.id + '">' +
        '<div class="mltop">' + (m.seen ? '' : '<span class="mldot"></span>') +
          '<span class="mlfrom">' + esc(m.from) + '</span>' +
          '<span class="mldate">' + relDate(m.date) + '</span></div>' +
        '<div class="mlsubj">' + esc(m.subject) + '</div></div>').join('');
    h += '</div>';   // /mllist
    h += '<div class="mlread" id="mlRead"><div class="mlempty">Sélectionne un message</div></div>';
    h += '</div>';   // /mlcols
    h += '<div class="wsrc">IMAP · lecture + marquer lu / supprimer · vue embarquée v0.1.0</div></div>';
    el.innerHTML = h;
    const rf = document.getElementById('mlRefresh'); if (rf) rf.addEventListener('click', () => render(el, S, tile));
    el.querySelectorAll('.mlrow').forEach(r => r.addEventListener('click', () => openMsg(r.dataset.id)));
    if (sel) openMsg(sel.id, true);   // ré-ouvrir la sélection après un refresh
  }

  async function openMsg(id, keepScroll) {
    const box = document.getElementById('mlRead'); if (!box) return;
    box.innerHTML = '<div class="mlempty">Chargement…</div>';
    let m = null;
    try { const r = await S.api('/read?id=' + encodeURIComponent(id)); m = await r.json(); }
    catch (e) { m = { ok: false, reason: 'lecture impossible' }; }
    if (!m || !m.ok) { box.innerHTML = '<div class="mlempty">' + esc((m && m.reason) || 'erreur') + '</div>'; return; }
    sel = { id: id };
    // marquer visuellement lu dans la liste + le cache
    const row = document.querySelector('.mlrow[data-id="' + id + '"]');
    if (row) { row.classList.remove('unseen'); row.classList.add('sel'); const dot = row.querySelector('.mldot'); if (dot) dot.remove(); }
    document.querySelectorAll('.mlrow.sel').forEach(r => { if (r.dataset.id !== id) r.classList.remove('sel'); });
    if (listCache && listCache.items) { const it = listCache.items.find(x => x.id === id); if (it) it.seen = true; }

    let bodyHtml;
    if (m.is_html) {
      // HTML dans une iframe sandbox (pas de script, pas de même origine)
      bodyHtml = '<iframe sandbox="" id="mlFrame"></iframe>';
    } else {
      bodyHtml = esc(m.body);
    }
    let h = '<div class="mlrhead"><div class="mlrsubj">' + esc(m.subject) + '</div>' +
      '<div class="mlrmeta"><b>' + esc(m.from) + '</b>' + (m.to ? '<br>à ' + esc(m.to) : '') +
      (m.date ? '<br>' + new Date(m.date).toLocaleString('fr-FR') : '') + '</div></div>';
    h += '<div class="mlrbody">' + bodyHtml + '</div>';
    if (m.attachments && m.attachments.length)
      h += '<div class="mlratt">📎 ' + m.attachments.map(esc).join(' · ') + '</div>';
    h += '<div class="mlract">' +
      '<button class="mlbtn" id="mlUnseen">◌ Marquer non lu</button>' +
      '<button class="mlbtn danger" id="mlDel">🗑 Supprimer</button></div>';
    box.innerHTML = h;

    if (m.is_html) {
      const fr = document.getElementById('mlFrame');
      if (fr) { fr.srcdoc = m.body; }
    }
    const ub = document.getElementById('mlUnseen');
    if (ub) ub.addEventListener('click', async () => {
      try {
        const r = await S.api('/flag', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id, seen: false }) });
        const j = await r.json();
        if (j.ok) {
          S.toast('Marqué non lu');
          if (listCache) { const it = listCache.items.find(x => x.id === id); if (it) it.seen = false; }
          sel = null; paint();
        } else S.toast(j.reason || 'échec');
      } catch (e) { S.toast('échec'); }
    });
    const db = document.getElementById('mlDel');
    if (db) db.addEventListener('click', async () => {
      if (!confirm('Supprimer ce message ?\nCette action est définitive (expunge IMAP).')) return;
      try {
        const r = await S.api('/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id }) });
        const j = await r.json();
        if (j.ok) { S.toast('Message supprimé'); sel = null; render(root, S, tile); }
        else S.toast(j.reason || 'échec');
      } catch (e) { S.toast('échec'); }
    });
  }

  return { render };
})();
