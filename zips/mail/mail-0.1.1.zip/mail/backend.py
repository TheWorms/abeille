"""Addon « mail » — client IMAP générique (lecture + marquer lu / supprimer).

    register(sdk) -> flask.Blueprint   (routes sous /addons/mail/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Aucune dépendance externe : imaplib + email (stdlib). Compatible avec tout
hébergeur IMAP (Infomaniak, Gmail avec mot de passe d'application, Proton via
Bridge, etc.). Lecture seule du corps ; les seules écritures possibles sont
marquer lu/non-lu (\\Seen) et supprimer (\\Deleted + expunge).

Réglages attendus (cfg) :
  host  : serveur IMAP           (ex. mail.infomaniak.com)
  port  : port IMAPS             (défaut 993)
  user  : adresse e-mail
  pass  : mot de passe d'application
  folder: dossier IMAP           (défaut INBOX)
"""
import email
import imaplib
from email.header import decode_header, make_header
from email.utils import parseaddr, parsedate_to_datetime


def _cfg(cfg):
    host = (cfg.get("host") or "").strip()
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    folder = (cfg.get("folder") or "INBOX").strip() or "INBOX"
    try:
        port = int(cfg.get("port") or 993)
    except (TypeError, ValueError):
        port = 993
    return host, port, user, pw, folder


def _connect(cfg):
    """Ouvre une session IMAPS authentifiée. Lève une exception sinon."""
    host, port, user, pw, folder = _cfg(cfg)
    if not (host and user and pw):
        raise ValueError("host / user / pass manquants")
    M = imaplib.IMAP4_SSL(host, port)
    M.login(user, pw)
    return M, folder


def _dec(raw):
    """Décode un en-tête MIME (=?utf-8?...) en str lisible."""
    if not raw:
        return ""
    try:
        return str(make_header(decode_header(raw)))
    except Exception:
        return str(raw)


def _body_text(msg):
    """Extrait le corps : préfère text/plain, retombe sur un text/html allégé."""
    html = None
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            disp = str(part.get("Content-Disposition") or "")
            if "attachment" in disp.lower():
                continue
            if ctype == "text/plain":
                return _decode_part(part), False
            if ctype == "text/html" and html is None:
                html = _decode_part(part)
        if html is not None:
            return html, True
        return "", False
    # non-multipart
    is_html = msg.get_content_type() == "text/html"
    return _decode_part(msg), is_html


def _decode_part(part):
    try:
        payload = part.get_payload(decode=True)
        if payload is None:
            return ""
        charset = part.get_content_charset() or "utf-8"
        return payload.decode(charset, errors="replace")
    except Exception:
        return ""


def _attachments(msg):
    out = []
    if not msg.is_multipart():
        return out
    for part in msg.walk():
        disp = str(part.get("Content-Disposition") or "")
        if "attachment" in disp.lower():
            name = _dec(part.get_filename() or "pièce jointe")
            out.append(name)
    return out


def _list(sdk, cfg, limit=40):
    M, folder = _connect(cfg)
    try:
        typ, _ = M.select(folder, readonly=True)
        if typ != "OK":
            return {"ok": False, "reason": f"dossier « {folder} » introuvable"}
        typ, data = M.search(None, "ALL")
        if typ != "OK":
            return {"ok": False, "reason": "recherche IMAP échouée"}
        ids = data[0].split()
        total = len(ids)
        recent = ids[-limit:][::-1]  # les plus récents d'abord
        items = []
        if recent:
            # FLAGS + en-têtes en un seul FETCH par lot
            id_set = b",".join(recent)
            typ, resp = M.fetch(
                id_set,
                "(FLAGS BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
            # resp alterne (métadonnées, en-têtes) et b')'
            parsed = {}
            cur_id = None
            for part in resp:
                if isinstance(part, tuple):
                    meta = part[0].decode("utf-8", "replace")
                    uid = meta.split()[0]
                    flags = imaplib.ParseFlags(part[0])
                    hdr = email.message_from_bytes(part[1])
                    parsed[uid] = {
                        "id": uid,
                        "from": _friendly(_dec(hdr.get("From"))),
                        "subject": _dec(hdr.get("Subject")) or "(sans objet)",
                        "date": _fmt_date(hdr.get("Date")),
                        "seen": b"\\Seen" in flags,
                    }
            # respecter l'ordre "récent d'abord"
            for i in recent:
                key = i.decode()
                if key in parsed:
                    items.append(parsed[key])
        unseen = sum(1 for x in items if not x["seen"])
        return {"ok": True, "items": items, "total": total,
                "unseen_shown": unseen, "folder": folder,
                "account": _cfg(cfg)[2]}
    finally:
        try:
            M.logout()
        except Exception:
            pass


def _friendly(addr):
    name, mail = parseaddr(addr)
    return name or mail or addr


def _fmt_date(raw):
    try:
        dt = parsedate_to_datetime(raw)
        return dt.isoformat()
    except Exception:
        return ""


def _read(sdk, cfg, mid):
    """Charge le corps complet d'un message ET le marque lu (\\Seen)."""
    M, folder = _connect(cfg)
    try:
        typ, _ = M.select(folder)  # RW pour poser le flag \Seen
        if typ != "OK":
            return {"ok": False, "reason": "dossier introuvable"}
        typ, data = M.fetch(mid.encode(), "(RFC822)")
        if typ != "OK" or not data or not isinstance(data[0], tuple):
            return {"ok": False, "reason": "message introuvable"}
        msg = email.message_from_bytes(data[0][1])
        body, is_html = _body_text(msg)
        # marquer lu
        try:
            M.store(mid.encode(), "+FLAGS", "\\Seen")
        except Exception:
            pass
        return {
            "ok": True,
            "id": mid,
            "from": _dec(msg.get("From")),
            "to": _dec(msg.get("To")),
            "subject": _dec(msg.get("Subject")) or "(sans objet)",
            "date": _fmt_date(msg.get("Date")),
            "body": body[:200000],
            "is_html": is_html,
            "attachments": _attachments(msg),
        }
    finally:
        try:
            M.logout()
        except Exception:
            pass


def _flag(sdk, cfg, mid, seen):
    """Marque lu (seen=True) ou non-lu (seen=False)."""
    M, folder = _connect(cfg)
    try:
        if M.select(folder)[0] != "OK":
            return {"ok": False, "reason": "dossier introuvable"}
        op = "+FLAGS" if seen else "-FLAGS"
        typ, _ = M.store(mid.encode(), op, "\\Seen")
        return {"ok": typ == "OK", "id": mid, "seen": seen}
    finally:
        try:
            M.logout()
        except Exception:
            pass


def _delete(sdk, cfg, mid):
    """Supprime : pose \\Deleted puis expunge."""
    M, folder = _connect(cfg)
    try:
        if M.select(folder)[0] != "OK":
            return {"ok": False, "reason": "dossier introuvable"}
        typ, _ = M.store(mid.encode(), "+FLAGS", "\\Deleted")
        if typ != "OK":
            return {"ok": False, "reason": "marquage \\Deleted échoué"}
        M.expunge()
        return {"ok": True, "id": mid}
    finally:
        try:
            M.logout()
        except Exception:
            pass


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("mail", __name__)

    def _guard(fn):
        try:
            return jsonify(fn())
        except imaplib.IMAP4.error as e:
            return jsonify({"ok": False, "reason": f"IMAP : {e}"[:140]})
        except (OSError, ValueError) as e:
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:140]})
        except Exception as e:
            sdk.log.exception("mail")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:140]})

    @bp.route("/list")
    def list_():
        return _guard(lambda: _list(sdk, sdk.config()))

    @bp.route("/read")
    def read():
        mid = request.args.get("id", "")
        if not mid.isdigit():
            return jsonify({"ok": False, "reason": "id invalide"}), 400
        return _guard(lambda: _read(sdk, sdk.config(), mid))

    @bp.route("/flag", methods=["POST"])
    def flag():
        j = request.get_json(silent=True) or {}
        mid = str(j.get("id", ""))
        if not mid.isdigit():
            return jsonify({"ok": False, "reason": "id invalide"}), 400
        return _guard(lambda: _flag(sdk, sdk.config(), mid, bool(j.get("seen"))))

    @bp.route("/delete", methods=["POST"])
    def delete():
        j = request.get_json(silent=True) or {}
        mid = str(j.get("id", ""))
        if not mid.isdigit():
            return jsonify({"ok": False, "reason": "id invalide"}), 400
        return _guard(lambda: _delete(sdk, sdk.config(), mid))

    return bp


def test(sdk, cfg):
    try:
        r = _list(sdk, cfg, limit=1)
    except imaplib.IMAP4.error as e:
        return False, f"IMAP ✗ ({e})"[:120]
    except (OSError, ValueError) as e:
        return False, f"Connexion ✗ ({type(e).__name__})"
    if r.get("ok"):
        return True, (f"IMAP ✓ — {r['account']} · dossier {r['folder']} · "
                      f"{r['total']} message(s)")
    return False, f"IMAP ✗ ({r.get('reason')})"
