"""Addon « grafana » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/grafana/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Particularité : la route /panel renvoie une IMAGE PNG (pas du JSON), rendue
côté Grafana par le endpoint /render/d-solo (plugin image-renderer requis).
Le frontend la consomme via une balise <img> ; l'auth du noyau s'applique
car la requête est same-origin (cookies de session transmis).
"""


def register(sdk):
    from flask import Blueprint, Response, request
    bp = Blueprint("grafana", __name__)

    @bp.route("/panel")
    def panel():
        cfg = sdk.config()
        url = (cfg.get("url") or "").rstrip("/")
        key = cfg.get("apikey") or ""
        uid = (cfg.get("dashboard") or "").strip()
        panel_id = request.args.get("panel", "")
        theme = (cfg.get("theme") or "light").strip()
        if not (url and key and uid and panel_id):
            return Response("non configuré", status=400)
        try:
            r = sdk.requests.get(
                f"{url}/render/d-solo/{uid}/_",
                params={"orgId": 1, "panelId": panel_id, "width": 1000,
                        "height": 400, "theme": theme},
                headers={"Authorization": f"Bearer {key}"},
                timeout=20, verify=False)
        except sdk.requests.exceptions.RequestException as e:
            return Response(f"injoignable ({type(e).__name__})", status=502)
        if r.status_code != 200:
            return Response(f"HTTP {r.status_code}", status=r.status_code)
        ct = r.headers.get("Content-Type", "image/png")
        if "image" not in ct:
            return Response("rendu indisponible (plugin image-renderer ?)", status=502)
        return Response(r.content, mimetype=ct)

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    url = (cfg.get("url") or "").rstrip("/")
    if not url:
        return False, "URL manquante"
    r = sdk.requests.get(f"{url}/api/health", timeout=4, verify=False)
    return (r.status_code == 200), f"Grafana: HTTP {r.status_code}"
