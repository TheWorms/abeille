/* Grafana — stats natives + rendu PNG d'un panel (sélecteur). Pleine page. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.grafana = (function () {
  let S = null, root = null, tile = null, data = null;
  let selDash = '', selPanel = '', panelsCache = {};
  const ACCENT = '#f46800';  // orange Grafana
  const CSS =
    "  .gfwrap{flex:1;display:flex;flex-direction:column;min-height:0;--gf:" + ACCENT + "}\n" +
    "  .gfscroll{flex:1;min-height:0;overflow:auto;padding:14px 22px 18px}\n" +
    "  .gfhead{display:flex;align-items:center;gap:12px;margin-bottom:14px}\n" +
    "  .gfh-ic{width:40px;height:40px;border-radius:11px;background:rgba(244,104,0,.13);display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}\n" +
    "  .gfh-tx b{font-size:16px;font-weight:700;display:block}\n" +
    "  .gfh-tx span{font-size:11.5px;color:var(--dim)}\n" +
    "  .gfh-open{margin-left:auto;font-size:12px;color:var(--gf);cursor:pointer;background:rgba(244,104,0,.1);border:1px solid rgba(244,104,0,.3);border-radius:9px;padding:7px 13px}\n" +
    "  .gfkpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:16px}\n" +
    "  .gfkpi{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:12px 14px}\n" +
    "  .gfkpi b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .gfkpi span{font-size:11px;color:var(--dim)}\n" +
    "  .gfkpi.alert b{color:var(--bad)}\n" +
    "  .gfkpi.ok b{color:var(--green)}\n" +
    "  .gfsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px}\n" +
    "  .gfalist{display:flex;flex-direction:column;gap:6px;margin-bottom:6px}\n" +
    "  .gfarow{display:flex;align-items:center;gap:9px;background:var(--tile);border:1px solid var(--border-soft);border-left:3px solid var(--bad);border-radius:9px;padding:8px 12px;font-size:12.5px}\n" +
    "  .gfarow.pending{border-left-color:var(--warn)}\n" +
    "  .gfabadge{font-size:10px;font-weight:700;padding:2px 8px;border-radius:8px;color:#111;background:var(--bad)}\n" +
    "  .gfabadge.pending{background:var(--warn)}\n" +
    "  .gfaname{font-weight:600}\n" +
    "  .gfok{color:var(--green);font-size:13px;padding:4px 0}\n" +
    "  .gfpanelbox{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;padding:14px;margin-top:6px}\n" +
    "  .gfselrow{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:12px}\n" +
    "  .gfsel{flex:1;min-width:180px;background:var(--bg);color:var(--fg);border:1px solid var(--border-soft);border-radius:9px;padding:10px 12px;font-size:13px;height:44px}\n" +
    "  .gfrefresh{background:rgba(244,104,0,.12);color:var(--gf);border:1px solid rgba(244,104,0,.3);border-radius:9px;padding:0 16px;height:44px;font-size:13px;font-weight:600;cursor:pointer;flex:none}\n" +
    "  .gfimg{width:100%;border-radius:10px;background:var(--bg);min-height:200px;display:block;border:1px solid var(--border-soft)}\n" +
    "  .gfimgwrap{position:relative;min-height:200px;display:flex;align-items:center;justify-content:center}\n" +
    "  .gfimgmsg{position:absolute;color:var(--dim);font-size:13px}";
  function ensureCss() { if (document.getElementById('gfUiCss')) return; const s = document.createElement('style'); s.id = 'gfUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de Grafana…</div></div>';
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📊</div><div class="t1">Grafana indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et une clé API (service account) dans ⚙.</div>' +
        '<button class="btnpill install" id="gfRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('gfRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const a = d.alerts || { firing: 0, pending: 0, rules: 0, list: [] };
    let h = '<div class="gfwrap"><div class="gfscroll">';
    // en-tête
    h += '<div class="gfhead"><div class="gfh-ic">📊</div>' +
      '<div class="gfh-tx"><b>Grafana</b><span>v' + esc(d.version || '?') + ' · base ' + esc(d.database || '?') + '</span></div>' +
      '<span class="gfh-open" id="gfOpen">Ouvrir Grafana ↗</span></div>';
    // KPIs
    h += '<div class="gfkpis">' +
      '<div class="gfkpi"><b>' + nf(d.dashboards.length) + '</b><span>dashboards</span></div>' +
      '<div class="gfkpi ' + (a.firing > 0 ? 'alert' : 'ok') + '"><b>' + nf(a.firing) + '</b><span>alertes actives</span></div>' +
      '<div class="gfkpi"><b>' + nf(a.pending) + '</b><span>en attente</span></div>' +
      '<div class="gfkpi"><b>' + nf(a.rules) + '</b><span>règles d\'alerte</span></div>' +
      '</div>';
    // alertes actives
    if (a.list && a.list.length) {
      h += '<div class="gfsec">Alertes</div><div class="gfalist">';
      a.list.forEach(al => {
        h += '<div class="gfarow ' + (al.state === 'pending' ? 'pending' : '') + '">' +
          '<span class="gfabadge ' + (al.state === 'pending' ? 'pending' : '') + '">' + (al.state === 'pending' ? 'EN ATTENTE' : 'ACTIVE') + '</span>' +
          '<span class="gfaname">' + esc(al.name) + '</span></div>';
      });
      h += '</div>';
    } else if (a.firing === 0 && a.pending === 0) {
      h += '<div class="gfsec">Alertes</div><div class="gfok">✓ Aucune alerte active</div>';
    }
    // sélecteur de panel
    h += '<div class="gfsec">Visualiser un panel</div><div class="gfpanelbox">';
    h += '<div class="gfselrow">' +
      '<select class="gfsel" id="gfDash"><option value="">— Choisir un dashboard —</option>' +
      d.dashboards.map(x => '<option value="' + esc(x.uid) + '"' + (x.uid === selDash ? ' selected' : '') + '>' + esc(x.title) + (x.folder && x.folder !== 'General' ? ' (' + esc(x.folder) + ')' : '') + '</option>').join('') +
      '</select>' +
      '<select class="gfsel" id="gfPanel" ' + (selDash ? '' : 'disabled') + '><option value="">— Panel —</option></select>' +
      '<button class="gfrefresh" id="gfGo">Afficher</button></div>';
    h += '<div class="gfimgwrap" id="gfImgWrap"><span class="gfimgmsg">Choisis un dashboard puis un panel.</span></div>';
    h += '</div>';
    h += '</div></div>';
    el.innerHTML = h;

    const openBtn = document.getElementById('gfOpen');
    if (openBtn) openBtn.addEventListener('click', () => { if (S.openService) S.openService(); });

    const dashSel = document.getElementById('gfDash');
    const panelSel = document.getElementById('gfPanel');
    const goBtn = document.getElementById('gfGo');

    if (dashSel) dashSel.addEventListener('change', async () => {
      selDash = dashSel.value; selPanel = '';
      panelSel.innerHTML = '<option value="">— Chargement… —</option>'; panelSel.disabled = true;
      if (!selDash) { panelSel.innerHTML = '<option value="">— Panel —</option>'; return; }
      let list = panelsCache[selDash];
      if (!list) {
        try { const r = await S.api('/panels?uid=' + encodeURIComponent(selDash)); const j = await r.json(); list = j.ok ? j.panels : []; panelsCache[selDash] = list; }
        catch (e) { list = []; }
      }
      panelSel.innerHTML = '<option value="">— Panel —</option>' + list.map(p => '<option value="' + p.id + '">' + esc(p.title) + '</option>').join('');
      panelSel.disabled = false;
    });
    if (panelSel) panelSel.addEventListener('change', () => { selPanel = panelSel.value; });
    if (goBtn) goBtn.addEventListener('click', showPanel);
    // restaurer sélection
    if (selDash && dashSel) { dashSel.value = selDash; dashSel.dispatchEvent(new Event('change')); }
  }

  function showPanel() {
    const wrap = document.getElementById('gfImgWrap');
    if (!wrap) return;
    if (!selDash || !selPanel) { wrap.innerHTML = '<span class="gfimgmsg">Choisis un dashboard et un panel.</span>'; return; }
    wrap.innerHTML = '<span class="gfimgmsg">Rendu en cours…</span>';
    const img = new Image();
    const theme = (document.body.classList.contains('light') ? 'light' : 'dark');
    img.className = 'gfimg';
    img.onload = () => { wrap.innerHTML = ''; wrap.appendChild(img); };
    img.onerror = () => { wrap.innerHTML = '<span class="gfimgmsg">⚠ rendu indisponible (renderer ?)</span>'; };
    img.src = '/addons/grafana/api/panel?uid=' + encodeURIComponent(selDash) + '&panel=' + encodeURIComponent(selPanel) + '&theme=' + theme + '&_=' + Date.now();
  }

  return { render };
})();
