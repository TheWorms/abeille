"""Addon « grafana » — stats natives + rendu PNG des panels.

    register(sdk) -> flask.Blueprint   (routes sous /addons/grafana/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:3000) + apikey (service account token).
Stats via l'API JSON Grafana ; panels via /render/d-solo (renderer distant).
La route /panel renvoie une IMAGE PNG, consommée par une balise <img>.
"""


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _hdr(key):
    return {"Authorization": f"Bearer {key}"}


def _overview(sdk, cfg):
    url, key = _base(cfg)
    if not (url and key):
        return {"ok": False, "reason": "URL/clé non configurées"}
    ck = f"graf:{url}"
    c = sdk.cache_get(ck, 30)
    if c is not None:
        return c
    h = _hdr(key)

    def get(path, default=None):
        try:
            r = sdk.requests.get(f"{url}{path}", headers=h, timeout=8, verify=False)
            return r.json() if r.ok else default
        except (sdk.requests.exceptions.RequestException, ValueError):
            return default

    # santé (sans auth) + version
    health = get("/api/health", {})
    # datasources + test de santé de chacune
    ds_raw = get("/api/datasources", []) or []
    datasources = []
    for d in ds_raw:
        uid = d.get("uid")
        state = "unknown"
        if uid:
            hr = get(f"/api/datasources/uid/{uid}/health")
            if isinstance(hr, dict):
                state = (hr.get("status") or "unknown").lower()
        datasources.append({"name": d.get("name"), "type": d.get("type"),
                            "uid": uid, "state": state,
                            "default": bool(d.get("isDefault"))})
    # dashboards
    dashboards = []
    for x in (get("/api/search?type=dash-db", []) or []):
        dashboards.append({"uid": x.get("uid"), "title": x.get("title"),
                          "folder": x.get("folderTitle") or "General"})
    dashboards.sort(key=lambda z: (z.get("title") or "").lower())
    # alertes (Grafana unified alerting)
    alerts = {"firing": 0, "pending": 0, "normal": 0, "rules": 0, "list": []}
    rules = get("/api/prometheus/grafana/api/v1/rules")
    if isinstance(rules, dict):
        for grp in (rules.get("data", {}) or {}).get("groups", []) or []:
            for rule in grp.get("rules", []) or []:
                if rule.get("type") != "alerting" and "state" not in rule:
                    continue
                alerts["rules"] += 1
                st = (rule.get("state") or "").lower()
                if st == "firing":
                    alerts["firing"] += 1
                    alerts["list"].append({"name": rule.get("name"),
                                           "state": "firing",
                                           "since": rule.get("activeAt")})
                elif st == "pending":
                    alerts["pending"] += 1
                    alerts["list"].append({"name": rule.get("name"),
                                           "state": "pending",
                                           "since": rule.get("activeAt")})
                else:
                    alerts["normal"] += 1
    alerts["list"] = alerts["list"][:8]

    res = {
        "ok": True,
        "version": health.get("version") if isinstance(health, dict) else None,
        "database": health.get("database") if isinstance(health, dict) else None,
        "datasources": datasources,
        "dashboards": dashboards,
        "alerts": alerts,
    }
    return sdk.cache_set(ck, res)


def _panels(sdk, cfg, uid):
    """Liste des panels d'un dashboard (id + titre) pour le sélecteur."""
    url, key = _base(cfg)
    if not (url and key and uid):
        return {"ok": False, "reason": "paramètres manquants"}
    try:
        r = sdk.requests.get(f"{url}/api/dashboards/uid/{uid}",
                             headers=_hdr(key), timeout=8, verify=False)
        if not r.ok:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        dash = r.json().get("dashboard", {})
    except (sdk.requests.exceptions.RequestException, ValueError):
        return {"ok": False, "reason": "réponse invalide"}
    panels = []

    def walk(items):
        for p in items or []:
            if p.get("type") == "row":
                walk(p.get("panels"))
                continue
            if p.get("id") is not None and p.get("type"):
                panels.append({"id": p.get("id"),
                               "title": p.get("title") or f"Panel {p.get('id')}",
                               "type": p.get("type")})
    walk(dash.get("panels"))
    return {"ok": True, "title": dash.get("title"), "panels": panels}


def register(sdk):
    from flask import Blueprint, Response, jsonify, request
    bp = Blueprint("grafana", __name__)

    @bp.route("/overview")
    def overview():
        try:
            return jsonify(_overview(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("grafana overview")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/panels")
    def panels():
        try:
            uid = (request.args.get("uid") or "").strip()
            return jsonify(_panels(sdk, sdk.config(), uid))
        except Exception as e:
            sdk.log.exception("grafana panels")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/panel")
    def panel():
        cfg = sdk.config()
        url, key = _base(cfg)
        uid = (request.args.get("uid") or "").strip()
        pid = request.args.get("panel", "")
        theme = (request.args.get("theme") or cfg.get("theme") or "dark").strip()
        if not (url and key and uid and pid):
            return Response("non configuré", status=400)
        try:
            r = sdk.requests.get(
                f"{url}/render/d-solo/{uid}/_",
                params={"orgId": 1, "panelId": pid, "width": 1000,
                        "height": 400, "theme": theme},
                headers=_hdr(key), timeout=25, verify=False)
        except sdk.requests.exceptions.RequestException as e:
            return Response(f"injoignable ({type(e).__name__})", status=502)
        if r.status_code != 200:
            return Response(f"HTTP {r.status_code}", status=r.status_code)
        ct = r.headers.get("Content-Type", "image/png")
        if "image" not in ct:
            return Response("rendu indisponible (renderer ?)", status=502)
        return Response(r.content, mimetype=ct)

    return bp


def test(sdk, cfg):
    url, key = _base(cfg)
    if not url:
        return False, "URL manquante"
    try:
        r = sdk.requests.get(f"{url}/api/health", timeout=4, verify=False)
        if r.status_code != 200:
            return False, f"Grafana: HTTP {r.status_code}"
        ver = ""
        try:
            ver = r.json().get("version", "")
        except ValueError:
            pass
        if not key:
            return True, f"Grafana ✓ v{ver} (clé API absente : stats limitées)"
        o = _overview(sdk, cfg)
        if o.get("ok"):
            return True, (f"Grafana ✓ v{ver} — {len(o['dashboards'])} dashboards, "
                          f"{len(o['datasources'])} sources, "
                          f"{o['alerts']['firing']} alerte(s) active(s)")
        return True, f"Grafana ✓ v{ver} (clé : {o.get('reason')})"
    except sdk.requests.exceptions.RequestException as e:
        return False, f"Grafana injoignable ({type(e).__name__})"
