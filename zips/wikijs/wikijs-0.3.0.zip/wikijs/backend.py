"""Addon « wikijs » — Wiki.js (Hibou) : stats, recherche, pages récentes + arbo.

    register(sdk) -> flask.Blueprint   (routes sous /addons/wikijs/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:3000) + token (API GraphQL, Bearer).
Interroge l'API GraphQL de Wiki.js 2 (pages.list). Calcule des stats, la
liste récente et une arborescence par premier segment de chemin.
"""

_QUERY = ("{ pages { list(orderBy: UPDATED, orderByDirection: DESC) "
          "{ id path title updatedAt createdAt isPublished locale } } }")


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("token") or "").strip()


def _fetch(sdk, cfg):
    url, token = _base(cfg)
    if not (url and token):
        return {"ok": False, "reason": "URL/token non configurés"}
    ck = f"wiki:{url}"
    c = sdk.cache_get(ck, 120)
    if c is not None:
        return c
    try:
        r = sdk.requests.post(
            f"{url}/graphql",
            headers={"Authorization": f"Bearer {token}",
                     "Content-Type": "application/json"},
            json={"query": _QUERY}, timeout=10, verify=False)
        if r.status_code == 401:
            return {"ok": False, "reason": "token refusé (401) — Administration → API"}
        if r.status_code != 200:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        body = r.json()
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": f"injoignable ({type(e).__name__})"}
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}

    if body.get("errors"):
        msg = body["errors"][0].get("message", "erreur GraphQL") if body["errors"] else "erreur GraphQL"
        return {"ok": False, "reason": msg[:80]}

    raw = (((body.get("data") or {}).get("pages") or {}).get("list")) or []
    pages = []
    for p in raw:
        if not isinstance(p, dict):
            continue
        pages.append({
            "id": p.get("id"),
            "path": p.get("path") or "",
            "title": p.get("title") or (p.get("path") or "sans titre"),
            "updatedAt": p.get("updatedAt"),
            "createdAt": p.get("createdAt"),
            "published": bool(p.get("isPublished", True)),
            "locale": p.get("locale") or "",
        })

    pages.sort(key=lambda x: (x.get("updatedAt") or ""), reverse=True)
    published = sum(1 for p in pages if p["published"])
    locales = sorted({p["locale"] for p in pages if p["locale"]})

    # arborescence : premier segment du path
    tree = {}
    for p in pages:
        seg = (p["path"].split("/")[0] if p["path"] and "/" in p["path"]
               else (p["path"] or "(racine)"))
        if "/" not in p["path"]:
            seg = "(racine)"
        tree.setdefault(seg, []).append(p)
    folders = []
    for name, items in tree.items():
        items_sorted = sorted(items, key=lambda x: x["title"].lower())
        folders.append({"name": name, "count": len(items), "pages": items_sorted})
    folders.sort(key=lambda f: (f["name"] == "(racine)", f["name"].lower()))

    out = {
        "ok": True,
        "pages": pages,              # déjà triées par date desc
        "recent": pages[:10],
        "folders": folders,
        "total": len(pages),
        "published": published,
        "drafts": len(pages) - published,
        "locales": locales,
    }
    return sdk.cache_set(ck, out)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("wikijs", __name__)

    @bp.route("/pages")
    def pages():
        try:
            return jsonify(_fetch(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("wikijs")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    d = _fetch(sdk, cfg)
    if d.get("ok"):
        return True, (f"Wiki.js ✓ — {d['total']} page(s), "
                      f"{d['published']} publiée(s), {len(d['folders'])} dossier(s)")
    return False, f"Wiki.js ✗ ({d.get('reason')})"
