/* Wiki.js — stats, recherche, pages récentes + arborescence, liste/cards. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.wikijs = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'list';
  let baseUrl = '', query = '', openFolders = {};
  const ACCENT = '#1976d2';  // bleu Wiki.js
  const CSS =
    "  .wkwrap{flex:1;display:flex;flex-direction:column;min-height:0;--wk:" + ACCENT + "}\n" +
    "  .wktopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .wktotals{display:flex;gap:16px;flex:1}\n" +
    "  .wktk{text-align:center}\n" +
    "  .wktk b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--wk)}\n" +
    "  .wktk.pub b{color:var(--green)}.wktk.draft b{color:var(--warn)}\n" +
    "  .wktk span{font-size:11px;color:var(--dim)}\n" +
    "  .wkvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .wkvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .wkvtoggle button.on{background:var(--tile);color:var(--wk)}\n" +
    "  .wksearch{padding:12px 22px 0}\n" +
    "  .wksearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .wkscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .wksec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px}\n" +
    "  .wksec:first-child{margin-top:0}\n" +
    /* liste */
    "  .wkrow{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:10px 14px;margin-bottom:7px;cursor:pointer}\n" +
    "  .wkrow:hover{border-color:var(--wk)}\n" +
    "  .wkrow.off{opacity:.55}\n" +
    "  .wkico{width:32px;height:32px;border-radius:8px;background:rgba(25,118,210,.1);display:flex;align-items:center;justify-content:center;font-size:15px;flex:none}\n" +
    "  .wktx{min-width:0;flex:1}\n" +
    "  .wknm{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wkpath{font-family:var(--mono);font-size:11px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wkmeta{font-size:11px;color:var(--dim);flex:none;text-align:right}\n" +
    "  .wkdraft{font-size:9px;font-weight:700;color:#111;background:var(--warn);border-radius:6px;padding:1px 6px;margin-left:6px}\n" +
    /* cards */
    "  .wkcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:11px}\n" +
    "  .wkcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px;border-left:3px solid var(--wk);cursor:pointer;display:flex;flex-direction:column}\n" +
    "  .wkcard:hover{border-color:var(--wk)}\n" +
    "  .wkcard.off{opacity:.55;border-left-color:var(--warn)}\n" +
    "  .wkctop{display:flex;align-items:center;gap:8px;margin-bottom:8px}\n" +
    "  .wkcnm{font-weight:700;font-size:13.5px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    "  .wkcpath{font-family:var(--mono);font-size:10.5px;color:var(--dim);margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .wkcfoot{display:flex;justify-content:space-between;align-items:center;font-size:10.5px;color:var(--dim);margin-top:auto}\n" +
    /* arbo */
    "  .wkfold{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;margin-bottom:8px;overflow:hidden}\n" +
    "  .wkfhead{display:flex;align-items:center;gap:10px;padding:11px 14px;cursor:pointer}\n" +
    "  .wkfic{font-size:15px}\n" +
    "  .wkfname{font-weight:700;font-size:13.5px;font-family:var(--mono)}\n" +
    "  .wkfcount{margin-left:auto;font-size:11px;color:var(--dim)}\n" +
    "  .wkfchev{color:var(--dim);transition:transform .15s}\n" +
    "  .wkfold.open .wkfchev{transform:rotate(90deg)}\n" +
    "  .wkflist{display:none;border-top:1px solid var(--border-soft);padding:4px 14px 8px}\n" +
    "  .wkfold.open .wkflist{display:block}\n" +
    "  .wkfrow{display:flex;align-items:center;gap:9px;padding:7px 0;border-bottom:1px solid var(--border-soft);cursor:pointer;font-size:13px}\n" +
    "  .wkfrow:last-child{border-bottom:0}\n" +
    "  .wkfrow:hover{color:var(--wk)}\n" +
    "  .wkfrp{font-family:var(--mono);font-size:10.5px;color:var(--dim);margin-left:auto}\n" +
    "  .wkempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { let s = document.getElementById('wkUiCss'); if (!s) { s = document.createElement('style'); s.id = 'wkUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const rel = v => S && S.rel ? S.rel(v) : (v || '—');

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture du wiki…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/pages'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openPage(path) {
    if (!baseUrl) { S.toast('URL du wiki non configurée'); return; }
    const u = baseUrl + '/' + String(path || '').replace(/^\/+/, '');
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  function filtered(pages) {
    if (!query) return pages;
    const q = query.toLowerCase();
    return pages.filter(p => (p.title || '').toLowerCase().includes(q) || (p.path || '').toLowerCase().includes(q));
  }

  function pageRow(p) {
    return '<div class="wkrow' + (p.published ? '' : ' off') + '" data-path="' + esc(p.path) + '">' +
      '<span class="wkico">📄</span>' +
      '<div class="wktx"><div class="wknm">' + esc(p.title) + (p.published ? '' : '<span class="wkdraft">brouillon</span>') + '</div>' +
      '<div class="wkpath">/' + esc(p.path) + '</div></div>' +
      '<span class="wkmeta">maj ' + rel(p.updatedAt) + (p.locale ? '<br>' + esc(p.locale) : '') + '</span></div>';
  }
  function pageCard(p) {
    return '<div class="wkcard' + (p.published ? '' : ' off') + '" data-path="' + esc(p.path) + '">' +
      '<div class="wkctop"><span class="wkico">📄</span></div>' +
      '<div class="wkcnm">' + esc(p.title) + '</div>' +
      '<div class="wkcpath">/' + esc(p.path) + '</div>' +
      '<div class="wkcfoot"><span>maj ' + rel(p.updatedAt) + '</span>' + (p.published ? '' : '<span class="wkdraft">brouillon</span>') + '</div></div>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📚</div><div class="t1">Wiki.js indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et un token API dans ⚙ (Administration → API).</div>' +
        '<button class="btnpill install" id="wkRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('wkRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="wkwrap"><div class="wktopbar">' +
      '<div class="wktotals">' +
      '<div class="wktk"><b>' + nf(d.total) + '</b><span>pages</span></div>' +
      '<div class="wktk pub"><b>' + nf(d.published) + '</b><span>publiées</span></div>' +
      '<div class="wktk draft"><b>' + nf(d.drafts) + '</b><span>brouillons</span></div>' +
      '<div class="wktk"><b>' + nf(d.folders.length) + '</b><span>dossiers</span></div>' +
      '</div>' +
      '<div class="wkvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="wksearch"><input id="wkQ" type="search" placeholder="Rechercher une page…" value="' + esc(query) + '"></div>';
    h += '<div class="wkscroll">';

    if (query) {
      // mode recherche : résultats à plat
      const res = filtered(d.pages);
      h += '<div class="wksec">' + nf(res.length) + ' résultat(s)</div>';
      if (!res.length) h += '<div class="wkempty">Aucune page ne correspond.</div>';
      else if (viewMode === 'cards') h += '<div class="wkcards">' + res.map(pageCard).join('') + '</div>';
      else h += res.map(pageRow).join('');
    } else if (viewMode === 'cards') {
      // cards : toutes les pages, groupées par dossier
      h += '<div class="wksec">Récemment modifiées</div>';
      h += '<div class="wkcards">' + d.recent.map(pageCard).join('') + '</div>';
      d.folders.forEach(f => {
        h += '<div class="wksec">📁 ' + esc(f.name) + ' · ' + nf(f.count) + '</div>';
        h += '<div class="wkcards">' + f.pages.map(pageCard).join('') + '</div>';
      });
    } else {
      // liste : récentes + arborescence dépliable
      h += '<div class="wksec">Récemment modifiées</div>';
      h += d.recent.map(pageRow).join('');
      h += '<div class="wksec">Arborescence</div>';
      d.folders.forEach((f, fi) => {
        const open = openFolders[f.name];
        h += '<div class="wkfold' + (open ? ' open' : '') + '" data-fi="' + fi + '">' +
          '<div class="wkfhead"><span class="wkfic">📁</span><span class="wkfname">' + esc(f.name) + '</span>' +
          '<span class="wkfcount">' + nf(f.count) + ' page(s)</span><span class="wkfchev">›</span></div>' +
          '<div class="wkflist">' + f.pages.map(p =>
            '<div class="wkfrow" data-path="' + esc(p.path) + '"><span>📄</span><span>' + esc(p.title) + '</span>' +
            (p.published ? '' : '<span class="wkdraft">brouillon</span>') +
            '<span class="wkfrp">/' + esc(p.path) + '</span></div>').join('') +
          '</div></div>';
      });
    }
    h += '</div></div>';
    el.innerHTML = h;

    // bascule vue
    el.querySelectorAll('.wkvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    // recherche
    const qin = document.getElementById('wkQ');
    if (qin) {
      qin.addEventListener('input', () => { query = qin.value; repaintKeepFocus(); });
    }
    // ouverture pages (rows, cards, arbo)
    el.querySelectorAll('[data-path]').forEach(n => n.addEventListener('click', (e) => {
      // ne pas déclencher si on clique sur l'en-tête d'un dossier
      openPage(n.getAttribute('data-path'));
    }));
    // pliage dossiers
    el.querySelectorAll('.wkfhead').forEach(hd => hd.addEventListener('click', (e) => {
      e.stopPropagation();
      const fold = hd.parentElement;
      const name = data.folders[parseInt(fold.getAttribute('data-fi'), 10)].name;
      openFolders[name] = !openFolders[name];
      fold.classList.toggle('open');
    }));
  }

  // repaint qui garde le focus dans le champ recherche
  let _t = null;
  function repaintKeepFocus() {
    if (_t) clearTimeout(_t);
    _t = setTimeout(() => {
      const el = root; const cur = document.getElementById('wkQ');
      const pos = cur ? cur.selectionStart : null;
      paint();
      const nq = document.getElementById('wkQ');
      if (nq) { nq.focus(); if (pos != null) try { nq.setSelectionRange(pos, pos); } catch (e) {} }
    }, 180);
  }

  return { render };
})();
