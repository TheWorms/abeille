"""Addon « komga » — Komga (Hérisson) : stats, en cours, nouveautés, couvertures.

    register(sdk) -> flask.Blueprint   (routes sous /addons/komga/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://herisson.lan) + apikey (Compte → Clés API).
Repli possible sur user/password (HTTP Basic) si la clé API n'est pas dispo.

Différences majeures avec Kavita (ne pas transposer le backend « livres ») :
  - auth en un temps : en-tête X-API-Key (ou Basic), pas d'échange JWT ;
  - identifiants ALPHANUMÉRIQUES (TSID) et non entiers → jamais de .isdigit() ;
  - pas de notion de volume : Série → Livres directement. On expose un volume
    unique factice pour conserver le contrat UI de la liseuse ;
  - pages images indexées à partir de 1 (l'UI compte à partir de 0).
"""

import re

_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _ok_id(v):
    return bool(v) and bool(_ID_RE.match(str(v)))


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    return url


def _auth(cfg):
    """-> (headers, basic_tuple) ; (None, None) si rien n'est configuré."""
    key = (cfg.get("apikey") or "").strip()
    if key:
        return {"X-API-Key": key}, None
    user = (cfg.get("user") or "").strip()
    if user:
        return {}, (user, cfg.get("password") or "")
    return None, None


def _get(sdk, cfg, path, params=None, timeout=10):
    """Requête GET brute ; renvoie l'objet Response ou None."""
    url = _base(cfg)
    hdr, basic = _auth(cfg)
    if not url or hdr is None:
        return None
    try:
        return sdk.requests.get(f"{url}{path}", headers=hdr, auth=basic,
                                params=params, timeout=timeout, verify=False)
    except sdk.requests.exceptions.RequestException:
        return None


def _jget(sdk, cfg, path, params=None):
    """GET + décodage JSON ; renvoie None en cas d'échec."""
    r = _get(sdk, cfg, path, params=params)
    if r is None or not r.ok:
        return None
    try:
        return r.json()
    except ValueError:
        return None


def _content(d):
    """Komga renvoie des pages Spring : {content: [...]}. Tolère aussi une liste."""
    if isinstance(d, dict):
        c = d.get("content")
        return c if isinstance(c, list) else []
    return d if isinstance(d, list) else []


def _shape_series(s):
    total = s.get("booksCount") or 0
    read = s.get("booksReadCount") or 0
    prog = s.get("booksInProgressCount") or 0
    pct = round(read / total * 100) if total else 0
    meta = s.get("metadata") or {}
    return {
        "id": s.get("id"),
        "name": meta.get("title") or s.get("name") or "Sans titre",
        "books": total,
        "booksRead": read,
        "booksInProgress": prog,
        "percent": pct,
        "libraryId": s.get("libraryId"),
    }


def _overview(sdk, cfg):
    url = _base(cfg)
    if not url:
        return {"ok": False, "reason": "URL non configurée"}
    hdr, _basic = _auth(cfg)
    if hdr is None:
        return {"ok": False, "reason": "clé API (ou identifiants) non configurés"}

    ck = f"komga:{url}"
    c = sdk.cache_get(ck, 90)
    if c is not None:
        return c

    libs_raw = _jget(sdk, cfg, "/api/v1/libraries")
    if libs_raw is None:
        return {"ok": False, "reason": "serveur injoignable ou authentification refusée"}
    libraries = [{"id": l.get("id"), "name": l.get("name")}
                 for l in libs_raw if isinstance(l, dict)]

    reading = [_shape_series(s) for s in _content(_jget(
        sdk, cfg, "/api/v1/series",
        {"read_status": "IN_PROGRESS", "size": 20,
         "sort": "metadata.titleSort,asc"})) if isinstance(s, dict)]

    recent = [_shape_series(s) for s in _content(_jget(
        sdk, cfg, "/api/v1/series/new", {"size": 20})) if isinstance(s, dict)]

    out = {
        "ok": True,
        "libraries": libraries,
        "reading": reading,
        "recent": recent,
        "lib_count": len(libraries),
        "reading_count": len(reading),
    }
    return sdk.cache_set(ck, out)


def _search(sdk, cfg, q):
    if not _base(cfg):
        return {"ok": False, "reason": "non configuré"}
    hdr, _basic = _auth(cfg)
    if hdr is None:
        return {"ok": False, "reason": "non configuré"}
    r = _get(sdk, cfg, "/api/v1/series", {"search": q, "size": 40,
                                          "sort": "metadata.titleSort,asc"})
    if r is None:
        return {"ok": False, "reason": "recherche indisponible"}
    if not r.ok:
        return {"ok": False, "reason": f"HTTP {r.status_code}"}
    try:
        res = r.json()
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}
    series = [_shape_series(s) for s in _content(res) if isinstance(s, dict)]
    return {"ok": True, "count": len(series), "series": series}


def _series_detail(sdk, cfg, sid):
    """Livres d'une série, enveloppés dans un volume unique (contrat UI)."""
    if not _base(cfg):
        return {"ok": False, "reason": "non configuré"}
    if not _ok_id(sid):
        return {"ok": False, "reason": "identifiant invalide"}
    hdr, _basic = _auth(cfg)
    if hdr is None:
        return {"ok": False, "reason": "non configuré"}

    r = _get(sdk, cfg, f"/api/v1/series/{sid}/books",
             {"size": 1000, "sort": "metadata.numberSort,asc"})
    if r is None:
        return {"ok": False, "reason": "serveur injoignable"}
    if not r.ok:
        return {"ok": False, "reason": f"HTTP {r.status_code}"}
    try:
        books = _content(r.json())
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}

    chapters = []
    for i, b in enumerate(books, 1):
        if not isinstance(b, dict):
            continue
        meta = b.get("metadata") or {}
        media = b.get("media") or {}
        rp = b.get("readProgress") or {}
        pages = media.get("pagesCount") or 0
        read = rp.get("page") or 0
        if rp.get("completed"):
            read = pages
        num = meta.get("number") or b.get("number") or i
        chapters.append({
            "id": b.get("id"),
            "title": (str(meta.get("title") or b.get("name") or "").strip()
                      or f"Livre {num}"),
            "pages": pages,
            "pagesRead": read,
            "volumeId": sid,
        })

    return {"ok": True,
            "volumes": [{"id": sid, "name": "", "minNumber": None,
                         "chapters": chapters}]}


def register(sdk):
    from flask import Blueprint, Response, jsonify, request
    bp = Blueprint("komga", __name__)

    @bp.route("/overview")
    def overview():
        try:
            return jsonify(_overview(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("komga overview")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/search")
    def search():
        try:
            q = (request.args.get("q") or "").strip()
            if not q:
                return jsonify({"ok": True, "count": 0, "series": []})
            return jsonify(_search(sdk, sdk.config(), q))
        except Exception as e:
            sdk.log.exception("komga search")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/series-detail")
    def series_detail():
        try:
            sid = (request.args.get("id") or "").strip()
            return jsonify(_series_detail(sdk, sdk.config(), sid))
        except Exception as e:
            sdk.log.exception("komga series-detail")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/page")
    def page():
        cfg = sdk.config()
        bid = (request.args.get("book") or "").strip()
        pg = (request.args.get("page") or "").strip()
        # l'UI compte à partir de 0, Komga à partir de 1
        if not (_ok_id(bid) and pg.isdigit()):
            return Response("", status=400)
        n = int(pg) + 1
        r = _get(sdk, cfg, f"/api/v1/books/{bid}/pages/{n}", timeout=30)
        if r is None:
            return Response("", status=502)
        if r.status_code != 200:
            return Response("", status=r.status_code)
        ct = r.headers.get("Content-Type", "image/jpeg")
        return Response(r.content, mimetype=ct,
                        headers={"Cache-Control": "private, max-age=3600"})

    @bp.route("/cover")
    def cover():
        cfg = sdk.config()
        sid = (request.args.get("series") or "").strip()
        if not _ok_id(sid):
            return Response("", status=400)
        r = _get(sdk, cfg, f"/api/v1/series/{sid}/thumbnail", timeout=15)
        if r is None:
            return Response("", status=502)
        if r.status_code != 200:
            return Response("", status=r.status_code)
        ct = r.headers.get("Content-Type", "image/jpeg")
        return Response(r.content, mimetype=ct,
                        headers={"Cache-Control": "private, max-age=3600"})

    @bp.route("/progress", methods=["POST"])
    def progress():
        try:
            cfg = sdk.config()
            url = _base(cfg)
            hdr, basic = _auth(cfg)
            if not url or hdr is None:
                return jsonify({"ok": False})
            body = request.get_json(silent=True) or {}
            bid = str(body.get("bookId") or "").strip()
            if not _ok_id(bid):
                return jsonify({"ok": False})
            try:
                pnum = int(body.get("page") or 0)
                total = int(body.get("pages") or 0)
            except (TypeError, ValueError):
                return jsonify({"ok": False})
            if pnum < 1:
                return jsonify({"ok": False})
            payload = {"page": pnum,
                       "completed": bool(total and pnum >= total)}
            r = sdk.requests.patch(
                f"{url}/api/v1/books/{bid}/read-progress",
                headers=dict(hdr, **{"Content-Type": "application/json"}),
                auth=basic, json=payload, timeout=10, verify=False)
            return jsonify({"ok": r.ok})
        except Exception:
            sdk.log.exception("komga progress")
            return jsonify({"ok": False})

    return bp


def test(sdk, cfg):
    d = _overview(sdk, cfg)
    if d.get("ok"):
        return True, (f"Komga ✓ — {d['lib_count']} bibliothèque(s), "
                      f"{d['reading_count']} lecture(s) en cours")
    return False, f"Komga ✗ ({d.get('reason')})"
