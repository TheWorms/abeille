/* Komga — bibliothèques, en cours + nouveautés, recherche, liseuse intégrée. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.komga = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  let baseUrl = '', query = '', searchRes = null;
  const CSS =
    "  .kgwrap{flex:1;display:flex;flex-direction:column;min-height:0;--kg:#3d8bf2}\n" +
    "  .kgtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .kglibs{display:flex;gap:8px;flex-wrap:wrap;flex:1}\n" +
    "  .kglib{display:flex;align-items:center;gap:6px;background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:6px 11px;font-size:12.5px}\n" +
    "  .kgvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .kgvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .kgvtoggle button.on{background:var(--tile);color:var(--kg)}\n" +
    "  .kgsearch{padding:12px 22px 0}\n" +
    "  .kgsearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .kgscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .kgsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px;display:flex;align-items:center;gap:7px}\n" +
    "  .kgsec:first-child{margin-top:0}\n" +
    /* cards couverture */
    "  .kgcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:14px}\n" +
    "  .kgcard{cursor:pointer;display:flex;flex-direction:column;gap:6px}\n" +
    "  .kgcover-wrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .kgcard:hover .kgcover-wrap{border-color:var(--kg)}\n" +
    "  .kgcover{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .kgcover-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:34px;color:var(--dim)}\n" +
    "  .kgprog{position:absolute;left:0;right:0;bottom:0;height:5px;background:rgba(0,0,0,.4)}\n" +
    "  .kgprog i{display:block;height:100%;background:var(--kg)}\n" +
    "  .kgpct{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:7px}\n" +
    "  .kgcname{font-size:12.5px;font-weight:600;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    /* liste */
    "  .kgrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .kgrow:hover{border-color:var(--kg)}\n" +
    "  .kgrcover{width:40px;height:60px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .kgrph{width:40px;height:60px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--dim);flex:none}\n" +
    "  .kgrtx{min-width:0;flex:1}\n" +
    "  .kgrname{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kgrprog{height:6px;background:var(--bg);border-radius:3px;overflow:hidden;margin-top:5px}\n" +
    "  .kgrprog i{display:block;height:100%;background:var(--kg)}\n" +
    "  .kgrmeta{font-size:11.5px;color:var(--dim);margin-top:3px}\n" +
    "  .kgempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    /* fiche série */
    "  .kgdet{position:absolute;inset:0;background:var(--bg);z-index:40;display:flex;flex-direction:column}\n" +
    "  .kgdtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .kgdback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .kgdtitle{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kgdopen{font-size:12px;color:var(--kg);cursor:pointer;background:rgba(61,139,242,.12);border:1px solid rgba(61,139,242,.35);border-radius:9px;padding:7px 12px}\n" +
    "  .kgdbody{flex:1;min-height:0;overflow:auto;padding:14px 18px}\n" +
    "  .kgdhead{display:flex;gap:14px;margin-bottom:14px}\n" +
    "  .kgdcover{width:96px;aspect-ratio:2/3;border-radius:9px;object-fit:cover;background:var(--tile);flex:none}\n" +
    "  .kgdresume{margin-top:10px;background:var(--kg);color:#fff;border:0;border-radius:10px;padding:11px 18px;font-size:13.5px;font-weight:700;cursor:pointer}\n" +
    "  .kgchap{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:11px 13px;margin-bottom:7px;cursor:pointer}\n" +
    "  .kgchap:hover{border-color:var(--kg)}\n" +
    "  .kgchtx{flex:1;min-width:0}\n" +
    "  .kgchnm{font-weight:600;font-size:13.5px}\n" +
    "  .kgchmeta{font-size:11px;color:var(--dim);margin-top:1px}\n" +
    "  .kgchpct{font-size:11px;color:var(--kg);font-weight:700;flex:none}\n" +
    /* lecteur */
    "  .kgreader{position:fixed;inset:0;background:#000;z-index:9999;overflow:hidden}\n" +
    "  .kgrimg-wrap{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}\n" +
    "  .kgrimg{max-width:100%;max-height:100%;object-fit:contain;display:block}\n" +
    "  .kgrload{position:absolute;color:rgba(255,255,255,.6);font-size:14px}\n" +
    "  .kgtapL{position:absolute;left:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .kgtapC{position:absolute;left:33%;top:0;bottom:0;width:34%;z-index:2}\n" +
    "  .kgtapR{position:absolute;right:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .kgrtop{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:12px;padding:11px 16px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .kgrback{background:transparent;border:0;color:#fff;font-size:19px;cursor:pointer;padding:6px 10px}\n" +
    "  .kgrtt{min-width:0;flex:1}\n" +
    "  .kgrnm{color:#fff;font-size:13.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .kgrch{color:rgba(255,255,255,.6);font-size:11.5px}\n" +
    "  .kgrpg{color:rgba(255,255,255,.75);font-size:12.5px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .kgrbot{position:absolute;bottom:0;left:0;right:0;padding:12px 16px 14px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .kgrbot input[type=range]{width:100%}";
  function ensureCss() { let s = document.getElementById('kgUiCss'); if (!s) { s = document.createElement('style'); s.id = 'kgUiCss'; document.head.appendChild(s); } s.textContent = CSS; }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const coverUrl = id => '/addons/komga/api/cover?series=' + encodeURIComponent(id);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de la bibliothèque…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openInKomga(id) {
    if (!baseUrl) { S.toast('URL non configurée'); return; }
    const u = baseUrl + '/series/' + encodeURIComponent(id);
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  /* ===== fiche série (livres) ===== */
  async function openSeries(id, libId, name) {
    const det = document.createElement('div');
    det.className = 'kgdet';
    det.innerHTML = '<div class="kgdtop"><button class="kgdback">‹ Retour</button>' +
      '<span class="kgdtitle">' + esc(name || 'Série') + '</span>' +
      '<span class="kgdopen">Komga ↗</span></div>' +
      '<div class="kgdbody"><div class="kgempty">Chargement…</div></div>';
    root.style.position = 'relative';
    root.appendChild(det);
    det.querySelector('.kgdback').addEventListener('click', () => det.remove());
    det.querySelector('.kgdopen').addEventListener('click', () => openInKomga(id));
    let d = null;
    try { const r = await S.api('/series-detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'injoignable' }; }
    const body = det.querySelector('.kgdbody');
    if (!d || !d.ok) { body.innerHTML = '<div class="kgempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    // Komga : un volume unique factice, on aplatit directement les livres
    const flat = [];
    (d.volumes || []).forEach(v => (v.chapters || []).forEach(c => flat.push(Object.assign({}, c, { seriesId: id, libraryId: libId }))));
    // point de reprise : premier livre entamé non fini, sinon premier non lu, sinon le premier
    let resume = flat.find(c => c.pagesRead > 0 && c.pagesRead < c.pages) ||
                 flat.find(c => !c.pagesRead) || flat[0];
    let h = '<div class="kgdhead">' +
      '<img class="kgdcover" src="' + coverUrl(id) + '" onerror="this.style.display=\'none\'">' +
      '<div><div style="font-weight:700;font-size:16px">' + esc(name || '') + '</div>' +
      '<div style="font-size:12px;color:var(--dim);margin-top:3px">' + flat.length + ' livre(s)</div>' +
      (resume ? '<button class="kgdresume">▶ ' + (resume.pagesRead > 0 ? 'Reprendre' : 'Commencer') + ' la lecture</button>' : '') +
      '</div></div>';
    if (!flat.length) h += '<div class="kgempty">Aucun livre dans cette série.</div>';
    flat.forEach(c => {
      const pct = c.pages ? Math.round(c.pagesRead / c.pages * 100) : 0;
      h += '<div class="kgchap" data-ch="' + esc(c.id) + '">' +
        '<span>📖</span><div class="kgchtx"><div class="kgchnm">' + esc(c.title) + '</div>' +
        '<div class="kgchmeta">' + nf(c.pages) + ' pages' + (pct > 0 && pct < 100 ? ' · ' + pct + '% lu' : pct >= 100 ? ' · terminé ✓' : '') + '</div></div>' +
        (pct > 0 && pct < 100 ? '<span class="kgchpct">' + pct + '%</span>' : '') + '</div>';
    });
    body.innerHTML = h;
    const rbtn = body.querySelector('.kgdresume');
    if (rbtn && resume) rbtn.addEventListener('click', () =>
      openReader(flat, flat.indexOf(resume), name, Math.max(0, (resume.pagesRead || 1) - 1)));
    body.querySelectorAll('.kgchap').forEach(n => n.addEventListener('click', () => {
      const c = flat.find(x => String(x.id) === n.getAttribute('data-ch'));
      if (c) openReader(flat, flat.indexOf(c), name, (c.pagesRead > 0 && c.pagesRead < c.pages) ? c.pagesRead - 1 : 0);
    }));
  }

  /* ===== lecteur plein écran ===== */
  function pageUrl(bookId, pg) { return '/addons/komga/api/page?book=' + encodeURIComponent(bookId) + '&page=' + pg; }
  function openReader(books, idx, seriesName, startPage) {
    let ci = idx, pg = startPage || 0, controls = true, saveT = null;
    const ov = document.createElement('div');
    ov.className = 'kgreader';
    document.body.appendChild(ov);
    function chap() { return books[ci]; }
    function saveProgress() {
      if (saveT) clearTimeout(saveT);
      saveT = setTimeout(() => {
        const c = chap(); if (!c) return;
        S.api('/progress', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bookId: c.id, page: pg + 1, pages: c.pages }) }).catch(() => {});
      }, 700);
    }
    function preload() {
      const c = chap(); if (!c) return;
      for (let k = 1; k <= 2; k++) {
        if (pg + k < c.pages) { const im = new Image(); im.src = pageUrl(c.id, pg + k); }
      }
    }
    function draw() {
      const c = chap(); if (!c) { close(); return; }
      ov.innerHTML = '<div class="kgrimg-wrap"><span class="kgrload">Chargement…</span></div>' +
        '<div class="kgtapL"></div><div class="kgtapC"></div><div class="kgtapR"></div>' +
        (controls ?
          '<div class="kgrtop"><button class="kgrback">‹</button>' +
          '<div class="kgrtt"><div class="kgrnm">' + esc(seriesName || '') + '</div>' +
          '<div class="kgrch">' + esc(c.title) + '</div></div>' +
          '<span class="kgrpg">' + (pg + 1) + ' / ' + c.pages + '</span></div>' +
          '<div class="kgrbot"><input type="range" min="1" max="' + Math.max(1, c.pages) + '" step="1" value="' + (pg + 1) + '"></div>'
          : '');
      const wrap = ov.querySelector('.kgrimg-wrap');
      const img = new Image();
      img.className = 'kgrimg';
      img.onload = () => { wrap.innerHTML = ''; wrap.appendChild(img); preload(); };
      img.onerror = () => { wrap.innerHTML = '<span class="kgrload">⚠ page indisponible</span>'; };
      img.src = pageUrl(c.id, pg);
      ov.querySelector('.kgtapL').addEventListener('click', () => turn(-1));
      ov.querySelector('.kgtapR').addEventListener('click', () => turn(1));
      ov.querySelector('.kgtapC').addEventListener('click', () => { controls = !controls; draw(); });
      const bk = ov.querySelector('.kgrback'); if (bk) bk.addEventListener('click', close);
      const sl = ov.querySelector('.kgrbot input'); if (sl) sl.addEventListener('change', () => { pg = parseInt(sl.value, 10) - 1; draw(); saveProgress(); });
    }
    function turn(d) {
      const c = chap(); if (!c) return;
      const np = pg + d;
      if (np < 0) {
        if (ci > 0) { ci--; pg = Math.max(0, (chap().pages || 1) - 1); S.toast(chap().title); }
      } else if (np >= c.pages) {
        if (ci < books.length - 1) { ci++; pg = 0; S.toast(chap().title); }
        else { S.toast('Fin de la série 🎉'); }
      } else { pg = np; }
      draw(); saveProgress();
    }
    function close() {
      if (saveT) clearTimeout(saveT);
      ov.remove();
      render(root, S, tile);  // recharge (progression à jour)
    }
    draw(); saveProgress();
  }

  function card(s) {
    const ph = '<div class=\'kgcover-ph\'>📗</div>';
    return '<div class="kgcard" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<div class="kgcover-wrap">' +
      '<img class="kgcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      (s.percent ? '<span class="kgpct">' + s.percent + '%</span>' : '') +
      (s.percent ? '<div class="kgprog"><i style="width:' + s.percent + '%"></i></div>' : '') +
      '</div>' +
      '<div class="kgcname">' + esc(s.name) + '</div></div>';
  }
  function row(s) {
    const ph = '<div class=\'kgrph\'>📗</div>';
    return '<div class="kgrow" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<img class="kgrcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      '<div class="kgrtx"><div class="kgrname">' + esc(s.name) + '</div>' +
      (s.books ? '<div class="kgrprog"><i style="width:' + s.percent + '%"></i></div>' +
        '<div class="kgrmeta">' + nf(s.booksRead) + ' / ' + nf(s.books) + ' livres · ' + s.percent + '%' +
        (s.booksInProgress ? ' · ' + nf(s.booksInProgress) + ' en cours' : '') + '</div>' : '') +
      '</div></div>';
  }
  function renderSeries(list) {
    if (!list || !list.length) return '<div class="kgempty">Rien à afficher.</div>';
    if (viewMode === 'cards') return '<div class="kgcards">' + list.map(card).join('') + '</div>';
    return list.map(row).join('');
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📗</div><div class="t1">Komga indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Compte → Clés API).</div>' +
        '<button class="btnpill install" id="kgRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('kgRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="kgwrap"><div class="kgtopbar">' +
      '<div class="kglibs">' +
      (d.libraries.length ? d.libraries.map(l => '<span class="kglib">📚 ' + esc(l.name) + '</span>').join('') : '<span class="kgempty">Aucune bibliothèque</span>') +
      '</div>' +
      '<div class="kgvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="kgsearch"><input id="kgQ" type="search" placeholder="Rechercher une série…" value="' + esc(query) + '"></div>';
    h += '<div class="kgscroll">';

    if (query && searchRes) {
      h += '<div class="kgsec">' + nf(searchRes.count) + ' résultat(s)</div>';
      h += renderSeries(searchRes.series);
    } else if (query) {
      h += '<div class="kgempty">Recherche…</div>';
    } else {
      if (d.reading && d.reading.length) {
        h += '<div class="kgsec">▶️ Lectures en cours · ' + nf(d.reading_count) + '</div>';
        h += renderSeries(d.reading);
      }
      if (d.recent && d.recent.length) {
        h += '<div class="kgsec">✨ Nouveautés</div>';
        h += renderSeries(d.recent);
      }
      if ((!d.reading || !d.reading.length) && (!d.recent || !d.recent.length)) {
        h += '<div class="kgempty">Aucune série à afficher.</div>';
      }
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.kgvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    const qin = document.getElementById('kgQ');
    if (qin) qin.addEventListener('input', () => { query = qin.value; scheduleSearch(); });
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openSeries(n.getAttribute('data-id'), n.getAttribute('data-lib'), n.getAttribute('data-nm'))));
  }

  let _t = null;
  function scheduleSearch() {
    if (_t) clearTimeout(_t);
    const q = query;
    _t = setTimeout(async () => {
      if (!q) { searchRes = null; paint(); refocus(); return; }
      try { const r = await S.api('/search?q=' + encodeURIComponent(q)); searchRes = await r.json(); }
      catch (e) { searchRes = { ok: false, count: 0, series: [] }; }
      if (query === q) { paint(); refocus(); }
    }, 350);
  }
  function refocus() {
    const nq = document.getElementById('kgQ');
    if (nq) { nq.focus(); const l = nq.value.length; try { nq.setSelectionRange(l, l); } catch (e) {} }
  }

  return { render };
})();
