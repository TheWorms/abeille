/* Instagram — interface embarquée (contrat Phase 3, crash-test n°1).
   Portage intégral de la vue du socle : galerie (profils, filtres, mode
   suppression), visionneuse plein écran (clavier, vidéo, corbeille) et
   volet ⚙ de pilotage de la synchronisation insta-ctl.
   SDK consommé : api, toast, session, delMode, esc. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.instagram = (function () {
  let S = null, root = null, tile = null;
  let data = null, post = 0, slide = 0, profile = null, adm = false, filter = 'all';
  let syncPoll = null, cfgPoll = null;

  const CSS = "  .iggrid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}\n  .igtile{position:relative;aspect-ratio:1;border-radius:10px;overflow:hidden;background:var(--tile);\n          border:1px solid var(--border-soft);cursor:pointer}\n  .igtile img{width:100%;height:100%;object-fit:cover;display:block}\n  .igtile:active{border-color:var(--accent)}\n  .igbadge{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.6);color:#fff;font-size:10px;\n           padding:2px 6px;border-radius:6px;backdrop-filter:blur(4px)}\n  .igplay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:30px;\n          color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.6);pointer-events:none}\n  .igview{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9998;display:flex;flex-direction:column}\n  .igtop{display:flex;align-items:center;gap:12px;padding:12px 16px;color:#fff;flex:none}\n  .igtop .t{font-size:13px;opacity:.75;font-variant-numeric:tabular-nums}\n  .igclose{margin-left:auto;font-size:22px;cursor:pointer;padding:2px 10px;border-radius:8px}\n  .igclose:active{background:rgba(255,255,255,.15)}\n  .igstage{flex:1;display:flex;align-items:center;justify-content:center;position:relative;min-height:0;padding:0 8px}\n  .igstage img,.igstage video{max-width:100%;max-height:100%;object-fit:contain;border-radius:8px}\n  .ignav{position:absolute;top:50%;transform:translateY(-50%);width:56px;height:56px;border-radius:50%;\n         background:rgba(0,0,0,.45);color:#fff;display:flex;align-items:center;justify-content:center;\n         font-size:24px;cursor:pointer;user-select:none;border:1px solid rgba(255,255,255,.18)}\n  .ignav.prev{left:14px}\n  .ignav:active{background:rgba(255,255,255,.2)}\n  .igcap{color:#fff;font-size:13px;line-height:1.5;padding:10px 20px 4px;max-height:74px;overflow:auto;flex:none;\n         white-space:pre-wrap}\n  .igctrl{display:flex;align-items:center;gap:12px;padding:10px 18px 16px;flex:none}\n  .igbtn{width:52px;height:52px;border-radius:12px;background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.16);\n         display:flex;align-items:center;justify-content:center;font-size:17px;cursor:pointer;flex:none;user-select:none}\n  .igbtn:active{background:rgba(255,255,255,.24)}\n  .igbtn.big{width:62px;height:52px;font-size:21px}\n  .igtime{color:#fff;font-size:12px;font-variant-numeric:tabular-nums;min-width:96px;text-align:center;flex:none}\n  .igseek{flex:1;height:30px;cursor:pointer}\n  .igdots{display:flex;gap:5px;justify-content:center;padding-bottom:6px;flex:none}\n  .igdots i{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.3);display:block}\n  .igdots i.on{background:#fff}\n  .igbtn.del{background:rgba(224,82,82,.22);border-color:rgba(224,82,82,.5)}\n  .igbtn.del:active{background:rgba(224,82,82,.45)}\n  .igadmin{font-size:11px;color:var(--faint);margin-bottom:9px}\n  .igsync{display:flex;align-items:center;gap:10px;background:var(--tile);border:1px solid var(--border-soft);\n          border-radius:10px;padding:9px 13px;margin-bottom:10px;font-size:11.5px;flex-wrap:wrap}\n  .igsync.ko{border-color:var(--bad)}\n  .igsync.run{border-color:var(--accent)}\n  .igsync b{font-variant-numeric:tabular-nums}\n  .igsync .sep{width:1px;height:16px;background:var(--border-soft)}\n  .igsync .dim{color:var(--dim)}\n  .igbar{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}\n  .igicon{width:40px;height:40px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);\n          display:flex;align-items:center;justify-content:center;font-size:16px;cursor:pointer;flex:none;user-select:none}\n  .igicon:active{background:var(--accent-tint);border-color:var(--accent)}\n  .igicon.danger{color:var(--bad);border-color:rgba(224,82,82,.45)}\n  .igicon.danger:active{background:rgba(224,82,82,.18)}\n  .igicon[disabled]{opacity:.4;pointer-events:none}\n  .igtrashicon{position:absolute;top:6px;left:6px;width:28px;height:28px;border-radius:8px;\n       background:rgba(0,0,0,.55);color:#fff;display:flex;align-items:center;justify-content:center;\n       font-size:13px;cursor:pointer}\n  .igtrashicon:active{background:rgba(224,82,82,.85)}\n  .igcount{margin-left:auto;font-size:12px;color:var(--dim);font-variant-numeric:tabular-nums}\n  .igbtn2{padding:8px 14px;border-radius:9px;border:1px solid var(--border-soft);background:var(--tile);\n          color:var(--text);font-size:12.5px;cursor:pointer;user-select:none}\n  .igbtn2:active{background:var(--accent-tint);border-color:var(--accent)}\n  .igbtn2.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n  .igbtn2.danger{border-color:var(--bad);color:var(--bad)}\n  .igbtn2.danger:active{background:rgba(224,82,82,.18)}\n  .igbtn2[disabled]{opacity:.45;pointer-events:none}\n  .igbub{position:absolute;top:6px;right:6px;width:24px;height:24px;border-radius:50%;\n         border:2px solid rgba(255,255,255,.85);background:rgba(0,0,0,.35);display:none;\n         align-items:center;justify-content:center;color:#fff;font-size:13px;font-weight:700}\n  .iggrid.select .igbub{display:flex}\n  .igtile.picked{outline:3px solid var(--accent);outline-offset:-3px}\n  .igtile.picked .igbub{background:var(--accent);border-color:#fff}\n  .igtrash{background:var(--tile);border:1px dashed var(--border-soft);border-radius:10px;\n           padding:10px 13px;margin-bottom:10px;font-size:11.5px;display:flex;align-items:center;gap:10px}\n  .igtf{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:9px;border:1px solid var(--border-soft);\n        background:var(--tile);margin-bottom:5px;cursor:pointer;font-size:12px}\n  .igtf.picked{border-color:var(--bad);background:rgba(224,82,82,.10)}\n  .igtf .box{width:20px;height:20px;border-radius:6px;border:2px solid var(--border-soft);flex:none;\n             display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff}\n  .igtf.picked .box{background:var(--bad);border-color:var(--bad)}\n  .igtf .nm{font-family:var(--mono);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .igtf .sz{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n  .igtlist{max-height:280px;overflow:auto;margin:8px 0}";
  function ensureCss() {
    if (document.getElementById('igUiCss')) return;
    const st = document.createElement('style');
    st.id = 'igUiCss'; st.textContent = CSS;
    document.head.appendChild(st);
  }

  const url = (p, f) => '/addons/instagram/api/media/' + encodeURIComponent(p) + '/' + encodeURIComponent(f);
  const media = p => p.videos.concat(p.images);
  const fmt = s2 => { if (!isFinite(s2)) return '0:00'; const m = Math.floor(s2 / 60); return m + ':' + String(Math.floor(s2 % 60)).padStart(2, '0'); };
  const stopSyncPoll = () => { if (syncPoll) { clearInterval(syncPoll); syncPoll = null; } };

  async function trashPost(payload) {
    try {
      const r = await S.api('/trash', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const j = await r.json();
      if (j.ok) { S.toast(j.count + ' fichier(s) mis à la corbeille'); return true; }
      S.toast('Impossible — ' + (j.reason || ''));
    } catch (e) { S.toast('Serveur injoignable'); }
    return false;
  }

  /* ---- visionneuse ---- */
  function vOpen(i) {
    post = i; slide = 0;
    const v = document.createElement('div'); v.className = 'igview'; v.id = 'igView';
    document.body.appendChild(v);
    vRender();
    document.addEventListener('keydown', vKeys);
  }
  function vClose() {
    const v = document.getElementById('igView'); if (v) v.remove();
    document.removeEventListener('keydown', vKeys);
  }
  function vKeys(e) {
    if (e.key === 'Escape') vClose();
    else if (e.key === 'ArrowRight') vStep(1);
    else if (e.key === 'ArrowLeft') vStep(-1);
    else if (e.key === ' ') { e.preventDefault(); vToggle(); }
  }
  function vStep(d) {
    const p = data.posts[post], med = media(p);
    if (slide + d >= 0 && slide + d < med.length) { slide += d; vRender(); return; }
    const n = post + d;
    if (n >= 0 && n < data.posts.length) { post = n; slide = (d > 0 ? 0 : media(data.posts[n]).length - 1); vRender(); }
  }
  function vToggle() {
    const vid = document.querySelector('#igView video');
    if (vid) vid.paused ? vid.play() : vid.pause();
  }
  function vRender() {
    const v = document.getElementById('igView'); if (!v || !data) return;
    const p = data.posts[post], med = media(p), file = med[slide];
    const isVid = /\.(mp4|mov|webm)$/i.test(file);
    const prof = data.profile;
    let h = '<div class="igtop"><span class="t">' + p.date + '</span>' +
      '<span class="t">' + (post + 1) + ' / ' + data.posts.length + '</span>' +
      '<span class="igclose" id="igX">✕</span></div>';
    h += '<div class="igstage">' +
      (isVid
        ? '<video id="igVid" src="' + url(prof, file) + '" playsinline autoplay></video>'
        : '<img src="' + url(prof, file) + '">') +
      '<div class="ignav prev" id="igPrev">‹</div><div class="ignav next" id="igNext">›</div></div>';
    if (med.length > 1) h += '<div class="igdots">' + med.map((_, k) => '<i class="' + (k === slide ? 'on' : '') + '"></i>').join('') + '</div>';
    if (p.caption) h += '<div class="igcap">' + p.caption.replace(/</g, '&lt;') + '</div>';
    if (isVid) {
      h += '<div class="igctrl"><span class="igbtn" id="igBack">⏪ 10</span>' +
        '<span class="igbtn big" id="igPlay">⏸</span>' +
        '<span class="igbtn" id="igFwd">10 ⏩</span>' +
        '<span class="igtime" id="igT">0:00 / 0:00</span>' +
        '<input class="igseek" id="igSeek" type="range" min="0" max="1000" value="0">' +
        '<span class="igbtn" id="igFull">⛶</span>' +
        '<span class="igbtn del" id="igDelM" title="Supprimer ce média">🗑</span></div>';
    } else {
      h += '<div class="igctrl"><span class="igbtn" id="igBackP">‹</span>' +
        '<span class="igtime">' + (slide + 1) + ' / ' + med.length + '</span>' +
        '<span class="igbtn" id="igNextP">›</span>' +
        '<span class="igbtn del" id="igDelM" title="Supprimer ce média">🗑</span></div>';
    }
    v.innerHTML = h;
    v.querySelector('#igX').addEventListener('click', vClose);
    v.querySelector('#igPrev').addEventListener('click', () => vStep(-1));
    v.querySelector('#igNext').addEventListener('click', () => vStep(1));
    const bp = v.querySelector('#igBackP'), np = v.querySelector('#igNextP');
    if (bp) bp.addEventListener('click', () => vStep(-1));
    if (np) np.addEventListener('click', () => vStep(1));
    const dm = v.querySelector('#igDelM');
    if (dm) dm.addEventListener('click', async () => {
      if (!confirm('Supprimer ce média ?\n' + file + '\nIl part à la corbeille.')) return;
      const okDel = await trashPost({ profile: data.profile, medias: [file] });
      if (!okDel) return;
      vClose();
      render(root, S, tile);
    });
    if (isVid) {
      const vid = v.querySelector('#igVid'), play = v.querySelector('#igPlay'),
        seek = v.querySelector('#igSeek'), tl = v.querySelector('#igT');
      v.querySelector('#igBack').addEventListener('click', () => { vid.currentTime = Math.max(0, vid.currentTime - 10); });
      v.querySelector('#igFwd').addEventListener('click', () => { vid.currentTime = Math.min(vid.duration || 0, vid.currentTime + 10); });
      play.addEventListener('click', () => { vid.paused ? vid.play() : vid.pause(); });
      vid.addEventListener('play', () => play.textContent = '⏸');
      vid.addEventListener('pause', () => play.textContent = '▶');
      vid.addEventListener('timeupdate', () => {
        if (vid.duration) {
          seek.value = Math.round(vid.currentTime / vid.duration * 1000);
          tl.textContent = fmt(vid.currentTime) + ' / ' + fmt(vid.duration);
        }
      });
      seek.addEventListener('input', () => { if (vid.duration) vid.currentTime = seek.value / 1000 * vid.duration; });
      v.querySelector('#igFull').addEventListener('click', () => {
        if (vid.requestFullscreen) vid.requestFullscreen().catch(() => {}); });
      v.querySelector('.igstage').addEventListener('click', e => { if (e.target === vid) vToggle(); });
    }
  }

  /* ---- galerie ---- */
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile;
    ensureCss();
    stopSyncPoll();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture du dossier…</div></div>';
    let d = null;
    try { const r = await S.api('/summary' + (profile ? ('?profile=' + encodeURIComponent(profile)) : '')); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d.ok) {
      const wait = d.empty === true;
      el.innerHTML = '<div class="stub"><div class="big">' + (wait ? '📥' : '📸') + '</div><div class="t1">' + (wait ? 'En attente de synchronisation' : 'Instagram') + '</div>' +
        '<div class="t2">' + (d.reason || '') + '<br>Cet addon lit un dossier alimenté par <code>instaloader</code> — il ne se connecte jamais à Instagram.</div></div>';
      return;
    }
    data = d; profile = d.profile;
    adm = !!(await S.session()).admin;
    const delMode = S.delMode();
    let h = '';
    if (d.profiles.length > 1) h += '<div class="tpfav">' + d.profiles.map(p => '<span class="tpchip' + (p === d.profile ? ' on' : '') + '" data-prof="' + p + '">' +
      (p === 'saved' ? '⭐ enregistrés' : '👤 ' + p) + '</span>').join('') + '</div>';
    const sy = d.sync || {};
    if (sy.available) {
      const cls = sy.running ? 'run' : (sy.result && sy.result !== 'success' ? 'ko' : '');
      const icn = sy.running ? '⏳' : (sy.result === 'success' ? '✅' : '⚠️');
      h += '<div class="igsync ' + cls + '">' + icn + ' ' +
        (sy.running ? 'Synchronisation en cours…'
          : ('Dernière synchro : <b>' + (sy.finished ? sy.finished.replace(/^\w+ /, '').slice(0, 16) : 'jamais') + '</b>' +
            (sy.result && sy.result !== 'success' ? ' — <b>échec (' + sy.result + ')</b>' : ''))) +
        '<span class="sep"></span><span class="dim">Prochaine : <b>' + (sy.timer_active ? (sy.next || '—') : 'timer inactif') + '</b></span>' +
        '<span class="sep"></span><span class="dim"><b>' + d.total + '</b> posts · <b>' + d.videos + '</b> vidéos · <b>' +
        (d.size_gb >= 1 ? d.size_gb + ' Go' : Math.round(d.size_gb * 1024) + ' Mo') + '</b></span>' +
        (d.last_file ? '<span class="sep"></span><span class="dim">dernier média : <b>' + d.last_file + '</b></span>' : '') +
        (adm ? '<button class="wch igsyncbtn" id="igSyncBtn"' + (sy.running ? ' disabled' : '') + '>' + (sy.running ? '⏳ en cours…' : '⟳ Synchroniser') + '</button>' : '') +
        '</div>';
    } else {
      h += '<div class="igsync"><span class="dim">📁 <b>' + d.total + '</b> posts · <b>' +
        (d.size_gb >= 1 ? d.size_gb + ' Go' : Math.round(d.size_gb * 1024) + ' Mo') + '</b> — synchro automatique non détectée sur cette machine</span></div>';
    }
    const nVid = d.posts.filter(p => p.video).length, nPho = d.posts.length - nVid;
    h += '<div class="tptabs"><span class="wch' + (filter === 'all' ? ' on' : '') + '" data-igf="all">Tout (' + d.posts.length + ')</span>' +
      '<span class="wch' + (filter === 'photo' ? ' on' : '') + '" data-igf="photo">🖼️ Photos (' + nPho + ')</span>' +
      '<span class="wch' + (filter === 'video' ? ' on' : '') + '" data-igf="video">🎬 Vidéos (' + nVid + ')</span></div>';
    d.posts = (data.posts || []).filter(p => filter === 'all' || (filter === 'video' ? p.video : !p.video));
    if (!d.posts.length) h += '<div class="stub"><div class="big">' + (filter === 'video' ? '🎬' : '🖼️') + '</div>' +
      '<div class="t2">' + (filter === 'all' ? 'Aucun média dans ce dossier' : 'Aucun média de ce type') + '</div></div>';
    else {
      if (delMode) h += '<div class="igadmin">🗑️ Mode suppression actif : touche la corbeille d\'une vignette pour l\'envoyer à la corbeille (restaurable dans ⚙ → Corbeille).</div>';
      h += '<div class="iggrid">' + d.posts.map((p, i) => {
        const cover = p.images.length ? p.images[0] : null;
        return '<div class="igtile" data-i="' + i + '" data-id="' + p.id + '">' +
          (cover ? '<img loading="lazy" src="' + url(d.profile, cover) + '">' : '<div style="width:100%;height:100%;background:#0d1116"></div>') +
          (p.video ? '<div class="igplay">▶</div>' : '') +
          (p.count > 1 ? '<div class="igbadge">🖼 ' + p.count + '</div>' : '') +
          (delMode ? '<span class="igtrashicon" data-igdel="' + p.id + '" data-date="' + p.date + '" data-n="' + p.count + '">🗑</span>' : '') +
          '</div>'; }).join('') + '</div>';
    }
    h += '<div class="wsrc">Lecture hors ligne d\'un dossier local · aucune connexion à Instagram · vue embarquée v0.3.0</div>';
    el.innerHTML = h;
    el.querySelectorAll('[data-prof]').forEach(c => c.addEventListener('click', () => { profile = c.dataset.prof; filter = 'all'; render(el, S, tile); }));
    el.querySelectorAll('[data-igf]').forEach(t => t.addEventListener('click', () => { filter = t.dataset.igf; render(el, S, tile); }));
    el.querySelectorAll('.igtile').forEach(t => t.addEventListener('click', ev => {
      if (ev.target.dataset.igdel != null) return;
      vOpen(parseInt(t.dataset.i)); }));
    el.querySelectorAll('[data-igdel]').forEach(b => b.addEventListener('click', async ev => {
      ev.stopPropagation();
      const n = parseInt(b.dataset.n) || 1;
      if (!confirm('Supprimer la publication du ' + b.dataset.date + ' (' + n + ' média' + (n > 1 ? 's' : '') + ') ?\nElle part à la corbeille, restaurable dans ⚙ → Corbeille.')) return;
      const ok = await trashPost({ profile: data.profile, posts: [b.dataset.igdel] });
      if (ok) render(el, S, tile);
    }));
    const sb = document.getElementById('igSyncBtn');
    if (sb) sb.addEventListener('click', async () => {
      sb.disabled = true; sb.textContent = '⏳ démarrage…';
      try {
        const r = await S.api('/sync', { method: 'POST' });
        const j = await r.json();
        if (!j.ok) { S.toast('Synchro : ' + (j.reason || 'échec')); sb.disabled = false; sb.textContent = '⟳ Synchroniser'; return; }
        S.toast('Synchronisation lancée');
        let n = 0;
        stopSyncPoll();
        syncPoll = setInterval(async () => {
          if (++n > 50 || !document.body.contains(el)) { stopSyncPoll(); return; }
          let dd = null; try { const rr = await S.api('/summary'); dd = await rr.json(); } catch (e) {}
          if (!(dd && dd.sync && dd.sync.running)) { stopSyncPoll(); render(el, S, tile); }
        }, 6000);
        render(el, S, tile);
      } catch (e) { S.toast('Synchro injoignable'); sb.disabled = false; sb.textContent = '⟳ Synchroniser'; }
    });
  }

  /* ---- volet ⚙ (pilotage insta-ctl) ---- */
  function configPanel(box, sdk) {
    S = S || sdk;
    const A = sdk;
    if (cfgPoll) { clearInterval(cfgPoll); cfgPoll = null; }
    const stop = () => { if (cfgPoll) { clearInterval(cfgPoll); cfgPoll = null; } };
    const load = async () => {
      if (!document.body.contains(box)) { stop(); return; }         // panneau fermé
      if (cfgPoll && box.contains(document.activeElement)) return;  // saisie en cours
      let st = null;
      try { const r = await A.api('/sync/status'); st = await r.json(); } catch (e) { st = null; }
      if (!st || !st.available) {
        stop();
        box.innerHTML = '<div class="cmeta" style="padding:4px 2px;line-height:1.5">📸 Synchronisation pilotée indisponible — <code>insta-ctl</code> n\'est pas installé sur cette machine.' +
          (st && st.reason ? '<br>' + A.esc(st.reason) : '') + '</div>';
        return;
      }
      const running = (st.active === 'activating' || st.active === 'active');
      const cal = st.calendar || '';
      let mode = 'off', hm = '03:20', m;
      if (st.timer && cal) {
        if (cal === '00/6:00:00') mode = '6h';
        else if (cal === '00/12:00:00') mode = '12h';
        else if ((m = cal.match(/^\*-\*-\* (\d{2}):(\d{2}):00$/))) { mode = 'daily'; hm = m[1] + ':' + m[2]; }
      }
      box.innerHTML = '<div class="cfgf"><span>Synchronisation Instagram</span>' +
        '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:4px">' +
        '<button type="button" class="btnpill install" id="igRunBtn"' + (running ? ' disabled' : '') + '>' +
        (running ? '⏳ Synchronisation en cours…' : '⟳ Synchroniser maintenant') + '</button>' +
        '<span style="font-size:12px;color:var(--dim)">' +
        (running ? 'en cours…' : ('dernière : <b>' + (st.last_exit || 'jamais') + '</b>' +
          (st.result === 'success' ? ' ✓' : (st.result ? ' — <b style="color:var(--bad)">échec (' + st.result + ')</b>' : '')))) +
        (st.timer ? ' · prochaine : <b>' + (st.next || '—') + '</b>' : ' · planification désactivée') +
        '</span></div></div>' +
        '<div class="cfgf" style="margin-top:8px"><span>Planification automatique</span>' +
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:4px">' +
        '<select class="inp" id="igSchedSel" style="max-width:220px">' +
        '<option value="off"' + (mode === 'off' ? ' selected' : '') + '>Désactivée</option>' +
        '<option value="daily"' + (mode === 'daily' ? ' selected' : '') + '>Quotidienne à…</option>' +
        '<option value="6h"' + (mode === '6h' ? ' selected' : '') + '>Toutes les 6 h</option>' +
        '<option value="12h"' + (mode === '12h' ? ' selected' : '') + '>Toutes les 12 h</option></select>' +
        '<input class="inp" id="igSchedTime" type="time" value="' + hm + '" style="max-width:120px;display:' + (mode === 'daily' ? 'block' : 'none') + '">' +
        '<button type="button" class="btnpill" id="igSchedApply">Appliquer</button>' +
        '<span id="igSchedRes" style="font-size:12px"></span></div></div>';
      const runBtn = document.getElementById('igRunBtn');
      runBtn.addEventListener('click', async () => {
        runBtn.disabled = true; runBtn.textContent = '⏳ démarrage…';
        try {
          const r = await A.api('/sync', { method: 'POST' });
          const j = await r.json();
          if (!j.ok) { A.toast('Synchro : ' + (j.reason || 'échec')); load(); return; }
          A.toast('Synchronisation lancée');
          setTimeout(load, 1200);
        } catch (e) { A.toast('Serveur injoignable'); load(); }
      });
      const sel = document.getElementById('igSchedSel'), ti = document.getElementById('igSchedTime');
      sel.addEventListener('change', () => { ti.style.display = sel.value === 'daily' ? 'block' : 'none'; });
      document.getElementById('igSchedApply').addEventListener('click', async () => {
        const res = document.getElementById('igSchedRes');
        let expr = 'off';
        if (sel.value === '6h') expr = '00/6:00:00';
        else if (sel.value === '12h') expr = '00/12:00:00';
        else if (sel.value === 'daily') {
          const v = (ti.value || '').trim();
          if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { res.textContent = '✗ heure invalide'; res.style.color = 'var(--bad)'; return; }
          expr = '*-*-* ' + v + ':00';
        }
        res.textContent = 'application…'; res.style.color = 'var(--dim)';
        try {
          const r = await A.api('/schedule', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expr: expr }) });
          const j = await r.json();
          if (j.ok) { res.textContent = '✓ planification appliquée'; res.style.color = 'var(--green)'; setTimeout(load, 800); }
          else { res.textContent = '✗ ' + (j.reason || 'refusé'); res.style.color = 'var(--bad)'; }
        } catch (e) { res.textContent = '✗ serveur injoignable'; res.style.color = 'var(--bad)'; }
      });
      if (running) { if (!cfgPoll) cfgPoll = setInterval(load, 6000); }
      else stop();
    };
    load();
  }

  function unmount() {
    vClose();
    stopSyncPoll();
    if (cfgPoll) { clearInterval(cfgPoll); cfgPoll = null; }
  }

  return { render, configPanel, unmount };
})();
