"""Addon « instagram » — lecteur des publications sauvegardées (lot N).

Migré du noyau vers un backend autonome. Lit l'arborescence produite par
instaloader (dossier ``path``), regroupe les carrousels, sert les médias avec
support Range (vidéo), et gère une corbeille **fichier** propre à instaloader :
les médias supprimés sont déplacés dans ``.corbeille`` et un marqueur vide est
laissé à leur place pour qu'instaloader ne les retélécharge pas.

La corbeille reste fichier (et non le fournisseur « corbeille » du lot E, qui
stocke du JSON léger) : on déplace ici des médias potentiellement lourds.

Routes de gestion de corbeille (list/purge/restore) réservées à l'admin
(parité avec l'ancien @require_admin ; le guard noyau n'impose que l'auth).
"""
import json
import lzma
import os
import re
import shutil
import subprocess
import time
from datetime import datetime

_EXT_IMG = (".jpg", ".jpeg", ".png", ".webp")
_EXT_VID = (".mp4", ".mov", ".webm")
_TRASH = ".corbeille"
_NAME = re.compile(r"[A-Za-z0-9._-]{1,128}")
_PROF = re.compile(r"[A-Za-z0-9._-]{1,64}")


def _run(args, timeout=6):
    """systemctl en liste d'arguments (jamais de shell)."""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, r.stdout
    except (subprocess.SubprocessError, OSError):
        return False, ""


def _root(cfg):
    root = os.path.expanduser((cfg.get("path") or "/srv/instagram").rstrip("/"))
    try:
        os.makedirs(root, exist_ok=True)   # créé à la volée (supporte ~)
    except OSError as e:
        raise RuntimeError(f"dossier inaccessible : {root} ({e.strerror})")
    return root


def _caption(base):
    txt = base + ".txt"
    if os.path.exists(txt):
        try:
            with open(txt, encoding="utf-8", errors="replace") as f:
                return f.read().strip()[:400]
        except OSError:
            pass
    meta = base + ".json.xz"
    if os.path.exists(meta):
        try:
            with lzma.open(meta, "rt", encoding="utf-8") as f:
                j = json.load(f)
            node = j.get("node") or j
            edges = ((node.get("edge_media_to_caption") or {}).get("edges") or [])
            if edges:
                return (edges[0].get("node", {}).get("text") or "")[:400]
        except (OSError, ValueError, lzma.LZMAError):
            pass
    return ""


def _sync_status():
    out = {"available": False}
    ok, txt = _run(["systemctl", "show", "insta-sync.service",
                    "-p", "ActiveState", "-p", "Result",
                    "-p", "ExecMainStartTimestamp", "-p", "ExecMainExitTimestamp"])
    if not ok:
        return out
    kv = dict(l.split("=", 1) for l in txt.strip().split("\n") if "=" in l)
    if not kv:
        return out
    out["available"] = True
    out["result"] = kv.get("Result", "")
    out["state"] = kv.get("ActiveState", "")
    out["running"] = kv.get("ActiveState") == "activating"
    for src, dst in (("ExecMainStartTimestamp", "started"),
                     ("ExecMainExitTimestamp", "finished")):
        v = kv.get(src, "").strip()
        out[dst] = v if v and v != "n/a" else ""
    ok2, txt2 = _run(["systemctl", "show", "insta-sync.timer",
                      "-p", "NextElapseUSecRealtime", "-p", "ActiveState"])
    if ok2:
        kv2 = dict(l.split("=", 1) for l in txt2.strip().split("\n") if "=" in l)
        out["timer_active"] = kv2.get("ActiveState") == "active"
        try:
            us = int(kv2.get("NextElapseUSecRealtime", "0"))
            out["next"] = (datetime.fromtimestamp(us / 1e6).strftime("%d/%m %H:%M") if us else "")
        except (ValueError, OSError):
            out["next"] = ""
    return out


def _scan(sdk, cfg, profile=None):
    root = _root(cfg)
    profiles = sorted(d for d in os.listdir(root)
                      if os.path.isdir(os.path.join(root, d)) and not d.startswith("."))
    if not profiles:
        return {"ok": False, "empty": True,
                "reason": "Dossier prêt — aucune publication téléchargée pour l'instant. "
                          "Configure la synchro (login + cible) puis lance instaloader."}
    if profile in profiles:
        prof = profile
    else:
        want = (cfg.get("profile") or "").strip()
        prof = want if want in profiles else max(
            profiles, key=lambda d: len(os.listdir(os.path.join(root, d))))
    pdir = os.path.join(root, prof)

    key = f"ig:{pdir}:{os.path.getmtime(pdir)}"
    hit = sdk.cache_get(key, 300)
    if hit is not None:
        return hit

    groups = {}
    for f in os.listdir(pdir):
        p = os.path.join(pdir, f)
        if not os.path.isfile(p):
            continue
        stem, ext = os.path.splitext(f)
        ext = ext.lower()
        if ext not in _EXT_IMG + _EXT_VID:
            continue
        if stem.endswith("_profile_pic"):
            continue
        if os.path.getsize(p) == 0:      # marqueur de corbeille
            continue
        gkey = re.sub(r"_\d+$", "", stem)
        g = groups.setdefault(gkey, {"images": [], "videos": []})
        (g["videos"] if ext in _EXT_VID else g["images"]).append(f)

    posts = []
    for gkey, g in groups.items():
        first = sorted(g["videos"] + g["images"])[0]
        stat = os.stat(os.path.join(pdir, first))
        m = re.match(r"(\d{4})-(\d{2})-(\d{2})_(\d{2})-(\d{2})-(\d{2})", gkey)
        when = ("-".join(m.groups()[:3]) + " " + ":".join(m.groups()[3:])) if m else ""
        posts.append({
            "id": gkey,
            "date": when or datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            "images": sorted(g["images"]), "videos": sorted(g["videos"]),
            "count": len(g["images"]) + len(g["videos"]), "video": bool(g["videos"]),
            "caption": _caption(os.path.join(pdir, gkey)),
            "size_mb": round(sum(os.path.getsize(os.path.join(pdir, x))
                                 for x in g["images"] + g["videos"]) / 1048576, 1),
        })
    posts.sort(key=lambda x: x["date"], reverse=True)
    total_bytes, nvid = 0, 0
    for p in posts:
        total_bytes += p["size_mb"] * 1048576
        if p["video"]:
            nvid += 1
    last = max((os.path.getmtime(os.path.join(pdir, f)) for f in os.listdir(pdir)), default=0)
    res = {"ok": True, "profile": prof, "profiles": profiles,
           "posts": posts[:200], "total": len(posts), "videos": nvid,
           "size_gb": round(total_bytes / 1073741824, 2),
           "last_file": (datetime.fromtimestamp(last).strftime("%d/%m %H:%M") if last else ""),
           "sync": _sync_status()}
    return sdk.cache_set(key, res)


def _safe_path(cfg, profile, name=None):
    root = os.path.realpath(_root(cfg))
    if not _PROF.fullmatch(profile or ""):
        raise RuntimeError("profil invalide")
    pdir = os.path.realpath(os.path.join(root, profile))
    if not pdir.startswith(root + os.sep):
        raise RuntimeError("chemin refusé")
    if name is None:
        return pdir
    if not _NAME.fullmatch(name):
        raise RuntimeError("nom invalide")
    target = os.path.realpath(os.path.join(pdir, name))
    if not target.startswith(pdir + os.sep):
        raise RuntimeError("chemin refusé")
    return target


def _trash_dir(cfg, profile):
    root = os.path.realpath(_root(cfg))
    t = os.path.join(root, _TRASH, profile)
    os.makedirs(t, exist_ok=True)
    return t


def _files_of(pdir, post):
    out = []
    for f in os.listdir(pdir):
        stem, ext = os.path.splitext(f)
        if re.sub(r"_\d+$", "", stem) != post:
            continue
        if ext.lower() in _EXT_IMG + _EXT_VID + (".txt", ".json", ".xz"):
            out.append(f)
    return out


def register(sdk):
    from flask import (Blueprint, jsonify, request, Response, session,
                       send_from_directory)
    bp = Blueprint("instagram", __name__)

    def _admin():
        return bool(session.get("admin"))

    @bp.route("/summary")
    def summary():
        cfg = sdk.config()
        try:
            return jsonify(_scan(sdk, cfg, request.args.get("profile")))
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except OSError as e:
            return jsonify({"ok": False, "reason": f"lecture impossible ({e.strerror})"})

    @bp.route("/media/<profile>/<path:name>")
    def media(profile, name):
        cfg = sdk.config()
        try:
            root = _root(cfg)
        except RuntimeError as e:
            return Response(str(e), status=404)
        if not _PROF.fullmatch(profile):
            return Response("profil invalide", status=400)
        if not _NAME.fullmatch(name):
            return Response("nom invalide", status=400)
        pdir = os.path.realpath(os.path.join(root, profile))
        target = os.path.realpath(os.path.join(pdir, name))
        if not (target.startswith(os.path.realpath(root) + os.sep) and os.path.isfile(target)):
            return Response("introuvable", status=404)
        if not target.lower().endswith(_EXT_IMG + _EXT_VID):
            return Response("type refusé", status=403)
        return send_from_directory(os.path.dirname(target), os.path.basename(target),
                                   conditional=True)

    @bp.route("/trash", methods=["POST"])
    def trash_move():
        j = request.get_json(force=True, silent=True) or {}
        cfg = sdk.config()
        profile = (j.get("profile") or "").strip()
        posts = j.get("posts") or []
        medias = j.get("medias") or []
        if not (posts or medias):
            return jsonify({"ok": False, "reason": "rien à supprimer"}), 400
        try:
            pdir = _safe_path(cfg, profile)
            tdir = _trash_dir(cfg, profile)
        except (RuntimeError, OSError) as e:
            return jsonify({"ok": False, "reason": str(e)}), 400
        names = []
        for p in posts[:200]:
            if not _NAME.fullmatch(str(p)):
                return jsonify({"ok": False, "reason": "publication invalide"}), 400
            names += _files_of(pdir, p)
        for mfile in medias[:200]:
            if not _NAME.fullmatch(str(mfile)):
                return jsonify({"ok": False, "reason": "nom invalide"}), 400
            if not mfile.lower().endswith(_EXT_IMG + _EXT_VID):
                return jsonify({"ok": False, "reason": "type refusé"}), 403
            names.append(mfile)
        moved = []
        try:
            for f in dict.fromkeys(names):
                src = os.path.realpath(os.path.join(pdir, f))
                if not (src.startswith(pdir + os.sep) and os.path.isfile(src)):
                    continue
                if os.path.getsize(src) == 0:
                    continue
                dst = os.path.join(tdir, f)
                if os.path.exists(dst):
                    dst = os.path.join(tdir, f"{int(time.time())}_{f}")
                shutil.move(src, dst)
                if f.lower().endswith(_EXT_IMG + _EXT_VID):
                    open(src, "wb").close()   # marqueur instaloader
                moved.append(f)
        except (RuntimeError, OSError) as e:
            return jsonify({"ok": False, "reason": f"déplacement impossible ({e})"})
        return jsonify({"ok": True, "moved": moved, "count": len(moved)})

    @bp.route("/trash", methods=["GET"])
    def trash_list():
        if not _admin():
            return jsonify(error="admin_required"), 403
        cfg = sdk.config()
        try:
            root = os.path.realpath(_root(cfg))
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        base = os.path.join(root, _TRASH)
        items, total = [], 0
        detail = request.args.get("detail") == "1"
        if os.path.isdir(base):
            for prof in sorted(os.listdir(base)):
                d = os.path.join(base, prof)
                if not os.path.isdir(d):
                    continue
                files = []
                for f in sorted(os.listdir(d)):
                    p = os.path.join(d, f)
                    if not os.path.isfile(p):
                        continue
                    sz = os.path.getsize(p)
                    total += sz
                    files.append({"name": f, "size_mb": round(sz / 1048576, 2),
                                  "video": f.lower().endswith(_EXT_VID)})
                entry = {"profile": prof, "count": len(files),
                         "size_mb": round(sum(x["size_mb"] for x in files), 1)}
                if detail:
                    entry["files"] = files
                items.append(entry)
        return jsonify({"ok": True, "profiles": items, "size_mb": round(total / 1048576, 1)})

    @bp.route("/trash/purge", methods=["POST"])
    def trash_purge():
        if not _admin():
            return jsonify(error="admin_required"), 403
        j = request.get_json(force=True, silent=True) or {}
        cfg = sdk.config()
        try:
            root = os.path.realpath(_root(cfg))
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)}), 400
        base = os.path.realpath(os.path.join(root, _TRASH))
        if not os.path.isdir(base):
            return jsonify({"ok": True, "removed": 0, "freed_mb": 0})
        want_prof = (j.get("profile") or "").strip()
        want_files = j.get("files") or []
        for f in want_files:
            if not re.fullmatch(r"[A-Za-z0-9._-]{1,160}", str(f)):
                return jsonify({"ok": False, "reason": "nom invalide"}), 400
        n, freed = 0, 0
        for prof in os.listdir(base):
            if want_prof and prof != want_prof:
                continue
            d = os.path.realpath(os.path.join(base, prof))
            if not d.startswith(base + os.sep):
                continue
            for f in os.listdir(d):
                if want_files and f not in want_files:
                    continue
                t = os.path.realpath(os.path.join(d, f))
                if not (t.startswith(d + os.sep) and os.path.isfile(t)):
                    continue
                try:
                    freed += os.path.getsize(t)
                    os.remove(t)
                    n += 1
                except OSError:
                    continue
        return jsonify({"ok": True, "removed": n, "freed_mb": round(freed / 1048576, 1)})

    @bp.route("/trash/restore", methods=["POST"])
    def trash_restore():
        if not _admin():
            return jsonify(error="admin_required"), 403
        j = request.get_json(force=True, silent=True) or {}
        cfg = sdk.config()
        profile = (j.get("profile") or "").strip()
        try:
            pdir = _safe_path(cfg, profile)
            tdir = _trash_dir(cfg, profile)
        except (RuntimeError, OSError) as e:
            return jsonify({"ok": False, "reason": str(e)}), 400
        n = 0
        for f in os.listdir(tdir):
            src = os.path.realpath(os.path.join(tdir, f))
            if not (src.startswith(tdir + os.sep) and os.path.isfile(src)):
                continue
            name = re.sub(r"^\d{10}_", "", f)
            dst = os.path.join(pdir, name)
            try:
                if os.path.exists(dst) and os.path.getsize(dst) == 0:
                    os.remove(dst)
                shutil.move(src, dst)
                n += 1
            except OSError:
                continue
        return jsonify({"ok": True, "restored": n})

    @bp.route("/sync", methods=["POST"])
    def sync():
        if not _admin():
            return jsonify(error="admin_required"), 403
        # oneshot : --no-block rend la main tout de suite (le téléchargement
        # continue en fond ; l'addon suit l'état via _sync_status).
        ok, out = _run(["systemctl", "start", "--no-block", "insta-sync.service"])
        if ok:
            return jsonify({"ok": True})
        return jsonify({"ok": False, "reason": (out or "").strip() or "démarrage refusé"}), 500

    return bp


def test(sdk, cfg):
    try:
        r = _scan(sdk, cfg)
        if r.get("ok"):
            return True, f"Instagram \u2713 \u2014 {r['total']} publication(s), profil « {r['profile']} »"
        if r.get("empty"):
            root = os.path.expanduser((cfg.get("path") or "/srv/instagram").rstrip("/"))
            return True, f"Dossier prêt ({root}) \u2014 en attente de la première synchro instaloader"
        return False, f"Instagram \u2717 ({r.get('reason')})"
    except Exception as e:
        return False, f"Instagram \u2717 ({e})"
