"""Addon « forgejo » — tableau de bord des dépôts (conversion déclaratif → code).

Vue cartes/liste avec recherche côté client et panneau « historique » à droite
(derniers commits agrégés sur les dépôts récemment actifs). Le backend
proxifie l'API Forgejo avec le token configuré : le token ne quitte jamais
le serveur.

TLS : même approche que le store Abeille (``_store_verify`` du noyau) —
bundle CA système s'il existe (il inclut la CA maison après
``update-ca-certificates``), sinon défaut certifi.
"""
import os

_CA = "/etc/ssl/certs/ca-certificates.crt"
_HIST_CHOICES = (5, 10, 20)
_HIST_REPOS = 6          # nb de dépôts récents sondés pour l'historique
_CACHE_TTL = 120         # aligné sur le cache_seconds de l'ancien déclaratif


def _verify():
    return _CA if os.path.exists(_CA) else True


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if not url:
        raise RuntimeError("URL Forgejo non configurée — ⚙ de l'addon")
    return url


def _api(sdk, cfg, path, params=None, timeout=8):
    tok = (cfg.get("token") or "").strip()
    headers = {"Authorization": f"token {tok}"} if tok else {}
    base = _base(cfg)          # hors du try : son erreur de config doit remonter telle quelle
    try:
        r = sdk.requests.get(base + "/api/v1" + path, params=params or {},
                             headers=headers, timeout=timeout, verify=_verify())
    except Exception as e:  # requests.RequestException et TLS
        raise RuntimeError(f"Forgejo injoignable ({e.__class__.__name__})")
    if r.status_code == 401:
        raise RuntimeError("token refusé (401) — Forgejo → Paramètres → "
                           "Applications → Générer un token")
    if r.status_code >= 400:
        raise RuntimeError(f"Forgejo a répondu {r.status_code}")
    try:
        return r.json()
    except ValueError:
        raise RuntimeError("réponse Forgejo illisible (JSON attendu)")


def _repo(it):
    """Projection compacte d'un dépôt de /repos/search."""
    return {
        "owner": ((it.get("owner") or {}).get("username")) or "",
        "name": it.get("name") or "",
        "full": it.get("full_name") or "",
        "desc": (it.get("description") or "")[:200],
        "branch": it.get("default_branch") or "",
        "issues": it.get("open_issues_count") or 0,
        "prs": it.get("open_pr_counter") or 0,
        "stars": it.get("stars_count") or 0,
        "private": bool(it.get("private")),
        "updated": it.get("updated_at") or "",
        "url": it.get("html_url") or "",
    }


def _repos(sdk, cfg):
    hit = sdk.cache_get("fj:repos", _CACHE_TTL)
    if hit is not None:
        return hit
    data = _api(sdk, cfg, "/repos/search",
                {"sort": "updated", "order": "desc", "limit": 50})
    repos = [_repo(it) for it in (data.get("data") or [])]
    return sdk.cache_set("fj:repos", repos)


def _hist(sdk, cfg, n):
    key = f"fj:hist:{n}"
    hit = sdk.cache_get(key, _CACHE_TTL)
    if hit is not None:
        return hit
    items = []
    for rp in _repos(sdk, cfg)[:_HIST_REPOS]:
        if not rp["full"]:
            continue
        try:
            commits = _api(sdk, cfg, f"/repos/{rp['full']}/commits",
                           {"limit": n, "stat": "false",
                            "verification": "false", "files": "false"},
                           timeout=6)
        except RuntimeError:
            continue           # un dépôt vide/inaccessible ne bloque pas le panneau
        for c in commits if isinstance(commits, list) else []:
            meta = (c.get("commit") or {})
            author = (meta.get("author") or {})
            items.append({
                "repo": rp["name"],
                "sha": (c.get("sha") or "")[:7],
                "msg": (meta.get("message") or "").split("\n")[0][:120],
                "author": author.get("name") or "",
                "date": author.get("date") or c.get("created") or "",
                "url": c.get("html_url") or "",
            })
    items.sort(key=lambda x: x["date"], reverse=True)
    return sdk.cache_set(key, items[:n])


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("forgejo", __name__)

    @bp.route("/summary")
    def summary():
        cfg = sdk.config()
        try:
            repos = _repos(sdk, cfg)
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        hist = str(cfg.get("hist") or "10")
        return jsonify({"ok": True, "repos": repos,
                        "view": "liste" if cfg.get("view") == "liste" else "cards",
                        "hist": int(hist) if hist.isdigit() else 10})

    @bp.route("/history")
    def history():
        cfg = sdk.config()
        try:
            n = int(request.args.get("n", "10"))
        except ValueError:
            n = 10
        if n not in _HIST_CHOICES:
            n = 10
        try:
            return jsonify({"ok": True, "items": _hist(sdk, cfg, n)})
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » du ⚙ : un appel léger avec les valeurs saisies."""
    try:
        d = _api(sdk, cfg, "/repos/search", {"limit": 1}, timeout=6)
        total = d.get("total_count")
        return True, (f"OK — {total} dépôt(s) visibles" if isinstance(total, int)
                      else "OK — API Forgejo joignable")
    except RuntimeError as e:
        return False, str(e)[:200]
