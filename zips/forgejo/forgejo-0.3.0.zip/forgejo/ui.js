/* Forgejo — interface embarquée (contrat Phase 3).
   Portage de la vue du socle 0.99.47 : cartes/liste, recherche live,
   panneau historique des derniers commits (Off/5/10/20).
   Le style est injecté par le module lui-même (préfixe fj-, une seule fois). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.forgejo = (function () {
  let S = null, root = null;                 // sdk + conteneur courant
  let repos = [], mode = null, histN = null, q = '';

  const CSS = [
    '.fjbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}',
    '.fjwrap{display:flex;gap:14px;align-items:flex-start}',
    '#fjLeft{flex:1;min-width:0}',
    '.fjgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px}',
    '.fjcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px;display:flex;flex-direction:column;gap:6px;cursor:pointer}',
    '.fjcard:active,.fjrow:active,.fjcm:active{border-color:var(--accent)}',
    '.fjtop{display:flex;gap:6px;align-items:center;font-size:11px;color:var(--dim)}',
    '.fjowner{background:var(--accent-tint);color:var(--accent);border-radius:6px;padding:1px 7px;font-size:10.5px}',
    '.fjupd{margin-left:auto;color:var(--faint)}',
    '.fjname{font-weight:700;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.fjdesc{font-size:12px;color:var(--dim);line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '.fjmeta{font-size:11.5px;color:var(--faint);margin-top:auto}',
    '.fjlist{display:flex;flex-direction:column;gap:6px}',
    '.fjrow{display:flex;gap:10px;align-items:center;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:9px 14px;cursor:pointer;min-width:0}',
    '.fjrow .fjname{font-size:13.5px;flex:none;max-width:40%}',
    '.fjrow .fjdesc{-webkit-line-clamp:1;flex:1;min-width:0}',
    '.fjrow .fjmeta{margin:0 0 0 auto;flex:none;white-space:nowrap}',
    '.fjhist{width:290px;flex:none;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px;max-height:72vh;overflow-y:auto}',
    '.fjhtitle{font-weight:700;font-size:13px;margin-bottom:8px}',
    '.fjcm{padding:7px 0;border-bottom:1px solid var(--border-soft);cursor:pointer}',
    '.fjcm:last-child{border-bottom:none}',
    '.fjcmsg{font-size:12.5px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '.fjcmeta{font-size:10.5px;color:var(--faint);margin-top:3px}'
  ].join('\n');

  function ensureCss() {
    if (document.getElementById('fjUiCss')) return;
    const st = document.createElement('style');
    st.id = 'fjUiCss'; st.textContent = CSS;
    document.head.appendChild(st);
  }

  function card(r) {
    return '<div class="fjcard" data-fjurl="' + S.esc(r.url) + '">' +
      '<div class="fjtop"><span class="fjowner">' + S.esc(r.owner) + '</span>' + (r.private ? '<span>🔒</span>' : '') +
      '<span class="fjupd">' + S.rel(r.updated) + '</span></div>' +
      '<div class="fjname">' + S.esc(r.name) + '</div>' +
      (r.desc ? '<div class="fjdesc">' + S.esc(r.desc) + '</div>' : '') +
      '<div class="fjmeta">🌿 ' + S.esc(r.branch || '—') + ' · 🐛 ' + r.issues + ' · 🔀 ' + r.prs + (r.stars ? ' · ⭐ ' + r.stars : '') + '</div></div>';
  }
  function row(r) {
    return '<div class="fjrow" data-fjurl="' + S.esc(r.url) + '">' +
      '<span class="fjowner">' + S.esc(r.owner) + '</span>' +
      '<div class="fjname">' + S.esc(r.name) + (r.private ? ' 🔒' : '') + '</div>' +
      (r.desc ? '<div class="fjdesc">' + S.esc(r.desc) + '</div>' : '<div class="fjdesc"></div>') +
      '<div class="fjmeta">🐛 ' + r.issues + ' · 🔀 ' + r.prs + ' · ' + S.rel(r.updated) + '</div></div>';
  }
  function filtered() {
    const t = q.trim().toLowerCase();
    return repos.filter(r => !t || ((r.full + ' ' + (r.desc || '')).toLowerCase().includes(t)));
  }
  function leftHtml(list) {
    if (!list.length) return '<div class="stub"><div class="big">🗂️</div><div class="t2">' +
      (q.trim() ? 'Aucun dépôt ne correspond à « ' + S.esc(q) + ' »' : 'Aucun dépôt visible avec ce token') + '</div></div>';
    return mode === 'liste' ? ('<div class="fjlist">' + list.map(row).join('') + '</div>')
                            : ('<div class="fjgrid">' + list.map(card).join('') + '</div>');
  }

  async function loadHist() {
    const box = document.getElementById('fjHist'); if (!box) return;
    let j = null;
    try { const r = await S.api('/history?n=' + histN); j = await r.json(); }
    catch (e) { j = { ok: false, reason: 'serveur injoignable' }; }
    const cur = document.getElementById('fjHist'); if (!cur) return;
    if (!j.ok) { cur.innerHTML = '<div class="fjhtitle">🕘 Derniers commits</div><div class="cmeta">' + S.esc(j.reason || 'indisponible') + '</div>'; return; }
    cur.innerHTML = '<div class="fjhtitle">🕘 ' + j.items.length + ' derniers commits</div>' +
      (j.items.length ? j.items.map(c => '<div class="fjcm" data-fjurl="' + S.esc(c.url) + '">' +
        '<div class="fjcmsg">' + S.esc(c.msg || '(sans message)') + '</div>' +
        '<div class="fjcmeta"><b>' + S.esc(c.repo) + '</b> · ' + S.esc(c.author || '?') + ' · ' + S.rel(c.date) + ' · <code>' + S.esc(c.sha) + '</code></div></div>').join('')
        : '<div class="cmeta">Aucun commit récent</div>');
  }

  function paint() {
    if (!root) return;
    const list = filtered();
    let h = '<div class="fjbar">' +
      '<input class="inp" id="fjQ" type="text" placeholder="🔍 Rechercher un dépôt…" value="' + S.esc(q) + '" style="flex:1;max-width:320px">' +
      '<span class="wch' + (mode === 'cards' ? ' on' : '') + '" data-fjm="cards">🖼️ Cartes</span>' +
      '<span class="wch' + (mode === 'liste' ? ' on' : '') + '" data-fjm="liste">📄 Liste</span>' +
      '<span style="font-size:12px;color:var(--dim);margin-left:8px">Historique :</span>' +
      [0, 5, 10, 20].map(n => '<span class="wch' + (histN === n ? ' on' : '') + '" data-fjh="' + n + '">' + (n === 0 ? 'Off' : n) + '</span>').join('') +
      '<span style="margin-left:auto;font-size:12px;color:var(--dim)"><b id="fjCount">' + list.length + '</b> / ' + repos.length + ' dépôts</span></div>';
    h += '<div class="fjwrap"><div id="fjLeft">' + leftHtml(list) + '</div>' +
      (histN > 0 ? '<div class="fjhist" id="fjHist"><div class="fjhtitle">🕘 Derniers commits</div><div class="cmeta">Chargement…</div></div>' : '') +
      '</div><div class="wsrc">API Forgejo · le token reste côté serveur · vue embarquée v0.3.0</div>';
    root.innerHTML = h;
    const qi = document.getElementById('fjQ');
    qi.addEventListener('input', () => {          // filtre live : seule la colonne
      q = qi.value;                                // gauche se re-rend, le focus et
      const l = filtered();                        // le clavier restent sur l'input
      document.getElementById('fjLeft').innerHTML = leftHtml(l);
      document.getElementById('fjCount').textContent = l.length;
    });
    root.querySelectorAll('[data-fjm]').forEach(c => c.addEventListener('click', () => { mode = c.dataset.fjm; paint(); }));
    root.querySelectorAll('[data-fjh]').forEach(c => c.addEventListener('click', () => { histN = parseInt(c.dataset.fjh); paint(); if (histN > 0) loadHist(); }));
    if (histN > 0) loadHist();
  }

  async function render(el, sdk) {
    S = sdk; root = el;
    ensureCss();
    if (!el.dataset.fjUi) {                        // délégation : un seul listener,
      el.dataset.fjUi = '1';                       // il survit aux re-rendus internes
      el.addEventListener('click', ev => {
        const t = ev.target.closest('[data-fjurl]');
        if (t && t.dataset.fjurl) S.openService(t.dataset.fjurl, 'Forgejo');
      });
    }
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des dépôts…</div></div>';
    let d = null;
    try { const r = await S.api('/summary'); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🗂️</div><div class="t1">Forgejo</div>' +
        '<div class="t2">' + S.esc(d.reason || '') + '<br>Configure l\'URL et le token dans le ⚙ de l\'addon.</div></div>';
      return;
    }
    repos = d.repos || [];
    if (mode == null) mode = (d.view === 'liste') ? 'liste' : 'cards';
    if (histN == null) histN = [0, 5, 10, 20].includes(d.hist) ? d.hist : 10;
    paint();
  }

  return { render };
})();
