/* Jardin — calendrier lunaire du potager (Phase 3, lot D). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.jardin = (function () {
  const CSS = "  .gdwrap{flex:1;display:flex;flex-direction:column;min-height:0}\n  .gdwrap .wsrc{margin-top:auto}\n  .gdhero{display:flex;gap:20px;align-items:center;background:var(--tile);border:1px solid var(--border-soft);\n          border-radius:14px;padding:18px 22px;margin:14px 22px 12px;flex:none}\n  .gdicon{font-size:56px;flex:none}\n  .gdlab{font-size:22px;font-weight:700}\n  .gdsub{font-size:13.5px;color:var(--dim);margin-top:4px}\n  .gdconseil{font-size:14px;margin-top:9px;color:var(--text)}\n  .gdmoon{margin-left:auto;text-align:right;flex:none}\n  .gdmoon .m1{font-size:38px}\n  .gdmoon .m2{font-size:12.5px;color:var(--dim)}\n  .gdrise{display:inline-block;font-size:12px;font-weight:600;padding:4px 11px;border-radius:7px;margin-top:8px}\n  .gdrise.up{background:var(--accent-tint);color:var(--accent)}\n  .gdrise.down{background:rgba(240,180,41,.15);color:var(--warn)}\n  .gdweek{display:grid;grid-template-columns:repeat(7,1fr);gap:8px;margin:0 22px 14px;flex:0 0 auto}\n  .gdcell{background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:12px 4px;text-align:center;\n          display:flex;flex-direction:column;justify-content:center}\n  .gdcell.today{border-color:var(--accent);background:var(--accent-tint)}\n  .gdd{font-size:11.5px;color:var(--dim);text-transform:capitalize}\n  .gdi{font-size:30px;margin:5px 0}\n  .gdk{font-size:10.5px;color:var(--faint)}\n  .gdcols{display:grid;grid-template-columns:repeat(2,1fr);grid-template-rows:repeat(2,1fr);gap:10px;margin:0 22px;flex:1;min-height:0}\n  .gdcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:11px;padding:13px 15px;\n          display:flex;flex-direction:column;min-height:0;overflow:auto}\n  .gdch{font-size:13px;font-weight:700;margin-bottom:9px;flex:none}\n  .gdchip{display:inline-block;font-size:12.5px;background:var(--bg);border:1px solid var(--border-soft);\n          border-radius:7px;padding:4px 10px;margin:0 6px 6px 0}";
  function ensureCss(){if(document.getElementById('gdUiCss'))return;const s=document.createElement('style');s.id='gdUiCss';s.textContent=CSS;document.head.appendChild(s);}
  async function render(el, sdk, a) {
    ensureCss();
    let lun=null,cal=null;
    try{const r=await sdk.api('/lunar?days=7');lun=await r.json();}catch(e){}
    try{const r=await sdk.api('/calendar');cal=await r.json();}catch(e){}
    if(!lun||!lun.ok){el.innerHTML='<div class="stub"><div class="big">🌱</div><div class="t1">Jardin</div><div class="t2">Calcul indisponible</div></div>';return;}
    const t=lun.days[0];
    let h='<div class="gdwrap"><div class="gdhero"><div class="gdicon">'+t.icon+'</div>'+
      '<div><div class="gdlab">'+t.label+'</div>'+
      '<div class="gdsub">Lune en '+t.sign+' · élément '+t.element+'</div>'+
      '<div class="gdconseil">'+t.conseil+'</div>'+
      '<span class="gdrise '+(t.rising?'up':'down')+'">'+(t.rising?'↑ Lune montante — semer, greffer':'↓ Lune descendante — planter, tailler, récolter')+'</span></div>'+
      '<div class="gdmoon"><div class="m1">'+t.moon_icon+'</div><div class="m2">'+t.illumination+' %<br>'+(t.waxing?'croissante':'décroissante')+'</div></div></div>';
    h+='<div class="wsec">Les 7 prochains jours</div><div class="gdweek">'+
      lun.days.map((x,i)=>{const dd=new Date(x.date+'T12:00:00');
        return '<div class="gdcell'+(i===0?' today':'')+'"><div class="gdd">'+dd.toLocaleDateString('fr-FR',{weekday:'short'})+' '+dd.getDate()+'</div>'+
          '<div class="gdi">'+x.icon+'</div><div class="gdk">'+x.kind+'</div>'+
          '<div class="gdk">'+(x.rising?'↑':'↓')+' '+x.moon_icon+'</div></div>';}).join('')+'</div>';
    if(cal&&cal.ok){
      const card=(t2,arr,ic)=>'<div class="gdcard"><div class="gdch">'+ic+' '+t2+'</div>'+
        (arr.length?arr.map(x=>'<span class="gdchip">'+x+'</span>').join(''):'<span class="gdk">rien ce mois-ci</span>')+'</div>';
      h+='<div class="wsec">Au potager en '+cal.month_name+'</div><div class="gdcols">'+
        card('Semis sous abri',cal.semis_abri,'🏠')+card('Semis en pleine terre',cal.semis_terre,'🌾')+
        card('Plantations',cal.plantation,'🪴')+card('Récoltes',cal.recolte,'🧺')+'</div>';
    }
    h+='<div class="wsrc">Éphémérides calculées localement · le calendrier lunaire relève de la tradition biodynamique, pas d\'un consensus scientifique · vue embarquée v0.3.0</div></div>';
    el.innerHTML=h;
  }
  return { render };
})();
