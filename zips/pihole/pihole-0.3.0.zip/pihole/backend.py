"""Addon « pihole » — supervision multi-instances Pi-hole v6.

    register(sdk) -> flask.Blueprint   (routes sous /addons/pihole/api)
    test(sdk, cfg) -> (bool, str)

Les instances sont gérées dynamiquement (ajout/suppression depuis la vue) et
stockées dans data_dir/instances.json — persistant, isolé, en 0700. Au premier
lancement, si ce fichier n'existe pas mais que l'ancienne config url1/url2 est
présente, on l'importe (migration douce depuis la v0.2.x).

API v6 : POST /api/auth (SID) -> appels avec en-tête X-FTL-SID -> DELETE /api/auth.
Chaque instance est interrogée indépendamment (Pi-hole non synchronisés).
"""
import json
import os
import threading

_LOCK = threading.Lock()


# ------------------------------------------------------------------ stockage
def _store_path(sdk):
    return os.path.join(sdk.data_dir, "instances.json")


def _load_instances(sdk):
    """Liste [{name,url,pass}]. Migre depuis url1/url2 au premier accès."""
    p = _store_path(sdk)
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, list):
                return data
        except (OSError, ValueError):
            pass
    cfg = sdk.config()
    migrated = []
    for i, defname in ((1, "Suricate"), (2, "Termite")):
        u = (cfg.get(f"url{i}") or "").strip()
        if u:
            migrated.append({"name": defname, "url": u,
                             "pass": (cfg.get(f"pass{i}") or "").strip()})
    if migrated:
        _save_instances(sdk, migrated)
    return migrated


def _save_instances(sdk, insts):
    p = _store_path(sdk)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(insts, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return insts


def _public(insts):
    """Vue sans les mots de passe (pour l'UI)."""
    return [{"name": x.get("name", "Pi-hole"), "url": x.get("url", ""),
             "has_pass": bool(x.get("pass"))} for x in insts]


# ------------------------------------------------------------------ API v6
def _auth(sdk, url, pw):
    ra = sdk.requests.post(f"{url}/api/auth", json={"password": pw}, timeout=6)
    if ra.status_code != 200:
        return None, f"auth HTTP {ra.status_code}"
    sid = (ra.json().get("session") or {}).get("sid")
    if not sid:
        return None, "mot de passe refusé"
    return sid, None


def _get(sdk, url, path, hdr, params=None, timeout=6):
    try:
        r = sdk.requests.get(f"{url}{path}", headers=hdr, params=params,
                             timeout=timeout)
        return r.json() if r.ok else None
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None


def _pihole_one(sdk, url, pw):
    """Toutes les stats d'une instance : auth -> N endpoints -> logout."""
    url = url.rstrip("/")
    sid = None
    try:
        sid, err = _auth(sdk, url, pw)
        if not sid:
            return {"ok": False, "reason": err}
        hdr = {"X-FTL-SID": sid}

        summary = _get(sdk, url, "/api/stats/summary", hdr)
        if not summary:
            return {"ok": False, "reason": "summary indisponible"}
        q = summary.get("queries") or {}
        g = summary.get("gravity") or {}
        clients = summary.get("clients") or {}
        out = {
            "ok": True,
            "queries": q.get("total"),
            "blocked": q.get("blocked"),
            "percent": round(q.get("percent_blocked") or 0, 1),
            "unique_domains": q.get("unique_domains"),
            "forwarded": q.get("forwarded"),
            "cached": q.get("cached"),
            "clients_active": clients.get("active"),
            "clients_total": clients.get("total"),
            "gravity": g.get("domains_being_blocked"),
            "gravity_updated": g.get("last_update"),
        }

        blk = _get(sdk, url, "/api/dns/blocking", hdr, timeout=5)
        out["blocking"] = (blk.get("blocking") == "enabled") if blk else None
        out["blocking_timer"] = (blk or {}).get("timer")

        qt = _get(sdk, url, "/api/stats/query_types", hdr)
        if qt and isinstance(qt.get("types"), dict):
            items = sorted(qt["types"].items(), key=lambda kv: -kv[1])
            out["query_types"] = [{"type": k, "count": v} for k, v in items if v]

        tb = _get(sdk, url, "/api/stats/top_domains", hdr,
                  params={"blocked": "true", "count": 6})
        if tb:
            out["top_blocked"] = [{"domain": x.get("domain"), "count": x.get("count")}
                                  for x in (tb.get("domains") or [])[:6]]
        ta = _get(sdk, url, "/api/stats/top_domains", hdr,
                  params={"blocked": "false", "count": 6})
        if ta:
            out["top_allowed"] = [{"domain": x.get("domain"), "count": x.get("count")}
                                  for x in (ta.get("domains") or [])[:6]]

        tc = _get(sdk, url, "/api/stats/top_clients", hdr, params={"count": 6})
        if tc:
            out["top_clients"] = [{"name": x.get("name") or x.get("ip"),
                                   "count": x.get("count")}
                                  for x in (tc.get("clients") or [])[:6]]

        up = _get(sdk, url, "/api/stats/upstreams", hdr)
        if up and isinstance(up.get("upstreams"), list):
            out["upstreams"] = [{"name": x.get("name") or x.get("ip"),
                                 "count": x.get("count"),
                                 "percent": round(x.get("percent") or 0, 1)}
                                for x in up["upstreams"][:6]]

        hist = _get(sdk, url, "/api/history", hdr, timeout=8)
        if hist and isinstance(hist.get("history"), list):
            pts = hist["history"]
            step = max(1, len(pts) // 60)
            series = [{"t": p.get("timestamp"),
                       "total": p.get("total"),
                       "blocked": p.get("blocked")}
                      for p in pts[::step]]
            out["history"] = series[-60:]

        ver = _get(sdk, url, "/api/info/version", hdr, timeout=5)
        if ver:
            v = (((ver.get("version") or {}).get("core") or {}).get("local") or {})
            out["version"] = v.get("version")

        return out
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}
    finally:
        if sid:
            try:
                sdk.requests.delete(f"{url}/api/auth",
                                    headers={"X-FTL-SID": sid}, timeout=4)
            except Exception:
                pass


def _stats(sdk):
    insts = _load_instances(sdk)
    if not insts:
        return {"ok": False, "reason": "aucune instance configurée",
                "instances": []}
    ck = "ph:" + "|".join(x.get("url", "") for x in insts)
    c = sdk.cache_get(ck, 30)
    if c is not None:
        return c
    out = {"ok": True, "instances": []}
    for x in insts:
        r = _pihole_one(sdk, x.get("url", ""), x.get("pass", ""))
        r["name"] = x.get("name", "Pi-hole")
        r["url"] = x.get("url", "")
        out["instances"].append(r)
    if not any(z.get("ok") for z in out["instances"]):
        out["ok"] = False
        out["reason"] = out["instances"][0].get("reason", "") if out["instances"] else ""
    return sdk.cache_set(ck, out)


# ------------------------------------------------------------------ routes
def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("pihole", __name__)

    @bp.route("/stats")
    def stats():
        try:
            return jsonify(_stats(sdk))
        except Exception as e:
            sdk.log.exception("pihole")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/instances")
    def instances():
        return jsonify({"ok": True, "instances": _public(_load_instances(sdk))})

    @bp.route("/instances", methods=["POST"])
    def add_instance():
        j = request.get_json(silent=True) or {}
        name = (j.get("name") or "Pi-hole").strip()[:40]
        url = (j.get("url") or "").strip().rstrip("/")
        pw = (j.get("pass") or "").strip()
        if not url:
            return jsonify({"ok": False, "reason": "URL requise"}), 400
        if not (url.startswith("http://") or url.startswith("https://")):
            url = "http://" + url
        with _LOCK:
            insts = _load_instances(sdk)
            insts.append({"name": name, "url": url, "pass": pw})
            _save_instances(sdk, insts)
        return jsonify({"ok": True, "instances": _public(insts)})

    @bp.route("/instances/<int:idx>", methods=["DELETE"])
    def del_instance(idx):
        with _LOCK:
            insts = _load_instances(sdk)
            if idx < 0 or idx >= len(insts):
                return jsonify({"ok": False, "reason": "index invalide"}), 404
            insts.pop(idx)
            _save_instances(sdk, insts)
        return jsonify({"ok": True, "instances": _public(insts)})

    @bp.route("/instances/<int:idx>", methods=["PATCH"])
    def edit_instance(idx):
        j = request.get_json(silent=True) or {}
        with _LOCK:
            insts = _load_instances(sdk)
            if idx < 0 or idx >= len(insts):
                return jsonify({"ok": False, "reason": "index invalide"}), 404
            if "name" in j:
                insts[idx]["name"] = (j.get("name") or "Pi-hole").strip()[:40]
            if "url" in j:
                u = (j.get("url") or "").strip().rstrip("/")
                if u and not (u.startswith("http://") or u.startswith("https://")):
                    u = "http://" + u
                insts[idx]["url"] = u
            if j.get("pass"):
                insts[idx]["pass"] = j["pass"].strip()
            _save_instances(sdk, insts)
        return jsonify({"ok": True, "instances": _public(insts)})

    return bp


def test(sdk, cfg):
    p = _stats(sdk)
    if p.get("ok"):
        bits = []
        for x in p["instances"]:
            bits.append(f"{x['name']} ✓ ({x['percent']}%)" if x.get("ok")
                        else f"{x['name']} ✗ ({x.get('reason')})")
        return True, " · ".join(bits)
    return False, f"Pi-hole ✗ ({p.get('reason')})"
