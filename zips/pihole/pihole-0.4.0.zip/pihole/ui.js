/* Pi-hole — supervision multi-instances, pleine page, couleurs Pi-hole. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.pihole = (function () {
  let S = null, root = null, tile = null, data = null, showManage = false;
  // Palette Pi-hole : rouge blocage, vert requêtes permises, bleu cache, ambre
  const CSS =
    "  .phwrap{flex:1;display:flex;flex-direction:column;min-height:0;--ph-red:#f56565;--ph-green:#5cb85c;--ph-blue:#4a90d9;--ph-amber:#f0ad4e}\n" +
    "  .phbar{display:flex;align-items:center;gap:10px;padding:10px 22px 6px;flex:none}\n" +
    "  .phbar .wch{margin:0}\n" +
    "  .phscroll{flex:1;min-height:0;overflow:auto;padding:6px 22px 14px}\n" +
    "  .phgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}\n" +
    "  .phgrid.solo{grid-template-columns:1fr;max-width:860px;margin:0 auto}\n" +
    "  .phnode{background:var(--tile);border:1px solid var(--border-soft);border-radius:14px;overflow:hidden;display:flex;flex-direction:column}\n" +
    "  .phnhead{display:flex;align-items:center;gap:10px;padding:13px 16px;background:linear-gradient(135deg,rgba(74,144,217,.14),transparent)}\n" +
    "  .phnhead .ic{font-size:22px}\n" +
    "  .phnname{font-weight:700;font-size:15.5px}\n" +
    "  .phnver{font-size:11px;color:var(--dim)}\n" +
    "  .phstate{margin-left:auto;font-size:11px;font-weight:700;padding:4px 11px;border-radius:20px}\n" +
    "  .phstate.on{background:rgba(92,184,92,.16);color:var(--ph-green)}\n" +
    "  .phstate.off{background:rgba(245,101,101,.16);color:var(--ph-red)}\n" +
    "  .phkpis{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--border-soft)}\n" +
    "  .phkpi{background:var(--tile);padding:12px 8px;text-align:center}\n" +
    "  .phkpi b{display:block;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.1}\n" +
    "  .phkpi span{font-size:10.5px;color:var(--dim);display:block;margin-top:3px}\n" +
    "  .phkpi.q b{color:var(--ph-blue)} .phkpi.b b{color:var(--ph-red)} .phkpi.p b{color:var(--ph-amber)} .phkpi.c b{color:var(--ph-green)}\n" +
    "  .phspark{height:44px;padding:6px 12px 0;display:flex;align-items:flex-end;gap:1px}\n" +
    "  .phspark i{flex:1;background:var(--ph-blue);border-radius:1px 1px 0 0;position:relative;min-height:1px;opacity:.5}\n" +
    "  .phspark i em{position:absolute;left:0;right:0;bottom:0;background:var(--ph-red);border-radius:1px 1px 0 0;display:block}\n" +
    "  .phsub{padding:10px 14px 14px}\n" +
    "  .phsecs{display:grid;grid-template-columns:1fr 1fr;gap:12px}\n" +
    "  .phblock{min-width:0}\n" +
    "  .phbh{font-size:10.5px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin:6px 0 5px;display:flex;align-items:center;gap:5px}\n" +
    "  .phbh .dot{width:7px;height:7px;border-radius:50%}\n" +
    "  .phrow{display:flex;align-items:center;font-size:12px;padding:3px 0;gap:8px;min-width:0}\n" +
    "  .phrow .nm{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--mono);font-size:11.5px}\n" +
    "  .phrow .ct{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .phrow .barbg{flex:none;width:52px;height:5px;border-radius:3px;background:var(--bg);overflow:hidden}\n" +
    "  .phrow .barbg>i{display:block;height:100%}\n" +
    "  .phtail{display:flex;gap:14px;flex-wrap:wrap;padding:9px 16px;border-top:1px solid var(--border-soft);font-size:11px;color:var(--dim)}\n" +
    "  .phtail b{color:var(--text);font-variant-numeric:tabular-nums}\n" +
    "  .pherr{padding:16px;color:var(--ph-red);font-size:13px}\n" +
    "  .phtotal{display:flex;gap:16px;flex-wrap:wrap;align-items:center;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 18px;margin-bottom:14px}\n" +
    "  .phtotal .tk{text-align:center}\n" +
    "  .phtotal .tk b{display:block;font-size:22px;font-weight:700;font-variant-numeric:tabular-nums}\n" +
    "  .phtotal .tk span{font-size:11px;color:var(--dim)}\n" +
    "  .phtotal .tk.q b{color:var(--ph-blue)} .phtotal .tk.b b{color:var(--ph-red)} .phtotal .tk.p b{color:var(--ph-amber)}\n" +
    "  .phmanage{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:14px 16px;margin-bottom:14px}\n" +
    "  .phmrow{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-soft)}\n" +
    "  .phmrow:last-child{border-bottom:0}\n" +
    "  .phmrow .mn{font-weight:600;font-size:13px}\n" +
    "  .phmrow .mu{font-size:11px;color:var(--dim);font-family:var(--mono)}\n" +
    "  .phmdel{margin-left:auto;background:rgba(245,101,101,.14);color:var(--ph-red);border:0;border-radius:8px;padding:7px 12px;font-size:12px;cursor:pointer}\n" +
    "  .phadd{display:grid;grid-template-columns:1fr 1.5fr 1fr auto;gap:8px;margin-top:12px}\n" +
    "  .phadd input{background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:9px 11px;font-size:13px;color:var(--text)}\n" +
    "  .phaddbtn{background:var(--accent);color:#04201c;border:0;border-radius:8px;padding:0 16px;font-weight:700;font-size:13px;cursor:pointer}\n" +
    "  .phmanage-toggle{margin-left:auto}";
  function ensureCss() { if (document.getElementById('phUiCss2')) return; const s = document.createElement('style'); s.id = 'phUiCss2'; s.textContent = CSS; document.head.appendChild(s); }
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Interrogation des Pi-hole…</div></div>';
    try { const r = await sdk.api('/stats'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function sparkline(hist) {
    if (!hist || !hist.length) return '';
    const max = Math.max(1, ...hist.map(p => p.total || 0));
    return '<div class="phspark">' + hist.map(p => {
      const h = Math.round((p.total || 0) / max * 100);
      const b = p.total ? Math.round((p.blocked || 0) / (p.total || 1) * 100) : 0;
      return '<i style="height:' + Math.max(2, h) + '%"><em style="height:' + b + '%"></em></i>';
    }).join('') + '</div>';
  }

  function miniList(title, dotColor, rows, keyName) {
    if (!rows || !rows.length) return '';
    const max = Math.max(1, ...rows.map(r => r.count || 0));
    return '<div class="phblock"><div class="phbh"><span class="dot" style="background:' + dotColor + '"></span>' + title + '</div>' +
      rows.map(r => '<div class="phrow"><span class="nm">' + esc(r[keyName] || r.domain || r.name || '—') + '</span>' +
        '<span class="barbg"><i style="width:' + Math.round((r.count || 0) / max * 100) + '%;background:' + dotColor + '"></i></span>' +
        '<span class="ct">' + nf(r.count) + '</span></div>').join('') + '</div>';
  }

  function nodeCard(x) {
    if (!x.ok) return '<div class="phnode"><div class="phnhead"><span class="ic">🛡️</span><span class="phnname">' + esc(x.name) + '</span>' +
      '<span class="phstate off">hors ligne</span></div><div class="pherr">' + esc(x.reason || 'injoignable') + '</div></div>';
    const on = x.blocking !== false;
    let h = '<div class="phnode"><div class="phnhead"><span class="ic">🛡️</span>' +
      '<span><div class="phnname">' + esc(x.name) + '</div>' + (x.version ? '<div class="phnver">Pi-hole ' + esc(x.version) + '</div>' : '') + '</span>' +
      '<span class="phstate ' + (on ? 'on' : 'off') + '">' + (on ? '● actif' : '○ désactivé' + (x.blocking_timer ? ' (' + Math.round(x.blocking_timer) + 's)' : '')) + '</span></div>';
    // KPI principaux
    h += '<div class="phkpis">' +
      '<div class="phkpi q"><b>' + nf(x.queries) + '</b><span>requêtes 24 h</span></div>' +
      '<div class="phkpi b"><b>' + nf(x.blocked) + '</b><span>bloquées</span></div>' +
      '<div class="phkpi p"><b>' + (x.percent != null ? x.percent + ' %' : '—') + '</b><span>taux blocage</span></div>' +
      '<div class="phkpi c"><b>' + nf(x.clients_active) + '</b><span>clients actifs</span></div>' +
      '</div>';
    h += sparkline(x.history);
    // Sections détaillées
    h += '<div class="phsub"><div class="phsecs">' +
      miniList('Top bloqués', 'var(--ph-red)', x.top_blocked, 'domain') +
      miniList('Top autorisés', 'var(--ph-green)', x.top_allowed, 'domain') +
      miniList('Top clients', 'var(--ph-blue)', x.top_clients, 'name') +
      miniList('Amont DNS', 'var(--ph-amber)', x.upstreams, 'name') +
      '</div>';
    // types de requêtes
    if (x.query_types && x.query_types.length) {
      const tot = x.query_types.reduce((a, t) => a + (t.count || 0), 0) || 1;
      h += '<div class="phbh" style="margin-top:12px">Types de requêtes</div><div class="phrow" style="flex-wrap:wrap;gap:6px">' +
        x.query_types.slice(0, 8).map(t => '<span style="font-size:11px;background:var(--bg);border-radius:6px;padding:3px 8px">' +
          esc(t.type) + ' <b style="color:var(--ph-blue)">' + Math.round((t.count || 0) / tot * 100) + '%</b></span>').join('') + '</div>';
    }
    h += '</div>';
    // pied : forwarded / cached / gravity / uniques
    h += '<div class="phtail">' +
      '<span>Transmises <b>' + nf(x.forwarded) + '</b></span>' +
      '<span>Cache <b>' + nf(x.cached) + '</b></span>' +
      '<span>Domaines uniques <b>' + nf(x.unique_domains) + '</b></span>' +
      '<span>Gravity <b>' + nf(x.gravity) + '</b></span>' +
      '</div></div>';
    return h;
  }

  function totalsBar(oks) {
    if (oks.length < 2) return '';
    const tq = oks.reduce((a, x) => a + (x.queries || 0), 0);
    const tb = oks.reduce((a, x) => a + (x.blocked || 0), 0);
    const tc = oks.reduce((a, x) => a + (x.clients_active || 0), 0);
    const pct = tq ? Math.round(tb / tq * 1000) / 10 : 0;
    return '<div class="phtotal"><div class="tk q"><b>' + nf(tq) + '</b><span>requêtes cumulées</span></div>' +
      '<div class="tk b"><b>' + nf(tb) + '</b><span>bloquées</span></div>' +
      '<div class="tk p"><b>' + pct + ' %</b><span>taux global</span></div>' +
      '<div class="tk"><b>' + nf(tc) + '</b><span>clients</span></div>' +
      '<div class="tk"><b>' + oks.length + '</b><span>nœuds en ligne</span></div></div>';
  }

  function managePanel() {
    const insts = (data && data.instances) || [];
    let h = '<div class="phmanage"><div class="phbh">Instances Pi-hole</div>' +
      '<div style="font-size:11.5px;color:var(--dim);margin-bottom:8px">Les instances marquées <b>⚙</b> viennent des Réglages de l\'addon (modifie-les ou vide leur bloc là-bas). Celles ajoutées ici sont propres à cette vue.</div>';
    if (!insts.length) h += '<div style="color:var(--dim);font-size:12px;padding:6px 0">Aucune instance. Ajoute ton premier Pi-hole ci-dessous, ou renseigne-les dans ⚙ Réglages.</div>';
    else h += insts.map((x, i) => {
      const fromCfg = x.source === 'config';
      return '<div class="phmrow"><div><div class="mn">' + (fromCfg ? '⚙ ' : '') + esc(x.name) + '</div><div class="mu">' + esc(x.url) + '</div></div>' +
        (fromCfg
          ? '<span style="margin-left:auto;font-size:11px;color:var(--dim)">via Réglages</span>'
          : '<button class="phmdel" data-del="' + i + '">🗑 Retirer</button>') + '</div>';
    }).join('');
    h += '<div class="phadd">' +
      '<input id="phAName" placeholder="Nom (ex. Suricate)">' +
      '<input id="phAUrl" placeholder="http://192.168.0.2:8080">' +
      '<input id="phAPass" type="password" placeholder="Mot de passe app">' +
      '<button class="phaddbtn" id="phAddBtn">+ Ajouter</button></div></div>';
    return h;
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    let h = '<div class="phwrap"><div class="phbar">' +
      '<div class="wsec" style="padding:0">🛡️ Pi-hole</div>' +
      '<button class="wch phmanage-toggle" id="phManage">' + (showManage ? '✓ Terminer' : '⚙ Gérer les instances') + '</button>' +
      '<button class="wch" id="phRefresh">↻</button></div>';
    h += '<div class="phscroll">';
    if (showManage) h += managePanel();
    if (!d || (!d.ok && (!d.instances || !d.instances.length))) {
      if (!showManage)
        h += '<div class="stub"><div class="big">🛡️</div><div class="t1">Aucun Pi-hole configuré</div>' +
          '<div class="t2">' + esc((d && d.reason) || '') + '<br>Appuie sur « Gérer les instances » pour ajouter ton premier Pi-hole.</div>' +
          '<button class="btnpill install" id="phFirst" style="margin-top:14px">⚙ Gérer les instances</button></div>';
    } else {
      const oks = d.instances.filter(x => x.ok);
      h += totalsBar(oks);
      h += '<div class="phgrid' + (d.instances.length === 1 ? ' solo' : '') + '">' +
        d.instances.map(nodeCard).join('') + '</div>';
    }
    h += '</div></div>';
    el.innerHTML = h;

    const mg = document.getElementById('phManage'); if (mg) mg.addEventListener('click', () => { showManage = !showManage; paint(); });
    const f1 = document.getElementById('phFirst'); if (f1) f1.addEventListener('click', () => { showManage = true; paint(); });
    const rf = document.getElementById('phRefresh'); if (rf) rf.addEventListener('click', () => render(el, S, tile));
    el.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => delInstance(parseInt(b.dataset.del))));
    const ab = document.getElementById('phAddBtn'); if (ab) ab.addEventListener('click', addInstance);
  }

  async function addInstance() {
    const name = (document.getElementById('phAName') || {}).value || '';
    const url = (document.getElementById('phAUrl') || {}).value || '';
    const pass = (document.getElementById('phAPass') || {}).value || '';
    if (!url.trim()) { S.toast('URL requise'); return; }
    try {
      const r = await S.api('/instances', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, url, pass }) });
      const j = await r.json();
      if (j.ok) { S.toast('Instance ajoutée'); await render(root, S, tile); showManage = true; paint(); }
      else S.toast(j.reason || 'échec');
    } catch (e) { S.toast('échec'); }
  }

  async function delInstance(i) {
    if (!confirm('Retirer cette instance Pi-hole ?')) return;
    try {
      const r = await S.api('/instances/' + i, { method: 'DELETE' });
      const j = await r.json();
      if (j.ok) { S.toast('Instance retirée'); await render(root, S, tile); showManage = true; paint(); }
      else S.toast(j.reason || 'échec');
    } catch (e) { S.toast('échec'); }
  }

  return { render };
})();
