/* Pi-hole — état natif multi-nœuds (Phase 3, lot B). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.pihole = (function () {
  let S = null, root = null, tile = null;
  const CSS = ".phwrap{display:grid;grid-template-columns:1fr 1fr;gap:12px}\n.phcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:12px 14px}\n.phhead{display:flex;align-items:center;gap:8px;font-weight:700;font-size:14px;margin-bottom:8px}\n.phstate{margin-left:auto;font-size:10.5px;font-weight:600;padding:2px 8px;border-radius:6px}\n.phstats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}\n.phst{background:var(--bg);border-radius:8px;padding:7px 6px;text-align:center}\n.phst b{display:block;font-size:15px;font-variant-numeric:tabular-nums}\n.phst span{font-size:10px;color:var(--dim)}\n.phtop{margin-top:10px}\n.phtoph{font-size:10.5px;color:var(--dim);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px}\n.phdom{display:flex;font-size:11.5px;font-family:var(--mono);padding:2px 0;color:var(--text)}\n.phdom span{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums}";
  function ensureCss() { if (document.getElementById('phUiCss')) return; const s = document.createElement('style'); s.id = 'phUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    const cfg = await sdk.config();
    const url = ((cfg.url1 || '').trim()) || 'http://192.168.1.10:8080';
    let d = null; try { const r = await sdk.api('/pihole'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    let h = '<div class="grafhead"><button class="lgbtn" id="phOpen" style="margin:0;padding:9px 18px;font-size:14px">Ouvrir Pi-hole \u2197</button><button class="wch" id="phRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">🛡️</div><div class="t1">Pi-hole — état natif</div><div class="t2">' + ((d && d.reason) || '') + '<br>Configure dans \u2699 : URL + <b>mot de passe d\'application</b> de chaque nœud (Réglages → API → App password).</div></div>';
    } else {
      const nf = x => x == null ? '—' : x.toLocaleString('fr-FR');
      h += '<div class="phwrap">' + d.instances.map(x => {
        if (!x.ok) return '<div class="phcard"><div class="phhead">🛡️ ' + x.name + '<span class="phstate" style="background:rgba(224,82,82,.15);color:var(--bad)">' + (x.reason || 'erreur') + '</span></div></div>';
        const on = x.blocking !== false;
        return '<div class="phcard"><div class="phhead">🛡️ ' + x.name +
          '<span class="phstate" style="background:' + (on ? 'var(--accent-tint)' : 'rgba(224,82,82,.15)') + ';color:' + (on ? 'var(--accent)' : 'var(--bad)') + '">' + (on ? 'blocage actif' : 'blocage désactivé') + '</span></div>' +
          '<div class="phstats">' +
          '<div class="phst"><b>' + nf(x.queries) + '</b><span>requêtes (24 h)</span></div>' +
          '<div class="phst"><b>' + nf(x.blocked) + '</b><span>bloquées</span></div>' +
          '<div class="phst"><b>' + x.percent + ' %</b><span>taux de blocage</span></div>' +
          '</div>' +
          ((x.top && x.top.length) ? ('<div class="phtop"><div class="phtoph">Top bloqués</div>' + x.top.map(t => '<div class="phdom">' + t.domain + '<span>' + nf(t.count) + '</span></div>').join('') + '</div>') : '') +
          '</div>';
      }).join('') + '</div>';
      const oks = d.instances.filter(x => x.ok);
      if (oks.length > 1) {
        const tq = oks.reduce((a2, x) => a2 + (x.queries || 0), 0), tb = oks.reduce((a2, x) => a2 + (x.blocked || 0), 0);
        h += '<div class="wsrc" style="padding-left:0">Total : ' + tq.toLocaleString('fr-FR') + ' requêtes · ' + tb.toLocaleString('fr-FR') + ' bloquées (' + (tq ? Math.round(tb / tq * 1000) / 10 : 0) + ' %) · gravity ' + ((oks[0].gravity || 0).toLocaleString('fr-FR')) + ' domaines</div>';
      }
    }
    el.innerHTML = h;
    const ob = document.getElementById('phOpen'); if (ob) ob.addEventListener('click', () => sdk.openService(url + '/admin', (a && (a.nm || a.name)) || 'Pi-hole'));
    const rb = document.getElementById('phRefresh'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
  }
  return { render };
})();
