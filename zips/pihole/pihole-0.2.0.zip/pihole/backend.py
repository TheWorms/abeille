"""Addon « pihole » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/pihole/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Deux instances Pi-hole v6 (Suricate, Termite), jamais synchronisées : on
interroge chacune indépendamment. Cycle d'auth v6 : POST /api/auth (SID) ->
appels avec en-tête X-FTL-SID -> DELETE /api/auth (logout).
"""


def _pihole_one(sdk, url, pw):
    """Stats d'une instance Pi-hole v6 : auth -> summary/blocking/top -> logout."""
    url = url.rstrip("/")
    sid = None
    try:
        ra = sdk.requests.post(f"{url}/api/auth", json={"password": pw}, timeout=6)
        if ra.status_code != 200:
            return {"ok": False, "reason": f"auth HTTP {ra.status_code}"}
        sid = (ra.json().get("session") or {}).get("sid")
        if not sid:
            return {"ok": False, "reason": "mot de passe refusé"}
        hdr = {"X-FTL-SID": sid}
        rs = sdk.requests.get(f"{url}/api/stats/summary", headers=hdr, timeout=6)
        if rs.status_code != 200:
            return {"ok": False, "reason": f"summary HTTP {rs.status_code}"}
        j = rs.json()
        q = j.get("queries") or {}
        g = j.get("gravity") or {}
        out = {"ok": True,
               "queries": q.get("total"), "blocked": q.get("blocked"),
               "percent": round(q.get("percent_blocked") or 0, 1),
               "clients": (j.get("clients") or {}).get("active"),
               "gravity": g.get("domains_being_blocked")}
        try:
            rb = sdk.requests.get(f"{url}/api/dns/blocking", headers=hdr, timeout=5)
            out["blocking"] = (rb.json().get("blocking") == "enabled") if rb.ok else None
        except Exception:
            out["blocking"] = None
        try:
            rt = sdk.requests.get(f"{url}/api/stats/top_domains",
                                  params={"blocked": "true", "count": 5},
                                  headers=hdr, timeout=6)
            if rt.ok:
                out["top"] = [{"domain": x.get("domain"), "count": x.get("count")}
                              for x in (rt.json().get("domains") or [])[:5]]
        except Exception:
            pass
        return out
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except ValueError:
        return {"ok": False, "reason": "réponse invalide"}
    finally:
        if sid:
            try:
                sdk.requests.delete(f"{url}/api/auth",
                                    headers={"X-FTL-SID": sid}, timeout=4)
            except Exception:
                pass


def _pihole(sdk, cfg):
    insts = []
    for i, defname in ((1, "Suricate"), (2, "Termite")):
        u = (cfg.get(f"url{i}") or "").strip()
        p = (cfg.get(f"pass{i}") or "").strip()
        if not u:
            continue
        insts.append((defname, u, p))
    if not insts:
        return {"ok": False, "reason": "aucune instance configurée"}
    ck = "ph:" + "|".join(u for _, u, _ in insts)
    c = sdk.cache_get(ck, 60)
    if c is not None:
        return c
    out = {"ok": True, "instances": []}
    for name, u, p in insts:
        r = _pihole_one(sdk, u, p)
        r["name"] = name
        r["url"] = u
        out["instances"].append(r)
    if not any(x.get("ok") for x in out["instances"]):
        out["ok"] = False
        out["reason"] = out["instances"][0].get("reason", "")
    return sdk.cache_set(ck, out)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("pihole", __name__)

    @bp.route("/pihole")
    def pihole():
        try:
            return jsonify(_pihole(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("pihole")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    p = _pihole(sdk, cfg)
    if p.get("ok"):
        bits = []
        for x in p["instances"]:
            bits.append(f"{x['name']} ✓ ({x['percent']}% bloqué)" if x.get("ok")
                        else f"{x['name']} ✗ ({x.get('reason')})")
        return True, " · ".join(bits)
    return False, f"Pi-hole ✗ ({p.get('reason')})"
