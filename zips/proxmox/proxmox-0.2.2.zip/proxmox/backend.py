"""Addon « proxmox » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/proxmox/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : API Proxmox VE (token API `USER@REALM!ID=UUID`, cache 30 s).
Deux appels : /nodes (hyperviseurs) et /cluster/resources?type=vm (VM/CT).
"""


def _pve(sdk, cfg):
    """Nœud(s) + VM/CT via l'API Proxmox (token API, cache 30 s)."""
    url = (cfg.get("url") or "").rstrip("/")
    token = (cfg.get("token") or "").strip()
    if not (url and token):
        return {"ok": False, "reason": "URL/token non configurés"}
    ck = f"pve:{url}"
    c = sdk.cache_get(ck, 30)
    if c is not None:
        return c
    hdr = {"Authorization": f"PVEAPIToken={token}"}
    try:
        rn = sdk.requests.get(f"{url}/api2/json/nodes", headers=hdr,
                              timeout=8, verify=False)
        rr = sdk.requests.get(f"{url}/api2/json/cluster/resources",
                              params={"type": "vm"}, headers=hdr,
                              timeout=8, verify=False)
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    if rn.status_code == 401 or rr.status_code == 401:
        return {"ok": False, "reason": "token refusé (401) — format USER@REALM!ID=UUID"}
    if rn.status_code != 200 or rr.status_code != 200:
        return {"ok": False, "reason": f"HTTP {max(rn.status_code, rr.status_code)}"}
    try:
        nodes = []
        for n in rn.json().get("data", []):
            nodes.append({"name": n.get("node"),
                          "cpu": round((n.get("cpu") or 0) * 100, 1),
                          "maxcpu": n.get("maxcpu"),
                          "mem": n.get("mem"), "maxmem": n.get("maxmem"),
                          "uptime": n.get("uptime"),
                          "status": n.get("status")})
        guests = []
        for g in rr.json().get("data", []):
            guests.append({"vmid": g.get("vmid"), "name": g.get("name"),
                           "type": "CT" if g.get("type") == "lxc" else "VM",
                           "status": g.get("status"),
                           "cpu": round((g.get("cpu") or 0) * 100, 1),
                           "mem": g.get("mem"), "maxmem": g.get("maxmem"),
                           "uptime": g.get("uptime")})
        guests.sort(key=lambda x: x.get("vmid") or 0)
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}
    res = {"ok": True, "nodes": nodes, "guests": guests}
    return sdk.cache_set(ck, res)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("proxmox", __name__)

    @bp.route("/proxmox")
    def proxmox():
        try:
            return jsonify(_pve(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("proxmox")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    p = _pve(sdk, cfg)
    if p.get("ok"):
        up = sum(1 for g in p["guests"] if g["status"] == "running")
        return True, (f"Proxmox ✓ — {len(p['nodes'])} nœud(s), "
                      f"{up}/{len(p['guests'])} VM/CT en marche")
    return False, f"Proxmox ✗ ({p.get('reason')})"
