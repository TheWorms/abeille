"""Addon « budget » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/budget/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : Actual Budget via la passerelle REST actual-http-api (en-tête
x-api-key). Cache 120 s. Le helper `_ck` (clé de cache incluant le secret,
pour qu'une clé erronée ne récupère pas la réponse d'une clé valide) est
dupliqué ici : le noyau garde le sien, partagé par d'autres addons.
"""
import hashlib
from datetime import datetime


def _ck(*parts):
    """Clé de cache incluant le secret : une config erronée ne peut pas
    récupérer la réponse d'une config valide. (Copie locale du helper noyau.)"""
    return hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()[:24]


def _actual_get(sdk, cfg, path, timeout=15):
    url = (cfg.get("url") or "").rstrip("/")
    key = (cfg.get("apikey") or "").strip()
    if not (url and key):
        raise RuntimeError("URL/clé API non configurées (⚙ Budget)")
    r = sdk.requests.get(f"{url}{path}", headers={"x-api-key": key}, timeout=timeout)
    if r.status_code in (401, 403):
        raise RuntimeError(f"clé API refusée ({r.status_code}) — "
                           f"elle fait {len(key)} caractère(s), attendu ~48")
    if r.status_code == 404:
        raise RuntimeError(f"introuvable ({path}) — vérifie l'ID du budget")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.json()


def _actual(sdk, cfg):
    """Actual Budget via la passerelle REST actual-http-api."""
    sync = (cfg.get("budget") or "").strip()
    ck = _ck("ab", cfg.get("url"), cfg.get("apikey"), sync)
    c = sdk.cache_get(ck, 120)
    if c is not None:
        return c
    try:
        if not sync:
            budgets = _actual_get(sdk, cfg, "/v1/budgets").get("data", [])
            noms = ", ".join(f"{b.get('name')} ({b.get('groupId') or b.get('id')})"
                             for b in budgets)
            return {"ok": False,
                    "reason": f"précise l'ID du budget dans ⚙. Disponibles : {noms or 'aucun'}"}
        accounts = _actual_get(sdk, cfg, f"/v1/budgets/{sync}/accounts").get("data", [])
        month = datetime.now().strftime("%Y-%m")
        cats = []
        try:
            cats = _actual_get(sdk, cfg, f"/v1/budgets/{sync}/months/{month}").get("data", {}) \
                       .get("categoryGroups", [])
        except RuntimeError:
            pass
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}

    def _eur(cents):
        return round((cents or 0) / 100, 2)

    accs, total = [], 0
    for a in accounts:
        if a.get("closed"):
            continue
        bal = a.get("balance")
        if bal is None:
            try:
                bal = _actual_get(sdk, cfg, f"/v1/budgets/{sync}/accounts/{a['id']}/balance") \
                          .get("data", 0)
            except RuntimeError:
                bal = 0
        total += bal or 0
        accs.append({"name": a.get("name", "?"), "balance": _eur(bal),
                     "offbudget": bool(a.get("offbudget"))})
    accs.sort(key=lambda x: (x["offbudget"], -x["balance"]))

    groups, budgeted, spent = [], 0, 0
    for g in cats:
        if g.get("is_income") or g.get("hidden"):
            continue
        gcats = []
        for c2 in g.get("categories", []):
            b, sp = c2.get("budgeted") or 0, c2.get("spent") or 0
            budgeted += b
            spent += sp
            if b or sp:
                gcats.append({"name": c2.get("name", "?"), "budgeted": _eur(b),
                              "spent": _eur(-sp), "balance": _eur(c2.get("balance") or 0)})
        if gcats:
            groups.append({"name": g.get("name", "?"), "categories": gcats})

    res = {"ok": True, "accounts": accs, "total": _eur(total),
           "month": month, "groups": groups,
           "budgeted": _eur(budgeted), "spent": _eur(-spent),
           "remaining": _eur(budgeted + spent)}
    return sdk.cache_set(ck, res)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("budget", __name__)

    @bp.route("/budget")
    def budget():
        try:
            return jsonify(_actual(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("budget")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    b = _actual(sdk, cfg)
    if b.get("ok"):
        return True, (f"Actual ✓ — {len(b['accounts'])} compte(s), "
                      f"solde {b['total']} €")
    return False, f"Actual ✗ ({b.get('reason')})"
