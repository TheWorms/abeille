/* Budget — Actual Budget en lecture seule via actual-http-api (Phase 3, lot A). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.budget = (function () {
  let S = null, root = null, tile = null;
  const CSS = ".abhero{display:flex;gap:22px;background:var(--tile);border:1px solid var(--border-soft);border-radius:14px;\n          padding:16px 20px;margin-bottom:12px;align-items:center}\n.abbig{font-size:30px;font-weight:700;line-height:1;font-variant-numeric:tabular-nums}\n.absub{font-size:11.5px;color:var(--dim);margin-top:3px}\n.absep{width:1px;align-self:stretch;background:var(--border-soft)}\n.abbar{flex:1;min-width:150px}\n.abtrk{height:9px;border-radius:5px;background:var(--border-soft);overflow:hidden;margin:8px 0 5px}\n.abfil{height:100%;border-radius:5px;background:var(--accent)}\n.abfil.warn{background:var(--warn)}\n.abfil.bad{background:var(--bad)}\n.abgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:12px}\n.abacc{display:flex;align-items:center;gap:10px;background:var(--tile);border:1px solid var(--border-soft);\n         border-radius:10px;padding:10px 13px}\n.abacc.off{border-style:dashed;opacity:.75}\n.abn{font-weight:600;font-size:13px}\n.abt{margin-left:auto;font-weight:700;font-size:14px;font-variant-numeric:tabular-nums;flex:none}\n.abt.neg{color:var(--bad)}\n.abcat{display:grid;grid-template-columns:1fr 78px 78px 78px;gap:8px;align-items:center;\n         background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:8px 12px;margin-bottom:5px}\n.abcat .v{text-align:right;font-size:12px;font-variant-numeric:tabular-nums}\n.abcat .v.neg{color:var(--bad);font-weight:600}\n.abhead{display:grid;grid-template-columns:1fr 78px 78px 78px;gap:8px;font-size:10px;color:var(--faint);\n          text-transform:uppercase;letter-spacing:.4px;padding:0 12px 4px}\n.abhead span{text-align:right}\n.abhead span:first-child{text-align:left}";
  function ensureCss() { if (document.getElementById('abUiCss')) return; const s = document.createElement('style'); s.id = 'abUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const eur = v => (v < 0 ? '\u2212' : '') + Math.abs(v).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture du budget…</div></div>';
    let d = null; try { const r = await sdk.api('/budget'); d = await r.json(); } catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (!d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">💶</div><div class="t1">Actual Budget</div>' +
        '<div class="t2">' + (d.reason || '') + '<br>Actual n\'a pas d\'API REST : il faut la passerelle <code>actual-http-api</code> à côté du serveur.</div>' +
        '<button class="btnpill install" id="abRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('abRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const pct = d.budgeted > 0 ? Math.min(100, Math.round(d.spent / d.budgeted * 100)) : 0;
    const cls = pct >= 100 ? 'bad' : (pct >= 85 ? 'warn' : '');
    let h = '<div class="abhero"><div><div class="abbig">' + eur(d.total) + '</div><div class="absub">solde total</div></div>' +
      '<div class="absep"></div>' +
      '<div class="abbar"><div style="display:flex;justify-content:space-between;font-size:12px">' +
      '<span>Dépensé ce mois</span><b>' + eur(d.spent) + ' / ' + eur(d.budgeted) + '</b></div>' +
      '<div class="abtrk"><div class="abfil ' + cls + '" style="width:' + pct + '%"></div></div>' +
      '<div class="absub">' + (d.remaining >= 0 ? ('Il reste ' + eur(d.remaining)) : ('Dépassement de ' + eur(-d.remaining))) + '</div></div>';
    h += '</div>';
    h += '<div class="wsec" style="padding-left:0">Comptes</div><div class="abgrid">' +
      d.accounts.map(x => '<div class="abacc' + (x.offbudget ? ' off' : '') + '">' +
        '<span>' + (x.offbudget ? '🏦' : '💳') + '</span><span class="abn">' + x.name + '</span>' +
        '<span class="abt' + (x.balance < 0 ? ' neg' : '') + '">' + eur(x.balance) + '</span></div>').join('') + '</div>';
    if (d.groups.length) {
      h += '<div class="wsec" style="padding-left:0">Budget de ' + new Date(d.month + '-01T12:00:00').toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) + '</div>';
      h += '<div class="abhead"><span>Catégorie</span><span>Budgété</span><span>Dépensé</span><span>Reste</span></div>';
      h += d.groups.map(g => '<div class="wsec" style="padding:6px 0 4px;font-size:11px">' + g.name + '</div>' +
        g.categories.map(c => '<div class="abcat"><span class="abn">' + c.name + '</span>' +
          '<span class="v">' + eur(c.budgeted) + '</span>' +
          '<span class="v">' + eur(c.spent) + '</span>' +
          '<span class="v' + (c.balance < 0 ? ' neg' : '') + '">' + eur(c.balance) + '</span></div>').join('')).join('');
    }
    h += '<div class="wsrc">Actual Budget via actual-http-api · lecture seule · vue embarquée v0.2.0</div>';
    el.innerHTML = h;
  }
  return { render };
})();
