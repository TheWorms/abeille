"""Addon « wallos » (Abonnements) — backend au contrat SDK du kiosk.

    register(sdk) -> flask.Blueprint   (routes sous /addons/wallos/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Source : Wallos (Fourmi). Deux endpoints combinés :
  - get_subscriptions.php  → liste des abonnements actifs
  - get_monthly_cost.php   → coût mensuel total (calculé par Wallos)

Le calcul du « budget restant ce mois » est fait ici : parmi les abonnements
dont next_payment tombe dans le mois courant, ceux dont la date est déjà passée
(< aujourd'hui) sont « déjà prélevés » ; restant = mensuel − somme des passés.
Le coût mensuel de référence vient de Wallos (fidèle aux cycles), pas d'un
recalcul local.
"""
from datetime import date, timedelta


def _num(v):
    """Convertit '12.99', 12.99, '€12,99' → float ; 0.0 si illisible."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    out = []
    for ch in s:
        if ch.isdigit() or ch in ".-":
            out.append(ch)
        elif ch == ",":
            out.append(".")
    try:
        return float("".join(out) or 0)
    except ValueError:
        return 0.0


def _parse_date(s):
    """'2026-07-08' → date ; None si illisible."""
    if not s:
        return None
    try:
        y, m, d = str(s)[:10].split("-")
        return date(int(y), int(m), int(d))
    except (ValueError, TypeError):
        return None


# Wallos : cycle → unité (1=jour, 2=semaine, 3=mois, 4=an)
_CYCLE_MONTHS = {1: 1 / 30.0, 2: 1 / 4.345, 3: 1.0, 4: 12.0}


def _cycle_label(cycle, frequency):
    freq = frequency or 1
    unit = {1: "jour", 2: "semaine", 3: "mois", 4: "an"}.get(cycle, "?")
    if freq == 1:
        return {"jour": "quotidien", "semaine": "hebdo",
                "mois": "mensuel", "an": "annuel"}.get(unit, unit)
    return f"tous les {freq} {unit}s"


def _monthly_equiv(price, cycle, frequency):
    """Coût mensualisé d'un abonnement selon son cycle/fréquence."""
    freq = frequency or 1
    per_month = _CYCLE_MONTHS.get(cycle, 1.0)
    if per_month <= 0:
        return 0.0
    # price est le montant par période ; période = per_month mois × freq
    return price / (per_month * freq)


def _add_period(d, cycle, frequency):
    """Avance une date d'une période (cycle/fréquence Wallos)."""
    freq = frequency or 1
    if cycle == 1:      # jours
        return d + timedelta(days=freq)
    if cycle == 2:      # semaines
        return d + timedelta(weeks=freq)
    if cycle == 3:      # mois
        mm = d.month - 1 + freq
        y = d.year + mm // 12
        m = mm % 12 + 1
        # clamp jour de fin de mois
        import calendar
        day = min(d.day, calendar.monthrange(y, m)[1])
        return date(y, m, day)
    if cycle == 4:      # ans
        try:
            return d.replace(year=d.year + freq)
        except ValueError:
            return d.replace(year=d.year + freq, day=28)
    return d + timedelta(days=30 * freq)


def _forecast(subs, months, today):
    """Projette les échéances sur `months` mois à partir du mois courant."""
    horizon = []
    # bornes : du 1er du mois courant au dernier jour du mois (courant+months-1)
    start = date(today.year, today.month, 1)
    end_mm = today.month - 1 + months
    end_y = today.year + end_mm // 12
    end_m = end_mm % 12 + 1
    import calendar
    end = date(end_y, end_m, calendar.monthrange(end_y, end_m)[1])

    buckets = {}
    for i in range(months):
        mm = today.month - 1 + i
        yy = today.year + mm // 12
        mo = mm % 12 + 1
        buckets[(yy, mo)] = {"label": f"{mo:02d}/{yy}", "total": 0.0, "count": 0}

    for sub in subs:
        if sub.get("inactive"):
            continue
        price = _num(sub.get("price"))
        cycle = sub.get("cycle")
        freq = sub.get("frequency") or 1
        nxt = _parse_date(sub.get("next_payment"))
        if not nxt or price <= 0:
            continue
        # dérouler les échéances de nxt jusqu'à end
        d = nxt
        guard = 0
        while d <= end and guard < 500:
            guard += 1
            if d >= start:
                key = (d.year, d.month)
                if key in buckets:
                    buckets[key]["total"] += price
                    buckets[key]["count"] += 1
            nd = _add_period(d, cycle, freq)
            if nd <= d:
                break
            d = nd

    for i in range(months):
        mm = today.month - 1 + i
        yy = today.year + mm // 12
        mo = mm % 12 + 1
        b = buckets[(yy, mo)]
        horizon.append({"label": b["label"], "total": round(b["total"], 2),
                        "count": b["count"], "current": (i == 0)})
    return horizon


def _wallos(sdk, cfg):
    url = (cfg.get("url") or "").rstrip("/")
    key = (cfg.get("apikey") or "").strip()
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    def _get(path, params):
        r = sdk.requests.get(url + path, params=params, timeout=10)
        if r.status_code == 401:
            raise RuntimeError("clé API refusée (401)")
        r.raise_for_status()
        return r.json()

    try:
        subs_raw = _get("/api/subscriptions/get_subscriptions.php",
                        {"api_key": key, "state": "0",
                         "convert_currency": "true", "sort": "next_payment"})
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except ValueError:
        return {"ok": False, "reason": "réponse Wallos invalide"}

    subs = subs_raw.get("subscriptions") or []
    today = date.today()
    y, m = today.year, today.month
    currency = "€"
    items, paid_this_month, due_this_month = [], 0.0, 0.0
    total_active = sum(1 for s in subs if not s.get("inactive"))

    all_items = []      # tous les abonnements actifs (vue « Tous » en cartes)
    cat_monthly = {}    # coût mensualisé par catégorie (répartition)
    monthly_total = 0.0

    for s in subs:
        if s.get("inactive"):
            continue
        price = _num(s.get("price"))
        nxt = _parse_date(s.get("next_payment"))
        cur = s.get("currency_code") or s.get("currency_symbol") or currency
        if cur:
            currency = cur
        cycle = s.get("cycle")
        freq = s.get("frequency") or 1
        cat = s.get("category_name") or "Sans catégorie"

        # coût mensualisé (pour répartition + total lissé maison)
        meq = _monthly_equiv(price, cycle, freq)
        monthly_total += meq
        cat_monthly[cat] = cat_monthly.get(cat, 0.0) + meq

        # entrée « tous »
        all_items.append({
            "name": s.get("name", "?"),
            "price": round(price, 2),
            "monthly": round(meq, 2),
            "category": cat,
            "cycle": cycle,
            "frequency": freq,
            "cycle_label": _cycle_label(cycle, freq),
            "next": nxt.isoformat() if nxt else "",
            "logo": s.get("logo") or "",
        })

        # vue « ce mois »
        in_month = bool(nxt and nxt.year == y and nxt.month == m)
        passed = bool(in_month and nxt < today)
        if not in_month:
            continue
        due_this_month += price
        if passed:
            paid_this_month += price
        items.append({
            "name": s.get("name", "?"),
            "price": round(price, 2),
            "category": cat,
            "next": nxt.isoformat() if nxt else "",
            "in_month": True,
            "passed": passed,
        })

    # répartition par catégorie (triée par montant décroissant)
    categories = sorted(
        ({"name": k, "monthly": round(v, 2),
          "pct": round(v / monthly_total * 100, 1) if monthly_total else 0}
         for k, v in cat_monthly.items()),
        key=lambda x: x["monthly"], reverse=True)

    all_items.sort(key=lambda x: x["monthly"], reverse=True)

    # prévisionnel sur N mois (config)
    try:
        n_months = int(cfg.get("forecast") or 6)
    except (TypeError, ValueError):
        n_months = 6
    if n_months not in (3, 6, 12):
        n_months = 6
    forecast = _forecast(subs, n_months, today)

    # « Montant dû ce mois-ci » = SOMME DES ÉCHÉANCES réelles du mois (ce qui sera
    # effectivement prélevé), et NON le coût mensualisé de get_monthly_cost.php
    # (qui ramène les cycles annuels/hebdo à une moyenne mensuelle — chiffre bien
    # plus gros, non représentatif du dû réel du mois).
    due_month = round(due_this_month, 2)
    remaining = round(max(0.0, due_month - paid_this_month), 2)

    # coût mensualisé « lissé » de Wallos, conservé à titre indicatif (info secondaire)
    smoothed = None
    try:
        mc = _get("/api/subscriptions/get_monthly_cost.php",
                  {"api_key": key, "month": str(m), "year": str(y)})
        smoothed = _num(mc.get("localized_monthly_cost")
                        or mc.get("monthly_cost"))
        sym = mc.get("currency_symbol")
        if sym:
            currency = sym
    except Exception:
        smoothed = None

    # tri : à venir d'abord (par date), puis déjà passés, puis hors mois
    def _rank(x):
        if x["in_month"] and not x["passed"]:
            return (0, x["next"])
        if x["passed"]:
            return (1, x["next"])
        return (2, x["next"] or "9999")
    items.sort(key=_rank)

    return {
        "ok": True,
        "items": items,
        "currency": currency,
        "due_month": due_month,                 # montant dû ce mois-ci (échéances réelles)
        "paid": round(paid_this_month, 2),      # déjà prélevé ce mois-ci
        "remaining": remaining,                 # reste à prélever d'ici la fin du mois
        "smoothed": round(smoothed, 2) if smoothed else None,  # coût mensualisé (indicatif)
        "count": len(items),               # abonnements échéant ce mois
        "total_active": total_active,      # total d'abonnements actifs (tous mois)
        "month_label": today.strftime("%m/%Y"),
        "all_items": all_items,            # tous les abonnements actifs (cartes)
        "categories": categories,          # répartition par catégorie (mensualisé)
        "monthly_total": round(monthly_total, 2),  # coût mensualisé total (maison)
        "forecast": forecast,              # projection sur N mois
        "forecast_months": n_months,
        "layout": (cfg.get("layout") or "tabs"),
    }


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("wallos", __name__)

    @bp.route("/subs")
    def subs():
        try:
            return jsonify(_wallos(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("wallos")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    w = _wallos(sdk, cfg)
    if w.get("ok"):
        return True, (f"Wallos ✓ — {w['count']} abonnement(s), "
                      f"dû ce mois {w['due_month']} {w['currency']}, "
                      f"reste {w['remaining']} {w['currency']}")
    return False, f"Wallos ✗ ({w.get('reason')})"
