/* Abonnements (Wallos) — 4 vues : ce mois (budget), tous (cartes),
   catégories (donut), prévisionnel. Disposition onglets ou empilée (config). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.wallos = (function () {
  let S = null, root = null, tile = null, data = null, tab = 'month', cfgCache = {};
  const PALETTE = ['#f0b429', '#2e8b57', '#3778dd', '#8a5cf6', '#d85a30', '#d4537e', '#1d9e75', '#5f5e5a', '#e24b4a', '#ba7517'];
  const CSS =
    "  .wawrap{flex:1;display:flex;flex-direction:column;min-height:0}\n" +
    "  .watabs{display:flex;gap:4px;padding:12px 22px 0;flex-wrap:wrap}\n" +
    "  .watab{background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:8px 14px;font-size:13px;color:var(--dim);cursor:pointer}\n" +
    "  .watab.on{background:var(--tile);color:var(--accent);border-color:var(--accent)}\n" +
    "  .wascroll{flex:1;min-height:0;overflow:auto;padding:14px 22px 16px}\n" +
    "  .wablk{margin-bottom:22px}\n" +
    "  .wablktitle{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin-bottom:10px}\n" +
    /* ce mois : liste + budget */
    "  .wacols{display:grid;grid-template-columns:1fr 300px;gap:16px}\n" +
    "  .walist{display:flex;flex-direction:column;gap:7px}\n" +
    "  .wasub{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-left:4px solid var(--accent);border-radius:10px;padding:10px 14px}\n" +
    "  .wasub.passed{border-left-color:var(--faint);opacity:.62}\n" +
    "  .wasub.passed .waname{text-decoration:line-through}\n" +
    "  .wanm{min-width:0;flex:1}\n" +
    "  .waname{font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n" +
    "  .wacat{font-size:11.5px;color:var(--dim);margin-top:1px}\n" +
    "  .waprice{font-weight:600;font-size:14.5px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .wadue{font-size:11px;color:var(--dim);flex:none;min-width:78px;text-align:right;font-variant-numeric:tabular-nums}\n" +
    "  .wadue.soon{color:var(--warn);font-weight:600}\n" +
    "  .wapaid{font-size:10px;color:var(--faint);flex:none}\n" +
    "  .wapanel{display:flex;flex-direction:column;gap:12px}\n" +
    "  .wacard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:16px 18px}\n" +
    "  .wacard .lbl{font-size:12px;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}\n" +
    "  .wacard .big{font-size:34px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.1;margin-top:4px}\n" +
    "  .wacard.rest{border-color:var(--accent)}\n" +
    "  .wacard.rest .big{color:var(--accent)}\n" +
    "  .wabar{height:9px;border-radius:6px;background:var(--bg);overflow:hidden;margin-top:12px;border:1px solid var(--border-soft)}\n" +
    "  .wabar > i{display:block;height:100%;background:var(--accent)}\n" +
    "  .wasplit{display:flex;justify-content:space-between;font-size:12px;margin-top:8px;color:var(--dim)}\n" +
    "  .wasplit b{color:var(--text);font-variant-numeric:tabular-nums}\n" +
    /* tous : cartes */
    "  .wagrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:11px}\n" +
    "  .wacell{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px;border-left:3px solid var(--accent)}\n" +
    "  .wacelltop{display:flex;align-items:baseline;gap:8px;margin-bottom:7px}\n" +
    "  .wacellnm{font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .wacellpr{font-weight:700;font-size:14px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .wacellmeta{display:flex;justify-content:space-between;font-size:11.5px;color:var(--dim)}\n" +
    "  .wacellmo{font-size:11px;color:var(--faint);margin-top:6px;font-variant-numeric:tabular-nums}\n" +
    /* catégories : donut */
    "  .wadonut-wrap{display:flex;gap:22px;align-items:center;flex-wrap:wrap}\n" +
    "  .wadonut{width:180px;height:180px;border-radius:50%;flex:none;position:relative}\n" +
    "  .wadonut::before{content:'';position:absolute;inset:26%;border-radius:50%;background:var(--panel,var(--bg))}\n" +
    "  .wadonut-c{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}\n" +
    "  .wadonut-c b{font-size:20px;font-variant-numeric:tabular-nums}\n" +
    "  .wadonut-c span{font-size:10.5px;color:var(--dim)}\n" +
    "  .walegend{flex:1;min-width:200px;display:flex;flex-direction:column;gap:7px}\n" +
    "  .walegrow{display:flex;align-items:center;gap:10px;font-size:13px}\n" +
    "  .waledot{width:12px;height:12px;border-radius:3px;flex:none}\n" +
    "  .walegnm{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .walegval{font-variant-numeric:tabular-nums;color:var(--dim)}\n" +
    "  .walegpct{font-variant-numeric:tabular-nums;font-weight:600;min-width:44px;text-align:right}\n" +
    /* prévisionnel */
    "  .wafc{display:flex;flex-direction:column;gap:8px}\n" +
    "  .wafcrow{display:flex;align-items:center;gap:12px}\n" +
    "  .wafclabel{font-size:12.5px;font-variant-numeric:tabular-nums;min-width:64px;flex:none;color:var(--dim)}\n" +
    "  .wafcrow.cur .wafclabel{color:var(--accent);font-weight:700}\n" +
    "  .wafcbar{flex:1;height:26px;background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;overflow:hidden;position:relative}\n" +
    "  .wafcbar > i{display:block;height:100%;background:var(--accent);opacity:.8}\n" +
    "  .wafcrow.cur .wafcbar > i{opacity:1}\n" +
    "  .wafcval{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:12px;font-weight:600;font-variant-numeric:tabular-nums}\n" +
    "  .wafccount{font-size:11px;color:var(--faint);min-width:70px;flex:none;text-align:right}\n" +
    "  .waopen{margin-top:14px;padding:11px;border-radius:10px;border:1px solid var(--border-soft);background:var(--tile);color:var(--text);font-size:13.5px;cursor:pointer;text-align:center;width:100%}\n" +
    "  .waopen:active{border-color:var(--accent);color:var(--accent)}\n" +
    "  .wasrc{font-size:11px;color:var(--faint);padding:8px 22px 4px}";
  function ensureCss() { if (document.getElementById('waUiCss')) return; const s = document.createElement('style'); s.id = 'waUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const fmtMoney = (v, c) => (Math.round(v * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + (c || '€');
  function dueLabel(iso) {
    if (!iso) return '—';
    const d = Math.ceil((new Date(iso + 'T12:00:00') - Date.now()) / 86400000);
    if (d < 0) return 'passé';
    if (d === 0) return "aujourd'hui";
    if (d === 1) return 'demain';
    if (d < 30) return 'dans ' + d + ' j';
    return new Date(iso + 'T12:00:00').toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des abonnements…</div></div>';
    try { cfgCache = await sdk.config(); } catch (e) { cfgCache = {}; }
    try { const r = await sdk.api('/subs'); data = await r.json(); } catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  /* ---- blocs de contenu ---- */
  function blkMonth(d, c) {
    const pct = d.due_month > 0 ? Math.min(100, Math.round(d.paid / d.due_month * 100)) : 0;
    let h = '<div class="wablk"><div class="wablktitle">Ce mois · ' + d.month_label + ' · ' + d.count + ' échéance' + (d.count > 1 ? 's' : '') + '</div>';
    h += '<div class="wacols"><div class="walist">';
    if (!d.items.length) h += '<div class="stub"><div class="t2">Aucune échéance ce mois-ci</div></div>';
    else h += d.items.map(it => {
      const dl = dueLabel(it.next), soon = it.in_month && !it.passed;
      return '<div class="wasub' + (it.passed ? ' passed' : '') + '">' +
        '<span class="wanm"><span class="waname">' + esc(it.name) + '</span>' +
        (it.category ? '<div class="wacat">' + esc(it.category) + '</div>' : '') + '</span>' +
        '<span class="waprice">' + fmtMoney(it.price, c) + '</span>' +
        (it.passed ? '<span class="wapaid">✓ prélevé</span>' : '<span class="wadue' + (soon ? ' soon' : '') + '">' + dl + '</span>') + '</div>';
    }).join('');
    h += '</div><div class="wapanel">' +
      '<div class="wacard"><div class="lbl">Dû ce mois-ci</div><div class="big">' + fmtMoney(d.due_month, c) + '</div>' +
        '<div class="wabar"><i style="width:' + pct + '%"></i></div>' +
        '<div class="wasplit"><span>Déjà prélevé <b>' + fmtMoney(d.paid, c) + '</b></span><span>' + pct + '%</span></div></div>' +
      '<div class="wacard rest"><div class="lbl">Restant ce mois</div><div class="big">' + fmtMoney(d.remaining, c) + '</div>' +
        '<div class="wasplit"><span>À venir d\'ici la fin du mois</span></div></div>' +
      '<div class="wacard"><div class="lbl">Coût mensualisé</div><div class="wasplit" style="margin-top:6px"><span>Tous abonnements ÷ mois</span><b>' + fmtMoney(d.monthly_total, c) + '</b></div></div>' +
      '</div></div></div>';
    return h;
  }
  function blkAll(d, c) {
    let h = '<div class="wablk"><div class="wablktitle">Tous les abonnements · ' + d.total_active + ' actifs</div><div class="wagrid">';
    h += d.all_items.map(it =>
      '<div class="wacell"><div class="wacelltop"><span class="wacellnm">' + esc(it.name) + '</span><span class="wacellpr">' + fmtMoney(it.price, c) + '</span></div>' +
      '<div class="wacellmeta"><span>' + esc(it.category) + '</span><span>' + esc(it.cycle_label) + '</span></div>' +
      '<div class="wacellmo">≈ ' + fmtMoney(it.monthly, c) + '/mois' + (it.next ? ' · proch. ' + dueLabel(it.next) : '') + '</div></div>').join('');
    h += '</div></div>';
    return h;
  }
  function blkCategories(d, c) {
    const cats = d.categories || [];
    let h = '<div class="wablk"><div class="wablktitle">Répartition par catégorie · mensualisé</div>';
    if (!cats.length) { return h + '<div class="stub"><div class="t2">Aucune donnée</div></div></div>'; }
    // donut via conic-gradient
    let acc = 0; const segs = [];
    cats.forEach((cat, i) => { const col = PALETTE[i % PALETTE.length]; const from = acc; acc += cat.pct; segs.push(col + ' ' + from + '% ' + acc + '%'); });
    h += '<div class="wadonut-wrap"><div class="wadonut" style="background:conic-gradient(' + segs.join(',') + ')">' +
      '<div class="wadonut-c"><b>' + fmtMoney(d.monthly_total, c) + '</b><span>par mois</span></div></div>';
    h += '<div class="walegend">' + cats.map((cat, i) =>
      '<div class="walegrow"><span class="waledot" style="background:' + PALETTE[i % PALETTE.length] + '"></span>' +
      '<span class="walegnm">' + esc(cat.name) + '</span>' +
      '<span class="walegval">' + fmtMoney(cat.monthly, c) + '</span>' +
      '<span class="walegpct">' + cat.pct + '%</span></div>').join('') + '</div></div></div>';
    return h;
  }
  function blkForecast(d, c) {
    const fc = d.forecast || [];
    let h = '<div class="wablk"><div class="wablktitle">Prévisionnel · ' + d.forecast_months + ' mois</div>';
    if (!fc.length) return h + '<div class="stub"><div class="t2">Aucune donnée</div></div></div>';
    const max = Math.max.apply(null, fc.map(f => f.total)) || 1;
    h += '<div class="wafc">' + fc.map(f =>
      '<div class="wafcrow' + (f.current ? ' cur' : '') + '"><span class="wafclabel">' + f.label + '</span>' +
      '<div class="wafcbar"><i style="width:' + Math.max(2, Math.round(f.total / max * 100)) + '%"></i>' +
      '<span class="wafcval">' + fmtMoney(f.total, c) + '</span></div>' +
      '<span class="wafccount">' + f.count + ' éch.</span></div>').join('') + '</div></div>';
    return h;
  }
  function openBtn() {
    return '<button class="waopen" id="waOpen">Ouvrir Wallos ↗</button>';
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🐜</div><div class="t1">Abonnements indisponibles</div><div class="t2">' +
        ((d && d.reason) || '') + ' — renseigne l\'URL Wallos et la clé API dans ⚙.</div>' +
        '<button class="btnpill install" id="waRetry" style="margin-top:14px">↻ Actualiser</button></div>';
      const rb = document.getElementById('waRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const c = d.currency || '€';
    const layout = d.layout || cfgCache.layout || 'tabs';

    if (layout === 'stack') {
      // tout empilé
      let h = '<div class="wawrap"><div class="wascroll">';
      h += blkMonth(d, c) + blkAll(d, c) + blkCategories(d, c) + blkForecast(d, c);
      h += openBtn();
      h += '</div><div class="wasrc">Wallos (Fourmi) · coûts mensualisés calculés localement · v0.4.0</div></div>';
      el.innerHTML = h;
    } else {
      // onglets
      const tabs = [['month', 'Ce mois'], ['all', 'Tous'], ['cats', 'Catégories'], ['forecast', 'Prévisionnel']];
      let h = '<div class="wawrap"><div class="watabs">' +
        tabs.map(t => '<button class="watab' + (tab === t[0] ? ' on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') +
        '</div><div class="wascroll">';
      if (tab === 'month') h += blkMonth(d, c);
      else if (tab === 'all') h += blkAll(d, c);
      else if (tab === 'cats') h += blkCategories(d, c);
      else h += blkForecast(d, c);
      h += openBtn();
      h += '</div><div class="wasrc">Wallos (Fourmi) · coûts mensualisés calculés localement · v0.4.0</div></div>';
      el.innerHTML = h;
      el.querySelectorAll('.watab').forEach(b => b.addEventListener('click', () => { tab = b.getAttribute('data-tab'); paint(); }));
    }

    const ob = document.getElementById('waOpen');
    if (ob) ob.addEventListener('click', () => { if (cfgCache.url) S.openService(cfgCache.url, (tile && (tile.nm || tile.name)) || 'Wallos'); });
  }

  return { render };
})();
