/* Abonnements (Wallos) — vue à deux colonnes : liste des abonnements à gauche,
   panneau budget à droite (coût du mois, déjà prélevé, restant à venir).
   Le restant est calculé côté backend à partir des échéances déjà passées. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.wallos = (function () {
  let S = null, root = null, tile = null, data = null;
  const CSS = "  .wawrap{flex:1;display:flex;flex-direction:column;min-height:0}\n" +
    "  .wacols{flex:1;display:grid;grid-template-columns:1fr 300px;gap:16px;min-height:0;padding:14px 22px}\n" +
    "  .walist{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:7px}\n" +
    "  .wasub{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);\n" +
    "         border-left:4px solid var(--accent);border-radius:10px;padding:10px 14px}\n" +
    "  .wasub.passed{border-left-color:var(--faint);opacity:.62}\n" +
    "  .wasub.passed .waname{text-decoration:line-through}\n" +
    "  .wanm{min-width:0;flex:1}\n" +
    "  .waname{font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n" +
    "  .wacat{font-size:11.5px;color:var(--dim);margin-top:1px}\n" +
    "  .waprice{font-weight:600;font-size:14.5px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .wadue{font-size:11px;color:var(--dim);flex:none;min-width:78px;text-align:right;font-variant-numeric:tabular-nums}\n" +
    "  .wadue.soon{color:var(--warn);font-weight:600}\n" +
    "  .wapaid{font-size:10px;color:var(--faint);flex:none}\n" +
    "  .wapanel{display:flex;flex-direction:column;gap:12px}\n" +
    "  .wacard{background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:16px 18px}\n" +
    "  .wacard .lbl{font-size:12px;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}\n" +
    "  .wacard .big{font-size:34px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.1;margin-top:4px}\n" +
    "  .wacard.rest{border-color:var(--accent)}\n" +
    "  .wacard.rest .big{color:var(--accent)}\n" +
    "  .wabar{height:9px;border-radius:6px;background:var(--bg);overflow:hidden;margin-top:12px;border:1px solid var(--border-soft)}\n" +
    "  .wabar > i{display:block;height:100%;background:var(--accent)}\n" +
    "  .wasplit{display:flex;justify-content:space-between;font-size:12px;margin-top:8px;color:var(--dim)}\n" +
    "  .wasplit b{color:var(--text);font-variant-numeric:tabular-nums}\n" +
    "  .waopen{margin-top:auto;padding:11px;border-radius:10px;border:1px solid var(--border-soft);\n" +
    "          background:var(--tile);color:var(--text);font-size:13.5px;cursor:pointer;text-align:center}\n" +
    "  .waopen:active{border-color:var(--accent);color:var(--accent)}";
  function ensureCss() { if (document.getElementById('waUiCss')) return; const s = document.createElement('style'); s.id = 'waUiCss'; s.textContent = CSS; document.head.appendChild(s); }

  const fmtMoney = (v, c) => (Math.round(v * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + (c || '€');
  function dueLabel(iso) {
    if (!iso) return '—';
    const d = Math.ceil((new Date(iso + 'T12:00:00') - Date.now()) / 86400000);
    if (d < 0) return 'passé';
    if (d === 0) return "aujourd'hui";
    if (d === 1) return 'demain';
    if (d < 30) return 'dans ' + d + ' j';
    return new Date(iso + 'T12:00:00').toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des abonnements…</div></div>';
    try { const r = await sdk.api('/subs'); data = await r.json(); } catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }
  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">🐜</div><div class="t1">Abonnements indisponibles</div><div class="t2">' +
        ((d && d.reason) || '') + ' — renseigne l\'URL Wallos et la clé API dans ⚙.</div>' +
        '<button class="btnpill install" id="waRetry" style="margin-top:14px">↻ Actualiser</button></div>';
      const rb = document.getElementById('waRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    const c = d.currency || '€';
    const pct = d.monthly > 0 ? Math.min(100, Math.round(d.paid / d.monthly * 100)) : 0;
    let h = '<div class="wawrap"><div class="wsec">Abonnements <span style="text-transform:none;letter-spacing:0;color:var(--dim);font-weight:400">· ' +
      d.count + ' actif' + (d.count > 1 ? 's' : '') + ' · ' + d.month_label + '</span></div>';
    h += '<div class="wacols"><div class="walist">';
    if (!d.items.length) h += '<div class="stub"><div class="t2">Aucun abonnement actif</div></div>';
    else h += d.items.map(it => {
      const dl = dueLabel(it.next);
      const soon = it.in_month && !it.passed;
      return '<div class="wasub' + (it.passed ? ' passed' : '') + '">' +
        '<span class="wanm"><span class="waname">' + esc(it.name) + '</span>' +
        (it.category ? '<div class="wacat">' + esc(it.category) + '</div>' : '') + '</span>' +
        '<span class="waprice">' + fmtMoney(it.price, c) + '</span>' +
        (it.passed ? '<span class="wapaid">✓ prélevé</span>'
                   : '<span class="wadue' + (soon ? ' soon' : '') + '">' + dl + '</span>') +
        '</div>';
    }).join('');
    h += '</div>';   // /walist

    // panneau budget
    h += '<div class="wapanel">' +
      '<div class="wacard"><div class="lbl">Coût du mois</div><div class="big">' + fmtMoney(d.monthly, c) + '</div>' +
        '<div class="wabar"><i style="width:' + pct + '%"></i></div>' +
        '<div class="wasplit"><span>Déjà prélevé <b>' + fmtMoney(d.paid, c) + '</b></span><span>' + pct + '%</span></div></div>' +
      '<div class="wacard rest"><div class="lbl">Restant ce mois</div><div class="big">' + fmtMoney(d.remaining, c) + '</div>' +
        '<div class="wasplit"><span>À venir d\'ici la fin du mois</span></div></div>' +
      '<button class="waopen" id="waOpen">Ouvrir Wallos ↗</button>' +
      '</div>';   // /wapanel
    h += '</div>';   // /wacols
    h += '<div class="wsrc">Wallos (Fourmi) · le coût mensuel est calculé par Wallos · vue embarquée v0.3.0</div></div>';
    el.innerHTML = h;
    const ob = document.getElementById('waOpen');
    if (ob) ob.addEventListener('click', async () => {
      let cfg = {}; try { cfg = await S.config(); } catch (e) {}
      if (cfg.url) S.openService(cfg.url, (tile && (tile.nm || tile.name)) || 'Wallos');
    });
  }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  return { render };
})();
