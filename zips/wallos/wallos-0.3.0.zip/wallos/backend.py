"""Addon « wallos » (Abonnements) — backend au contrat SDK du kiosk.

    register(sdk) -> flask.Blueprint   (routes sous /addons/wallos/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Source : Wallos (Fourmi). Deux endpoints combinés :
  - get_subscriptions.php  → liste des abonnements actifs
  - get_monthly_cost.php   → coût mensuel total (calculé par Wallos)

Le calcul du « budget restant ce mois » est fait ici : parmi les abonnements
dont next_payment tombe dans le mois courant, ceux dont la date est déjà passée
(< aujourd'hui) sont « déjà prélevés » ; restant = mensuel − somme des passés.
Le coût mensuel de référence vient de Wallos (fidèle aux cycles), pas d'un
recalcul local.
"""
from datetime import date


def _num(v):
    """Convertit '12.99', 12.99, '€12,99' → float ; 0.0 si illisible."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    out = []
    for ch in s:
        if ch.isdigit() or ch in ".-":
            out.append(ch)
        elif ch == ",":
            out.append(".")
    try:
        return float("".join(out) or 0)
    except ValueError:
        return 0.0


def _parse_date(s):
    """'2026-07-08' → date ; None si illisible."""
    if not s:
        return None
    try:
        y, m, d = str(s)[:10].split("-")
        return date(int(y), int(m), int(d))
    except (ValueError, TypeError):
        return None


def _wallos(sdk, cfg):
    url = (cfg.get("url") or "").rstrip("/")
    key = (cfg.get("apikey") or "").strip()
    if not url or not key:
        return {"ok": False, "reason": "URL ou clé API non configurées"}

    def _get(path, params):
        r = sdk.requests.get(url + path, params=params, timeout=10)
        if r.status_code == 401:
            raise RuntimeError("clé API refusée (401)")
        r.raise_for_status()
        return r.json()

    try:
        subs_raw = _get("/api/subscriptions/get_subscriptions.php",
                        {"api_key": key, "state": "0",
                         "convert_currency": "true", "sort": "next_payment"})
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except ValueError:
        return {"ok": False, "reason": "réponse Wallos invalide"}

    subs = subs_raw.get("subscriptions") or []
    today = date.today()
    y, m = today.year, today.month
    currency = "€"
    items, paid_this_month, due_this_month = [], 0.0, 0.0

    for s in subs:
        if s.get("inactive"):
            continue
        price = _num(s.get("price"))
        nxt = _parse_date(s.get("next_payment"))
        cur = s.get("currency_code") or s.get("currency_symbol") or currency
        if cur:
            currency = cur
        in_month = bool(nxt and nxt.year == y and nxt.month == m)
        passed = bool(in_month and nxt < today)
        if in_month:
            due_this_month += price
            if passed:
                paid_this_month += price
        items.append({
            "name": s.get("name", "?"),
            "price": round(price, 2),
            "category": s.get("category_name") or "",
            "next": nxt.isoformat() if nxt else "",
            "in_month": in_month,
            "passed": passed,
        })

    # coût mensuel total de référence (calculé par Wallos, fidèle aux cycles)
    monthly = None
    try:
        mc = _get("/api/subscriptions/get_monthly_cost.php",
                  {"api_key": key, "month": str(m), "year": str(y)})
        monthly = _num(mc.get("localized_monthly_cost")
                       or mc.get("monthly_cost"))
        sym = mc.get("currency_symbol")
        if sym:
            currency = sym
    except Exception:
        monthly = None  # Wallos n'a pas répondu : on tombera sur le total des échéances

    # base du budget mensuel : Wallos si dispo, sinon somme des échéances du mois
    monthly_base = monthly if (monthly and monthly > 0) else round(due_this_month, 2)
    remaining = round(max(0.0, monthly_base - paid_this_month), 2)

    # tri : à venir d'abord (par date), puis déjà passés, puis hors mois
    def _rank(x):
        if x["in_month"] and not x["passed"]:
            return (0, x["next"])
        if x["passed"]:
            return (1, x["next"])
        return (2, x["next"] or "9999")
    items.sort(key=_rank)

    return {
        "ok": True,
        "items": items,
        "currency": currency,
        "monthly": round(monthly_base, 2),
        "paid": round(paid_this_month, 2),
        "remaining": remaining,
        "count": len(items),
        "month_label": today.strftime("%m/%Y"),
    }


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("wallos", __name__)

    @bp.route("/subs")
    def subs():
        try:
            return jsonify(_wallos(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("wallos")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    w = _wallos(sdk, cfg)
    if w.get("ok"):
        return True, (f"Wallos ✓ — {w['count']} abonnement(s), "
                      f"{w['monthly']} {w['currency']}/mois, "
                      f"reste {w['remaining']} {w['currency']}")
    return False, f"Wallos ✗ ({w.get('reason')})"
