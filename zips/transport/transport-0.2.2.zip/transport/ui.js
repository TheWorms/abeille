/* Transport — départs temps réel SNCF + itinéraires aller-retour (Phase 3,
   lot B, livraison 2). Favoris de gares via sdk.store (reprise one-shot de
   state.transFav). Réutilise les classes partagées tpfav/tpchip/tptabs/sy*
   (instagram/radio) et embarque son CSS propre. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.transport = (function () {
  let S = null, root = null, tile = null;
  let stop = null, results = null, tab = 'depart', from = null, to = null, journeys = null;
  let rt = false, backJourneys = null, selOut = null, selBack = null;
  let modesAll = ['TGV INOUI', 'OUIGO', 'TER', 'Intercités', 'BreizhGo', 'Car TER'], modes = [];
  let favs = null, favsLoaded = false;
  const MOIS_FR = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  const CSS = ".tpdep{display:flex;align-items:center;gap:13px;background:var(--tile);border:1px solid var(--border-soft);\n         border-radius:11px;padding:11px 14px;margin-bottom:7px}\n.tpin{min-width:74px;text-align:center;flex:none}\n.tpin b{display:block;font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.1}\n.tpin span{font-size:10px;color:var(--dim)}\n.tpline{font-size:10.5px;font-weight:700;padding:3px 8px;border-radius:6px;background:var(--accent-tint);color:var(--accent);flex:none}\n.tpdir{font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.tpsub{font-size:11px;color:var(--dim)}\n.tpstat{margin-left:auto;text-align:right;font-size:11.5px;flex:none}\n.tpstat.ok{color:var(--accent)}\n.tpstat.late{color:var(--warn);font-weight:600}\n.tpdis{background:rgba(240,180,41,.13);border:1px solid var(--warn);color:var(--warn);border-radius:9px;\n         padding:9px 12px;font-size:12px;margin-bottom:9px}\n.tpfav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:11px}\n.tpchip{display:inline-flex;align-items:center;gap:6px;font-size:12px;padding:6px 11px;border-radius:9px;\n          border:1px solid var(--border-soft);background:var(--tile);cursor:pointer}\n.tpchip.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n.tpchip .x{color:var(--faint);font-size:11px}\n.tptabs{display:flex;gap:6px;margin-bottom:11px}\n.tpform{display:grid;grid-template-columns:1fr 38px 1fr;gap:8px;margin-bottom:8px;align-items:center}\n.tpdates{display:grid;grid-template-columns:1fr 1fr 150px;gap:8px;margin-bottom:11px;align-items:stretch}\n.tpdates.rt{grid-template-rows:auto auto}\n.tpdates input{padding:11px 13px;border-radius:10px;border:1px solid var(--border-soft);\n        background:var(--tile);color:var(--text);font-size:14px;width:100%}\n.tpdates .lab{display:flex;align-items:center;font-size:11px;color:var(--faint);\n        text-transform:uppercase;letter-spacing:.4px;grid-column:1/3;margin-bottom:-4px}\n.tpsearch{grid-column:3;grid-row:1/-1;border-radius:10px;border:none;background:var(--accent);color:#fff;\n        font-size:15px;font-weight:600;cursor:pointer;min-height:48px}\n.tpsearch:active{filter:brightness(.94)}\n.tpform input,.tpform2 input{padding:11px 13px;border-radius:10px;border:1px solid var(--border-soft);\n        background:var(--tile);color:var(--text);font-size:14px;width:100%}\n.tpswap{width:38px;height:38px;border-radius:9px;border:1px solid var(--border-soft);background:var(--tile);\n          display:flex;align-items:center;justify-content:center;cursor:pointer}\n.tpsug{position:relative}\n.tpdrop{position:absolute;left:0;right:0;top:46px;z-index:40;background:var(--panel,#1b1f24);\n          border:1px solid var(--border-soft);border-radius:10px;overflow:hidden;max-height:190px;overflow-y:auto}\n.tpdrop div{padding:10px 12px;font-size:13px;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.tpdrop div b{font-weight:600}\n.tpdrop div:active{background:var(--accent-tint)}\n.tpjour{display:block;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;\n          padding:12px 15px;margin-bottom:9px;cursor:pointer}\n.tpjh{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}\n.tplegs{margin-top:8px;padding-top:8px;border-top:1px dashed var(--border-soft)}\n.tpjt{font-size:19px;font-weight:700;font-variant-numeric:tabular-nums;white-space:nowrap}\n.tpjd{font-size:11.5px;color:var(--dim)}\n.tpjbook{margin-left:auto;flex:none;padding:9px 16px;border-radius:9px;border:1px solid var(--accent);\n           background:var(--accent-tint);color:var(--accent);font-size:12.5px;font-weight:600;cursor:pointer;flex:none}\n.tpsec{display:flex;align-items:center;gap:9px;font-size:11.5px;color:var(--dim);margin-top:7px;padding-left:2px}\n.tpnote{font-size:10.5px;color:var(--faint);margin-top:8px;line-height:1.5}\n.tprt{display:flex;gap:8px;align-items:center;margin-bottom:10px}\n.tprt .sw{flex:none}\n.tprtl{font-size:12.5px;color:var(--dim)}\n.tphdr{display:flex;align-items:center;gap:9px;font-size:12px;font-weight:700;color:var(--accent);\n         text-transform:uppercase;letter-spacing:.5px;margin:12px 0 7px}\n.tphdr.back{color:var(--warn)}\n.tphdr i{flex:1;height:1px;background:var(--border-soft)}\n.tpjour.sel{border-color:var(--accent);background:var(--accent-tint)}\n.tpjour.back.sel{border-color:var(--warn);background:rgba(240,180,41,.12)}\n.tprecap{background:var(--tile);border:1px solid var(--accent);border-radius:12px;padding:13px 16px;margin-top:12px}\n.tprecl{display:flex;align-items:center;gap:10px;font-size:13px;margin-bottom:5px}\n.tprecl b{font-variant-numeric:tabular-nums}\n.tprecb{width:100%;margin-top:10px;padding:12px;border-radius:10px;border:none;background:var(--accent);\n          color:#fff;font-size:14px;font-weight:600;cursor:pointer}\n.tpmodes{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;align-items:center}\n.tpmode{font-size:11.5px;padding:6px 11px;border-radius:8px;border:1px solid var(--border-soft);\n          background:var(--tile);cursor:pointer;user-select:none}\n.tpmode.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n.tpmodel{font-size:11px;color:var(--faint);margin-right:2px}\n.tpleg{display:grid;grid-template-columns:96px 116px 1fr;align-items:center;gap:10px;\n         font-size:11.5px;padding:4px 0;color:var(--text)}\n.tpleg .h{font-family:var(--mono);font-size:11px;color:var(--dim);white-space:nowrap}\n.tpleg .m{font-size:10px;font-weight:700;padding:3px 7px;border-radius:5px;background:var(--accent-tint);\n            color:var(--accent);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.tpleg .g{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.tpleg.walk .m{background:var(--bg);color:var(--dim)}\n.tpleg.walk .g{color:var(--dim)}";
  function ensureCss() { let s = document.getElementById('tpUiCss'); if (!s) { s = document.createElement('style'); s.id = 'tpUiCss'; document.head.appendChild(s); } s.textContent = CSS; }

  async function loadFavs() {
    if (favsLoaded) return;
    const st = await S.store.load();
    favs = st.transFav || null;
    if (!favs && typeof window.state === 'object' && window.state && window.state.transFav) {
      favs = JSON.parse(JSON.stringify(window.state.transFav));
      await S.store.save({ transFav: favs });
    }
    favs = favs || []; favsLoaded = true;
  }
  function saveFavs() { S.store.save({ transFav: favs }); }

  const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  function modesBar() {
    return '<div class="tpmodes"><span class="tpmodel">Modes :</span>' +
      modesAll.map(m => '<span class="tpmode' + (modes.includes(m) ? ' on' : '') + '" data-mode="' + m + '">' + m + '</span>').join('') +
      (modes.length ? '<span class="tpmode" data-mode="__all">✕ tout afficher</span>' : '') + '</div>';
  }
  function modesWire(el, after) {
    el.querySelectorAll('[data-mode]').forEach(b => b.addEventListener('click', () => {
      const m = b.dataset.mode;
      if (m === '__all') modes = [];
      else if (modes.includes(m)) modes = modes.filter(x => x !== m);
      else modes.push(m);
      after();
    }));
  }
  const modesQS = () => modes.length ? ('&modes=' + encodeURIComponent(modes.join(','))) : '';
  function modesLearn(seen) { (seen || []).forEach(m => { if (m && !modesAll.includes(m)) modesAll.push(m); }); }
  function sug(inputId, dropId, onPick) {
    const inp = document.getElementById(inputId), drop = document.getElementById(dropId);
    if (!inp) return;
    let t = null;
    inp.addEventListener('input', () => {
      clearTimeout(t);
      const v = (inp.value || '').trim();
      if (v.length < 2) { drop.innerHTML = ''; return; }
      t = setTimeout(async () => {
        try {
          const r = await S.api('/places?q=' + encodeURIComponent(v)); const j = await r.json();
          if (!j.ok || !j.places.length) { drop.innerHTML = ''; return; }
          drop.innerHTML = j.places.map(p => '<div data-id="' + p.id + '" data-name="' + p.name + '">' +
            (p.train ? '🚆' : '🚏') + ' <b>' + p.name + '</b>' + (p.city && p.city !== p.name ? ' · ' + p.city : '') +
            ((p.modes && p.modes.length) ? '<span style="color:var(--faint);font-size:10.5px"> — ' + p.modes.join(', ') + '</span>' : '') +
            '</div>').join('');
          drop.querySelectorAll('[data-id]').forEach(d => d.addEventListener('click', () => {
            inp.value = d.dataset.name; drop.innerHTML = ''; onPick({ id: d.dataset.id, name: d.dataset.name }); }));
        } catch (e) { drop.innerHTML = ''; }
      }, 350);
    });
  }
  function sncfQuery(j, f, t2, dateStr) {
    const d = new Date(dateStr + 'T00:00:00');
    const quand = isNaN(d) ? '' : (' le ' + d.getDate() + ' ' + MOIS_FR[d.getMonth()]);
    const heure = j && j.departure ? (' à ' + j.departure.replace(':', 'h')) : '';
    return [f || '', t2 || ''].filter(Boolean).join(' ') + quand + heure;
  }
  async function book(j, f, t2, dateStr) {
    const q = sncfQuery(j, f, t2, dateStr);
    let copie = false;
    try { await navigator.clipboard.writeText(q); copie = true; }
    catch (e) {
      try { const ta = document.createElement('textarea'); ta.value = q; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); copie = document.execCommand('copy'); ta.remove(); } catch (e2) {}
    }
    S.toast(copie ? ('Copié : « ' + q + ' » — colle-le dans la recherche') : ('Recherche : ' + q));
    S.openService('https://www.sncf-connect.com/', 'SNCF Connect');
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    await loadFavs();
    let h = '<div class="tptabs"><span class="wch' + (tab === 'depart' ? ' on' : '') + '" data-tpt="depart">Prochains départs</span>' +
      '<span class="wch' + (tab === 'itin' ? ' on' : '') + '" data-tpt="itin">Itinéraire</span></div>';
    if (tab === 'depart') {
      if (!stop && favs.length) stop = favs[0];
      h += '<div class="koadd"><input id="tpQ" placeholder="Rechercher une gare…" autocomplete="off">' +
        '<button id="tpGo">Chercher</button></div><div class="kotoast" id="tpErr"></div>';
      if (favs.length) h += '<div class="tpfav">' + favs.map(f => '<span class="tpchip' + (stop && stop.id === f.id ? ' on' : '') + '" data-fav="' + f.id + '">' +
        '🚉 ' + f.name + '<span class="x" data-unfav="' + f.id + '">✕</span></span>').join('') + '</div>';
      if (results) h += results.map(p => '<div class="syrow"><span style="font-size:18px">' + (p.train ? '🚆' : '🚏') + '</span>' +
        '<span><span class="syn">' + p.name + '</span><span class="sysub">' +
        [p.city && p.city !== p.name ? p.city : '', (p.modes || []).join(', ')].filter(Boolean).join(' · ') + '</span></span>' +
        '<span class="syact"><span class="sybtn" data-add="' + p.id + '" data-name="' + p.name + '">⭐ Favori</span>' +
        '<span class="sybtn" data-pick="' + p.id + '" data-name="' + p.name + '">Départs</span></span></div>').join('');
      h += modesBar() + '<div id="tpDeps"></div>';
    } else {
      const today = ymd(new Date());
      const hh = String(new Date().getHours()).padStart(2, '0') + ':' + String(new Date().getMinutes()).padStart(2, '0');
      h += '<div class="tpform"><span class="tpsug"><input id="tpF" placeholder="Gare de départ" value="' + ((from && from.name) || '') + '" autocomplete="off"><div class="tpdrop" id="tpFD"></div></span>' +
        '<span class="tpswap" id="tpSwap">⇄</span>' +
        '<span class="tpsug"><input id="tpT" placeholder="Gare d\'arrivée" value="' + ((to && to.name) || '') + '" autocomplete="off"><div class="tpdrop" id="tpTD"></div></span></div>';
      h += '<div class="tprt"><div class="sw' + (rt ? ' on' : '') + '" id="tpRTsw"></div><span class="tprtl">Aller-retour</span></div>';
      h += '<div class="tpdates' + (rt ? ' rt' : '') + '">' +
        (rt ? '<span class="lab">Aller</span>' : '') +
        '<input id="tpD" type="date" value="' + today + '"><input id="tpH" type="time" value="' + hh + '">' +
        '<button class="tpsearch" id="tpSearch">Rechercher</button>' +
        (rt ? ('<span class="lab">Retour</span><input id="tpD2" type="date" value="' + today + '">' +
          '<input id="tpH2" type="time" value="18:00">') : '') +
        '</div>';
      h += modesBar() + '<div class="kotoast" id="tpErr"></div><div id="tpJour"></div>';
    }
    el.innerHTML = h;
    el.querySelectorAll('[data-tpt]').forEach(t => t.addEventListener('click', () => { tab = t.dataset.tpt; render(el, S, tile); }));
    const err = document.getElementById('tpErr');
    if (tab === 'depart') {
      const q = document.getElementById('tpQ');
      const search = async () => {
        const v = (q.value || '').trim(); if (v.length < 2) { err.textContent = 'Saisis au moins 2 caractères'; return; }
        err.textContent = ''; S.vk.close();
        try { const r = await S.api('/places?q=' + encodeURIComponent(v)); const j = await r.json();
          if (j.ok) { results = j.places; render(el, S, tile); } else err.textContent = j.reason || 'Recherche impossible'; }
        catch (e) { err.textContent = 'Serveur injoignable'; }
      };
      document.getElementById('tpGo').addEventListener('click', search);
      q.addEventListener('keydown', e => { if (e.key === 'Enter') search(); });
      el.querySelectorAll('[data-fav]').forEach(c => c.addEventListener('click', ev => {
        if (ev.target.dataset.unfav) return;
        stop = favs.find(f => f.id === c.dataset.fav); results = null; render(el, S, tile); }));
      el.querySelectorAll('[data-unfav]').forEach(x => x.addEventListener('click', ev => {
        ev.stopPropagation();
        favs = favs.filter(f => f.id !== x.dataset.unfav);
        if (stop && stop.id === x.dataset.unfav) stop = null; saveFavs(); render(el, S, tile); }));
      el.querySelectorAll('[data-add]').forEach(b => b.addEventListener('click', ev => {
        ev.stopPropagation();
        if (!favs.some(f => f.id === b.dataset.add)) favs.push({ id: b.dataset.add, name: b.dataset.name });
        saveFavs(); render(el, S, tile); }));
      el.querySelectorAll('[data-pick]').forEach(b => b.addEventListener('click', () => {
        stop = { id: b.dataset.pick, name: b.dataset.name || '' }; results = null; render(el, S, tile); }));
      modesWire(el, () => render(el, S, tile));
      if (stop) renderDepartures();
    } else {
      sug('tpF', 'tpFD', p => { from = p; });
      sug('tpT', 'tpTD', p => { to = p; });
      document.getElementById('tpSwap').addEventListener('click', () => { const t = from; from = to; to = t; render(el, S, tile); });
      modesWire(el, () => render(el, S, tile));
      const rtsw = document.getElementById('tpRTsw');
      if (rtsw) rtsw.addEventListener('click', () => { rt = !rt; backJourneys = null; selBack = null; render(el, S, tile); });
      document.getElementById('tpSearch').addEventListener('click', async () => {
        err.textContent = '';
        if (!from || !to) { err.textContent = 'Choisis les deux gares dans la liste proposée'; return; }
        const dte = document.getElementById('tpD').value, hr = document.getElementById('tpH').value;
        const when = dte.replace(/-/g, '') + 'T' + hr.replace(':', '') + '00';
        let back = '', dte2 = '';
        if (rt) {
          dte2 = document.getElementById('tpD2').value; const hr2 = document.getElementById('tpH2').value;
          if (!dte2 || !hr2) { err.textContent = 'Renseigne la date et l\'heure du retour'; return; }
          if (dte2 + 'T' + hr2 < dte + 'T' + hr) { err.textContent = 'Le retour doit être après l\'aller'; return; }
          back = dte2.replace(/-/g, '') + 'T' + hr2.replace(':', '') + '00';
        }
        S.vk.close();
        const box = document.getElementById('tpJour');
        box.innerHTML = '<div class="stub"><div class="t2">Recherche des itinéraires…</div></div>';
        try {
          const url = (rt
            ? ('/roundtrip?from=' + encodeURIComponent(from.id) + '&to=' + encodeURIComponent(to.id) + '&outbound=' + when + '&inbound=' + back)
            : ('/journeys?from=' + encodeURIComponent(from.id) + '&to=' + encodeURIComponent(to.id) + '&datetime=' + when)) + modesQS();
          const r = await S.api(url); const j = await r.json();
          if (j.ok) modesLearn(j.modes_seen);
          if (!j.ok) { box.innerHTML = '<div class="stub"><div class="big">🚆</div><div class="t2">' + (j.reason || '') + '</div></div>'; return; }
          if (rt) { journeys = j.outbound; backJourneys = j.inbound; if (j.inbound_error) err.textContent = 'Retour indisponible — ' + j.inbound_error; }
          else { journeys = j.journeys; backJourneys = null; }
          selOut = 0; selBack = (backJourneys && backJourneys.length) ? 0 : null;
          renderJourneys(dte, dte2);
        } catch (e) { box.innerHTML = '<div class="stub"><div class="t2">Serveur injoignable</div></div>'; }
      });
      if (journeys) renderJourneys(document.getElementById('tpD').value, rt && document.getElementById('tpD2') ? document.getElementById('tpD2').value : '');
    }
  }
  async function renderDepartures() {
    const box = document.getElementById('tpDeps'); if (!box || !stop) return;
    box.innerHTML = '<div class="stub"><div class="t2">Chargement des départs…</div></div>';
    let d = null;
    try { const r = await S.api('/departures?stop=' + encodeURIComponent(stop.id) + modesQS()); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'serveur injoignable' }; }
    if (d.ok) modesLearn(d.modes_seen);
    if (!d.ok) {
      box.innerHTML = '<div class="stub"><div class="big">🚆</div><div class="t1">' + (stop.name || 'Transport') + '</div>' +
        '<div class="t2">' + (d.reason || '') + '<br>Crée un jeton gratuit sur l\'API SNCF et renseigne-le dans \u2699.</div></div>';
      return;
    }
    let h = '<div class="wsec" style="padding-left:0">Prochains départs · ' + (stop.name || '') +
      ' <span class="wch" id="tpRef" style="margin-left:8px">↻</span></div>';
    h += (d.disruptions || []).map(x => '<div class="tpdis">⚠️ ' + (x.severity ? x.severity + ' — ' : '') + x.text + '</div>').join('');
    if (!d.departures.length) h += '<div class="stub"><div class="t2">' + (modes.length ? 'Aucun départ pour les modes sélectionnés' : 'Aucun départ prévu prochainement') + '</div></div>';
    else h += d.departures.map(x => {
      const late = x.delay > 0;
      return '<div class="tpdep"><span class="tpin"><b>' + (x.in_min != null && x.in_min >= 0 ? x.in_min : '—') + '</b><span>min</span></span>' +
        (x.line ? '<span class="tpline"' + (x.color ? ' style="background:' + x.color + '22;color:' + x.color + '"' : '') + '>' + x.line + '</span>' : '') +
        '<span style="min-width:0"><span class="tpdir">→ ' + (x.direction || '—') + '</span>' +
        '<span class="tpsub">' + [x.mode, x.network].filter(Boolean).join(' · ') + '</span></span>' +
        '<span class="tpstat ' + (late ? 'late' : 'ok') + '"><b>' + x.time + '</b><br>' +
        (late ? ('retard ' + x.delay + ' min') : 'à l\'heure') + '</span></div>'; }).join('');
    h += '<div class="wsrc">Données temps réel · API SNCF (TGV, TER, OUIGO, cars BreizhGo)</div>';
    box.innerHTML = h;
    const rf = document.getElementById('tpRef'); if (rf) rf.addEventListener('click', () => renderDepartures());
  }
  function legs(j) {
    return '<div class="tplegs">' + j.sections.map(sx => {
      if (sx.type === 'public_transport')
        return '<div class="tpleg"><span class="h">' + sx.dep + ' → ' + sx.arr + '</span>' +
          '<span class="m"' + (sx.color ? ' style="background:' + sx.color + '22;color:' + sx.color + '"' : '') + '>' +
          (sx.mode || '') + (sx.line ? ' ' + sx.line : '') + '</span>' +
          '<span class="g">' + sx.from + ' <b style="color:var(--dim)">→</b> ' + sx.to + '</span></div>';
      return '<div class="tpleg walk"><span class="h"></span>' +
        '<span class="m">' + (sx.type === 'transfer' ? '🚶 corresp.' : '⏳ attente') + '</span>' +
        '<span class="g">' + sx.minutes + ' min' + (sx.from ? ' à ' + sx.from : '') + '</span></div>';
    }).join('') + '</div>';
  }
  function jourCard(j, i, back, sel) {
    const dur = j.duration >= 60 ? (Math.floor(j.duration / 60) + ' h ' + String(j.duration % 60).padStart(2, '0')) : (j.duration + ' min');
    return '<div class="tpjour' + (back ? ' back' : '') + (sel ? ' sel' : '') + '" data-j="' + i + '" data-back="' + (back ? 1 : 0) + '"><div class="tpjh">' +
      '<span class="tpjt">' + j.departure + ' → ' + j.arrival + '</span>' +
      '<span class="tpjd">' + dur + ' · ' + (j.changes ? j.changes + ' correspondance' + (j.changes > 1 ? 's' : '') : 'direct') + '</span>' +
      (sel ? '<span class="tpjbook" style="pointer-events:none">✓ choisi</span>' : '') + '</div>' +
      legs(j) + '</div>';
  }
  const fmtDur = m => m >= 60 ? (Math.floor(m / 60) + ' h ' + String(m % 60).padStart(2, '0')) : (m + ' min');
  const fmtDate = d => { const x = new Date(d + 'T00:00:00'); return isNaN(x) ? '' : (x.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })); };
  function renderJourneys(dateStr, dateBack) {
    const box = document.getElementById('tpJour'); if (!box) return;
    if (!journeys || !journeys.length) {
      box.innerHTML = '<div class="stub"><div class="big">🚆</div><div class="t2">' +
        (modes.length ? ('Aucun itinéraire n\'utilise uniquement : ' + modes.join(', ') + '. Élargis les modes.') : 'Aucun itinéraire trouvé') + '</div></div>'; return;
    }
    let h;
    if (rt) {
      h = '<div class="tphdr">🚆 Aller<i></i></div>';
      h += journeys.map((j, i) => jourCard(j, i, false, selOut === i)).join('');
      if (backJourneys && backJourneys.length) {
        h += '<div class="tphdr back">↩ Retour<i></i></div>';
        h += backJourneys.map((j, i) => jourCard(j, i, true, selBack === i)).join('');
      }
      if (selOut != null && selBack != null && backJourneys && backJourneys[selBack]) {
        h += '<div class="tprecap"><div class="tprecl">✅ Aller et retour sélectionnés</div>' +
          '<button class="tprecb" id="tpRecap">Voir le récapitulatif</button></div>';
      }
    } else {
      h = journeys.map((j, i) => jourCard(j, i, false, false).replace('data-j="' + i + '"', 'data-book="' + i + '"')).join('');
    }
    h += '<div class="tpnote">SNCF Connect n\'accepte pas de lien pré-rempli. Le bouton « Réserver » <b>copie ton trajet</b> ' +
      '(ex. « Nantes Paris le 10 juillet à 8h12 ») et ouvre le site : il ne reste qu\'à coller dans la barre de recherche.</div>';
    box.innerHTML = h;
    box.querySelectorAll('[data-j]').forEach(c => c.addEventListener('click', () => {
      const i = parseInt(c.dataset.j);
      if (c.dataset.back === '1') selBack = i; else selOut = i;
      renderJourneys(dateStr, dateBack); }));
    box.querySelectorAll('[data-book]').forEach(b => b.addEventListener('click', ev => {
      ev.stopPropagation();
      book(journeys[parseInt(b.dataset.book)], from && from.name, to && to.name, dateStr); }));
    const rb = document.getElementById('tpRecap');
    if (rb) rb.addEventListener('click', () => openRecap(dateStr, dateBack));
  }
  function openRecap(dateStr, dateBack) {
    const o = journeys[selOut], r = backJourneys[selBack];
    if (!o || !r) return;
    const tot = o.duration + r.duration;
    const sh = document.createElement('div'); sh.className = 'tprecsheet';
    sh.innerHTML = '<div class="tprecbox">' +
      '<div class="tprech">' + (from ? from.name : '') + ' ⇄ ' + (to ? to.name : '') + '</div>' +
      '<div class="tprecs">Récapitulatif de ton aller-retour</div>' +
      '<div class="tprecsec out"><div class="tprect"><b>' + o.departure + ' → ' + o.arrival + '</b>' +
      '<span>' + fmtDate(dateStr) + ' · ' + fmtDur(o.duration) + ' · ' +
      (o.changes ? o.changes + ' correspondance' + (o.changes > 1 ? 's' : '') : 'direct') + '</span></div>' +
      legs(o) + '</div>' +
      '<div class="tprecsec back"><div class="tprect"><b>' + r.departure + ' → ' + r.arrival + '</b>' +
      '<span>' + fmtDate(dateBack) + ' · ' + fmtDur(r.duration) + ' · ' +
      (r.changes ? r.changes + ' correspondance' + (r.changes > 1 ? 's' : '') : 'direct') + '</span></div>' +
      legs(r) + '</div>' +
      '<div class="tprectot"><span>Temps de trajet cumulé</span><b>' + fmtDur(tot) + '</b></div>' +
      '<button class="tprecb" id="tpBookNow">Réserver sur SNCF Connect ↗</button>' +
      '<button class="catclose" id="tpRecClose">Fermer</button></div>';
    document.body.appendChild(sh);
    const close = () => sh.remove();
    sh.querySelector('#tpRecClose').addEventListener('click', close);
    sh.addEventListener('click', e => { if (e.target === sh) close(); });
    sh.querySelector('#tpBookNow').addEventListener('click', () => { close(); bookRT(dateStr, dateBack); });
  }
  async function bookRT(dateStr, dateBack) {
    const o = journeys[selOut], r = backJourneys[selBack];
    const q = sncfQuery(o, from && from.name, to && to.name, dateStr) +
      ' retour le ' + new Date(dateBack + 'T00:00:00').getDate() + ' ' + MOIS_FR[new Date(dateBack + 'T00:00:00').getMonth()] +
      ' à ' + r.departure.replace(':', 'h');
    let copie = false;
    try { await navigator.clipboard.writeText(q); copie = true; } catch (e) {}
    S.toast(copie ? ('Copié : « ' + q + ' »') : ('Recherche : ' + q));
    S.openService('https://www.sncf-connect.com/', 'SNCF Connect');
  }
  function unmount() { document.querySelectorAll('.tprecsheet').forEach(x => x.remove()); }
  return { render, unmount };
})();
