"""Addon « transport » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/transport/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : API compatible Navitia (SNCF api.sncf.com ou navitia.io, auth par
jeton en basic-auth). Quatre routes : /places (autocomplétion), /departures
(prochains départs), /journeys (itinéraires), /roundtrip (aller-retour en
parallèle). Le helper `_ck` (clé de cache incluant le secret) est dupliqué
ici ; le noyau garde le sien, partagé par d'autres addons.
"""
import re
import hashlib
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor


def _ck(*parts):
    """Clé de cache incluant le secret. (Copie locale du helper noyau.)"""
    return hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()[:24]


def _nav_cfg(cfg):
    """API compatible Navitia : SNCF (api.sncf.com) ou navitia.io."""
    url = (cfg.get("url") or "https://api.sncf.com/v1").rstrip("/")
    token = (cfg.get("token") or "").strip()
    cov = (cfg.get("coverage") or "sncf").strip()
    return url, token, cov


def _nav_get(sdk, cfg, path, params=None, timeout=12):
    url, token, cov = _nav_cfg(cfg)
    if not token:
        raise RuntimeError("jeton manquant (⚙ Transport)")
    r = sdk.requests.get(f"{url}{path}", params=params or {},
                         auth=(token, ""), timeout=timeout)
    if r.status_code == 401:
        raise RuntimeError("jeton refusé (401)")
    if r.status_code == 404:
        raise RuntimeError("ressource introuvable (arrêt inconnu ?)")
    if r.status_code == 429:
        raise RuntimeError("quota dépassé (429)")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.json()


def _trans_places(sdk, cfg, q):
    """Autocomplétion : gares et arrêts correspondant à la saisie."""
    _, _, cov = _nav_cfg(cfg)
    ck = _ck("pl", cov, q)
    c = sdk.cache_get(ck, 600)
    if c is not None:
        return c
    try:
        j = _nav_get(sdk, cfg, f"/coverage/{cov}/places",
                     {"q": q, "type[]": ["stop_area"], "count": 10, "depth": 2})
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    places = []
    for p in j.get("places", []):
        sa = p.get("stop_area") or {}
        # la commune porte le niveau 8 ; les niveaux inférieurs sont des quartiers
        admins = sa.get("administrative_regions") or []
        commune = next((a.get("name") for a in admins if a.get("level") == 8), "")
        if not commune and admins:
            commune = admins[-1].get("name", "")
        modes = [m.get("name") for m in (sa.get("physical_modes") or [])]
        train = any("rain" in (m or "") or "TER" in (m or "") for m in modes)
        places.append({"id": sa.get("id") or p.get("id"),
                       "name": p.get("name", "?"),
                       "city": commune,
                       "modes": modes[:3],
                       "train": train})
    # gares ferroviaires d'abord, puis le reste
    places.sort(key=lambda x: (not x["train"],))
    return sdk.cache_set(ck, {"ok": True, "places": places})


def _trans_departures(sdk, cfg, stop_id, count=10, modes=None):
    """Prochains départs (théoriques + temps réel) d'un arrêt."""
    _, _, cov = _nav_cfg(cfg)
    ck = _ck("dep", cov, stop_id, count, ",".join(sorted(modes or [])))
    c = sdk.cache_get(ck, 45)
    if c is not None:
        return c
    try:
        j = _nav_get(sdk, cfg, f"/coverage/{cov}/stop_areas/{stop_id}/departures",
                     {"count": count * 3 if modes else count,
                      "data_freshness": "realtime"})
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}

    def _pt(s2):
        try:
            return datetime.strptime(s2, "%Y%m%dT%H%M%S")
        except (ValueError, TypeError):
            return None

    deps, now, seen = [], datetime.now(), set()
    for d in j.get("departures", []):
        st = d.get("stop_date_time") or {}
        di = d.get("display_informations") or {}
        base = _pt(st.get("base_departure_date_time"))
        real = _pt(st.get("departure_date_time"))
        delay = int((real - base).total_seconds() // 60) if (base and real) else 0
        mins = int((real - now).total_seconds() // 60) if real else None
        mode_i = (di.get("commercial_mode") or di.get("physical_mode") or "")
        seen.add(mode_i)
        if modes and mode_i not in modes:
            continue
        deps.append({
            "time": real.strftime("%H:%M") if real else "—",
            "base": base.strftime("%H:%M") if base else "",
            "in_min": mins,
            "delay": delay,
            "direction": di.get("direction", ""),
            "line": (di.get("trip_short_name") or di.get("headsign")
                     or di.get("code") or ""),
            "network": di.get("network", ""),
            "mode": (di.get("commercial_mode") or di.get("physical_mode") or ""),
            "color": "#" + di.get("color", "") if di.get("color") else "",
        })
    disruptions = []
    for d in j.get("disruptions", []):
        for m in d.get("messages", []):
            txt = re.sub(r"<[^>]+>", "", m.get("text", "")).strip()
            if txt:
                disruptions.append({"severity": (d.get("severity") or {}).get("name", ""),
                                    "text": txt[:180]})
                break
    res = {"ok": True, "departures": deps[:count],
           "disruptions": disruptions[:3], "modes_seen": sorted(x for x in seen if x)}
    return sdk.cache_set(ck, res)


def _trans_journeys(sdk, cfg, frm, to, when=None, count=5, modes=None):
    """Itinéraires entre deux arrêts, avec correspondances et perturbations."""
    _, _, cov = _nav_cfg(cfg)
    ck = _ck("jr", cov, frm, to, when or "", count, ",".join(sorted(modes or [])))
    c = sdk.cache_get(ck, 60)
    if c is not None:
        return c
    # on demande plus d'itinéraires quand un filtre est actif, pour en garder assez après tri
    params = {"from": frm, "to": to, "count": (count * 3 if modes else count),
              "data_freshness": "realtime"}
    if when:
        params["datetime"] = when          # format ISO 20260709T143000
    try:
        j = _nav_get(sdk, cfg, f"/coverage/{cov}/journeys", params, timeout=20)
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}

    def _pt(x):
        try:
            return datetime.strptime(x, "%Y%m%dT%H%M%S")
        except (ValueError, TypeError):
            return None

    out, seen_modes = [], set()
    for jr2 in j.get("journeys", []):
        dep, arr = _pt(jr2.get("departure_date_time")), _pt(jr2.get("arrival_date_time"))
        secs = []
        for sec in jr2.get("sections", []):
            if sec.get("type") not in ("public_transport", "transfer", "waiting"):
                continue
            di = sec.get("display_informations") or {}
            s_dep, s_arr = _pt(sec.get("departure_date_time")), _pt(sec.get("arrival_date_time"))
            secs.append({
                "type": sec.get("type"),
                "mode": di.get("commercial_mode") or "",
                # numéro du train : surtout PAS `label`, qui est le nom de la ligne
                # (« Saint-Nazaire - Paris - Montparnasse »), pas le trajet demandé.
                "line": (di.get("trip_short_name") or di.get("headsign")
                         or di.get("code") or ""),
                "direction": di.get("direction") or "",
                "from": ((sec.get("from") or {}).get("name") or ""),
                "to": ((sec.get("to") or {}).get("name") or ""),
                "dep": s_dep.strftime("%H:%M") if s_dep else "",
                "arr": s_arr.strftime("%H:%M") if s_arr else "",
                "minutes": int((sec.get("duration") or 0) // 60),
                "color": "#" + di.get("color", "") if di.get("color") else "",
            })
        nb_pt = sum(1 for x in secs if x["type"] == "public_transport")
        jmodes = {x["mode"] for x in secs if x["type"] == "public_transport" and x["mode"]}
        seen_modes |= jmodes
        if modes and jmodes and not jmodes.issubset(set(modes)):
            continue          # un segment emprunte un mode non désiré
        out.append({
            "departure": dep.strftime("%H:%M") if dep else "",
            "arrival": arr.strftime("%H:%M") if arr else "",
            "date": dep.strftime("%Y-%m-%d") if dep else "",
            "duration": int((jr2.get("duration") or 0) // 60),
            "changes": max(0, nb_pt - 1),
            "status": jr2.get("status") or "",
            "sections": secs,
        })
    res = {"ok": True, "journeys": out[:count],
           "modes_seen": sorted(x for x in seen_modes if x)}
    return sdk.cache_set(ck, res)


def register(sdk):
    from flask import Blueprint, jsonify, request
    bp = Blueprint("transport", __name__)

    @bp.route("/journeys")
    def journeys():
        frm = (request.args.get("from") or "").strip()[:120]
        to = (request.args.get("to") or "").strip()[:120]
        when = (request.args.get("datetime") or "").strip()[:20]
        if not (frm and to):
            return jsonify({"ok": False, "reason": "gare de départ et d'arrivée requises"}), 400
        if when and not re.fullmatch(r"\d{8}T\d{6}", when):
            return jsonify({"ok": False, "reason": "date invalide"}), 400
        modes = [m for m in (request.args.get("modes") or "").split(",") if m][:8]
        return jsonify(_trans_journeys(sdk, sdk.config(), frm, to,
                                       when or None, modes=modes or None))

    @bp.route("/roundtrip")
    def roundtrip():
        frm = (request.args.get("from") or "").strip()[:120]
        to = (request.args.get("to") or "").strip()[:120]
        out_dt = (request.args.get("outbound") or "").strip()[:20]
        back_dt = (request.args.get("inbound") or "").strip()[:20]
        if not (frm and to):
            return jsonify({"ok": False, "reason": "gares requises"}), 400
        for d in (out_dt, back_dt):
            if d and not re.fullmatch(r"\d{8}T\d{6}", d):
                return jsonify({"ok": False, "reason": "date invalide"}), 400
        cfg = sdk.config()
        modes = [m for m in (request.args.get("modes") or "").split(",") if m][:8] or None

        with ThreadPoolExecutor(max_workers=2) as pool:
            f1 = pool.submit(_trans_journeys, sdk, cfg, frm, to, out_dt or None, 5, modes)
            f2 = (pool.submit(_trans_journeys, sdk, cfg, to, frm, back_dt or None, 5, modes)
                  if back_dt else None)
            aller = f1.result()
            retour = f2.result() if f2 else {"ok": True, "journeys": []}
        if not aller.get("ok"):
            return jsonify({"ok": False, "reason": aller.get("reason")})
        return jsonify({"ok": True,
                        "outbound": aller.get("journeys", []),
                        "inbound": retour.get("journeys", []) if retour.get("ok") else [],
                        "modes_seen": sorted(set(aller.get("modes_seen", []))
                                             | set(retour.get("modes_seen", []) if retour.get("ok") else [])),
                        "inbound_error": None if retour.get("ok") else retour.get("reason")})

    @bp.route("/places")
    def places():
        q = (request.args.get("q") or "").strip()[:60]
        if len(q) < 2:
            return jsonify({"ok": False, "reason": "saisis au moins 2 caractères"})
        return jsonify(_trans_places(sdk, sdk.config(), q))

    @bp.route("/departures")
    def departures():
        stop = (request.args.get("stop") or "").strip()[:120]
        if not stop:
            return jsonify({"ok": False, "reason": "arrêt manquant"}), 400
        modes = [m for m in (request.args.get("modes") or "").split(",") if m][:8]
        return jsonify(_trans_departures(sdk, sdk.config(), stop, modes=modes or None))

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    try:
        _, _, cov = _nav_cfg(cfg)
        j = _nav_get(sdk, cfg, f"/coverage/{cov}")
        regs = j.get("regions") or []
        nom = regs[0].get("id", cov) if regs else cov
        return True, f"Navitia ✓ — couverture « {nom} »"
    except RuntimeError as e:
        return False, f"Transport ✗ ({e})"
    except sdk.requests.exceptions.RequestException as e:
        return False, f"Transport ✗ ({type(e).__name__})"
