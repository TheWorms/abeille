"""Addon « livres » — Kavita (Hérisson) : stats, en cours, nouveautés, couvertures.

    register(sdk) -> flask.Blueprint   (routes sous /addons/livres/api)
    test(sdk, cfg) -> (bool, str)

Config : url (http://host:5000) + apikey (Compte → Clé API).
Kavita : auth en 2 temps (clé API -> JWT via /api/Plugin/authenticate), puis
Bearer JWT. Le JWT est mis en cache (~50 min). Couvertures servies par proxy
(auth requise). Séries : on-deck (en cours) + recently-added (nouveautés).
"""


def _base(cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    return url, (cfg.get("apikey") or "").strip()


def _jwt(sdk, url, apikey):
    """Échange clé API -> JWT (caché ~50 min)."""
    ck = f"livres:jwt:{url}"
    tok = sdk.cache_get(ck, 3000)
    if tok:
        return tok
    try:
        r = sdk.requests.post(
            f"{url}/api/Plugin/authenticate",
            params={"apiKey": apikey, "pluginName": "panda"},
            timeout=10, verify=False)
        if not r.ok:
            return None
        tok = r.json().get("token")
    except (sdk.requests.exceptions.RequestException, ValueError):
        return None
    if tok:
        sdk.cache_set(ck, tok)
    return tok


def _hdr(jwt):
    return {"Authorization": f"Bearer {jwt}", "Content-Type": "application/json"}


def _shape_series(s):
    pages = s.get("pages") or 0
    read = s.get("pagesRead") or 0
    pct = round(read / pages * 100) if pages else 0
    return {
        "id": s.get("id"),
        "name": s.get("name") or "Sans titre",
        "pages": pages,
        "pagesRead": read,
        "percent": pct,
        "libraryId": s.get("libraryId"),
    }


def _overview(sdk, cfg):
    url, apikey = _base(cfg)
    if not (url and apikey):
        return {"ok": False, "reason": "URL/clé non configurées"}
    ck = f"livres:{url}"
    c = sdk.cache_get(ck, 90)
    if c is not None:
        return c

    jwt = _jwt(sdk, url, apikey)
    if not jwt:
        return {"ok": False, "reason": "clé API refusée — Kavita → Compte → Clé API"}
    h = _hdr(jwt)

    def get(path):
        try:
            r = sdk.requests.get(f"{url}{path}", headers=h, timeout=10, verify=False)
            return r.json() if r.ok else None
        except (sdk.requests.exceptions.RequestException, ValueError):
            return None

    def post(path, body):
        try:
            r = sdk.requests.post(f"{url}{path}", headers=h, json=body,
                                  timeout=10, verify=False)
            return r.json() if r.ok else None
        except (sdk.requests.exceptions.RequestException, ValueError):
            return None

    libs_raw = get("/api/Library/libraries") or []
    libraries = [{"id": l.get("id"), "name": l.get("name"), "type": l.get("type")}
                 for l in libs_raw if isinstance(l, dict)]

    ondeck_raw = post("/api/Series/on-deck", {"pageSize": 20}) or []
    if isinstance(ondeck_raw, dict):
        ondeck_raw = ondeck_raw.get("results", [])
    reading = [_shape_series(s) for s in ondeck_raw if isinstance(s, dict)]

    recent_raw = post("/api/Series/recently-added-v2",
                      {"pageSize": 20}) or []
    if isinstance(recent_raw, dict):
        recent_raw = recent_raw.get("results", [])
    if not recent_raw:  # repli sur l'ancien endpoint
        recent_raw = post("/api/Series/recently-added", {"pageSize": 20}) or []
        if isinstance(recent_raw, dict):
            recent_raw = recent_raw.get("results", [])
    recent = [_shape_series(s) for s in recent_raw if isinstance(s, dict)]

    out = {
        "ok": True,
        "libraries": libraries,
        "reading": reading,
        "recent": recent,
        "lib_count": len(libraries),
        "reading_count": len(reading),
    }
    return sdk.cache_set(ck, out)


def _search(sdk, cfg, q):
    url, apikey = _base(cfg)
    if not (url and apikey):
        return {"ok": False, "reason": "non configuré"}
    jwt = _jwt(sdk, url, apikey)
    if not jwt:
        return {"ok": False, "reason": "clé API refusée"}
    try:
        r = sdk.requests.get(f"{url}/api/Search/search",
                             headers=_hdr(jwt), params={"queryString": q},
                             timeout=10, verify=False)
        if not r.ok:
            return {"ok": False, "reason": f"HTTP {r.status_code}"}
        res = r.json()
    except (sdk.requests.exceptions.RequestException, ValueError):
        return {"ok": False, "reason": "recherche indisponible"}
    series = []
    for s in (res.get("series") or []):
        series.append({"id": s.get("seriesId") or s.get("id"),
                       "name": s.get("name") or s.get("title") or "Sans titre",
                       "libraryId": s.get("libraryId")})
    return {"ok": True, "count": len(series), "series": series}


def register(sdk):
    from flask import Blueprint, Response, jsonify, request
    bp = Blueprint("livres", __name__)

    @bp.route("/overview")
    def overview():
        try:
            return jsonify(_overview(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("livres overview")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/search")
    def search():
        try:
            q = (request.args.get("q") or "").strip()
            if not q:
                return jsonify({"ok": True, "count": 0, "series": []})
            return jsonify(_search(sdk, sdk.config(), q))
        except Exception as e:
            sdk.log.exception("livres search")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    @bp.route("/cover")
    def cover():
        cfg = sdk.config()
        url, apikey = _base(cfg)
        sid = (request.args.get("series") or "").strip()
        if not (url and apikey and sid.isdigit()):
            return Response("", status=400)
        jwt = _jwt(sdk, url, apikey)
        if not jwt:
            return Response("", status=401)
        try:
            r = sdk.requests.get(f"{url}/api/Image/series-cover",
                                 headers={"Authorization": f"Bearer {jwt}"},
                                 params={"seriesId": sid, "apiKey": apikey},
                                 timeout=15, verify=False)
            if r.status_code != 200:
                return Response("", status=r.status_code)
            ct = r.headers.get("Content-Type", "image/jpeg")
            return Response(r.content, mimetype=ct,
                            headers={"Cache-Control": "private, max-age=3600"})
        except sdk.requests.exceptions.RequestException:
            return Response("", status=502)

    return bp


def test(sdk, cfg):
    d = _overview(sdk, cfg)
    if d.get("ok"):
        return True, (f"Kavita ✓ — {d['lib_count']} bibliothèque(s), "
                      f"{d['reading_count']} lecture(s) en cours")
    return False, f"Kavita ✗ ({d.get('reason')})"
