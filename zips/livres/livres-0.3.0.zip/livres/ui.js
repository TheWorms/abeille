/* Livres (Kavita) — stats, en cours + nouveautés, recherche, couvertures. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.livres = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  let baseUrl = '', query = '', searchRes = null;
  const CSS =
    "  .lvwrap{flex:1;display:flex;flex-direction:column;min-height:0;--lv:#8a5cf6}\n" +
    "  .lvtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .lvlibs{display:flex;gap:8px;flex-wrap:wrap;flex:1}\n" +
    "  .lvlib{display:flex;align-items:center;gap:6px;background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:6px 11px;font-size:12.5px}\n" +
    "  .lvvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .lvvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .lvvtoggle button.on{background:var(--tile);color:var(--lv)}\n" +
    "  .lvsearch{padding:12px 22px 0}\n" +
    "  .lvsearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .lvscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .lvsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px;display:flex;align-items:center;gap:7px}\n" +
    "  .lvsec:first-child{margin-top:0}\n" +
    /* cards couverture */
    "  .lvcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:14px}\n" +
    "  .lvcard{cursor:pointer;display:flex;flex-direction:column;gap:6px}\n" +
    "  .lvcover-wrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .lvcard:hover .lvcover-wrap{border-color:var(--lv)}\n" +
    "  .lvcover{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .lvcover-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:34px;color:var(--dim)}\n" +
    "  .lvprog{position:absolute;left:0;right:0;bottom:0;height:5px;background:rgba(0,0,0,.4)}\n" +
    "  .lvprog i{display:block;height:100%;background:var(--lv)}\n" +
    "  .lvpct{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:7px}\n" +
    "  .lvcname{font-size:12.5px;font-weight:600;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    /* liste */
    "  .lvrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .lvrow:hover{border-color:var(--lv)}\n" +
    "  .lvrcover{width:40px;height:60px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .lvrph{width:40px;height:60px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--dim);flex:none}\n" +
    "  .lvrtx{min-width:0;flex:1}\n" +
    "  .lvrname{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .lvrprog{height:6px;background:var(--bg);border-radius:3px;overflow:hidden;margin-top:5px}\n" +
    "  .lvrprog i{display:block;height:100%;background:var(--lv)}\n" +
    "  .lvrmeta{font-size:11.5px;color:var(--dim);margin-top:3px}\n" +
    "  .lvempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { if (document.getElementById('lvUiCss')) return; const s = document.createElement('style'); s.id = 'lvUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const coverUrl = id => '/addons/livres/api/cover?series=' + encodeURIComponent(id);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de la bibliothèque…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openSeries(id, libId) {
    if (!baseUrl) { S.toast('URL non configurée'); return; }
    const u = baseUrl + '/library/' + (libId || 0) + '/series/' + id;
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  function card(s) {
    const ph = '<div class=\'lvcover-ph\'>📖</div>';
    return '<div class="lvcard" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '">' +
      '<div class="lvcover-wrap">' +
      '<img class="lvcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      (s.percent ? '<span class="lvpct">' + s.percent + '%</span>' : '') +
      (s.percent ? '<div class="lvprog"><i style="width:' + s.percent + '%"></i></div>' : '') +
      '</div>' +
      '<div class="lvcname">' + esc(s.name) + '</div></div>';
  }
  function row(s) {
    const ph = '<div class=\'lvrph\'>📖</div>';
    return '<div class="lvrow" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '">' +
      '<img class="lvrcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      '<div class="lvrtx"><div class="lvrname">' + esc(s.name) + '</div>' +
      (s.pages ? '<div class="lvrprog"><i style="width:' + s.percent + '%"></i></div>' +
        '<div class="lvrmeta">' + nf(s.pagesRead) + ' / ' + nf(s.pages) + ' pages · ' + s.percent + '%</div>' : '') +
      '</div></div>';
  }
  function renderSeries(list) {
    if (!list || !list.length) return '<div class="lvempty">Rien à afficher.</div>';
    if (viewMode === 'cards') return '<div class="lvcards">' + list.map(card).join('') + '</div>';
    return list.map(row).join('');
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📚</div><div class="t1">Kavita indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Compte → Clé API).</div>' +
        '<button class="btnpill install" id="lvRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('lvRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="lvwrap"><div class="lvtopbar">' +
      '<div class="lvlibs">' +
      (d.libraries.length ? d.libraries.map(l => '<span class="lvlib">📚 ' + esc(l.name) + '</span>').join('') : '<span class="lvempty">Aucune bibliothèque</span>') +
      '</div>' +
      '<div class="lvvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="lvsearch"><input id="lvQ" type="search" placeholder="Rechercher une série…" value="' + esc(query) + '"></div>';
    h += '<div class="lvscroll">';

    if (query && searchRes) {
      h += '<div class="lvsec">' + nf(searchRes.count) + ' résultat(s)</div>';
      h += renderSeries(searchRes.series);
    } else if (query) {
      h += '<div class="lvempty">Recherche…</div>';
    } else {
      if (d.reading && d.reading.length) {
        h += '<div class="lvsec">▶️ Lectures en cours · ' + nf(d.reading_count) + '</div>';
        h += renderSeries(d.reading);
      }
      if (d.recent && d.recent.length) {
        h += '<div class="lvsec">✨ Nouveautés</div>';
        h += renderSeries(d.recent);
      }
      if ((!d.reading || !d.reading.length) && (!d.recent || !d.recent.length)) {
        h += '<div class="lvempty">Aucune série à afficher.</div>';
      }
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.lvvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    const qin = document.getElementById('lvQ');
    if (qin) qin.addEventListener('input', () => { query = qin.value; scheduleSearch(); });
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openSeries(n.getAttribute('data-id'), n.getAttribute('data-lib'))));
  }

  let _t = null;
  function scheduleSearch() {
    if (_t) clearTimeout(_t);
    const q = query;
    _t = setTimeout(async () => {
      if (!q) { searchRes = null; paint(); refocus(); return; }
      try { const r = await S.api('/search?q=' + encodeURIComponent(q)); searchRes = await r.json(); }
      catch (e) { searchRes = { ok: false, count: 0, series: [] }; }
      if (query === q) { paint(); refocus(); }
    }, 350);
  }
  function refocus() {
    const nq = document.getElementById('lvQ');
    if (nq) { nq.focus(); const l = nq.value.length; try { nq.setSelectionRange(l, l); } catch (e) {} }
  }

  return { render };
})();
