/* Livres (Kavita) — stats, en cours + nouveautés, recherche, couvertures. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.livres = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'cards';
  let baseUrl = '', query = '', searchRes = null;
  const CSS =
    "  .lvwrap{flex:1;display:flex;flex-direction:column;min-height:0;--lv:#8a5cf6}\n" +
    "  .lvtopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .lvlibs{display:flex;gap:8px;flex-wrap:wrap;flex:1}\n" +
    "  .lvlib{display:flex;align-items:center;gap:6px;background:var(--tile);border:1px solid var(--border-soft);border-radius:9px;padding:6px 11px;font-size:12.5px}\n" +
    "  .lvvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .lvvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .lvvtoggle button.on{background:var(--tile);color:var(--lv)}\n" +
    "  .lvsearch{padding:12px 22px 0}\n" +
    "  .lvsearch input{width:100%;height:44px;background:var(--bg);border:1px solid var(--border-soft);border-radius:11px;padding:0 14px;color:var(--fg);font-size:14px;box-sizing:border-box}\n" +
    "  .lvscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .lvsec{font-size:12px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:14px 0 8px;display:flex;align-items:center;gap:7px}\n" +
    "  .lvsec:first-child{margin-top:0}\n" +
    /* cards couverture */
    "  .lvcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:14px}\n" +
    "  .lvcard{cursor:pointer;display:flex;flex-direction:column;gap:6px}\n" +
    "  .lvcover-wrap{position:relative;aspect-ratio:2/3;border-radius:10px;overflow:hidden;background:var(--tile);border:1px solid var(--border-soft)}\n" +
    "  .lvcard:hover .lvcover-wrap{border-color:var(--lv)}\n" +
    "  .lvcover{width:100%;height:100%;object-fit:cover;display:block}\n" +
    "  .lvcover-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:34px;color:var(--dim)}\n" +
    "  .lvprog{position:absolute;left:0;right:0;bottom:0;height:5px;background:rgba(0,0,0,.4)}\n" +
    "  .lvprog i{display:block;height:100%;background:var(--lv)}\n" +
    "  .lvpct{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:7px}\n" +
    "  .lvcname{font-size:12.5px;font-weight:600;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n" +
    /* liste */
    "  .lvrow{display:flex;align-items:center;gap:12px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:8px 12px;margin-bottom:7px;cursor:pointer}\n" +
    "  .lvrow:hover{border-color:var(--lv)}\n" +
    "  .lvrcover{width:40px;height:60px;object-fit:cover;border-radius:6px;background:var(--bg);flex:none}\n" +
    "  .lvrph{width:40px;height:60px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--dim);flex:none}\n" +
    "  .lvrtx{min-width:0;flex:1}\n" +
    "  .lvrname{font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .lvrprog{height:6px;background:var(--bg);border-radius:3px;overflow:hidden;margin-top:5px}\n" +
    "  .lvrprog i{display:block;height:100%;background:var(--lv)}\n" +
    "  .lvrmeta{font-size:11.5px;color:var(--dim);margin-top:3px}\n" +
    "  .lvempty{color:var(--dim);font-size:13px;padding:8px 0}\n" +
    /* fiche série */
    "  .lvdet{position:absolute;inset:0;background:var(--bg);z-index:40;display:flex;flex-direction:column}\n" +
    "  .lvdtop{display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border-soft)}\n" +
    "  .lvdback{background:transparent;border:0;color:var(--fg);font-size:15px;cursor:pointer;padding:8px 10px}\n" +
    "  .lvdtitle{font-weight:700;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .lvdopen{font-size:12px;color:var(--lv);cursor:pointer;background:rgba(138,92,246,.1);border:1px solid rgba(138,92,246,.3);border-radius:9px;padding:7px 12px}\n" +
    "  .lvdbody{flex:1;min-height:0;overflow:auto;padding:14px 18px}\n" +
    "  .lvdhead{display:flex;gap:14px;margin-bottom:14px}\n" +
    "  .lvdcover{width:96px;aspect-ratio:2/3;border-radius:9px;object-fit:cover;background:var(--tile);flex:none}\n" +
    "  .lvdresume{margin-top:10px;background:var(--lv);color:#fff;border:0;border-radius:10px;padding:11px 18px;font-size:13.5px;font-weight:700;cursor:pointer}\n" +
    "  .lvvol{font-size:11.5px;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin:12px 0 7px}\n" +
    "  .lvchap{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;padding:11px 13px;margin-bottom:7px;cursor:pointer}\n" +
    "  .lvchap:hover{border-color:var(--lv)}\n" +
    "  .lvchtx{flex:1;min-width:0}\n" +
    "  .lvchnm{font-weight:600;font-size:13.5px}\n" +
    "  .lvchmeta{font-size:11px;color:var(--dim);margin-top:1px}\n" +
    "  .lvchpct{font-size:11px;color:var(--lv);font-weight:700;flex:none}\n" +
    /* lecteur */
    "  .lvreader{position:fixed;inset:0;background:#000;z-index:9999;overflow:hidden}\n" +
    "  .lvrimg-wrap{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}\n" +
    "  .lvrimg{max-width:100%;max-height:100%;object-fit:contain;display:block}\n" +
    "  .lvrload{position:absolute;color:rgba(255,255,255,.6);font-size:14px}\n" +
    "  .lvtapL{position:absolute;left:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .lvtapC{position:absolute;left:33%;top:0;bottom:0;width:34%;z-index:2}\n" +
    "  .lvtapR{position:absolute;right:0;top:0;bottom:0;width:33%;z-index:2}\n" +
    "  .lvrtop{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:12px;padding:11px 16px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .lvrback{background:transparent;border:0;color:#fff;font-size:19px;cursor:pointer;padding:6px 10px}\n" +
    "  .lvrtt{min-width:0;flex:1}\n" +
    "  .lvrnm{color:#fff;font-size:13.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .lvrch{color:rgba(255,255,255,.6);font-size:11.5px}\n" +
    "  .lvrpg{color:rgba(255,255,255,.75);font-size:12.5px;font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .lvrbot{position:absolute;bottom:0;left:0;right:0;padding:12px 16px 14px;background:rgba(0,0,0,.78);z-index:3}\n" +
    "  .lvrbot input[type=range]{width:100%}";
  function ensureCss() { if (document.getElementById('lvUiCss')) return; const s = document.createElement('style'); s.id = 'lvUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const coverUrl = id => '/addons/livres/api/cover?series=' + encodeURIComponent(id);

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture de la bibliothèque…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const cfg = await sdk.config(); baseUrl = (cfg.url || '').replace(/\/+$/, ''); } catch (e) { baseUrl = ''; }
    try { const r = await sdk.api('/overview'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function openInKavita(id, libId) {
    if (!baseUrl) { S.toast('URL non configurée'); return; }
    const u = baseUrl + '/library/' + (libId || 0) + '/series/' + id;
    if (S.openService) S.openService(u); else window.open(u, '_blank');
  }

  /* ===== fiche série (volumes / chapitres) ===== */
  async function openSeries(id, libId, name) {
    const host = root.closest ? (root.closest('.aui') || root) : root;
    const det = document.createElement('div');
    det.className = 'lvdet';
    det.innerHTML = '<div class="lvdtop"><button class="lvdback">‹ Retour</button>' +
      '<span class="lvdtitle">' + esc(name || 'Série') + '</span>' +
      '<span class="lvdopen">Kavita ↗</span></div>' +
      '<div class="lvdbody"><div class="lvempty">Chargement…</div></div>';
    root.style.position = 'relative';
    root.appendChild(det);
    det.querySelector('.lvdback').addEventListener('click', () => det.remove());
    det.querySelector('.lvdopen').addEventListener('click', () => openInKavita(id, libId));
    let d = null;
    try { const r = await S.api('/series-detail?id=' + encodeURIComponent(id)); d = await r.json(); }
    catch (e) { d = { ok: false, reason: 'injoignable' }; }
    const body = det.querySelector('.lvdbody');
    if (!d || !d.ok) { body.innerHTML = '<div class="lvempty">⚠ ' + esc((d && d.reason) || 'erreur') + '</div>'; return; }
    // aplatir les chapitres (ordre volumes puis chapitres)
    const flat = [];
    (d.volumes || []).forEach(v => (v.chapters || []).forEach(c => flat.push(Object.assign({}, c, { seriesId: id, libraryId: libId }))));
    // point de reprise : premier chapitre entamé non fini, sinon premier non lu, sinon le premier
    let resume = flat.find(c => c.pagesRead > 0 && c.pagesRead < c.pages) ||
                 flat.find(c => !c.pagesRead) || flat[0];
    let h = '<div class="lvdhead">' +
      '<img class="lvdcover" src="' + coverUrl(id) + '" onerror="this.style.display=\'none\'">' +
      '<div><div style="font-weight:700;font-size:16px">' + esc(name || '') + '</div>' +
      '<div style="font-size:12px;color:var(--dim);margin-top:3px">' + flat.length + ' chapitre(s)</div>' +
      (resume ? '<button class="lvdresume">▶ ' + (resume.pagesRead > 0 ? 'Reprendre' : 'Commencer') + ' la lecture</button>' : '') +
      '</div></div>';
    (d.volumes || []).forEach(v => {
      if (v.name || (d.volumes.length > 1)) h += '<div class="lvvol">Volume ' + esc(v.name || v.minNumber || '') + '</div>';
      (v.chapters || []).forEach(c => {
        const pct = c.pages ? Math.round(c.pagesRead / c.pages * 100) : 0;
        h += '<div class="lvchap" data-ch="' + c.id + '">' +
          '<span>📖</span><div class="lvchtx"><div class="lvchnm">' + esc(c.title) + '</div>' +
          '<div class="lvchmeta">' + nf(c.pages) + ' pages' + (pct > 0 && pct < 100 ? ' · ' + pct + '% lu' : pct >= 100 ? ' · terminé ✓' : '') + '</div></div>' +
          (pct > 0 && pct < 100 ? '<span class="lvchpct">' + pct + '%</span>' : '') + '</div>';
      });
    });
    body.innerHTML = h;
    const rbtn = body.querySelector('.lvdresume');
    if (rbtn && resume) rbtn.addEventListener('click', () =>
      openReader(flat, flat.indexOf(resume), name, Math.max(0, (resume.pagesRead || 1) - 1)));
    body.querySelectorAll('.lvchap').forEach(n => n.addEventListener('click', () => {
      const c = flat.find(x => String(x.id) === n.getAttribute('data-ch'));
      if (c) openReader(flat, flat.indexOf(c), name, (c.pagesRead > 0 && c.pagesRead < c.pages) ? c.pagesRead - 1 : 0);
    }));
  }

  /* ===== lecteur plein écran ===== */
  function pageUrl(chapId, pg) { return '/addons/livres/api/page?chapter=' + chapId + '&page=' + pg; }
  function openReader(chapters, idx, seriesName, startPage) {
    let ci = idx, pg = startPage || 0, controls = true, saveT = null;
    const ov = document.createElement('div');
    ov.className = 'lvreader';
    document.body.appendChild(ov);
    function chap() { return chapters[ci]; }
    function saveProgress() {
      if (saveT) clearTimeout(saveT);
      saveT = setTimeout(() => {
        const c = chap(); if (!c) return;
        S.api('/progress', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ seriesId: c.seriesId, volumeId: c.volumeId, chapterId: c.id, page: pg + 1, libraryId: c.libraryId }) }).catch(() => {});
      }, 700);
    }
    function preload() {
      const c = chap(); if (!c) return;
      for (let k = 1; k <= 2; k++) {
        if (pg + k < c.pages) { const im = new Image(); im.src = pageUrl(c.id, pg + k); }
      }
    }
    function draw() {
      const c = chap(); if (!c) { close(); return; }
      ov.innerHTML = '<div class="lvrimg-wrap"><span class="lvrload">Chargement…</span></div>' +
        '<div class="lvtapL"></div><div class="lvtapC"></div><div class="lvtapR"></div>' +
        (controls ?
          '<div class="lvrtop"><button class="lvrback">‹</button>' +
          '<div class="lvrtt"><div class="lvrnm">' + esc(seriesName || '') + '</div>' +
          '<div class="lvrch">' + esc(c.title) + '</div></div>' +
          '<span class="lvrpg">' + (pg + 1) + ' / ' + c.pages + '</span></div>' +
          '<div class="lvrbot"><input type="range" min="1" max="' + c.pages + '" step="1" value="' + (pg + 1) + '"></div>'
          : '');
      const wrap = ov.querySelector('.lvrimg-wrap');
      const img = new Image();
      img.className = 'lvrimg';
      img.onload = () => { wrap.innerHTML = ''; wrap.appendChild(img); preload(); };
      img.onerror = () => { wrap.innerHTML = '<span class="lvrload">⚠ page indisponible</span>'; };
      img.src = pageUrl(c.id, pg);
      ov.querySelector('.lvtapL').addEventListener('click', () => turn(-1));
      ov.querySelector('.lvtapR').addEventListener('click', () => turn(1));
      ov.querySelector('.lvtapC').addEventListener('click', () => { controls = !controls; draw(); });
      const bk = ov.querySelector('.lvrback'); if (bk) bk.addEventListener('click', close);
      const sl = ov.querySelector('.lvrbot input'); if (sl) sl.addEventListener('change', () => { pg = parseInt(sl.value, 10) - 1; draw(); saveProgress(); });
    }
    function turn(d) {
      const c = chap(); if (!c) return;
      const np = pg + d;
      if (np < 0) {
        if (ci > 0) { ci--; pg = Math.max(0, (chap().pages || 1) - 1); S.toast(chap().title); }
      } else if (np >= c.pages) {
        if (ci < chapters.length - 1) { ci++; pg = 0; S.toast(chap().title); }
        else { S.toast('Fin de la série 🎉'); }
      } else { pg = np; }
      draw(); saveProgress();
    }
    function close() {
      if (saveT) clearTimeout(saveT);
      ov.remove();
      render(root, S, tile);  // recharge (progression à jour)
    }
    draw(); saveProgress();
  }

  function card(s) {
    const ph = '<div class=\'lvcover-ph\'>📖</div>';
    return '<div class="lvcard" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<div class="lvcover-wrap">' +
      '<img class="lvcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      (s.percent ? '<span class="lvpct">' + s.percent + '%</span>' : '') +
      (s.percent ? '<div class="lvprog"><i style="width:' + s.percent + '%"></i></div>' : '') +
      '</div>' +
      '<div class="lvcname">' + esc(s.name) + '</div></div>';
  }
  function row(s) {
    const ph = '<div class=\'lvrph\'>📖</div>';
    return '<div class="lvrow" data-id="' + esc(s.id) + '" data-lib="' + esc(s.libraryId || '') + '" data-nm="' + esc(s.name) + '">' +
      '<img class="lvrcover" loading="lazy" src="' + coverUrl(s.id) + '" onerror="this.outerHTML=\'' + ph + '\'">' +
      '<div class="lvrtx"><div class="lvrname">' + esc(s.name) + '</div>' +
      (s.pages ? '<div class="lvrprog"><i style="width:' + s.percent + '%"></i></div>' +
        '<div class="lvrmeta">' + nf(s.pagesRead) + ' / ' + nf(s.pages) + ' pages · ' + s.percent + '%</div>' : '') +
      '</div></div>';
  }
  function renderSeries(list) {
    if (!list || !list.length) return '<div class="lvempty">Rien à afficher.</div>';
    if (viewMode === 'cards') return '<div class="lvcards">' + list.map(card).join('') + '</div>';
    return list.map(row).join('');
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">📚</div><div class="t1">Kavita indisponible</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL et la clé API dans ⚙ (Compte → Clé API).</div>' +
        '<button class="btnpill install" id="lvRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('lvRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="lvwrap"><div class="lvtopbar">' +
      '<div class="lvlibs">' +
      (d.libraries.length ? d.libraries.map(l => '<span class="lvlib">📚 ' + esc(l.name) + '</span>').join('') : '<span class="lvempty">Aucune bibliothèque</span>') +
      '</div>' +
      '<div class="lvvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';
    h += '<div class="lvsearch"><input id="lvQ" type="search" placeholder="Rechercher une série…" value="' + esc(query) + '"></div>';
    h += '<div class="lvscroll">';

    if (query && searchRes) {
      h += '<div class="lvsec">' + nf(searchRes.count) + ' résultat(s)</div>';
      h += renderSeries(searchRes.series);
    } else if (query) {
      h += '<div class="lvempty">Recherche…</div>';
    } else {
      if (d.reading && d.reading.length) {
        h += '<div class="lvsec">▶️ Lectures en cours · ' + nf(d.reading_count) + '</div>';
        h += renderSeries(d.reading);
      }
      if (d.recent && d.recent.length) {
        h += '<div class="lvsec">✨ Nouveautés</div>';
        h += renderSeries(d.recent);
      }
      if ((!d.reading || !d.reading.length) && (!d.recent || !d.recent.length)) {
        h += '<div class="lvempty">Aucune série à afficher.</div>';
      }
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.lvvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v'); if (v === viewMode) return;
      viewMode = v; try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    const qin = document.getElementById('lvQ');
    if (qin) qin.addEventListener('input', () => { query = qin.value; scheduleSearch(); });
    el.querySelectorAll('[data-id]').forEach(n => n.addEventListener('click', () => openSeries(n.getAttribute('data-id'), n.getAttribute('data-lib'), n.getAttribute('data-nm'))));
  }

  let _t = null;
  function scheduleSearch() {
    if (_t) clearTimeout(_t);
    const q = query;
    _t = setTimeout(async () => {
      if (!q) { searchRes = null; paint(); refocus(); return; }
      try { const r = await S.api('/search?q=' + encodeURIComponent(q)); searchRes = await r.json(); }
      catch (e) { searchRes = { ok: false, count: 0, series: [] }; }
      if (query === q) { paint(); refocus(); }
    }, 350);
  }
  function refocus() {
    const nq = document.getElementById('lvQ');
    if (nq) { nq.focus(); const l = nq.value.length; try { nq.setSelectionRange(l, l); } catch (e) {} }
  }

  return { render };
})();
