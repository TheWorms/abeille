"""Addon « musique » — client Navidrome/Subsonic (lot K).

Migré du noyau vers un backend autonome. Le mot de passe ne transite jamais :
authentification Subsonic par jeton salé (md5(pass+salt)). Les flux audio et
pochettes sont relayés côté serveur (l'app ne voit jamais les identifiants).
Cache 2 min du résumé via ``sdk.cache``.
"""
import hashlib
import re
import secrets


def _params(cfg):
    """Paramètres d'auth Subsonic (jeton salé)."""
    user = (cfg.get("user") or "").strip()
    pw = (cfg.get("pass") or "").strip()
    if not user or not pw:
        raise RuntimeError("identifiants non configurés (⚙ Musique)")
    salt = secrets.token_hex(8)
    token = hashlib.md5((pw + salt).encode()).hexdigest()
    return {"u": user, "t": token, "s": salt, "v": "1.16.1",
            "c": "panda", "f": "json"}


def _get(sdk, cfg, endpoint, extra=None, timeout=10):
    url = (cfg.get("url") or "").rstrip("/")
    if not url:
        raise RuntimeError("URL non configurée (⚙ Musique)")
    params = _params(cfg)
    params.update(extra or {})
    r = sdk.requests.get(f"{url}/rest/{endpoint}", params=params, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    try:
        j = r.json()["subsonic-response"]
    except (ValueError, KeyError):
        raise RuntimeError("réponse invalide")
    if j.get("status") != "ok":
        err = j.get("error", {})
        code = err.get("code")
        if code in (40, 41):
            raise RuntimeError("identifiants refusés")
        raise RuntimeError(err.get("message") or f"erreur {code}")
    return j


def _song(x):
    return {"id": x.get("id"), "title": x.get("title", "?"),
            "artist": x.get("artist", ""), "album": x.get("album", ""),
            "duration": x.get("duration") or 0, "cover": x.get("coverArt"),
            "track": x.get("track"), "year": x.get("year"),
            "genre": x.get("genre", "")}


def _alb(a):
    return {"id": a.get("id"), "name": a.get("name", "?"),
            "artist": a.get("artist", ""), "year": a.get("year"),
            "songs": a.get("songCount"), "cover": a.get("coverArt"),
            "genre": a.get("genre", "")}


def _summary(sdk, cfg):
    key = f"nd:{(cfg.get('url') or '')}:{(cfg.get('user') or '')}"
    hit = sdk.cache_get(key, 120)
    if hit is not None:
        return hit
    try:
        stats = _get(sdk, cfg, "getScanStatus.view")
        albums = _get(sdk, cfg, "getAlbumList2.view", {"type": "recent", "size": 12})
        random_songs = _get(sdk, cfg, "getRandomSongs.view", {"size": 8})
        starred = _get(sdk, cfg, "getStarred2.view")
    except RuntimeError as e:
        return {"ok": False, "reason": str(e)}
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    scan = stats.get("scanStatus", {})
    res = {"ok": True, "scanning": bool(scan.get("scanning")),
           "count": scan.get("count") or 0,
           "albums": [_alb(a) for a in (albums.get("albumList2", {}).get("album") or [])],
           "random": [_song(x) for x in (random_songs.get("randomSongs", {}).get("song") or [])],
           "starred": [_song(x) for x in (starred.get("starred2", {}).get("song") or [])][:8]}
    return sdk.cache_set(key, res)


_IDRE = re.compile(r"[A-Za-z0-9._:-]{1,64}")


def register(sdk):
    from flask import Blueprint, jsonify, request, Response
    bp = Blueprint("musique", __name__)

    def cfg():
        return sdk.config()

    def _err(fn):
        """Enveloppe JSON : RuntimeError → reason, réseau → nom d'exception."""
        try:
            return jsonify(fn())
        except RuntimeError as e:
            return jsonify({"ok": False, "reason": str(e)})
        except sdk.requests.exceptions.RequestException as e:
            return jsonify({"ok": False, "reason": type(e).__name__})

    @bp.route("/summary")
    def summary():
        return jsonify(_summary(sdk, cfg()))

    @bp.route("/search")
    def search():
        q = (request.args.get("q") or "").strip()[:60]
        if len(q) < 2:
            return jsonify({"ok": False, "reason": "saisis au moins 2 caractères"})

        def _do():
            j = _get(sdk, cfg(), "search3.view",
                     {"query": q, "songCount": 30, "albumCount": 12, "artistCount": 12},
                     timeout=12)
            r = j.get("searchResult3", {})
            return {"ok": True,
                    "songs": [_song(x) for x in (r.get("song") or [])],
                    "albums": [_alb(a) for a in (r.get("album") or [])],
                    "artists": [{"id": a.get("id"), "name": a.get("name", "?"),
                                 "albums": a.get("albumCount"), "cover": a.get("coverArt")}
                                for a in (r.get("artist") or [])]}
        return _err(_do)

    @bp.route("/albums")
    def albums():
        t = (request.args.get("type") or "newest").strip()
        if t not in ("newest", "alphabeticalByName", "alphabeticalByArtist",
                     "random", "frequent", "recent", "byGenre", "starred"):
            t = "newest"
        params = {"type": t, "size": 36,
                  "offset": max(0, int(request.args.get("offset") or 0))}
        g = (request.args.get("genre") or "").strip()
        if t == "byGenre":
            if not g:
                return jsonify({"ok": False, "reason": "genre manquant"}), 400
            params["genre"] = g

        def _do():
            j = _get(sdk, cfg(), "getAlbumList2.view", params, timeout=12)
            return {"ok": True, "albums": [_alb(a) for a in
                                           (j.get("albumList2", {}).get("album") or [])]}
        return _err(_do)

    @bp.route("/album/<aid>")
    def album(aid):
        if not _IDRE.fullmatch(aid):
            return jsonify({"ok": False, "reason": "id invalide"}), 400

        def _do():
            j = _get(sdk, cfg(), "getAlbum.view", {"id": aid}, timeout=12)
            a = j.get("album", {})
            return {"ok": True, "album": _alb(a),
                    "songs": [_song(x) for x in (a.get("song") or [])]}
        return _err(_do)

    @bp.route("/artists")
    def artists():
        def _do():
            j = _get(sdk, cfg(), "getArtists.view", timeout=15)
            out = []
            for idx in (j.get("artists", {}).get("index") or []):
                for a in (idx.get("artist") or []):
                    out.append({"id": a.get("id"), "name": a.get("name", "?"),
                                "albums": a.get("albumCount") or 0, "cover": a.get("coverArt")})
            out.sort(key=lambda x: x["name"].lower())
            return {"ok": True, "artists": out}
        return _err(_do)

    @bp.route("/artist/<aid>")
    def artist(aid):
        if not _IDRE.fullmatch(aid):
            return jsonify({"ok": False, "reason": "id invalide"}), 400

        def _do():
            j = _get(sdk, cfg(), "getArtist.view", {"id": aid}, timeout=12)
            a = j.get("artist", {})
            return {"ok": True, "name": a.get("name", "?"),
                    "albums": [_alb(x) for x in (a.get("album") or [])]}
        return _err(_do)

    @bp.route("/genres")
    def genres():
        def _do():
            j = _get(sdk, cfg(), "getGenres.view", timeout=12)
            g = [{"name": x.get("value", "?"), "songs": x.get("songCount") or 0,
                  "albums": x.get("albumCount") or 0}
                 for x in (j.get("genres", {}).get("genre") or [])]
            g.sort(key=lambda x: -x["songs"])
            return {"ok": True, "genres": g}
        return _err(_do)

    @bp.route("/playlists")
    def playlists():
        def _do():
            j = _get(sdk, cfg(), "getPlaylists.view", timeout=12)
            p = [{"id": x.get("id"), "name": x.get("name", "?"),
                  "songs": x.get("songCount") or 0, "duration": x.get("duration") or 0,
                  "cover": x.get("coverArt"), "owner": x.get("owner", "")}
                 for x in (j.get("playlists", {}).get("playlist") or [])]
            return {"ok": True, "playlists": p}
        return _err(_do)

    @bp.route("/playlist/<pid>")
    def playlist(pid):
        if not _IDRE.fullmatch(pid):
            return jsonify({"ok": False, "reason": "id invalide"}), 400

        def _do():
            j = _get(sdk, cfg(), "getPlaylist.view", {"id": pid}, timeout=12)
            p = j.get("playlist", {})
            return {"ok": True, "name": p.get("name", "?"),
                    "songs": [_song(x) for x in (p.get("entry") or [])]}
        return _err(_do)

    @bp.route("/random")
    def random():
        params = {"size": min(100, max(1, int(request.args.get("size") or 30)))}
        g = (request.args.get("genre") or "").strip()
        if g:
            params["genre"] = g

        def _do():
            j = _get(sdk, cfg(), "getRandomSongs.view", params, timeout=12)
            return {"ok": True, "songs": [_song(x) for x in
                                          (j.get("randomSongs", {}).get("song") or [])]}
        return _err(_do)

    @bp.route("/stream/<sid>")
    def stream(sid):
        if not _IDRE.fullmatch(sid):
            return Response("id invalide", status=400)
        c = cfg()
        try:
            params = _params(c)
        except RuntimeError as e:
            return Response(str(e), status=400)
        url = (c.get("url") or "").rstrip("/")
        params.update({"id": sid, "format": "mp3", "maxBitRate": "192"})
        try:
            up = sdk.requests.get(f"{url}/rest/stream.view", params=params,
                                  stream=True, timeout=20)
        except sdk.requests.exceptions.RequestException:
            return Response("flux indisponible", status=502)
        if up.status_code != 200:
            return Response("flux indisponible", status=502)
        return Response(up.iter_content(chunk_size=64 * 1024),
                        content_type=up.headers.get("Content-Type", "audio/mpeg"))

    @bp.route("/cover/<cid>")
    def cover(cid):
        if not _IDRE.fullmatch(cid):
            return Response("id invalide", status=400)
        c = cfg()
        try:
            params = _params(c)
        except RuntimeError as e:
            return Response(str(e), status=400)
        url = (c.get("url") or "").rstrip("/")
        params.update({"id": cid, "size": "300"})
        try:
            up = sdk.requests.get(f"{url}/rest/getCoverArt.view", params=params, timeout=10)
        except sdk.requests.exceptions.RequestException:
            return Response(status=404)
        if up.status_code != 200:
            return Response(status=404)
        return Response(up.content, content_type=up.headers.get("Content-Type", "image/jpeg"))

    return bp


def test(sdk, cfg):
    r = _summary(sdk, cfg)
    if r.get("ok"):
        return True, f"Navidrome \u2713 \u2014 {r.get('count') or 0} morceau(x)"
    return False, f"Navidrome \u2717 ({r.get('reason')})"
