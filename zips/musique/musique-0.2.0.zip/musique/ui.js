/* Musique — Navidrome via le kiosk (Phase 3, lot D). Pattern radio :
   l'audio, la file et l'état vivent dans le module ; la barre #muBar (noyau)
   est pilotée d'ici et background() la réaffiche au déverrouillage. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.musique = (function () {
  let S=null, root=null, tile=null, bgSdk=null;
  let audio=null, cur=null, queue=[], idx=0;
  let tab='albums', sort='newest', genre='', query='', shuffle=false, view=null, seeking=false;
  const CSS = "  .mualb{display:grid;grid-template-columns:repeat(6,1fr);gap:9px;margin-bottom:14px}\n  .muc{background:var(--tile);border:1px solid var(--border-soft);border-radius:10px;overflow:hidden}\n  .muc img,.mucph{width:100%;aspect-ratio:1;object-fit:cover;display:block;background:#0d1116}\n  .mucph{display:flex;align-items:center;justify-content:center;font-size:26px;color:var(--faint)}\n  .mucb{padding:7px 8px}\n  .mucn{font-size:11.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .muca{font-size:10px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .musong{display:flex;align-items:center;gap:11px;background:var(--tile);border:1px solid var(--border-soft);\n          border-radius:10px;padding:8px 12px;margin-bottom:6px;cursor:pointer;min-height:50px}\n  .musong.on{border-color:var(--accent);background:var(--accent-tint)}\n  .musong img{width:36px;height:36px;border-radius:6px;object-fit:cover;flex:none}\n  .must{font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .musa{font-size:11px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .musd{margin-left:auto;font-size:11.5px;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n  .muplayer{display:flex;align-items:center;gap:13px;background:var(--tile);border:1px solid var(--accent);\n            border-radius:12px;padding:11px 15px;margin-bottom:12px}\n  .muplayer img{width:48px;height:48px;border-radius:8px;object-fit:cover;flex:none}\n  .mubtn{width:44px;height:44px;border-radius:10px;border:1px solid var(--border-soft);background:var(--bg);\n         display:flex;align-items:center;justify-content:center;font-size:16px;cursor:pointer;flex:none}\n  .mubtn:active{background:var(--accent-tint);border-color:var(--accent)}\n  .museek{flex:1;height:26px}\n  .mutime{font-size:11.5px;color:var(--dim);font-variant-numeric:tabular-nums;min-width:88px;text-align:right;flex:none}\n  .mutabs{display:flex;gap:6px;margin-bottom:10px;flex-wrap:wrap}\n  .musearch{flex:1;position:relative;min-width:220px}\n  .musearch input{width:100%;padding:10px 12px 10px 34px;border-radius:10px;border:1px solid var(--border-soft);\n        background:var(--tile);color:var(--text);font-size:13px}\n  .musearch .mag{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--faint);font-size:13px}\n  .mubar2{display:flex;gap:8px;align-items:center;margin-bottom:11px}\n  .mushuf{padding:9px 13px;border-radius:9px;border:1px solid var(--border-soft);background:var(--tile);\n          font-size:12px;cursor:pointer;white-space:nowrap}\n  .mushuf.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n  .muc{cursor:pointer}\n  .muc:active{border-color:var(--accent)}\n  .mugen{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:11px}\n  .mugchip{font-size:11.5px;padding:6px 11px;border-radius:8px;border:1px solid var(--border-soft);\n           background:var(--tile);cursor:pointer}\n  .mugchip.on{border-color:var(--accent);background:var(--accent-tint);color:var(--accent);font-weight:600}\n  .muart{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}\n  .muartc{display:flex;align-items:center;gap:9px;background:var(--tile);border:1px solid var(--border-soft);\n          border-radius:10px;padding:9px 11px;cursor:pointer}\n  .muartc:active{border-color:var(--accent)}\n  .muan{font-weight:600;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n  .muas{font-size:10px;color:var(--dim)}\n  .muback{font-size:12px;color:var(--accent);cursor:pointer;margin-bottom:8px;display:inline-block}";
  function ensureCss(){if(document.getElementById('muUiCss'))return;const s=document.createElement('style');s.id='muUiCss';s.textContent=CSS;document.head.appendChild(s);}
  const fmt=s2=>{if(!isFinite(s2)||s2<0)return '0:00';const m=Math.floor(s2/60);return m+':'+String(Math.floor(s2%60)).padStart(2,'0');};
  const cover=id=>id?('/addons/musique/api/cover/'+encodeURIComponent(id)):'';
  const api=async u=>{try{const r=await fetch('/addons/musique/api'+u);return await r.json();}catch(e){return{ok:false,reason:'serveur injoignable'};}};
  function shuffled(list){const a=list.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

  function play(list,i){
    queue=shuffle?shuffled(list):list;
    if(shuffle&&list[i]){const k=queue.findIndex(x=>x.id===list[i].id);idx=k>=0?k:0;}else idx=i;
    cur=queue[idx];
    if(audio){audio.pause();audio=null;}
    audio=new Audio('/addons/musique/api/stream/'+encodeURIComponent(cur.id));
    audio.play().catch(()=>{});
    audio.addEventListener('ended',()=>{if(idx+1<queue.length)play(queue,idx+1);else{cur=null;rerender();}});
    audio.addEventListener('timeupdate',tick);
    audio.addEventListener('play',()=>{const b=document.getElementById('muPP');if(b)b.textContent='⏸';updBar();});
    audio.addEventListener('pause',()=>{const b=document.getElementById('muPP');if(b)b.textContent='▶';updBar();});
    updBar();rerender();
  }
  function stop(){if(audio){audio.pause();audio=null;}cur=null;updBar();rerender();}
  function tick(){
    const sk=document.getElementById('muSeek'),tl=document.getElementById('muTime');
    const d=audio?(audio.duration||(cur&&cur.duration)||0):0;
    if(audio&&sk&&tl&&d&&!seeking){sk.value=Math.round(audio.currentTime/d*1000);tl.textContent=fmt(audio.currentTime)+' / '+fmt(d);}
    updBar();
  }
  function updBar(){
    const bar=document.getElementById('muBar');if(!bar)return;
    if(!cur||!audio){bar.style.display='none';return;}
    bar.style.display='inline-flex';
    bar.innerHTML='🎵<span class="mut" id="muBarT"></span><span class="mub" id="muBarPP">'+(audio.paused?'▶':'⏸')+'</span>';
    const t=document.getElementById('muBarT');t.textContent=cur.title;
    t.onclick=()=>(bgSdk||S).open();
    document.getElementById('muBarPP').onclick=(e)=>{e.stopPropagation();if(!audio)return;audio.paused?audio.play():audio.pause();updBar();};
  }
  function rerender(){if(root&&document.body.contains(root)&&S)render(root,S,tile);}

  function player(){
    if(!cur)return '';
    const dur=(audio&&audio.duration)||cur.duration||0;
    return '<div class="muplayer">'+
      (cur.cover?'<img src="'+cover(cur.cover)+'">':'<div class="mubtn">🎵</div>')+
      '<div style="min-width:0"><div class="must">'+cur.title+'</div>'+
      '<div class="musa">'+cur.artist+' · '+cur.album+'</div></div>'+
      '<span class="mubtn" id="muPrev">⏮</span>'+
      '<span class="mubtn" id="muPP">'+(audio&&!audio.paused?'⏸':'▶')+'</span>'+
      '<span class="mubtn" id="muNext">⏭</span>'+
      '<input class="museek" id="muSeek" type="range" min="0" max="1000" value="0">'+
      '<span class="mutime" id="muTime">0:00 / '+fmt(dur)+'</span>'+
      '<span class="mubtn" id="muStop">⏹</span></div>';
  }
  function songRows(list,key){
    return list.map((sg,i)=>'<div class="musong'+(cur&&cur.id===sg.id?' on':'')+'" data-'+key+'="'+i+'">'+
      (sg.cover?'<img src="'+cover(sg.cover)+'">':'<span class="mubtn" style="width:36px;height:36px">🎵</span>')+
      '<span style="min-width:0"><span class="must">'+sg.title+'</span>'+
      '<span class="musa">'+sg.artist+' · '+sg.album+'</span></span>'+
      '<span class="musd">'+fmt(sg.duration)+'</span></div>').join('');
  }
  function albGrid(albums){
    if(!albums.length)return '<div class="stub"><div class="t2">Aucun album</div></div>';
    return '<div class="mualb">'+albums.map(al=>'<div class="muc" data-alb="'+al.id+'">'+
      (al.cover?'<img loading="lazy" src="'+cover(al.cover)+'">':'<div class="mucph">💿</div>')+
      '<div class="mucb"><div class="mucn">'+al.name+'</div>'+
      '<div class="muca">'+al.artist+(al.year?' · '+al.year:'')+'</div></div></div>').join('')+'</div>';
  }
  function wireAlbums(){document.querySelectorAll('[data-alb]').forEach(x=>x.addEventListener('click',()=>{view={type:'album',id:x.dataset.alb};renderMain();}));}
  function wireArtists(){document.querySelectorAll('[data-art]').forEach(x=>x.addEventListener('click',()=>{view={type:'artist',id:x.dataset.art};renderMain();}));}
  function wireLists(d,key){
    document.querySelectorAll('[data-'+key+']').forEach(x=>x.addEventListener('click',()=>play(d.songs,parseInt(x.dataset[key]))));
    wireAlbums();wireArtists();
  }
  function wirePlayer(){
    const pp=document.getElementById('muPP');
    if(pp)pp.addEventListener('click',()=>{if(!audio)return;audio.paused?audio.play():audio.pause();});
    const pv=document.getElementById('muPrev');
    if(pv)pv.addEventListener('click',()=>{if(idx>0)play(queue,idx-1);else if(audio)audio.currentTime=0;});
    const nx=document.getElementById('muNext');
    if(nx)nx.addEventListener('click',()=>{if(idx+1<queue.length)play(queue,idx+1);});
    const st=document.getElementById('muStop');
    if(st)st.addEventListener('click',()=>stop());
    const sk=document.getElementById('muSeek');
    if(sk){
      const dur=()=>audio?(audio.duration||(cur&&cur.duration)||0):0;
      const start=()=>{seeking=true;};
      const move=()=>{const d=dur(),tl=document.getElementById('muTime');if(d&&tl)tl.textContent=fmt(sk.value/1000*d)+' / '+fmt(d);};
      const end=()=>{const d=dur();if(audio&&d)audio.currentTime=sk.value/1000*d;seeking=false;};
      sk.addEventListener('pointerdown',start);sk.addEventListener('touchstart',start,{passive:true});
      sk.addEventListener('input',move);sk.addEventListener('change',end);
      sk.addEventListener('pointerup',end);sk.addEventListener('touchend',end);
    }
    const sh=document.getElementById('muShuf');
    if(sh)sh.addEventListener('click',()=>{shuffle=!shuffle;sh.classList.toggle('on',shuffle);
      S.toast(shuffle?'Lecture aléatoire activée':'Lecture dans l\'ordre');});
    tick();
  }

  async function render(el, sdk, a) {
    S=sdk;bgSdk=bgSdk||sdk;root=el;tile=a||tile;ensureCss();
    const base=await api('/summary');
    if(!base.ok){
      el.innerHTML='<div class="stub"><div class="big">🎵</div><div class="t1">Rossignol — Navidrome</div>'+
        '<div class="t2">'+(base.reason||'')+'<br>Renseigne l\'URL et tes identifiants dans \u2699.</div></div>';
      return;
    }
    let h=player();
    const TABS=[['albums','💿 Albums'],['artistes','🎤 Artistes'],['genres','🎼 Genres'],['playlists','📃 Playlists'],['aleatoire','🔀 Aléatoire']];
    h+='<div class="mubar2"><span class="musearch"><span class="mag">🔍</span>'+
       '<input id="muQ" placeholder="Rechercher un titre, un artiste, un album…" value="'+query.replace(/"/g,'&quot;')+'" autocomplete="off"></span>'+
       '<span class="mushuf'+(shuffle?' on':'')+'" id="muShuf">🔀 Lecture aléatoire</span>'+
       '<span class="gybadge">'+base.count.toLocaleString('fr-FR')+' morceaux</span></div>';
    h+='<div class="mutabs">'+TABS.map(t=>'<span class="wch'+(tab===t[0]&&!query?' on':'')+'" data-mt="'+t[0]+'">'+t[1]+'</span>').join('')+'</div>';
    h+='<div id="muMain"><div class="stub"><div class="t2">Chargement…</div></div></div>';
    h+='<div class="wsrc">Navidrome · le flux passe par le kiosk, tes identifiants ne sortent pas du serveur · vue embarquée v0.2.0</div>';
    el.innerHTML=h;
    wirePlayer();
    const q=document.getElementById('muQ');
    let t=null;
    q.addEventListener('input',()=>{clearTimeout(t);t=setTimeout(()=>{query=q.value;renderMain();},250);});
    el.querySelectorAll('[data-mt]').forEach(x=>x.addEventListener('click',()=>{tab=x.dataset.mt;query='';view=null;rerender();}));
    renderMain();
  }
  async function renderMain(){
    const box=document.getElementById('muMain');if(!box)return;
    box.innerHTML='<div class="stub"><div class="t2">Chargement…</div></div>';
    if(query.trim().length>=2){
      const d=await api('/search?q='+encodeURIComponent(query.trim()));
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      let h='';
      if(d.artists.length)h+='<div class="wsec" style="padding-left:0">Artistes</div><div class="muart">'+
        d.artists.map(x=>'<div class="muartc" data-art="'+x.id+'"><span>🎤</span><span style="min-width:0">'+
          '<span class="muan">'+x.name+'</span><span class="muas">'+(x.albums||0)+' album(s)</span></span></div>').join('')+'</div>';
      if(d.albums.length)h+='<div class="wsec" style="padding-left:0">Albums</div>'+albGrid(d.albums);
      if(d.songs.length)h+='<div class="wsec" style="padding-left:0">Titres</div>'+songRows(d.songs,'sq');
      if(!h)h='<div class="stub"><div class="t2">Aucun résultat pour « '+query+' »</div></div>';
      box.innerHTML=h;wireLists({songs:d.songs},'sq');return;
    }
    if(view&&view.type==='album'){
      const d=await api('/album/'+encodeURIComponent(view.id));
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      box.innerHTML='<span class="muback" id="muBack">← Retour</span>'+
        '<div class="wsec" style="padding-left:0">'+d.album.name+' — '+d.album.artist+'</div>'+
        '<div class="igbar"><span class="igbtn2" id="muPlayAll">▶ Tout lire</span></div>'+songRows(d.songs,'sa');
      document.getElementById('muBack').addEventListener('click',()=>{view=null;renderMain();});
      document.getElementById('muPlayAll').addEventListener('click',()=>play(d.songs,0));
      wireLists({songs:d.songs},'sa');return;
    }
    if(view&&view.type==='artist'){
      const d=await api('/artist/'+encodeURIComponent(view.id));
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      box.innerHTML='<span class="muback" id="muBack">← Retour</span>'+
        '<div class="wsec" style="padding-left:0">'+d.name+'</div>'+albGrid(d.albums);
      document.getElementById('muBack').addEventListener('click',()=>{view=null;renderMain();});
      wireAlbums();return;
    }
    if(view&&view.type==='playlist'){
      const d=await api('/playlist/'+encodeURIComponent(view.id));
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      box.innerHTML='<span class="muback" id="muBack">← Retour</span>'+
        '<div class="wsec" style="padding-left:0">📃 '+d.name+' · '+d.songs.length+' titres</div>'+
        '<div class="igbar"><span class="igbtn2" id="muPlayAll">▶ Tout lire</span></div>'+songRows(d.songs,'sp');
      document.getElementById('muBack').addEventListener('click',()=>{view=null;renderMain();});
      document.getElementById('muPlayAll').addEventListener('click',()=>play(d.songs,0));
      wireLists({songs:d.songs},'sp');return;
    }
    if(tab==='albums'){
      const SORTS=[['newest','Récents'],['alphabeticalByName','Par album'],['alphabeticalByArtist','Par artiste'],['random','Au hasard']];
      let h='<div class="mugen">'+SORTS.map(x=>'<span class="mugchip'+(sort===x[0]?' on':'')+'" data-ms="'+x[0]+'">'+x[1]+'</span>').join('')+'</div>';
      const d=await api('/albums?type='+encodeURIComponent(sort));
      h+=d.ok?albGrid(d.albums):'<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';
      box.innerHTML=h;
      box.querySelectorAll('[data-ms]').forEach(x=>x.addEventListener('click',()=>{sort=x.dataset.ms;renderMain();}));
      wireAlbums();return;
    }
    if(tab==='artistes'){
      const d=await api('/artists');
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      box.innerHTML='<div class="muart">'+d.artists.map(x=>'<div class="muartc" data-art="'+x.id+'"><span>🎤</span>'+
        '<span style="min-width:0"><span class="muan">'+x.name+'</span><span class="muas">'+x.albums+' album(s)</span></span></div>').join('')+'</div>';
      wireArtists();return;
    }
    if(tab==='genres'){
      const d=await api('/genres');
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      let h='<div class="mugen">'+d.genres.map(g=>'<span class="mugchip'+(genre===g.name?' on':'')+'" data-mg="'+g.name+'">'+
        g.name+' · '+g.songs+'</span>').join('')+'</div>';
      if(genre){
        const al=await api('/albums?type=byGenre&genre='+encodeURIComponent(genre));
        h+='<div class="igbar"><span class="igbtn2" id="muGenRand">🔀 Écouter '+genre+' au hasard</span></div>';
        h+=al.ok?albGrid(al.albums):'';
      }
      box.innerHTML=h;
      box.querySelectorAll('[data-mg]').forEach(x=>x.addEventListener('click',()=>{genre=(genre===x.dataset.mg)?'':x.dataset.mg;renderMain();}));
      const gr=document.getElementById('muGenRand');
      if(gr)gr.addEventListener('click',async()=>{
        const r=await api('/random?size=50&genre='+encodeURIComponent(genre));
        if(r.ok&&r.songs.length)play(r.songs,0);else S.toast('Aucun titre');});
      wireAlbums();return;
    }
    if(tab==='playlists'){
      const d=await api('/playlists');
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      if(!d.playlists.length){box.innerHTML='<div class="stub"><div class="big">📃</div>'+
        '<div class="t2">Aucune playlist — crée-les dans Navidrome, elles apparaîtront ici</div></div>';return;}
      box.innerHTML=d.playlists.map(p=>'<div class="musong" data-pl="'+p.id+'">'+
        (p.cover?'<img src="'+cover(p.cover)+'">':'<span class="mubtn" style="width:36px;height:36px">📃</span>')+
        '<span style="min-width:0"><span class="must">'+p.name+'</span>'+
        '<span class="musa">'+p.songs+' titres · '+fmt(p.duration)+'</span></span></div>').join('');
      box.querySelectorAll('[data-pl]').forEach(x=>x.addEventListener('click',()=>{view={type:'playlist',id:x.dataset.pl};renderMain();}));
      return;
    }
    if(tab==='aleatoire'){
      const d=await api('/random?size=40');
      if(!d.ok){box.innerHTML='<div class="stub"><div class="t2">'+(d.reason||'')+'</div></div>';return;}
      box.innerHTML='<div class="igbar"><span class="igbtn2" id="muRandAll">▶ Tout lire</span>'+
        '<span class="igbtn2" id="muRandNew">🔀 Retirer au hasard</span></div>'+songRows(d.songs,'sr');
      document.getElementById('muRandAll').addEventListener('click',()=>play(d.songs,0));
      document.getElementById('muRandNew').addEventListener('click',()=>renderMain());
      wireLists({songs:d.songs},'sr');return;
    }
  }
  function background(sdk){bgSdk=sdk;updBar();}
  function unmount(){root=null;}   // audio/cur conservés : lecture persistante
  return { render, background, unmount };
})();
