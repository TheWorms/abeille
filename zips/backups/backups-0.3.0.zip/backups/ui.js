/* Sauvegarde — fichiers vzdump Proxmox, groupés par VM/CT. Pleine page. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.backups = (function () {
  let S = null, root = null, tile = null, data = null;
  const ACCENT = "#e57000";  // orange Proxmox
  const CSS =
    "  .bkwrap{flex:1;display:flex;flex-direction:column;min-height:0;--bk:" + ACCENT + "}\n" +
    "  .bkscroll{flex:1;min-height:0;overflow:auto;padding:14px 22px}\n" +
    "  .bktotals{display:flex;gap:16px;flex-wrap:wrap;align-items:center;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px 18px;margin-bottom:16px}\n" +
    "  .bktk{text-align:center}\n" +
    "  .bktk b{display:block;font-size:21px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--bk)}\n" +
    "  .bktk span{font-size:11px;color:var(--dim)}\n" +
    "  .bkstores{margin-left:auto;font-size:11.5px;color:var(--dim)}\n" +
    "  .bkstores .chip{background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:2px 9px;margin-left:6px;font-family:var(--mono)}\n" +
    "  .bkgrp{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;margin-bottom:10px;overflow:hidden}\n" +
    "  .bkghead{display:flex;align-items:center;gap:11px;padding:12px 15px;cursor:pointer}\n" +
    "  .bkgic{width:34px;height:34px;border-radius:9px;background:rgba(229,112,0,.13);display:flex;align-items:center;justify-content:center;font-size:16px;flex:none}\n" +
    "  .bkgname{font-weight:700;font-size:14.5px}\n" +
    "  .bkgid{font-family:var(--mono);font-size:11.5px;color:var(--dim)}\n" +
    "  .bkgmeta{margin-left:auto;text-align:right;flex:none}\n" +
    "  .bkglast{font-size:12.5px;font-weight:600}\n" +
    "  .bkglast.old{color:var(--warn)}\n" +
    "  .bkgsub{font-size:11px;color:var(--dim);margin-top:2px}\n" +
    "  .bkgchev{margin-left:4px;color:var(--dim);transition:transform .15s;flex:none}\n" +
    "  .bkgrp.open .bkgchev{transform:rotate(90deg)}\n" +
    "  .bklist{border-top:1px solid var(--border-soft);padding:4px 15px 10px;display:none}\n" +
    "  .bkgrp.open .bklist{display:block}\n" +
    "  .bkrow{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border-soft);font-size:12.5px}\n" +
    "  .bkrow:last-child{border-bottom:0}\n" +
    "  .bkdate{font-variant-numeric:tabular-nums;flex:none;width:130px}\n" +
    "  .bkfile{font-family:var(--mono);font-size:11px;color:var(--dim);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .bksize{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .bklock{color:var(--bk);flex:none}\n" +
    "  .bkempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { if (document.getElementById('bkUiCss')) return; const s = document.createElement('style'); s.id = 'bkUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);

  function fmtDate(ts) {
    if (!ts) return '—';
    const d = new Date(ts * 1000);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit' }) +
      ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }
  function ageDays(ts) {
    if (!ts) return null;
    return Math.floor((Date.now() / 1000 - ts) / 86400);
  }
  function ageLabel(ts) {
    const a = ageDays(ts);
    if (a == null) return '';
    if (a <= 0) return "aujourd'hui";
    if (a === 1) return 'hier';
    return 'il y a ' + a + ' j';
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des sauvegardes…</div></div>';
    try { const r = await sdk.api('/backups'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">💾</div><div class="t1">Sauvegardes indisponibles</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL Proxmox et un token API dans ⚙ (format USER@REALM!ID=UUID).</div>' +
        '<button class="btnpill install" id="bkRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('bkRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="bkwrap"><div class="bkscroll">';
    // Totaux
    h += '<div class="bktotals">' +
      '<div class="bktk"><b>' + nf(d.total_count) + '</b><span>sauvegardes</span></div>' +
      '<div class="bktk"><b>' + nf(d.vm_count) + '</b><span>VM / CT</span></div>' +
      '<div class="bktk"><b>' + esc(d.total_size || '—') + '</b><span>espace total</span></div>' +
      (d.storages && d.storages.length ? '<div class="bkstores">Stockages' + d.storages.map(s => '<span class="chip">' + esc(s) + '</span>').join('') + '</div>' : '') +
      '</div>';

    if (!d.groups || !d.groups.length) {
      h += '<div class="bkempty">Aucune sauvegarde trouvée sur les stockages.</div>';
    } else {
      d.groups.forEach((g, gi) => {
        const last = g.last_ctime;
        const old = ageDays(last) != null && ageDays(last) > 7;  // >7j = orange
        const icon = g.type === 'CT' ? '📦' : (g.type === 'VM' ? '🖥️' : '❓');
        h += '<div class="bkgrp" data-gi="' + gi + '"><div class="bkghead">' +
          '<div class="bkgic">' + icon + '</div>' +
          '<div><div class="bkgname">' + esc(g.name || 'VMID ' + (g.vmid != null ? g.vmid : '?')) + '</div>' +
          '<div class="bkgid">' + (g.type ? esc(g.type) + ' · ' : '') + 'ID ' + (g.vmid != null ? g.vmid : '?') + '</div></div>' +
          '<div class="bkgmeta"><div class="bkglast' + (old ? ' old' : '') + '">' + ageLabel(last) + '</div>' +
          '<div class="bkgsub">' + nf(g.count) + ' sauv. · ' + esc(g.total_size || '—') + '</div></div>' +
          '<span class="bkgchev">›</span></div>';
        // liste détaillée
        h += '<div class="bklist">' + g.backups.map(b =>
          '<div class="bkrow"><span class="bkdate">' + fmtDate(b.ctime) + '</span>' +
          (b.protected ? '<span class="bklock" title="protégé">🔒</span>' : '') +
          '<span class="bkfile">' + esc(b.filename) + '</span>' +
          '<span class="bksize">' + esc(b.size_h || '—') + '</span></div>').join('') + '</div>';
        h += '</div>';
      });
    }
    h += '</div></div>';
    el.innerHTML = h;
    // pliage
    el.querySelectorAll('.bkghead').forEach(hd => hd.addEventListener('click', () => {
      hd.parentElement.classList.toggle('open');
    }));
  }

  return { render };
})();
