"""Addon « backups » — backend au contrat SDK du kiosk (lot D).

    register(sdk) -> flask.Blueprint   (routes montées sous /addons/backups/api)
    test(sdk, cfg) -> (bool, str)      (bouton « Tester » des réglages)

Le SDK remis par le noyau est étroit : config du module, cache court, logger,
requests partagé. Pas d'accès au config.json global ni aux autres addons.

Source : API Proxmox VE (token API). Pour chaque guest, on cherche le dernier
vzdump : d'abord dans le contenu des stockages « backup » (interrogés en
parallèle), avec repli sur les tâches vzdump si le stockage ne renvoie rien.
Cache 60 s.
"""
import re
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor


def _backups(sdk, cfg):
    """Sauvegardes vzdump : dernier backup par guest (API Proxmox, cache 60 s)."""
    url = (cfg.get("url") or "").rstrip("/")
    token = (cfg.get("token") or "").strip()
    if not (url and token):
        return {"ok": False, "reason": "Proxmox non configuré (⚙ Sauvegardes)"}
    if not url.startswith(("http://", "https://")):
        return {"ok": False, "reason": "URL invalide : commence par http:// ou https://"}
    ck = f"bk:{url}"
    c = sdk.cache_get(ck, 60)
    if c is not None:
        return c
    hdr = {"Authorization": f"PVEAPIToken={token}"}
    try:
        rn = sdk.requests.get(f"{url}/api2/json/nodes", headers=hdr, timeout=8, verify=False)
        if rn.status_code == 401:
            return {"ok": False, "reason": "token refusé (401)"}
        if rn.status_code != 200:
            return {"ok": False, "reason": f"HTTP {rn.status_code}"}
        rr = sdk.requests.get(f"{url}/api2/json/cluster/resources",
                              params={"type": "vm"}, headers=hdr, timeout=8, verify=False)

        def _vid(x):
            try:
                return int(x)
            except (TypeError, ValueError):
                return None

        names = {}
        for g in (rr.json().get("data", []) if rr.ok else []):
            v = _vid(g.get("vmid"))
            if v is not None:
                names[v] = {"name": g.get("name"),
                            "type": "CT" if g.get("type") == "lxc" else "VM"}
        vols = []
        diag = {"nodes": [], "storages": [], "errors": []}
        targets = []
        for n in rn.json().get("data", []):
            node = n.get("node")
            diag["nodes"].append(node)
            rs = sdk.requests.get(f"{url}/api2/json/nodes/{node}/storage",
                                  headers=hdr, timeout=8, verify=False)
            if not rs.ok:
                diag["errors"].append(f"{node}/storage HTTP {rs.status_code}")
                continue
            for st in rs.json().get("data", []):
                if "backup" not in (st.get("content") or ""):
                    continue
                if not st.get("active", 1) or not st.get("enabled", 1):
                    diag["errors"].append(f"{st.get('storage')} inactif")
                    continue
                targets.append((node, st.get("storage")))
                diag["storages"].append(st.get("storage"))

        def _fetch_storage(t):
            node, sid = t
            try:
                rc = sdk.requests.get(f"{url}/api2/json/nodes/{node}/storage/{sid}/content",
                                      params={"content": "backup"}, headers=hdr,
                                      timeout=10, verify=False)
                if not rc.ok:
                    return sid, [], f"{sid}/content HTTP {rc.status_code}"
                return sid, rc.json().get("data", []), None
            except sdk.requests.exceptions.RequestException as e:
                return sid, [], f"{sid} {type(e).__name__}"

        # les stockages sont interrogés en parallèle : 8 stockages à 3 s = 3 s, pas 24 s
        if targets:
            with ThreadPoolExecutor(max_workers=min(8, len(targets))) as pool:
                for sid, data, err in pool.map(_fetch_storage, targets):
                    if err:
                        diag["errors"].append(err)
                        continue
                    for v in data:
                        vid = _vid(v.get("vmid"))
                        volid = v.get("volid", "") or ""
                        if vid is None:
                            m = re.search(r"vzdump-(?:qemu|lxc)-(\d+)-", volid)
                            vid = int(m.group(1)) if m else None
                        ct = v.get("ctime")
                        if ct is None:
                            m = re.search(r"(\d{4})_(\d{2})_(\d{2})-(\d{2})_(\d{2})_(\d{2})", volid)
                            if m:
                                ct = int(datetime(*(int(x) for x in m.groups())).timestamp())
                        vols.append({"vmid": vid, "ctime": ct, "size": v.get("size"),
                                     "storage": sid, "volid": volid})
    except sdk.requests.exceptions.RequestException as e:
        return {"ok": False, "reason": type(e).__name__}
    except (ValueError, KeyError, TypeError):
        return {"ok": False, "reason": "réponse invalide"}

    if not vols:
        diag["errors"].append("stockage vide → repli sur les tâches vzdump")
        for node in diag["nodes"]:
            try:
                rt = sdk.requests.get(f"{url}/api2/json/nodes/{node}/tasks",
                                      params={"typefilter": "vzdump", "limit": 200,
                                              "source": "archive"},
                                      headers=hdr, timeout=12, verify=False)
                if not rt.ok:
                    diag["errors"].append(f"{node}/tasks HTTP {rt.status_code}")
                    continue
                for t in rt.json().get("data", []):
                    if t.get("status") != "OK":
                        continue
                    try:
                        vid = int(t.get("id"))
                    except (TypeError, ValueError):
                        m = re.search(r"(\d+)", str(t.get("id") or ""))
                        vid = int(m.group(1)) if m else None
                    if vid is None:
                        continue
                    vols.append({"vmid": vid,
                                 "ctime": t.get("endtime") or t.get("starttime"),
                                 "size": 0, "storage": "tâche vzdump", "volid": ""})
            except sdk.requests.exceptions.RequestException as e:
                diag["errors"].append(f"{node}/tasks {type(e).__name__}")

    latest = {}
    for v in vols:
        vid = v.get("vmid")
        if vid is None:
            continue
        cur = latest.get(vid)
        if not cur or (v.get("ctime") or 0) > (cur.get("ctime") or 0):
            latest[vid] = v
    now = time.time()
    items = []
    for vid, v in latest.items():
        age_h = (now - (v.get("ctime") or 0)) / 3600
        meta = names.get(vid, {})
        items.append({"vmid": vid, "name": meta.get("name") or f"guest {vid}",
                      "type": meta.get("type") or "?", "ctime": v.get("ctime"),
                      "age_h": round(age_h, 1),
                      "size_gb": round((v.get("size") or 0) / 1073741824, 2),
                      "storage": v.get("storage"), "stale": age_h > 192})
    items.sort(key=lambda x: x["ctime"] or 0, reverse=True)
    missing = [{"vmid": vid, "name": m.get("name") or f"guest {vid}",
                "type": m.get("type") or "?"}
               for vid, m in names.items() if vid not in latest]
    res = {"ok": True, "items": items, "missing": missing,
           "total_gb": round(sum(x["size_gb"] for x in items), 1),
           "count": len(vols), "diag": diag}
    return sdk.cache_set(ck, res)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("backups", __name__)

    @bp.route("/backups")
    def backups():
        try:
            return jsonify(_backups(sdk, sdk.config()))
        except Exception as e:  # jamais de 500 : le kiosk doit afficher l'erreur
            sdk.log.exception("backups")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    """Bouton « Tester » des réglages (reçoit les valeurs non sauvées)."""
    b = _backups(sdk, cfg)
    if b.get("ok"):
        dg = b.get("diag", {})
        extra = ""
        if not b["items"]:
            extra = (f" · stockages vus : {', '.join(dg.get('storages') or ['aucun'])}"
                     f" · erreurs : {'; '.join(dg.get('errors') or ['aucune'])}")
        return True, (f"vzdump ✓ — {len(b['items'])} guest(s) sauvegardé(s), "
                      f"{b['total_gb']} Go" +
                      (f", {len(b['missing'])} sans backup" if b["missing"] else "")
                      + extra)
    return False, f"Sauvegardes ✗ ({b.get('reason')})"
