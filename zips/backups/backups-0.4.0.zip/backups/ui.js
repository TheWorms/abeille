/* Sauvegarde — fichiers vzdump Proxmox, groupés par VM/CT. Pleine page. */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.backups = (function () {
  let S = null, root = null, tile = null, data = null, viewMode = 'list';
  const ACCENT = "#e57000";  // orange Proxmox
  const CSS =
    "  .bkwrap{flex:1;display:flex;flex-direction:column;min-height:0;--bk:" + ACCENT + "}\n" +
    "  .bkscroll{flex:1;min-height:0;overflow:auto;padding:12px 22px 16px}\n" +
    "  .bktotals{display:flex;gap:16px;flex-wrap:wrap;align-items:center;background:var(--tile);border:1px solid var(--border-soft);border-radius:12px;padding:13px 18px;margin-bottom:16px}\n" +
    "  .bktk{text-align:center}\n" +
    "  .bktk b{display:block;font-size:21px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--bk)}\n" +
    "  .bktk span{font-size:11px;color:var(--dim)}\n" +
    "  .bkstores{margin-left:auto;font-size:11.5px;color:var(--dim)}\n" +
    "  .bkstores .chip{background:var(--bg);border:1px solid var(--border-soft);border-radius:8px;padding:2px 9px;margin-left:6px;font-family:var(--mono)}\n" +
    "  .bkgrp{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;margin-bottom:10px;overflow:hidden}\n" +
    "  .bkghead{display:flex;align-items:center;gap:11px;padding:12px 15px;cursor:pointer}\n" +
    "  .bkgic{width:34px;height:34px;border-radius:9px;background:rgba(229,112,0,.13);display:flex;align-items:center;justify-content:center;font-size:16px;flex:none}\n" +
    "  .bkgname{font-weight:700;font-size:14.5px}\n" +
    "  .bkgid{font-family:var(--mono);font-size:11.5px;color:var(--dim)}\n" +
    "  .bkgmeta{margin-left:auto;text-align:right;flex:none}\n" +
    "  .bkglast{font-size:12.5px;font-weight:600}\n" +
    "  .bkglast.old{color:var(--warn)}\n" +
    "  .bkgsub{font-size:11px;color:var(--dim);margin-top:2px}\n" +
    "  .bkgchev{margin-left:4px;color:var(--dim);transition:transform .15s;flex:none}\n" +
    "  .bkgrp.open .bkgchev{transform:rotate(90deg)}\n" +
    "  .bklist{border-top:1px solid var(--border-soft);padding:4px 15px 10px;display:none}\n" +
    "  .bkgrp.open .bklist{display:block}\n" +
    "  .bkrow{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border-soft);font-size:12.5px}\n" +
    "  .bkrow:last-child{border-bottom:0}\n" +
    "  .bkdate{font-variant-numeric:tabular-nums;flex:none;width:130px}\n" +
    "  .bkfile{font-family:var(--mono);font-size:11px;color:var(--dim);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}\n" +
    "  .bksize{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n" +
    "  .bklock{color:var(--bk);flex:none}\n" +
    "  .bktopbar{display:flex;align-items:center;gap:14px;padding:14px 22px 0}\n" +
    "  .bktopbar .bktotals{margin-bottom:0;flex:1}\n" +
    "  .bkvtoggle{display:flex;gap:2px;background:var(--bg);border:1px solid var(--border-soft);border-radius:9px;padding:3px;flex:none}\n" +
    "  .bkvtoggle button{background:transparent;border:0;color:var(--dim);font-size:16px;width:38px;height:32px;border-radius:7px;cursor:pointer}\n" +
    "  .bkvtoggle button.on{background:var(--tile);color:var(--bk)}\n" +
    "  .bkcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}\n" +
    "  .bkcard{background:var(--tile);border:1px solid var(--border-soft);border-radius:13px;padding:14px;border-top:3px solid var(--bk)}\n" +
    "  .bkcard.old{border-top-color:var(--warn)}\n" +
    "  .bkctop{display:flex;align-items:center;gap:10px;margin-bottom:10px}\n" +
    "  .bkcic{width:38px;height:38px;border-radius:10px;background:rgba(45,212,191,.12);display:flex;align-items:center;justify-content:center;font-size:18px;flex:none}\n" +
    "  .bkcnm{min-width:0}\n" +
    "  .bkcnm .n{font-weight:700;font-size:14.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n" +
    "  .bkcnm .i{font-family:var(--mono);font-size:11px;color:var(--dim)}\n" +
    "  .bkclast{font-size:13px;font-weight:600;margin-bottom:10px}\n" +
    "  .bkclast.old{color:var(--warn)}\n" +
    "  .bkcfoot{display:flex;justify-content:space-between;font-size:11.5px;color:var(--dim);border-top:1px solid var(--border-soft);padding-top:9px;font-variant-numeric:tabular-nums}\n" +
    "  .bkempty{color:var(--dim);font-size:13px;padding:8px 0}";
  function ensureCss() { if (document.getElementById('bkUiCss')) return; const s = document.createElement('style'); s.id = 'bkUiCss'; s.textContent = CSS; document.head.appendChild(s); }
  const nf = x => x == null ? '—' : Number(x).toLocaleString('fr-FR');
  const esc = s => S ? S.esc(s) : String(s == null ? '' : s);

  function fmtDate(ts) {
    if (!ts) return '—';
    const d = new Date(ts * 1000);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit' }) +
      ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }
  function ageDays(ts) {
    if (!ts) return null;
    return Math.floor((Date.now() / 1000 - ts) / 86400);
  }
  function ageLabel(ts) {
    const a = ageDays(ts);
    if (a == null) return '';
    if (a <= 0) return "aujourd'hui";
    if (a === 1) return 'hier';
    return 'il y a ' + a + ' j';
  }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des sauvegardes…</div></div>';
    try { const st = await sdk.store.load(); if (st && (st.view === 'cards' || st.view === 'list')) viewMode = st.view; } catch (e) {}
    try { const r = await sdk.api('/backups'); data = await r.json(); }
    catch (e) { data = { ok: false, reason: 'serveur injoignable' }; }
    paint();
  }

  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    if (!d || !d.ok) {
      el.innerHTML = '<div class="stub"><div class="big">💾</div><div class="t1">Sauvegardes indisponibles</div><div class="t2">' +
        esc((d && d.reason) || '') + '<br>Renseigne l\'URL Proxmox et un token API dans ⚙ (format USER@REALM!ID=UUID).</div>' +
        '<button class="btnpill install" id="bkRetry" style="margin-top:14px">↻ Réessayer</button></div>';
      const rb = document.getElementById('bkRetry'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
      return;
    }
    let h = '<div class="bkwrap">';
    // Barre : totaux compacts + bascule liste/cards
    h += '<div class="bktopbar">' +
      '<div class="bktotals">' +
      '<div class="bktk"><b>' + nf(d.total_count) + '</b><span>sauvegardes</span></div>' +
      '<div class="bktk"><b>' + nf(d.vm_count) + '</b><span>VM / CT</span></div>' +
      '<div class="bktk"><b>' + esc(d.total_size || '—') + '</b><span>espace total</span></div>' +
      (d.storages && d.storages.length ? '<div class="bkstores">Stockages' + d.storages.map(s => '<span class="chip">' + esc(s) + '</span>').join('') + '</div>' : '') +
      '</div>' +
      '<div class="bkvtoggle">' +
      '<button data-v="list"' + (viewMode === 'list' ? ' class="on"' : '') + ' title="Liste">\u2630</button>' +
      '<button data-v="cards"' + (viewMode === 'cards' ? ' class="on"' : '') + ' title="Cartes">\u25A6</button>' +
      '</div></div>';

    h += '<div class="bkscroll">';
    if (!d.groups || !d.groups.length) {
      h += '<div class="bkempty">Aucune sauvegarde trouvée sur les stockages.</div>';
    } else if (viewMode === 'cards') {
      h += '<div class="bkcards">' + d.groups.map(g => {
        const last = g.last_ctime;
        const old = ageDays(last) != null && ageDays(last) > 7;
        const icon = g.type === 'CT' ? '📦' : (g.type === 'VM' ? '🖥️' : '❓');
        const lastB = g.backups && g.backups[0];
        return '<div class="bkcard' + (old ? ' old' : '') + '">' +
          '<div class="bkctop"><span class="bkcic">' + icon + '</span>' +
          '<div class="bkcnm"><div class="n">' + esc(g.name || 'VMID ' + (g.vmid != null ? g.vmid : '?')) + '</div>' +
          '<div class="i">' + (g.type ? esc(g.type) + ' · ' : '') + 'ID ' + (g.vmid != null ? g.vmid : '?') + '</div></div></div>' +
          '<div class="bkclast' + (old ? ' old' : '') + '">' + ageLabel(last) + (lastB ? ' · ' + fmtDate(lastB.ctime).split(' ')[0] : '') + '</div>' +
          '<div class="bkcfoot"><span>' + nf(g.count) + ' sauv.</span><span>' + esc(g.total_size || '—') + '</span></div>' +
          '</div>';
      }).join('') + '</div>';
    } else {
      d.groups.forEach((g, gi) => {
        const last = g.last_ctime;
        const old = ageDays(last) != null && ageDays(last) > 7;
        const icon = g.type === 'CT' ? '📦' : (g.type === 'VM' ? '🖥️' : '❓');
        h += '<div class="bkgrp" data-gi="' + gi + '"><div class="bkghead">' +
          '<div class="bkgic">' + icon + '</div>' +
          '<div><div class="bkgname">' + esc(g.name || 'VMID ' + (g.vmid != null ? g.vmid : '?')) + '</div>' +
          '<div class="bkgid">' + (g.type ? esc(g.type) + ' · ' : '') + 'ID ' + (g.vmid != null ? g.vmid : '?') + '</div></div>' +
          '<div class="bkgmeta"><div class="bkglast' + (old ? ' old' : '') + '">' + ageLabel(last) + '</div>' +
          '<div class="bkgsub">' + nf(g.count) + ' sauv. · ' + esc(g.total_size || '—') + '</div></div>' +
          '<span class="bkgchev">›</span></div>';
        h += '<div class="bklist">' + g.backups.map(b =>
          '<div class="bkrow"><span class="bkdate">' + fmtDate(b.ctime) + '</span>' +
          (b.protected ? '<span class="bklock" title="protégé">🔒</span>' : '') +
          '<span class="bkfile">' + esc(b.filename) + '</span>' +
          '<span class="bksize">' + esc(b.size_h || '—') + '</span></div>').join('') + '</div>';
        h += '</div>';
      });
    }
    h += '</div></div>';
    el.innerHTML = h;
    // bascule liste/cards
    el.querySelectorAll('.bkvtoggle button').forEach(b => b.addEventListener('click', async () => {
      const v = b.getAttribute('data-v');
      if (v === viewMode) return;
      viewMode = v;
      try { await S.store.save({ view: v }); } catch (e) {}
      paint();
    }));
    // pliage (mode liste)
    el.querySelectorAll('.bkghead').forEach(hd => hd.addEventListener('click', () => {
      hd.parentElement.classList.toggle('open');
    }));
  }

  return { render };
})();
