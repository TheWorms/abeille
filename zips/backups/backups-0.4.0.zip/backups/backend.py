"""Addon « backups » — fichiers de backup vzdump sur Proxmox VE.

    register(sdk) -> flask.Blueprint   (routes sous /addons/backups/api)
    test(sdk, cfg) -> (bool, str)

Config : url (https://host:8006) + token (USER@REALM!ID=UUID).
Parcourt chaque nœud, chaque stockage, et liste le contenu content=backup.
Regroupe les backups par VM/CT (vmid) pour une lecture « qui est sauvegardé,
quand, combien de fois ». Cache 60 s.
"""


def _fmt_bytes(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return None
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}".replace(".0 ", " ")
        n /= 1024
    return f"{n:.1f} Po"


def _parse_volid(volid):
    """« storage:backup/vzdump-lxc-100-2026_07_19-03_00_00.tar.zst »
    -> (storage, filename)."""
    if ":" in volid:
        storage, rest = volid.split(":", 1)
        return storage, rest.split("/")[-1]
    return "", volid.split("/")[-1]


def _pve(sdk, cfg):
    url = (cfg.get("url") or "").strip().rstrip("/")
    token = (cfg.get("token") or "").strip()
    if not (url and token):
        return {"ok": False, "reason": "URL/token non configurés"}
    if url and not (url.startswith("http://") or url.startswith("https://")):
        url = "https://" + url

    ck = f"bak:{url}"
    c = sdk.cache_get(ck, 60)
    if c is not None:
        return c

    hdr = {"Authorization": f"PVEAPIToken={token}"}

    def get(path, params=None):
        try:
            r = sdk.requests.get(f"{url}/api2/json{path}", headers=hdr,
                                 params=params, timeout=10, verify=False)
            if r.status_code == 401:
                return {"__401": True}
            return r.json().get("data") if r.ok else None
        except (sdk.requests.exceptions.RequestException, ValueError):
            return None

    nodes = get("/nodes")
    if isinstance(nodes, dict) and nodes.get("__401"):
        return {"ok": False, "reason": "token refusé (401) — format USER@REALM!ID=UUID"}
    if not nodes:
        return {"ok": False, "reason": "Proxmox injoignable"}

    backups = []
    storages_seen = set()
    for n in nodes:
        node = n.get("node")
        if not node or n.get("status") != "online":
            continue
        # stockages du nœud qui peuvent contenir des backups
        stores = get(f"/nodes/{node}/storage") or []
        for st in stores:
            sid = st.get("storage")
            content = st.get("content") or ""
            if not sid or "backup" not in content:
                continue
            key = (node, sid)
            if key in storages_seen:
                continue
            storages_seen.add(key)
            items = get(f"/nodes/{node}/storage/{sid}/content",
                        params={"content": "backup"}) or []
            for it in items:
                volid = it.get("volid") or ""
                storage, fname = _parse_volid(volid)
                backups.append({
                    "vmid": it.get("vmid"),
                    "node": node,
                    "storage": sid,
                    "filename": fname,
                    "ctime": it.get("ctime"),
                    "size": it.get("size"),
                    "size_h": _fmt_bytes(it.get("size")),
                    "format": it.get("format"),
                    "protected": bool(it.get("protected")),
                    "notes": it.get("notes"),
                })

    # noms des VM/CT (pour afficher « nom » à côté du vmid)
    names = {}
    res = get("/cluster/resources", params={"type": "vm"})
    if isinstance(res, list):
        for g in res:
            if g.get("vmid") is not None:
                names[g.get("vmid")] = {
                    "name": g.get("name"),
                    "type": "CT" if g.get("type") == "lxc" else "VM",
                }

    # regroupement par vmid
    groups = {}
    for b in backups:
        vid = b.get("vmid")
        g = groups.setdefault(vid, {"vmid": vid, "backups": [],
                                    "name": (names.get(vid) or {}).get("name"),
                                    "type": (names.get(vid) or {}).get("type")})
        g["backups"].append(b)
    for g in groups.values():
        g["backups"].sort(key=lambda x: x.get("ctime") or 0, reverse=True)
        g["count"] = len(g["backups"])
        g["total_size"] = _fmt_bytes(sum((x.get("size") or 0) for x in g["backups"]))
        g["last_ctime"] = g["backups"][0].get("ctime") if g["backups"] else None

    grouped = sorted(groups.values(),
                     key=lambda x: x.get("last_ctime") or 0, reverse=True)

    total_size = sum((b.get("size") or 0) for b in backups)
    out = {
        "ok": True,
        "groups": grouped,
        "total_count": len(backups),
        "total_size": _fmt_bytes(total_size),
        "vm_count": len(groups),
        "storages": sorted({b["storage"] for b in backups}),
    }
    return sdk.cache_set(ck, out)


def register(sdk):
    from flask import Blueprint, jsonify
    bp = Blueprint("backups", __name__)

    @bp.route("/backups")
    def backups():
        try:
            return jsonify(_pve(sdk, sdk.config()))
        except Exception as e:
            sdk.log.exception("backups")
            return jsonify({"ok": False, "reason": f"{type(e).__name__}: {e}"[:120]})

    return bp


def test(sdk, cfg):
    p = _pve(sdk, cfg)
    if p.get("ok"):
        return True, (f"Proxmox ✓ — {p.get('total_count', 0)} sauvegarde(s) "
                      f"pour {p.get('vm_count', 0)} VM/CT "
                      f"({p.get('total_size') or '0'})")
    return False, f"Proxmox ✗ ({p.get('reason')})"
