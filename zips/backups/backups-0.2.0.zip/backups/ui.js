/* Backups — sauvegardes vzdump via l'API Proxmox (Phase 3, lot A). */
window.PandaAddons = window.PandaAddons || {};
window.PandaAddons.backups = (function () {
  let S = null, root = null, tile = null, data = null;
  let filter = 'all', sort = 'age';
  const CSS = ".pvetype{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:var(--accent-tint);color:var(--accent)}\n.gybadges{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}\n.gybadge{font-size:11.5px;font-weight:600;padding:4px 10px;border-radius:8px;background:var(--tile);border:1px solid var(--border-soft)}\n.gybadge.warn{color:var(--warn)}\n.gybadge.bad{color:var(--bad)}\n.bkrow{display:flex;align-items:center;gap:10px;background:var(--tile);border:1px solid var(--border-soft);border-left:4px solid var(--accent);border-radius:10px;padding:8px 12px;margin-bottom:6px}\n.bkrow.stale{border-left-color:var(--warn)}\n.bkrow.none{border-left-color:var(--bad);opacity:.85}\n.bkage{margin-left:auto;font-size:11.5px;color:var(--dim);font-variant-numeric:tabular-nums;flex:none}\n.bkage.stale{color:var(--warn);font-weight:600}\n.bksz{font-size:11.5px;color:var(--faint);font-variant-numeric:tabular-nums;min-width:62px;text-align:right;flex:none}\n.bkgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:9px}\n.bkcard{background:var(--tile);border:1px solid var(--border-soft);border-top:3px solid var(--accent);border-radius:11px;padding:10px 11px}\n.bkcard.stale{border-top-color:var(--warn)}\n.bkcard.none{border-top-color:var(--bad)}\n.bkch{display:flex;align-items:center;gap:6px;margin-bottom:6px}\n.bkcn{font-weight:700;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.bkcid{margin-left:auto;font-family:var(--mono);font-size:10px;color:var(--faint)}\n.bkcage{font-size:15px;font-weight:700;font-variant-numeric:tabular-nums}\n.bkcage.stale{color:var(--warn)}\n.bkcage.none{color:var(--bad);font-size:13px}\n.bkcsub{font-size:10.5px;color:var(--dim);margin-top:2px}\n.bkcard.ct{border-top-color:var(--accent)}\n.bkcard.vm{border-top-color:#c98af0}\n.bkcard.stale{border-top-color:var(--warn)}\n.bkcard.none{border-top-color:var(--bad)}\n.pvetype.vm{background:rgba(201,138,240,.16);color:#c98af0}\n.bklegend{display:flex;gap:14px;font-size:10.5px;color:var(--faint);margin:2px 0 10px}\n.bklegend i{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:5px;vertical-align:middle}\n.bkcard{border:2px solid var(--accent)}\n.bkcard.vm{border-color:#c98af0}\n.bkcard.ct{border-color:var(--accent)}\n.bkcard.stale{border-color:var(--warn)}\n.bkcard.none{border-color:var(--bad)}\n.bktools{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:10px}\n.bktools .sep{width:1px;height:20px;background:var(--border-soft);margin:0 4px}\n.admwarn{background:rgba(240,180,41,.13);border:1px solid var(--warn);color:var(--warn);border-radius:9px;padding:8px 12px;font-size:12px;margin-bottom:12px}";
  function ensureCss() { if (document.getElementById('bkUiCss')) return; const s = document.createElement('style'); s.id = 'bkUiCss'; s.textContent = CSS; document.head.appendChild(s); }

  async function render(el, sdk, a) {
    S = sdk; root = el; tile = a || tile; ensureCss();
    el.innerHTML = '<div class="stub"><div class="t2">Lecture des sauvegardes…</div><div class="t2" style="font-size:11px;color:var(--faint);margin-top:6px">Proxmox peut mettre quelques secondes à répondre.</div></div>';
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 40000);
    try { const r = await sdk.api('/backups', { signal: ctl.signal }); data = await r.json(); }
    catch (e) { data = { ok: false, reason: (e.name === 'AbortError') ? 'Proxmox n\'a pas répondu en 40 s — vérifie l\'URL et le token' : 'serveur injoignable' }; }
    clearTimeout(to);
    paint();
  }
  function paint() {
    const el = root; if (!el || !document.body.contains(el)) return;
    const d = data;
    let h = '<div class="grafhead"><button class="wch" id="bkRefresh">\u21bb Rafraîchir</button></div>';
    if (!d || !d.ok) {
      h += '<div class="stub"><div class="big">💾</div><div class="t1">Sauvegardes vzdump</div><div class="t2">' + ((d && d.reason) || '') + '<br>Configure l\'URL + le token Proxmox dans \u2699 (même token que l\'addon Proxmox).</div></div>';
      el.innerHTML = h; const r0 = document.getElementById('bkRefresh'); if (r0) r0.addEventListener('click', () => render(el, S, tile)); return;
    }
    const age = hh => hh < 24 ? (Math.round(hh) + ' h') : (Math.floor(hh / 24) + ' j ' + Math.round(hh % 24) + ' h');
    const stale = d.items.filter(x => x.stale).length;
    h += '<div class="gybadges">' +
      '<span class="gybadge">💾 ' + d.items.length + ' guest(s)' + (d.total_gb ? (' · ' + d.total_gb + ' Go') : '') + '</span>' +
      (stale ? '<span class="gybadge warn">⚠️ ' + stale + ' périmé(s) (&gt; 8 j)</span>' : '') +
      (d.missing.length ? '<span class="gybadge bad">🚫 ' + d.missing.length + ' sans sauvegarde</span>' : '') + '</div>';
    if (!d.items.length && d.diag) {
      h += '<div class="admwarn">Aucune archive lue. Stockages scannés : <b>' + ((d.diag.storages || []).join(', ') || 'aucun') +
        '</b> · Erreurs : ' + ((d.diag.errors || []).join(' ; ') || 'aucune') +
        '<br>Vérifie que le token a le rôle <code>PVEAuditor</code> sur <code>/storage</code>.</div>';
    }
    const F = [['all', 'Tous'], ['ct', 'CT'], ['vm', 'VM'], ['stale', 'Périmés'], ['none', 'Sans sauvegarde']];
    const SR = [['age', 'Ancienneté'], ['name', 'Nom'], ['size', 'Taille'], ['id', 'ID']];
    h += '<div class="bktools">' + F.map(f => '<span class="wch' + (filter === f[0] ? ' on' : '') + '" data-bkf="' + f[0] + '">' + f[1] + '</span>').join('') +
      '<span class="sep"></span><span style="font-size:11px;color:var(--faint)">Tri :</span>' +
      SR.map(x => '<span class="wch' + (sort === x[0] ? ' on' : '') + '" data-bks="' + x[0] + '">' + x[1] + '</span>').join('') + '</div>';
    h += '<div class="bklegend"><span><i style="background:var(--accent)"></i>Conteneur (CT)</span>' +
      '<span><i style="background:#c98af0"></i>Machine virtuelle (VM)</span>' +
      '<span><i style="background:var(--warn)"></i>Périmé (&gt; 8 j)</span>' +
      '<span><i style="background:var(--bad)"></i>Aucune sauvegarde</span></div>';
    const card = (cls, type, vmid, name, big, bigcls, sub) => '<div class="bkcard ' + cls + '">' +
      '<div class="bkch"><span class="pvetype' + (type === 'VM' ? ' vm' : '') + '">' + type + '</span><span class="bkcn">' + name + '</span><span class="bkcid">' + vmid + '</span></div>' +
      '<div class="bkcage' + bigcls + '">' + big + '</div><div class="bkcsub">' + sub + '</div></div>';
    let items = d.items.slice();
    if (filter === 'ct') items = items.filter(x => x.type === 'CT');
    if (filter === 'vm') items = items.filter(x => x.type === 'VM');
    if (filter === 'stale') items = items.filter(x => x.stale);
    if (filter === 'none') items = [];
    const cmp = { age: (x, y) => y.age_h - x.age_h, name: (x, y) => x.name.localeCompare(y.name), size: (x, y) => y.size_gb - x.size_gb, id: (x, y) => x.vmid - y.vmid };
    items.sort(cmp[sort] || cmp.age);
    if (items.length)
      h += '<div class="bkgrid">' + items.map(x => card((x.stale ? 'stale' : (x.type === 'VM' ? 'vm' : 'ct')), x.type, x.vmid, x.name,
        age(x.age_h), x.stale ? ' stale' : '', (x.size_gb ? (x.size_gb + ' Go · ') : '') + x.storage)).join('') + '</div>';
    let miss = d.missing.slice();
    if (filter === 'ct') miss = miss.filter(x => x.type === 'CT');
    if (filter === 'vm') miss = miss.filter(x => x.type === 'VM');
    if (filter === 'stale') miss = [];
    if (miss.length && filter !== 'stale') {
      miss.sort((x, y) => sort === 'id' ? x.vmid - y.vmid : x.name.localeCompare(y.name));
      h += '<div class="wsec" style="padding-left:0">Sans sauvegarde</div><div class="bkgrid">' +
        miss.map(m => card('none', m.type, m.vmid, m.name, 'aucune', ' none', 'jamais sauvegardé')).join('') + '</div>';
    }
    h += '<div class="wsrc">Archives vzdump lues via l\'API Proxmox · dernier backup par machine · vue embarquée v0.2.0</div>';
    el.innerHTML = h;
    el.querySelectorAll('[data-bkf]').forEach(x => x.addEventListener('click', () => { filter = x.dataset.bkf; paint(); }));
    el.querySelectorAll('[data-bks]').forEach(x => x.addEventListener('click', () => { sort = x.dataset.bks; paint(); }));
    const rb = document.getElementById('bkRefresh'); if (rb) rb.addEventListener('click', () => render(el, S, tile));
  }
  return { render };
})();
